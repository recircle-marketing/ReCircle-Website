export type AdminRole = 'super_admin' | 'editor' | 'viewer';

export interface AdminUser {
  id: string;
  email: string;
  full_name: string;
  role: AdminRole;
}

const SESSION_KEY = 'recircle_admin_session';
const SESSION_TIMEOUT_MS = 8 * 60 * 60 * 1000;

export interface AdminSession {
  user: AdminUser;
  loginAt: number;
}

const ADMIN_CREDENTIALS = [
  { email: 'admin@recircle.in', password: 'Admin@ReCircle2024', full_name: 'ReCircle Admin', role: 'super_admin' as AdminRole },
];

export function getSession(): AdminSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session: AdminSession = JSON.parse(raw);
    if (Date.now() - session.loginAt > SESSION_TIMEOUT_MS) {
      clearSession();
      return null;
    }
    return session;
  } catch {
    return null;
  }
}

export function setSession(user: AdminUser): void {
  localStorage.setItem(SESSION_KEY, JSON.stringify({ user, loginAt: Date.now() }));
}

export function clearSession(): void {
  localStorage.removeItem(SESSION_KEY);
}

export function isAuthenticated(): boolean {
  return getSession() !== null;
}

export function getCurrentUser(): AdminUser | null {
  return getSession()?.user ?? null;
}

export function hasRole(required: AdminRole[]): boolean {
  const user = getCurrentUser();
  if (!user) return false;
  return required.includes(user.role);
}

export function canEdit(): boolean {
  return hasRole(['super_admin', 'editor']);
}

export function canPublish(): boolean {
  return hasRole(['super_admin']);
}

export function canManageUsers(): boolean {
  return hasRole(['super_admin']);
}

export function loginWithCredentials(
  email: string,
  password: string
): { user: AdminUser | null; error: string | null } {
  const match = ADMIN_CREDENTIALS.find(
    (c) => c.email === email.toLowerCase().trim() && c.password === password
  );

  if (!match) {
    return { user: null, error: 'Invalid email or password.' };
  }

  const user: AdminUser = {
    id: match.email,
    email: match.email,
    full_name: match.full_name,
    role: match.role,
  };

  setSession(user);
  return { user, error: null };
}

export function logout(): void {
  clearSession();
}
