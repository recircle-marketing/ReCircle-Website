import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import Navigation from './components/layout/Navigation';
import Footer from './components/layout/Footer';
import HeroSection from './components/sections/HeroSection';
import AboutSection from './components/sections/AboutSection';
import ImpactSection from './components/sections/ImpactSection';
import SolutionsSection from './components/sections/SolutionsSection';
import InvestorsSection from './components/sections/InvestorsSection';
import ClientsSection from './components/sections/ClientsSection';
import AccoladesSection from './components/sections/AccoladesSection';
import ContactPage from './components/pages/ContactPage';
import BlogListingPage from './components/pages/BlogListingPage';
import BlogPostPage from './components/pages/BlogPostPage';
import CareersPage from './components/pages/CareersPage';
import AnnualReportsPage from './components/pages/AnnualReportsPage';
import WebinarsPage from './components/pages/WebinarsPage';
import BrandKitRedirect from './components/pages/BrandKitRedirect';
import ImpactPage from './components/pages/ImpactPage';
import RPetFlakesPage from './components/pages/RPetFlakesPage';
import ClimaOneEprPage from './components/pages/ClimaOneEprPage';
import PnpPage from './components/pages/PnpPage';
import MrfPage from './components/pages/MrfPage';
import TrfPage from './components/pages/TrfPage';
import RecyclingPlantPage from './components/pages/RecyclingPlantPage';
import EsgProjectsPage from './components/pages/EsgProjectsPage';
import EprPage from './components/pages/EprPage';
import TextileWastePage from './components/pages/TextileWastePage';
import PlasticWastePage from './components/pages/PlasticWastePage';
import AboutPage from './components/pages/AboutPage';
import PitwPage from './components/pages/PitwPage';
import PctwPage from './components/pages/PctwPage';
import PrivacyPolicyPage from './components/pages/PrivacyPolicyPage';
import TermsOfUsePage from './components/pages/TermsOfUsePage';

const AdminRouter = lazy(() => import('./admin/AdminRouter'));

const LoadingSpinner = () => (
  <div style={{ minHeight: '100vh', backgroundColor: '#F7F1EE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <div style={{ width: 24, height: 24, border: '2px solid #C5D0ED', borderTopColor: '#01298A', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
  </div>
);

function WithNav({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-ivory font-sans">
      <Navigation />
      {children}
      <Footer />
    </div>
  );
}

function HomePage() {
  return (
    <WithNav>
      <main>
        <HeroSection />
        <AboutSection />
        <ImpactSection />
        <SolutionsSection />
        <InvestorsSection />
        <ClientsSection />
        <AccoladesSection />
      </main>
    </WithNav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Admin panel — completely isolated from public site, lazy loaded */}
        <Route path="/admin/*" element={
          <Suspense fallback={<LoadingSpinner />}>
            <AdminRouter />
          </Suspense>
        } />

        {/* Public pages */}
        <Route path="/" element={<HomePage />} />
        <Route path="/contact" element={<WithNav><ContactPage /></WithNav>} />
        <Route path="/blog" element={<WithNav><BlogListingPage /></WithNav>} />
        <Route path="/knowledge-centre" element={<WithNav><BlogListingPage /></WithNav>} />
        <Route path="/blog/:slug" element={<WithNav><BlogPostPage /></WithNav>} />
        <Route path="/careers" element={<WithNav><CareersPage /></WithNav>} />
        <Route path="/annual-reports" element={<WithNav><AnnualReportsPage /></WithNav>} />
        <Route path="/webinars" element={<WithNav><WebinarsPage /></WithNav>} />
        <Route path="/brand-kit" element={<BrandKitRedirect />} />
        <Route path="/impact" element={<WithNav><ImpactPage /></WithNav>} />
        <Route path="/rpet-flakes" element={<WithNav><RPetFlakesPage /></WithNav>} />
        <Route path="/climaone-epr" element={<WithNav><ClimaOneEprPage /></WithNav>} />
        <Route path="/pnp" element={<WithNav><PnpPage /></WithNav>} />
        <Route path="/infrastructure/mrf" element={<WithNav><MrfPage /></WithNav>} />
        <Route path="/infrastructure/trf" element={<WithNav><TrfPage /></WithNav>} />
        <Route path="/infrastructure/recycling-plant" element={<WithNav><RecyclingPlantPage /></WithNav>} />
        <Route path="/esg-projects" element={<WithNav><EsgProjectsPage /></WithNav>} />
        <Route path="/epr" element={<WithNav><EprPage /></WithNav>} />
        <Route path="/about" element={<WithNav><AboutPage /></WithNav>} />
        <Route path="/plastic-waste" element={<WithNav><PlasticWastePage /></WithNav>} />
        <Route path="/textile" element={<WithNav><TextileWastePage /></WithNav>} />
        <Route path="/textile/pitw" element={<WithNav><PitwPage /></WithNav>} />
        <Route path="/textile/pctw" element={<WithNav><PctwPage /></WithNav>} />
        <Route path="/privacy-policy" element={<WithNav><PrivacyPolicyPage /></WithNav>} />
        <Route path="/terms-of-use" element={<WithNav><TermsOfUsePage /></WithNav>} />

        {/* Fallback to homepage */}
        <Route path="*" element={<HomePage />} />
      </Routes>
    </BrowserRouter>
  );
}
