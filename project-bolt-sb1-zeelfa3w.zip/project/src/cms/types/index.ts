// ============================================================
// CMS TYPE DEFINITIONS
// All content types matching Supabase schema
// ============================================================

export interface HeroSlide {
  id: string;
  sort_order: number;
  is_active: boolean;
  tag: string;
  headline: string;
  subheading: string;
  cta_label: string;
  cta_href: string;
  cta_secondary_label: string;
  cta_secondary_href: string;
  image_url: string;
  image_alt: string;
  created_at: string;
  updated_at: string;
}

export interface CtaButton {
  label: string;
  href: string;
}

export interface Highlight {
  value: string;
  unit: string;
  label: string;
}

export interface AboutContent {
  id: string;
  section_label: string;
  heading: string;
  body_paragraphs: string[];
  closing_line: string;
  cta_buttons: CtaButton[];
  highlights: Highlight[];
  updated_at: string;
}

export interface ImpactStat {
  id: string;
  sort_order: number;
  is_active: boolean;
  number_value: string;
  suffix: string;
  unit: string;
  label: string;
  created_at: string;
  updated_at: string;
}

export interface SolutionsSectionMeta {
  id: string;
  heading: string;
  body_copy: string;
  updated_at: string;
}

export interface Solution {
  id: string;
  sort_order: number;
  is_active: boolean;
  heading: string;
  expanded_description: string;
  tag: string;
  side: 'left' | 'right';
  href: string;
  created_at: string;
  updated_at: string;
}

export interface InvestorsSectionMeta {
  id: string;
  heading: string;
  body_copy: string;
  updated_at: string;
}

export interface Investor {
  id: string;
  sort_order: number;
  is_active: boolean;
  name: string;
  logo_url: string;
  logo_alt: string;
  abbr: string;
  color: string;
  created_at: string;
  updated_at: string;
}

export interface ClientsSectionMeta {
  id: string;
  heading: string;
  body_copy: string;
  updated_at: string;
}

export interface Client {
  id: string;
  sort_order: number;
  is_active: boolean;
  name: string;
  logo_url: string;
  logo_alt: string;
  created_at: string;
  updated_at: string;
}

export interface AccoladesSectionMeta {
  id: string;
  heading: string;
  body_copy: string;
  updated_at: string;
}

export interface Accolade {
  id: string;
  sort_order: number;
  is_active: boolean;
  org: string;
  award: string;
  detail: string;
  year: string;
  color: string;
  image_url: string;
  image_alt: string;
  created_at: string;
  updated_at: string;
}

export interface SocialLink {
  platform: string;
  url: string;
}

export interface NavLink {
  label: string;
  href: string;
  children?: NavLink[];
}

export interface NavColumn {
  heading: string;
  links: NavLink[];
}

export interface FooterContent {
  id: string;
  tagline: string;
  grievance_officer_name: string;
  grievance_officer_phone: string;
  grievance_officer_email: string;
  newsletter_cta_text: string;
  social_links: SocialLink[];
  nav_columns: NavColumn[];
  legal_company_name: string;
  legal_cin: string;
  legal_copyright: string;
  updated_at: string;
}

export interface SocialLinkEntry {
  platform: string;
  url: string;
  is_active: boolean;
}

export interface SiteSettings {
  id: string;
  site_name: string;
  logo_url: string;
  favicon_url: string;
  default_seo_title: string;
  default_seo_description: string;
  default_og_image: string;
  primary_email: string;
  primary_phone: string;
  secondary_phone: string;
  primary_address: string;
  address_line_1: string;
  address_line_2: string;
  city: string;
  state: string;
  country: string;
  pincode: string;
  working_hours: string;
  social_links: SocialLinkEntry[];
  brand_kit_url: string;
  updated_at: string;
}

export interface SeoMetadata {
  id: string;
  page_slug: string;
  page_label: string;
  page_title: string;
  meta_description: string;
  keywords: string;
  og_title: string;
  og_description: string;
  og_image: string;
  canonical_url: string;
  updated_at: string;
}

// Future content types (schema ready)
export interface Blog {
  id: string;
  title: string;
  slug: string;
  author: string;
  publish_date: string | null;
  category: string;
  tags: string[];
  featured_image_url: string;
  featured_image_alt: string;
  body_content: string;
  status: 'draft' | 'review' | 'published';
  seo_title: string;
  seo_description: string;
  seo_og_image: string;
  created_at: string;
  updated_at: string;
}

export interface Webinar {
  id: string;
  title: string;
  event_date: string | null;
  description: string;
  speaker_name: string;
  speaker_photo_url: string;
  speaker_photo_alt: string;
  registration_link: string;
  watch_link: string;
  thumbnail_url: string;
  thumbnail_alt: string;
  webinar_status: 'upcoming' | 'past';
  created_at: string;
  updated_at: string;
}

export interface AnnualReport {
  id: string;
  title: string;
  report_year: number;
  description: string;
  cover_image_url: string;
  cover_image_alt: string;
  pdf_url: string;
  download_link: string;
  created_at: string;
  updated_at: string;
}

export interface Career {
  id: string;
  title: string;
  department: string;
  location: string;
  job_type: 'full-time' | 'part-time' | 'contract' | 'internship' | '';
  description: string;
  application_link: string;
  status: 'draft' | 'active';
  created_at: string;
  updated_at: string;
}

// New page settings types
export interface ContactPageSettings {
  id: string;
  email: string;
  phone: string;
  linkedin_url: string;
  facebook_url: string;
  instagram_url: string;
  form_heading: string;
  form_subheading: string;
  service_options: string[];
  map_embed_url: string;
  updated_at: string;
}

export interface ContactEnquiry {
  id: string;
  name: string;
  company_name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
  created_at: string;
}

export interface BlogPageSettings {
  id: string;
  hero_image_url: string;
  hero_heading: string;
  hero_subheading: string;
  updated_at: string;
}

export interface QuestionCard {
  label: string;
  question: string;
}

export interface CareersPageSettings {
  id: string;
  hero_heading: string;
  hero_body: string;
  hero_cta_label: string;
  hero_cta_url: string;
  culture_heading: string;
  culture_body: string;
  work_heading: string;
  work_body: string;
  work_cta_label: string;
  work_cta_url: string;
  question_cards: QuestionCard[];
  listings_heading: string;
  updated_at: string;
}

export interface AnnualReportsPageSettings {
  id: string;
  hero_heading: string;
  hero_body: string;
  hero_cta_text: string;
  reports_heading: string;
  updated_at: string;
}

export interface AnnualReportItem {
  id: string;
  sort_order: number;
  is_active: boolean;
  year_label: string;
  button_text: string;
  report_url: string;
  title: string;
  report_year: number;
  created_at: string;
  updated_at: string;
}

export interface WebinarsPageSettings {
  id: string;
  page_heading: string;
  page_intro: string;
  youtube_source_id: string;
  source_type: string;
  entry_mode: 'auto' | 'manual';
  updated_at: string;
}

export interface WebinarItem {
  id: string;
  title: string;
  youtube_url: string;
  thumbnail_url: string;
  thumbnail_alt: string;
  description: string;
  publish_date: string | null;
  is_active: boolean;
  webinar_status: 'upcoming' | 'past';
  created_at: string;
  updated_at: string;
}

export interface ImpactPageSettings {
  id: string;
  annual_feature_heading: string;
  annual_feature_subheading: string;
  annual_feature_body: string;
  annual_feature_cta_label: string;
  annual_feature_report_url: string;
  metrics_heading: string;
  metrics_subheading: string;
  report_block_heading: string;
  report_block_subheading: string;
  report_block_body: string;
  report_block_cta_text: string;
  gated_form_heading: string;
  gated_form_button_label: string;
  gated_report_url: string;
  previous_reports_heading: string;
  updated_at: string;
}

export interface ImpactMetric {
  id: string;
  sort_order: number;
  is_active: boolean;
  number_value: string;
  suffix: string;
  unit: string;
  label: string;
  created_at: string;
  updated_at: string;
}

export interface ImpactPreviousReport {
  id: string;
  sort_order: number;
  is_active: boolean;
  year_label: string;
  button_text: string;
  report_url: string;
  created_at: string;
  updated_at: string;
}

export interface ImpactReportLead {
  id: string;
  full_name: string;
  email: string;
  created_at: string;
}

// rPET Flakes page
export interface RpetPageSettings {
  id: string;
  // Hero
  hero_heading: string;
  hero_body: string;
  hero_cta_label: string;
  hero_cta_href: string;
  hero_image_url: string;
  // Applications
  applications_label: string;
  applications_intro: string;
  // Technical Specs
  tech_specs_label: string;
  tech_specs_heading: string;
  tech_specs_body: string;
  tech_specs_cta_label: string;
  tech_specs_cta_href: string;
  tech_specs_image_url: string;
  // Advantages
  advantages_label: string;
  advantages_heading: string;
  advantages_body: string;
  // Benchmarks
  benchmarks_label: string;
  benchmarks_heading: string;
  benchmarks_intro: string;
  benchmarks_cta_label: string;
  benchmarks_cta_href: string;
  // ClimaOne
  climaone_label: string;
  climaone_heading: string;
  climaone_body_1: string;
  climaone_body_2: string;
  climaone_cta_label: string;
  climaone_cta_href: string;
  climaone_image_url: string;
  // Certifications
  certifications_label: string;
  certifications_heading: string;
  certifications_body: string;
  certifications_image_url: string;
  // Contact Band
  contact_band_label: string;
  contact_band_heading: string;
  contact_band_body: string;
  contact_band_email: string;
  contact_band_phone: string;
  updated_at: string;
}

export interface RpetApplication {
  id: string;
  sort_order: number;
  is_active: boolean;
  title: string;
  spec_callout: string;
  image_url: string;
  image_alt: string;
  created_at: string;
  updated_at: string;
}

export interface RpetAdvantageCard {
  id: string;
  sort_order: number;
  is_active: boolean;
  icon_name: string;
  heading: string;
  body: string;
  created_at: string;
  updated_at: string;
}

export interface RpetBenchmarkCard {
  id: string;
  sort_order: number;
  is_active: boolean;
  icon_name: string;
  heading: string;
  body: string;
  created_at: string;
  updated_at: string;
}

export interface ContentAuditEntry {
  id: string;
  content_type: string;
  content_id: string | null;
  action: 'created' | 'updated' | 'deleted' | 'published';
  performed_by: string | null;
  performed_by_name: string | null;
  performed_at: string;
}

// ── NEW PAGE CMS TYPES ────────────────────────────────────────────────────────

export interface AboutPageSettings {
  id: string;
  hero_stat: string;
  hero_stat_label: string;
  hero_stat_note: string;
  hero_paragraph_1: string;
  hero_paragraph_2: string;
  vision_quote: string;
  commitments: { num: string; text: string }[];
  roots_heading: string;
  roots_body: string;
  roots_closing: string;
  mind_heading: string;
  mind_body: string;
  growth_heading: string;
  growth_body: string;
  growth_closing: string;
  growth_stat: string;
  growth_stat_unit: string;
  growth_stat_descriptor: string;
  reach_heading: string;
  reach_body: string;
  reach_stats: { value: string; label: string }[];
  reach_footnote: string;
  team_section_heading: string;
  team_section_intro_1: string;
  team_section_intro_2: string;
  updated_at: string;
}

export interface MrfPageSettings {
  id: string;
  hero_label: string;
  hero_heading: string;
  hero_body: string;
  stat_1_value: string;
  stat_1_label: string;
  stat_2_value: string;
  stat_2_label: string;
  overview_heading: string;
  overview_body: string;
  process_heading: string;
  process_steps: { step: string; title: string; body: string }[];
  capabilities: { title: string }[];
  updated_at: string;
}

export interface TrfPageSettings {
  id: string;
  hero_label: string;
  hero_heading: string;
  hero_body: string;
  stat_1_value: string;
  stat_1_label: string;
  stat_2_value: string;
  stat_2_label: string;
  overview_heading: string;
  overview_body: string;
  categories_heading: string;
  categories: { label: string; color: string; bg: string; desc: string }[];
  updated_at: string;
}

export interface RecyclingPlantPageSettings {
  id: string;
  hero_label: string;
  hero_heading: string;
  hero_body: string;
  stat_1_value: string;
  stat_1_label: string;
  stat_2_value: string;
  stat_2_label: string;
  overview_heading: string;
  overview_body: string;
  process_heading: string;
  process_steps: { step: string; title: string; body: string }[];
  certifications: { name: string }[];
  updated_at: string;
}

export interface PlasticWastePageSettings {
  id: string;
  hero_heading: string;
  hero_stat: string;
  hero_stat_label: string;
  hero_stat_descriptor: string;
  hero_para_1: string;
  hero_para_2: string;
  hero_cta_label: string;
  compliance_heading: string;
  compliance_body: string;
  compliance_closing: string;
  consequences: { text: string }[];
  why_heading: string;
  why_advantages: { num: string; title: string; body: string }[];
  infra_body: string;
  updated_at: string;
}

export interface EprPageSettings {
  id: string;
  hero_heading: string;
  hero_body: string;
  stat_1_value: string;
  stat_1_label: string;
  stat_2_value: string;
  stat_2_label: string;
  process_heading: string;
  process_steps: { step: string; title: string; body: string }[];
  benefits_heading: string;
  benefits: { title: string; body: string }[];
  updated_at: string;
}

export interface PnpPageSettings {
  id: string;
  hero_heading: string;
  hero_body: string;
  hero_tag: string;
  programme_heading: string;
  programme_body: string;
  steps_heading: string;
  steps: { step: string; title: string; body: string }[];
  benefits_heading: string;
  benefits: { title: string; body: string }[];
  updated_at: string;
}

export interface TextileWastePageSettings {
  id: string;
  hero_stat: string;
  hero_fact_1: string;
  hero_fact_2: string;
  hero_closing: string;
  problem_body: string;
  problem_closing: string;
  model_intro: string;
  model_pillars: { num: string; title: string; body: string }[];
  trf_stat_1_value: string;
  trf_stat_1_label: string;
  trf_stat_2_value: string;
  trf_stat_2_label: string;
  trf_body: string;
  partner_categories: { title: string; subtypes: string; desc: string }[];
  community_heading: string;
  community_body_1: string;
  community_body_2: string;
  supporters: { name: string }[];
  updated_at: string;
}

export interface PitwPageSettings {
  id: string;
  hero_heading: string;
  stat_1_value: string;
  stat_1_label: string;
  stat_2_value: string;
  stat_2_label: string;
  process_heading: string;
  process_intro: string;
  scope_note: string;
  comparison_current: { text: string }[];
  comparison_recircle: { text: string }[];
  outputs: { name: string; application: string }[];
  grs_note: string;
  work_models: { num: string; title: string; body: string }[];
  updated_at: string;
}

export interface PctwPageSettings {
  id: string;
  hero_heading: string;
  hero_subheading: string;
  channels: { title: string; icon: string; desc: string }[];
  stats: { value: string; label: string }[];
  institutions: { name: string }[];
  community_heading: string;
  community_body_1: string;
  community_body_2: string;
  updated_at: string;
}

export interface EsgPageSettings {
  id: string;
  hero_heading: string;
  hero_body: string;
  intro_heading: string;
  intro_body: string;
  projects: { title: string; category: string; body: string }[];
  reporting_heading: string;
  reporting_body: string;
  updated_at: string;
}

// Fallback data for when CMS is unavailable
export const FALLBACK_HERO_SLIDES: HeroSlide[] = [
  {
    id: '1', sort_order: 1, is_active: true,
    tag: 'Circular Economy Infrastructure',
    headline: 'Building India\'s Resource Recovery Systems',
    subheading: 'From waste collection to verified recycled materials — ReCircle operates end-to-end circular infrastructure at scale.',
    cta_label: 'Explore Our Solutions', cta_href: '/about',
    cta_secondary_label: 'Our Impact', cta_secondary_href: '/impact',
    image_url: 'https://recircle.in/wp-content/uploads/2025/12/Web-Banner-Impact-Report-1920-x-1080-px-1.png',
    image_alt: 'ReCircle resource recovery systems',
    created_at: '', updated_at: '',
  },
  {
    id: '2', sort_order: 2, is_active: true,
    tag: 'EPR Compliance & Traceability',
    headline: 'Closing the Loop on Plastic Packaging',
    subheading: 'Food-grade rPET flakes enabling circular packaging supply chains for India\'s leading brands.',
    cta_label: 'rPET Flakes', cta_href: '/rpet-flakes',
    cta_secondary_label: 'ClimaOne Platform', cta_secondary_href: '/climaone-epr',
    image_url: 'https://recircle.in/wp-content/uploads/2025/12/Web-Banner-Impact-Report-1920-x-1080-px-1.png',
    image_alt: 'Closing the loop on plastic packaging',
    created_at: '', updated_at: '',
  },
  {
    id: '3', sort_order: 3, is_active: true,
    tag: 'Traceability & Compliance',
    headline: 'Traceable, Compliant, Circular Operations',
    subheading: 'End-to-end EPR compliance backed by ClimaOne — our in-house traceability platform providing full supply chain visibility.',
    cta_label: 'EPR Solutions', cta_href: '/epr',
    cta_secondary_label: 'ClimaOne for EPR', cta_secondary_href: '/climaone-epr',
    image_url: 'https://recircle.in/wp-content/uploads/2025/12/Web-Banner-Impact-Report-1920-x-1080-px-1.png',
    image_alt: 'Traceable compliant circular operations',
    created_at: '', updated_at: '',
  },
  {
    id: '4', sort_order: 4, is_active: true,
    tag: 'Social Impact at Scale',
    headline: '3,608 Safai Saathis Powering Circularity',
    subheading: 'A pan-India waste recovery network recovering 14,970 kgs of waste every hour while creating dignified livelihoods.',
    cta_label: 'Our Impact', cta_href: '/impact',
    cta_secondary_label: 'Our Story', cta_secondary_href: '/about',
    image_url: 'https://recircle.in/wp-content/uploads/2025/12/Web-Banner-Impact-Report-1920-x-1080-px-1.png',
    image_alt: 'Safai Saathis powering circularity',
    created_at: '', updated_at: '',
  },
];
