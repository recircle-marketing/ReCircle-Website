import { supabase } from '../../lib/supabase';
import type {
  HeroSlide, AboutContent, ImpactStat, SolutionsSectionMeta, Solution,
  InvestorsSectionMeta, Investor, ClientsSectionMeta, Client,
  AccoladesSectionMeta, Accolade, FooterContent, SiteSettings, SeoMetadata,
  Blog, Webinar, AnnualReport, Career, ContentAuditEntry,
  ContactPageSettings, ContactEnquiry,
  BlogPageSettings,
  CareersPageSettings,
  AnnualReportsPageSettings, AnnualReportItem,
  WebinarsPageSettings, WebinarItem,
  ImpactPageSettings, ImpactMetric, ImpactPreviousReport, ImpactReportLead,
  SocialLinkEntry,
  RpetPageSettings, RpetApplication, RpetAdvantageCard, RpetBenchmarkCard,
  AboutPageSettings, MrfPageSettings, TrfPageSettings, RecyclingPlantPageSettings,
  PlasticWastePageSettings, EprPageSettings, PnpPageSettings,
  TextileWastePageSettings, PitwPageSettings, PctwPageSettings, EsgPageSettings,
} from '../types';
import { FALLBACK_HERO_SLIDES } from '../types';

// ── HERO ──────────────────────────────────────────────────────────────────
export async function getHeroSlides(): Promise<HeroSlide[]> {
  const { data, error } = await supabase
    .from('cms_hero_slides')
    .select('*')
    .eq('is_active', true)
    .order('sort_order');
  if (error || !data?.length) return FALLBACK_HERO_SLIDES;
  return data;
}

export async function upsertHeroSlide(slide: Partial<HeroSlide> & { id?: string }) {
  const { id, ...rest } = slide;
  if (id) {
    return supabase.from('cms_hero_slides').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  }
  return supabase.from('cms_hero_slides').insert(rest);
}

export async function deleteHeroSlide(id: string) {
  return supabase.from('cms_hero_slides').delete().eq('id', id);
}

// ── ABOUT ─────────────────────────────────────────────────────────────────
export async function getAboutContent(): Promise<AboutContent | null> {
  const { data } = await supabase.from('cms_about').select('*').maybeSingle();
  return data;
}

export async function upsertAboutContent(content: Partial<AboutContent> & { id?: string }) {
  const { id, ...rest } = content;
  if (id) {
    return supabase.from('cms_about').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  }
  return supabase.from('cms_about').insert(rest);
}

// ── IMPACT STATS ──────────────────────────────────────────────────────────
export async function getImpactStats(): Promise<ImpactStat[]> {
  const { data } = await supabase
    .from('cms_impact_stats')
    .select('*')
    .eq('is_active', true)
    .order('sort_order');
  return data ?? [];
}

export async function upsertImpactStat(stat: Partial<ImpactStat> & { id?: string }) {
  const { id, ...rest } = stat;
  if (id) return supabase.from('cms_impact_stats').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_impact_stats').insert(rest);
}

export async function deleteImpactStat(id: string) {
  return supabase.from('cms_impact_stats').delete().eq('id', id);
}

// ── SOLUTIONS ─────────────────────────────────────────────────────────────
export async function getSolutionsMeta(): Promise<SolutionsSectionMeta | null> {
  const { data } = await supabase.from('cms_solutions_section').select('*').maybeSingle();
  return data;
}

export async function getSolutions(): Promise<Solution[]> {
  const { data } = await supabase
    .from('cms_solutions')
    .select('*')
    .eq('is_active', true)
    .order('sort_order');
  return data ?? [];
}

export async function upsertSolution(sol: Partial<Solution> & { id?: string }) {
  const { id, ...rest } = sol;
  if (id) return supabase.from('cms_solutions').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_solutions').insert(rest);
}

export async function deleteSolution(id: string) {
  return supabase.from('cms_solutions').delete().eq('id', id);
}

export async function upsertSolutionsMeta(meta: Partial<SolutionsSectionMeta> & { id?: string }) {
  const { id, ...rest } = meta;
  if (id) return supabase.from('cms_solutions_section').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_solutions_section').insert(rest);
}

// ── INVESTORS ─────────────────────────────────────────────────────────────
export async function getInvestorsMeta(): Promise<InvestorsSectionMeta | null> {
  const { data } = await supabase.from('cms_investors_section').select('*').maybeSingle();
  return data;
}

export async function getInvestors(): Promise<Investor[]> {
  const { data } = await supabase
    .from('cms_investors')
    .select('*')
    .eq('is_active', true)
    .order('sort_order');
  return data ?? [];
}

export async function upsertInvestor(inv: Partial<Investor> & { id?: string }) {
  const { id, ...rest } = inv;
  if (id) return supabase.from('cms_investors').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_investors').insert(rest);
}

export async function deleteInvestor(id: string) {
  return supabase.from('cms_investors').delete().eq('id', id);
}

// ── CLIENTS ───────────────────────────────────────────────────────────────
export async function getClientsMeta(): Promise<ClientsSectionMeta | null> {
  const { data } = await supabase.from('cms_clients_section').select('*').maybeSingle();
  return data;
}

export async function getClients(): Promise<Client[]> {
  const { data } = await supabase
    .from('cms_clients')
    .select('*')
    .eq('is_active', true)
    .order('sort_order');
  return data ?? [];
}

export async function upsertClient(client: Partial<Client> & { id?: string }) {
  const { id, ...rest } = client;
  if (id) return supabase.from('cms_clients').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_clients').insert(rest);
}

export async function deleteClient(id: string) {
  return supabase.from('cms_clients').delete().eq('id', id);
}

// ── ACCOLADES ─────────────────────────────────────────────────────────────
export async function getAccoladesMeta(): Promise<AccoladesSectionMeta | null> {
  const { data } = await supabase.from('cms_accolades_section').select('*').maybeSingle();
  return data;
}

export async function getAccolades(): Promise<Accolade[]> {
  const { data } = await supabase
    .from('cms_accolades')
    .select('*')
    .eq('is_active', true)
    .order('sort_order');
  return data ?? [];
}

export async function upsertAccolade(acc: Partial<Accolade> & { id?: string }) {
  const { id, ...rest } = acc;
  if (id) return supabase.from('cms_accolades').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_accolades').insert(rest);
}

export async function deleteAccolade(id: string) {
  return supabase.from('cms_accolades').delete().eq('id', id);
}

// ── FOOTER ────────────────────────────────────────────────────────────────
export async function getFooterContent(): Promise<FooterContent | null> {
  const { data } = await supabase.from('cms_footer').select('*').maybeSingle();
  return data;
}

export async function upsertFooterContent(content: Partial<FooterContent> & { id?: string }) {
  const { id, ...rest } = content;
  if (id) return supabase.from('cms_footer').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_footer').insert(rest);
}

// ── SITE SETTINGS ─────────────────────────────────────────────────────────
export async function getSiteSettings(): Promise<SiteSettings | null> {
  const { data } = await supabase.from('cms_site_settings').select('*').maybeSingle();
  return data;
}

export async function upsertSiteSettings(settings: Partial<SiteSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_site_settings').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_site_settings').insert(rest);
}

// ── SEO METADATA ──────────────────────────────────────────────────────────
export async function getSeoMetadata(slug: string): Promise<SeoMetadata | null> {
  const { data } = await supabase.from('cms_seo_metadata').select('*').eq('page_slug', slug).maybeSingle();
  return data;
}

export async function getAllSeoMetadata(): Promise<SeoMetadata[]> {
  const { data } = await supabase.from('cms_seo_metadata').select('*').order('page_slug');
  return data ?? [];
}

export async function upsertSeoMetadata(meta: Partial<SeoMetadata>) {
  return supabase.from('cms_seo_metadata').upsert(
    { ...meta, updated_at: new Date().toISOString() },
    { onConflict: 'page_slug' }
  );
}

// ── SOCIAL LINKS (via site settings) ─────────────────────────────────────
export async function getSocialLinks(): Promise<SocialLinkEntry[]> {
  const { data } = await supabase.from('cms_site_settings').select('social_links').maybeSingle();
  return (data?.social_links as SocialLinkEntry[]) ?? [];
}

export async function upsertSocialLinks(links: SocialLinkEntry[], settingsId: string) {
  return supabase.from('cms_site_settings').update({ social_links: links, updated_at: new Date().toISOString() }).eq('id', settingsId);
}

// ── BRAND KIT URL (via site settings) ────────────────────────────────────
export async function getBrandKitUrl(): Promise<string> {
  const { data } = await supabase.from('cms_site_settings').select('brand_kit_url').maybeSingle();
  return (data?.brand_kit_url as string) ?? '';
}

// ── BLOGS ─────────────────────────────────────────────────────────────────
export async function getBlogs(includeAll = false): Promise<Blog[]> {
  let query = supabase.from('cms_blogs').select('*').order('publish_date', { ascending: false });
  if (!includeAll) query = query.eq('status', 'published');
  const { data } = await query;
  return data ?? [];
}

export async function getBlogBySlug(slug: string): Promise<Blog | null> {
  const { data } = await supabase.from('cms_blogs').select('*').eq('slug', slug).maybeSingle();
  return data;
}

export async function upsertBlog(blog: Partial<Blog> & { id?: string }) {
  const { id, ...rest } = blog;
  if (id) return supabase.from('cms_blogs').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_blogs').insert(rest);
}

export async function deleteBlog(id: string) {
  return supabase.from('cms_blogs').delete().eq('id', id);
}

// ── WEBINARS ──────────────────────────────────────────────────────────────
export async function getWebinars(): Promise<Webinar[]> {
  const { data } = await supabase.from('cms_webinars').select('*').order('event_date', { ascending: false });
  return data ?? [];
}

export async function upsertWebinar(webinar: Partial<Webinar> & { id?: string }) {
  const { id, ...rest } = webinar;
  if (id) return supabase.from('cms_webinars').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_webinars').insert(rest);
}

export async function deleteWebinar(id: string) {
  return supabase.from('cms_webinars').delete().eq('id', id);
}

// ── ANNUAL REPORTS ────────────────────────────────────────────────────────
export async function getAnnualReports(): Promise<AnnualReport[]> {
  const { data } = await supabase.from('cms_annual_reports').select('*').order('report_year', { ascending: false });
  return data ?? [];
}

export async function upsertAnnualReport(report: Partial<AnnualReport> & { id?: string }) {
  const { id, ...rest } = report;
  if (id) return supabase.from('cms_annual_reports').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_annual_reports').insert(rest);
}

export async function deleteAnnualReport(id: string) {
  return supabase.from('cms_annual_reports').delete().eq('id', id);
}

// ── CAREERS ───────────────────────────────────────────────────────────────
export async function getCareers(includeAll = false): Promise<Career[]> {
  let query = supabase.from('cms_careers').select('*').order('created_at', { ascending: false });
  if (!includeAll) query = query.eq('status', 'active');
  const { data } = await query;
  return data ?? [];
}

export async function upsertCareer(career: Partial<Career> & { id?: string }) {
  const { id, ...rest } = career;
  if (id) return supabase.from('cms_careers').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_careers').insert(rest);
}

export async function deleteCareer(id: string) {
  return supabase.from('cms_careers').delete().eq('id', id);
}

// ── CONTACT PAGE ──────────────────────────────────────────────────────────
export async function getContactPageSettings(): Promise<ContactPageSettings | null> {
  const { data } = await supabase.from('contact_page_settings').select('*').maybeSingle();
  return data;
}

export async function upsertContactPageSettings(settings: Partial<ContactPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('contact_page_settings').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('contact_page_settings').insert(rest);
}

export async function submitContactEnquiry(enquiry: Omit<ContactEnquiry, 'id' | 'created_at'>) {
  return supabase.from('contact_enquiries').insert(enquiry);
}

export async function getContactEnquiries(): Promise<ContactEnquiry[]> {
  const { data } = await supabase.from('contact_enquiries').select('*').order('created_at', { ascending: false });
  return data ?? [];
}

// ── BLOG PAGE SETTINGS ────────────────────────────────────────────────────
export async function getBlogPageSettings(): Promise<BlogPageSettings | null> {
  const { data } = await supabase.from('blog_page_settings').select('*').maybeSingle();
  return data;
}

export async function upsertBlogPageSettings(settings: Partial<BlogPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('blog_page_settings').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('blog_page_settings').insert(rest);
}

// ── CAREERS PAGE SETTINGS ─────────────────────────────────────────────────
export async function getCareersPageSettings(): Promise<CareersPageSettings | null> {
  const { data } = await supabase.from('careers_page_settings').select('*').maybeSingle();
  return data;
}

export async function upsertCareersPageSettings(settings: Partial<CareersPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('careers_page_settings').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('careers_page_settings').insert(rest);
}

// ── ANNUAL REPORTS PAGE ───────────────────────────────────────────────────
export async function getAnnualReportsPageSettings(): Promise<AnnualReportsPageSettings | null> {
  const { data } = await supabase.from('annual_reports_page_settings').select('*').maybeSingle();
  return data;
}

export async function upsertAnnualReportsPageSettings(settings: Partial<AnnualReportsPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('annual_reports_page_settings').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('annual_reports_page_settings').insert(rest);
}

export async function getAnnualReportItems(): Promise<AnnualReportItem[]> {
  const { data } = await supabase.from('cms_annual_reports').select('*').order('sort_order');
  return data ?? [];
}

export async function upsertAnnualReportItem(item: Partial<AnnualReportItem> & { id?: string }) {
  const { id, ...rest } = item;
  if (id) return supabase.from('cms_annual_reports').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_annual_reports').insert(rest);
}

export async function deleteAnnualReportItem(id: string) {
  return supabase.from('cms_annual_reports').delete().eq('id', id);
}

// ── WEBINARS PAGE SETTINGS ────────────────────────────────────────────────
export async function getWebinarsPageSettings(): Promise<WebinarsPageSettings | null> {
  const { data } = await supabase.from('webinars_page_settings').select('*').maybeSingle();
  return data;
}

export async function upsertWebinarsPageSettings(settings: Partial<WebinarsPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('webinars_page_settings').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('webinars_page_settings').insert(rest);
}

export async function getWebinarItems(includeAll = false): Promise<WebinarItem[]> {
  let query = supabase.from('cms_webinars').select('*').order('publish_date', { ascending: false });
  if (!includeAll) query = query.eq('is_active', true);
  const { data } = await query;
  return data ?? [];
}

export async function upsertWebinarItem(item: Partial<WebinarItem> & { id?: string }) {
  const { id, ...rest } = item;
  if (id) return supabase.from('cms_webinars').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_webinars').insert(rest);
}

export async function deleteWebinarItem(id: string) {
  return supabase.from('cms_webinars').delete().eq('id', id);
}

// ── IMPACT PAGE ───────────────────────────────────────────────────────────
export async function getImpactPageSettings(): Promise<ImpactPageSettings | null> {
  const { data } = await supabase.from('impact_page_settings').select('*').maybeSingle();
  return data;
}

export async function upsertImpactPageSettings(settings: Partial<ImpactPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('impact_page_settings').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('impact_page_settings').insert(rest);
}

export async function getImpactMetrics(): Promise<ImpactMetric[]> {
  const { data } = await supabase.from('impact_metrics').select('*').eq('is_active', true).order('sort_order');
  return data ?? [];
}

export async function upsertImpactMetric(metric: Partial<ImpactMetric> & { id?: string }) {
  const { id, ...rest } = metric;
  if (id) return supabase.from('impact_metrics').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('impact_metrics').insert(rest);
}

export async function deleteImpactMetric(id: string) {
  return supabase.from('impact_metrics').delete().eq('id', id);
}

export async function getImpactPreviousReports(): Promise<ImpactPreviousReport[]> {
  const { data } = await supabase.from('impact_previous_reports').select('*').eq('is_active', true).order('sort_order');
  return data ?? [];
}

export async function upsertImpactPreviousReport(report: Partial<ImpactPreviousReport> & { id?: string }) {
  const { id, ...rest } = report;
  if (id) return supabase.from('impact_previous_reports').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('impact_previous_reports').insert(rest);
}

export async function deleteImpactPreviousReport(id: string) {
  return supabase.from('impact_previous_reports').delete().eq('id', id);
}

export async function submitImpactReportLead(lead: { full_name: string; email: string }) {
  return supabase.from('impact_report_leads').insert(lead);
}

export async function getImpactReportLeads(): Promise<ImpactReportLead[]> {
  const { data } = await supabase.from('impact_report_leads').select('*').order('created_at', { ascending: false });
  return data ?? [];
}

// ── rPET FLAKES PAGE ──────────────────────────────────────────────────────
export async function getRpetPageSettings(): Promise<RpetPageSettings | null> {
  const { data } = await supabase.from('cms_rpet_page_settings').select('*').maybeSingle();
  return data;
}

export async function upsertRpetPageSettings(settings: Partial<RpetPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_rpet_page_settings').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_rpet_page_settings').insert(rest);
}

export async function getRpetApplications(): Promise<RpetApplication[]> {
  const { data } = await supabase.from('cms_rpet_applications').select('*').eq('is_active', true).order('sort_order');
  return data ?? [];
}

export async function getRpetApplicationsAll(): Promise<RpetApplication[]> {
  const { data } = await supabase.from('cms_rpet_applications').select('*').order('sort_order');
  return data ?? [];
}

export async function upsertRpetApplication(item: Partial<RpetApplication> & { id?: string }) {
  const { id, ...rest } = item;
  if (id) return supabase.from('cms_rpet_applications').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_rpet_applications').insert(rest);
}

export async function deleteRpetApplication(id: string) {
  return supabase.from('cms_rpet_applications').delete().eq('id', id);
}

export async function getRpetAdvantageCards(): Promise<RpetAdvantageCard[]> {
  const { data } = await supabase.from('cms_rpet_advantage_cards').select('*').eq('is_active', true).order('sort_order');
  return data ?? [];
}

export async function getRpetAdvantageCardsAll(): Promise<RpetAdvantageCard[]> {
  const { data } = await supabase.from('cms_rpet_advantage_cards').select('*').order('sort_order');
  return data ?? [];
}

export async function upsertRpetAdvantageCard(card: Partial<RpetAdvantageCard> & { id?: string }) {
  const { id, ...rest } = card;
  if (id) return supabase.from('cms_rpet_advantage_cards').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_rpet_advantage_cards').insert(rest);
}

export async function deleteRpetAdvantageCard(id: string) {
  return supabase.from('cms_rpet_advantage_cards').delete().eq('id', id);
}

export async function getRpetBenchmarkCards(): Promise<RpetBenchmarkCard[]> {
  const { data } = await supabase.from('cms_rpet_benchmark_cards').select('*').eq('is_active', true).order('sort_order');
  return data ?? [];
}

export async function getRpetBenchmarkCardsAll(): Promise<RpetBenchmarkCard[]> {
  const { data } = await supabase.from('cms_rpet_benchmark_cards').select('*').order('sort_order');
  return data ?? [];
}

export async function upsertRpetBenchmarkCard(card: Partial<RpetBenchmarkCard> & { id?: string }) {
  const { id, ...rest } = card;
  if (id) return supabase.from('cms_rpet_benchmark_cards').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_rpet_benchmark_cards').insert(rest);
}

export async function deleteRpetBenchmarkCard(id: string) {
  return supabase.from('cms_rpet_benchmark_cards').delete().eq('id', id);
}

// ── AUDIT LOG ─────────────────────────────────────────────────────────────
export async function logAudit(
  contentType: string,
  action: ContentAuditEntry['action'],
  performedByName: string,
  performedById?: string,
  contentId?: string
) {
  return supabase.from('cms_content_audit').insert({
    content_type: contentType,
    content_id: contentId,
    action,
    performed_by: performedById,
    performed_by_name: performedByName,
  });
}

export async function getRecentAuditEntries(limit = 10): Promise<ContentAuditEntry[]> {
  const { data } = await supabase
    .from('cms_content_audit')
    .select('*')
    .order('performed_at', { ascending: false })
    .limit(limit);
  return data ?? [];
}

// ── ADMIN USERS ───────────────────────────────────────────────────────────
export async function getAdminUsers() {
  const { data } = await supabase
    .from('admin_users')
    .select('id, email, full_name, role, is_active, last_login_at, created_at')
    .order('created_at');
  return data ?? [];
}

export async function updateAdminUser(id: string, updates: { full_name?: string; role?: string; is_active?: boolean }) {
  return supabase.from('admin_users').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id);
}

export async function createAdminUser(user: { email: string; full_name: string; role: string; password_hash: string }) {
  return supabase.from('admin_users').insert(user);
}

// ── ABOUT PAGE ────────────────────────────────────────────────────────────────
export async function getAboutPageSettings(): Promise<AboutPageSettings | null> {
  const { data } = await supabase.from('cms_about_page').select('*').maybeSingle();
  return data;
}
export async function upsertAboutPageSettings(settings: Partial<AboutPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_about_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_about_page').insert(rest);
}

// ── MRF PAGE ──────────────────────────────────────────────────────────────────
export async function getMrfPageSettings(): Promise<MrfPageSettings | null> {
  const { data } = await supabase.from('cms_mrf_page').select('*').maybeSingle();
  return data;
}
export async function upsertMrfPageSettings(settings: Partial<MrfPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_mrf_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_mrf_page').insert(rest);
}

// ── TRF PAGE ──────────────────────────────────────────────────────────────────
export async function getTrfPageSettings(): Promise<TrfPageSettings | null> {
  const { data } = await supabase.from('cms_trf_page').select('*').maybeSingle();
  return data;
}
export async function upsertTrfPageSettings(settings: Partial<TrfPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_trf_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_trf_page').insert(rest);
}

// ── RECYCLING PLANT PAGE ──────────────────────────────────────────────────────
export async function getRecyclingPlantPageSettings(): Promise<RecyclingPlantPageSettings | null> {
  const { data } = await supabase.from('cms_recycling_plant_page').select('*').maybeSingle();
  return data;
}
export async function upsertRecyclingPlantPageSettings(settings: Partial<RecyclingPlantPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_recycling_plant_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_recycling_plant_page').insert(rest);
}

// ── PLASTIC WASTE PAGE ────────────────────────────────────────────────────────
export async function getPlasticWastePageSettings(): Promise<PlasticWastePageSettings | null> {
  const { data } = await supabase.from('cms_plastic_waste_page').select('*').maybeSingle();
  return data;
}
export async function upsertPlasticWastePageSettings(settings: Partial<PlasticWastePageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_plastic_waste_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_plastic_waste_page').insert(rest);
}

// ── EPR PAGE ──────────────────────────────────────────────────────────────────
export async function getEprPageSettings(): Promise<EprPageSettings | null> {
  const { data } = await supabase.from('cms_epr_page').select('*').maybeSingle();
  return data;
}
export async function upsertEprPageSettings(settings: Partial<EprPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_epr_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_epr_page').insert(rest);
}

// ── PNP PAGE ──────────────────────────────────────────────────────────────────
export async function getPnpPageSettings(): Promise<PnpPageSettings | null> {
  const { data } = await supabase.from('cms_pnp_page').select('*').maybeSingle();
  return data;
}
export async function upsertPnpPageSettings(settings: Partial<PnpPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_pnp_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_pnp_page').insert(rest);
}

// ── TEXTILE WASTE PAGE ────────────────────────────────────────────────────────
export async function getTextileWastePageSettings(): Promise<TextileWastePageSettings | null> {
  const { data } = await supabase.from('cms_textile_waste_page').select('*').maybeSingle();
  return data;
}
export async function upsertTextileWastePageSettings(settings: Partial<TextileWastePageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_textile_waste_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_textile_waste_page').insert(rest);
}

// ── PITW PAGE ─────────────────────────────────────────────────────────────────
export async function getPitwPageSettings(): Promise<PitwPageSettings | null> {
  const { data } = await supabase.from('cms_pitw_page').select('*').maybeSingle();
  return data;
}
export async function upsertPitwPageSettings(settings: Partial<PitwPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_pitw_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_pitw_page').insert(rest);
}

// ── PCTW PAGE ─────────────────────────────────────────────────────────────────
export async function getPctwPageSettings(): Promise<PctwPageSettings | null> {
  const { data } = await supabase.from('cms_pctw_page').select('*').maybeSingle();
  return data;
}
export async function upsertPctwPageSettings(settings: Partial<PctwPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_pctw_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_pctw_page').insert(rest);
}

// ── ESG PAGE ──────────────────────────────────────────────────────────────────
export async function getEsgPageSettings(): Promise<EsgPageSettings | null> {
  const { data } = await supabase.from('cms_esg_page').select('*').maybeSingle();
  return data;
}
export async function upsertEsgPageSettings(settings: Partial<EsgPageSettings> & { id?: string }) {
  const { id, ...rest } = settings;
  if (id) return supabase.from('cms_esg_page').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
  return supabase.from('cms_esg_page').insert(rest);
}
