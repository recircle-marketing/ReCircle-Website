import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getEsgPageSettings, upsertEsgPageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { EsgPageSettings } from '../../cms/queries';

export default function EsgEditor() {
  const [settings, setSettings] = useState<Partial<EsgPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getEsgPageSettings().then(s => {
      if (s) setSettings(s);
      setLoading(false);
    });
  }, []);

  const update = (field: string, val: string) =>
    setSettings(s => ({ ...s, [field]: val }));

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertEsgPageSettings(settings);
    await logAudit(
      'esg_page',
      settings.id ? 'updated' : 'created',
      user?.full_name ?? '',
      user?.id,
      settings.id,
    );
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{ color: '#858585' }}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#1A1A1A' }}>ESG Projects</h1>
          <p className="text-sm" style={{ color: '#858585' }}>Manage content for the ESG Projects page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      <SectionCard title="Hero Section">
        <FormField label="Hero Heading">
          <Input
            value={settings.hero_heading ?? ''}
            onChange={e => update('hero_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Body">
          <Textarea
            rows={4}
            value={settings.hero_body ?? ''}
            onChange={e => update('hero_body', e.target.value)}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Introduction">
        <FormField label="Intro Heading">
          <Input
            value={settings.intro_heading ?? ''}
            onChange={e => update('intro_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Intro Body">
          <Textarea
            rows={4}
            value={settings.intro_body ?? ''}
            onChange={e => update('intro_body', e.target.value)}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Projects">
        <FormField label="Projects" hint="Array of {title, category, body} objects. Categories: Environmental, Social, Education">
          <Textarea
            rows={14}
            value={JSON.stringify(settings.projects ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, projects: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Reporting Section">
        <FormField label="Reporting Heading">
          <Input
            value={settings.reporting_heading ?? ''}
            onChange={e => update('reporting_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Reporting Body">
          <Textarea
            rows={4}
            value={settings.reporting_body ?? ''}
            onChange={e => update('reporting_body', e.target.value)}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
