import { useEffect, useState } from 'react';
import { Save, ExternalLink, FolderOpen } from 'lucide-react';
import { getSiteSettings, upsertSiteSettings } from '../../cms/queries';
import { logAudit } from '../../cms/queries';
import { getCurrentUser } from '../../lib/auth';

export default function BrandKitEditor() {
  const [url, setUrl] = useState('');
  const [settingsId, setSettingsId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const user = getCurrentUser();

  useEffect(() => {
    getSiteSettings().then((data) => {
      if (data) {
        setSettingsId(data.id);
        setUrl(data.brand_kit_url ?? '');
      }
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    setSaving(true);
    const payload: { id?: string; brand_kit_url: string } = { brand_kit_url: url };
    if (settingsId) payload.id = settingsId;
    await upsertSiteSettings(payload);
    await logAudit('brand_kit_url', 'updated', user?.full_name ?? 'Admin', user?.id, settingsId ?? undefined);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-7 h-7 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1" style={{ color: '#1A1A1A' }}>Brand Kit</h1>
        <p className="text-sm" style={{ color: '#858585' }}>
          Set the external link for the Brand Kit — visitors are sent here when they click Brand Kit in the navigation.
        </p>
      </div>

      <div className="bg-white border p-6" style={{ borderColor: '#E8E8E8' }}>
        <div className="flex items-center gap-3 mb-6 p-4 border" style={{ borderColor: '#E8EDF8', backgroundColor: '#F5F8FF' }}>
          <FolderOpen size={20} style={{ color: '#01298A' }} />
          <div>
            <p className="text-sm font-semibold" style={{ color: '#01298A' }}>External Link</p>
            <p className="text-xs mt-0.5" style={{ color: '#5F5F5F' }}>
              This link opens in a new tab. It is typically a Google Drive folder containing brand assets, logo files, and usage guidelines.
            </p>
          </div>
        </div>

        <div className="mb-5">
          <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
            Brand Kit URL
          </label>
          <div className="relative">
            <input
              type="url"
              value={url}
              onChange={(e) => { setUrl(e.target.value); setSaved(false); }}
              placeholder="https://drive.google.com/drive/folders/…"
              className="w-full px-4 pr-10 py-3 border text-sm focus:outline-none"
              style={{ borderColor: '#D1D1D1' }}
              onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
              onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
            />
            {url && (
              <a
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="absolute right-3 top-1/2 -translate-y-1/2"
                style={{ color: '#01298A' }}
                title="Open link"
              >
                <ExternalLink size={15} />
              </a>
            )}
          </div>
          <p className="text-xs mt-1.5" style={{ color: '#ABABAB' }}>
            Paste the full URL starting with https://
          </p>
        </div>

        {url && (
          <div className="mb-5 p-3 border flex items-start gap-2.5 text-xs" style={{ borderColor: '#E8E8E8', backgroundColor: '#FAFAFA' }}>
            <ExternalLink size={13} className="mt-0.5 shrink-0" style={{ color: '#01298A' }} />
            <div className="min-w-0">
              <p className="font-semibold mb-0.5" style={{ color: '#5F5F5F' }}>Current link</p>
              <a href={url} target="_blank" rel="noopener noreferrer" className="break-all hover:underline" style={{ color: '#01298A' }}>
                {url}
              </a>
            </div>
          </div>
        )}

        <div className="border-t pt-5 flex items-center gap-3" style={{ borderColor: '#F0F0F0' }}>
          <button
            onClick={handleSave}
            disabled={saving || !url.trim()}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white transition-opacity disabled:opacity-60"
            style={{ backgroundColor: '#01298A' }}
          >
            <Save size={14} />
            {saving ? 'Saving…' : saved ? 'Saved!' : 'Save Link'}
          </button>
          {saved && <span className="text-xs font-medium" style={{ color: '#00C499' }}>Brand Kit link updated</span>}
        </div>
      </div>

      <div className="mt-4 p-4 border border-dashed text-xs" style={{ borderColor: '#D1D1D1', color: '#858585' }}>
        This URL is used in both the desktop navigation mega-menu and the mobile navigation menu under Know Us &rsaquo; Brand Kit. Saving here updates both automatically.
      </div>
    </div>
  );
}
