import { useEffect, useState } from 'react';
import { Save, Plus, Trash2, GripVertical, ExternalLink } from 'lucide-react';
import { getSiteSettings, upsertSiteSettings } from '../../cms/queries';
import { logAudit } from '../../cms/queries';
import { getCurrentUser } from '../../lib/auth';
import type { SiteSettings, SocialLinkEntry } from '../../cms/types';

const PLATFORM_SUGGESTIONS = [
  'LinkedIn', 'Instagram', 'Facebook', 'YouTube', 'X (Twitter)', 'Pinterest', 'WhatsApp',
];

const DEFAULT_LINKS: SocialLinkEntry[] = [
  { platform: 'LinkedIn', url: '', is_active: true },
  { platform: 'Instagram', url: '', is_active: true },
  { platform: 'Facebook', url: '', is_active: true },
  { platform: 'YouTube', url: '', is_active: true },
];

export default function SocialLinksEditor() {
  const [links, setLinks] = useState<SocialLinkEntry[]>(DEFAULT_LINKS);
  const [settingsId, setSettingsId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const user = getCurrentUser();

  useEffect(() => {
    getSiteSettings().then((data) => {
      if (data) {
        setSettingsId(data.id);
        const raw = data.social_links as SocialLinkEntry[] | null;
        if (Array.isArray(raw) && raw.length > 0) {
          setLinks(raw.map((l) => ({ platform: l.platform ?? '', url: l.url ?? '', is_active: l.is_active ?? true })));
        }
      }
      setLoading(false);
    });
  }, []);

  const addLink = () => {
    setLinks((prev) => [...prev, { platform: '', url: '', is_active: true }]);
    setSaved(false);
  };

  const removeLink = (idx: number) => {
    setLinks((prev) => prev.filter((_, i) => i !== idx));
    setSaved(false);
  };

  const updateLink = (idx: number, field: keyof SocialLinkEntry, value: string | boolean) => {
    setLinks((prev) => prev.map((l, i) => (i === idx ? { ...l, [field]: value } : l)));
    setSaved(false);
  };

  const moveLink = (idx: number, dir: -1 | 1) => {
    const next = idx + dir;
    if (next < 0 || next >= links.length) return;
    setLinks((prev) => {
      const arr = [...prev];
      [arr[idx], arr[next]] = [arr[next], arr[idx]];
      return arr;
    });
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    const payload: Partial<SiteSettings> & { id?: string } = {
      social_links: links,
    };
    if (settingsId) payload.id = settingsId;
    await upsertSiteSettings(payload);
    await logAudit('site_settings_social', 'updated', user?.full_name ?? 'Admin', user?.id, settingsId ?? undefined);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-7 h-7 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1" style={{ color: '#1A1A1A' }}>Social Links</h1>
        <p className="text-sm" style={{ color: '#858585' }}>
          Manage all social media profile URLs displayed in the footer, contact page, and across the site.
        </p>
      </div>

      <div className="bg-white border p-6" style={{ borderColor: '#E8E8E8' }}>
        <div className="space-y-3 mb-5">
          {links.map((link, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-4 border"
              style={{ borderColor: link.is_active ? '#E8E8E8' : '#F5F5F5', backgroundColor: link.is_active ? '#fff' : '#FAFAFA' }}
            >
              {/* Drag handle (visual only) */}
              <div className="mt-2.5 cursor-grab">
                <GripVertical size={16} style={{ color: '#D1D1D1' }} />
              </div>

              {/* Fields */}
              <div className="flex-1 grid grid-cols-1 sm:grid-cols-5 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: '#858585' }}>
                    Platform
                  </label>
                  <input
                    type="text"
                    value={link.platform}
                    onChange={(e) => updateLink(idx, 'platform', e.target.value)}
                    list={`platform-suggestions-${idx}`}
                    placeholder="e.g. LinkedIn"
                    className="w-full px-3 py-2 border text-sm focus:outline-none"
                    style={{ borderColor: '#D1D1D1' }}
                    onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                    onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                  />
                  <datalist id={`platform-suggestions-${idx}`}>
                    {PLATFORM_SUGGESTIONS.map((p) => <option key={p} value={p} />)}
                  </datalist>
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: '#858585' }}>
                    URL
                  </label>
                  <div className="relative">
                    <input
                      type="url"
                      value={link.url}
                      onChange={(e) => updateLink(idx, 'url', e.target.value)}
                      placeholder="https://linkedin.com/company/recircle"
                      className="w-full pl-3 pr-8 py-2 border text-sm focus:outline-none"
                      style={{ borderColor: '#D1D1D1' }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                    />
                    {link.url && (
                      <a
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="absolute right-2.5 top-1/2 -translate-y-1/2"
                        style={{ color: '#01298A' }}
                        title="Open link"
                      >
                        <ExternalLink size={13} />
                      </a>
                    )}
                  </div>
                </div>
              </div>

              {/* Controls */}
              <div className="flex flex-col gap-1.5 mt-1 shrink-0">
                <button
                  onClick={() => moveLink(idx, -1)}
                  disabled={idx === 0}
                  className="p-1.5 transition-colors disabled:opacity-30"
                  style={{ color: '#858585' }}
                  title="Move up"
                >
                  ↑
                </button>
                <button
                  onClick={() => moveLink(idx, 1)}
                  disabled={idx === links.length - 1}
                  className="p-1.5 transition-colors disabled:opacity-30"
                  style={{ color: '#858585' }}
                  title="Move down"
                >
                  ↓
                </button>
              </div>

              {/* Active toggle */}
              <div className="flex flex-col items-center gap-1 mt-1 shrink-0">
                <button
                  onClick={() => updateLink(idx, 'is_active', !link.is_active)}
                  className="w-9 h-5 relative rounded-full transition-colors duration-200"
                  style={{ backgroundColor: link.is_active ? '#00C499' : '#D1D1D1' }}
                  title={link.is_active ? 'Active — click to hide' : 'Hidden — click to show'}
                >
                  <span
                    className="absolute top-0.5 w-4 h-4 bg-white rounded-full transition-all duration-200"
                    style={{ left: link.is_active ? '17px' : '2px' }}
                  />
                </button>
                <span className="text-xs" style={{ color: '#ABABAB' }}>{link.is_active ? 'On' : 'Off'}</span>
              </div>

              {/* Delete */}
              <button
                onClick={() => removeLink(idx)}
                className="mt-1 p-1.5 transition-colors shrink-0"
                style={{ color: '#D1D1D1' }}
                onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }}
                onMouseLeave={(e) => { e.currentTarget.style.color = '#D1D1D1'; }}
                title="Remove"
              >
                <Trash2 size={15} />
              </button>
            </div>
          ))}
        </div>

        {/* Add new */}
        <button
          onClick={addLink}
          className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed text-sm font-medium transition-colors mb-6"
          style={{ borderColor: '#D1D1D1', color: '#858585' }}
          onMouseEnter={(e) => { e.currentTarget.style.borderColor = '#01298A'; e.currentTarget.style.color = '#01298A'; }}
          onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; e.currentTarget.style.color = '#858585'; }}
        >
          <Plus size={15} />
          Add Social Platform
        </button>

        <div className="border-t pt-5 flex items-center gap-3" style={{ borderColor: '#F0F0F0' }}>
          <button
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white transition-opacity disabled:opacity-60"
            style={{ backgroundColor: '#01298A' }}
          >
            <Save size={14} />
            {saving ? 'Saving…' : saved ? 'Saved!' : 'Save Changes'}
          </button>
          {saved && <span className="text-xs font-medium" style={{ color: '#00C499' }}>Social links updated</span>}
        </div>
      </div>
    </div>
  );
}
