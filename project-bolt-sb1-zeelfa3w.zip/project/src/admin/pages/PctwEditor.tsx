import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getPctwPageSettings, upsertPctwPageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { PctwPageSettings } from '../../cms/queries';

export default function PctwEditor() {
  const [settings, setSettings] = useState<Partial<PctwPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getPctwPageSettings().then(s => {
      if (s) setSettings(s);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertPctwPageSettings(settings);
    await logAudit(
      'pctw_page',
      settings.id ? 'updated' : 'created',
      user?.full_name ?? '',
      user?.id,
      settings.id,
    );
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{ color: '#858585' }}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#1A1A1A' }}>PCTW — Post-Consumer Textile Waste</h1>
          <p className="text-sm" style={{ color: '#858585' }}>Manage content for the Post-Consumer Textile Waste page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      {/* Hero Section */}
      <SectionCard title="Hero Section">
        <FormField label="Hero Heading">
          <Textarea
            rows={2}
            value={settings.hero_heading ?? ''}
            onChange={e => setSettings(s => ({ ...s, hero_heading: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Subheading">
          <Textarea
            rows={2}
            value={settings.hero_subheading ?? ''}
            onChange={e => setSettings(s => ({ ...s, hero_subheading: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Collection Channels */}
      <SectionCard title="Collection Channels">
        <FormField label="Channels" hint="Array of {title, icon, desc} objects. icon values: Building2, Users, Heart">
          <Textarea
            rows={10}
            value={JSON.stringify(settings.channels ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, channels: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Impact Statistics */}
      <SectionCard title="Impact Statistics">
        <FormField label="Stats" hint="Array of {value, label} objects">
          <Textarea
            rows={8}
            value={JSON.stringify(settings.stats ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, stats: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Partner Institutions */}
      <SectionCard title="Partner Institutions">
        <FormField label="Institutions" hint="Array of {name} objects">
          <Textarea
            rows={6}
            value={JSON.stringify(settings.institutions ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, institutions: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Community Section */}
      <SectionCard title="Community Section">
        <FormField label="Community Heading">
          <Input
            value={settings.community_heading ?? ''}
            onChange={e => setSettings(s => ({ ...s, community_heading: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Community Body 1">
          <Textarea
            rows={3}
            value={settings.community_body_1 ?? ''}
            onChange={e => setSettings(s => ({ ...s, community_body_1: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Community Body 2">
          <Textarea
            rows={3}
            value={settings.community_body_2 ?? ''}
            onChange={e => setSettings(s => ({ ...s, community_body_2: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
