import { useEffect, useState } from 'react';
import { Plus, X } from 'lucide-react';
import { getAdminUsers, updateAdminUser, createAdminUser } from '../../cms/queries';
import { getCurrentUser } from '../../lib/auth';
import { FormField, Input, Select, SaveButton, SectionCard } from '../components/FormField';

interface AdminUserRow {
  id: string;
  email: string;
  full_name: string;
  role: string;
  is_active: boolean;
  last_login_at: string | null;
  created_at: string;
}

function RoleBadge({ role }: { role: string }) {
  const map: Record<string, { bg: string; text: string; label: string }> = {
    super_admin: { bg: '#E8EDF8', text: '#01298A', label: 'Super Admin' },
    editor: { bg: '#E0FAF4', text: '#00A882', label: 'Editor' },
    viewer: { bg: '#F5F5F5', text: '#5F5F5F', label: 'Viewer' },
  };
  const s = map[role] ?? map.viewer;
  return <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: s.bg, color: s.text }}>{s.label}</span>;
}

function timeAgo(str: string | null): string {
  if (!str) return 'Never';
  const diff = Date.now() - new Date(str).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  return `${days} days ago`;
}

export default function UserManagement() {
  const [users, setUsers] = useState<AdminUserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editRole, setEditRole] = useState('');
  const [editActive, setEditActive] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newUser, setNewUser] = useState({ email: '', full_name: '', role: 'editor' });
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState('');
  const currentUser = getCurrentUser();

  useEffect(() => {
    getAdminUsers().then((data) => {
      setUsers(data as AdminUserRow[]);
      setLoading(false);
    });
  }, []);

  const handleEditSave = async (id: string) => {
    setSaving(true);
    await updateAdminUser(id, { role: editRole, is_active: editActive });
    const fresh = await getAdminUsers();
    setUsers(fresh as AdminUserRow[]);
    setSaving(false);
    setEditingId(null);
  };

  const handleCreate = async () => {
    setCreateError('');
    if (!newUser.email || !newUser.full_name) {
      setCreateError('All fields are required.');
      return;
    }
    setCreating(true);
    const { error } = await createAdminUser({
      email: newUser.email.toLowerCase().trim(),
      full_name: newUser.full_name,
      role: newUser.role,
      password_hash: '',
    });
    if (error) {
      setCreateError('Could not create user. Email may already exist.');
      setCreating(false);
      return;
    }
    const fresh = await getAdminUsers();
    setUsers(fresh as AdminUserRow[]);
    setCreating(false);
    setShowCreate(false);
    setNewUser({ email: '', full_name: '', role: 'editor' });
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>User Management</h1>
          <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Manage CMS admin accounts and their access levels.</p>
        </div>
        {!showCreate && (
          <button onClick={() => setShowCreate(true)} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white" style={{ backgroundColor: '#01298A' }}>
            <Plus size={14} /> Add User
          </button>
        )}
      </div>

      {/* Role reference */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { role: 'super_admin', label: 'Super Admin', desc: 'Full access: create, edit, publish, delete content and manage users.' },
          { role: 'editor', label: 'Editor', desc: 'Can create and edit all content. Cannot publish, delete, or manage users.' },
          { role: 'viewer', label: 'Viewer', desc: 'Read-only access. Cannot create, edit, publish, or delete content.' },
        ].map((r) => (
          <div key={r.role} className="bg-white border p-4" style={{ borderColor: '#E8E8E8' }}>
            <RoleBadge role={r.role} />
            <p className="text-xs mt-2 leading-relaxed" style={{ color: '#858585' }}>{r.desc}</p>
          </div>
        ))}
      </div>

      {/* Create user form */}
      {showCreate && (
        <SectionCard title="Create New User">
          <div className="space-y-4">
            {createError && <p className="text-sm px-3 py-2 border" style={{ color: '#E7182A', borderColor: '#FECACA', backgroundColor: '#FEE2E2' }}>{createError}</p>}
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Full Name" required><Input value={newUser.full_name} onChange={(e) => setNewUser({ ...newUser, full_name: e.target.value })} placeholder="Jane Doe" /></FormField>
              <FormField label="Email Address" required><Input type="email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} placeholder="jane@recircle.in" /></FormField>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Role" required>
                <Select value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}>
                  <option value="viewer">Viewer</option>
                  <option value="editor">Editor</option>
                  <option value="super_admin">Super Admin</option>
                </Select>
              </FormField>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <SaveButton saving={creating} onClick={handleCreate}>Create User</SaveButton>
              <button onClick={() => { setShowCreate(false); setCreateError(''); }} className="flex items-center gap-1.5 px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>
                <X size={14} /> Cancel
              </button>
            </div>
          </div>
        </SectionCard>
      )}

      {/* Users table */}
      <div className="bg-white border overflow-hidden" style={{ borderColor: '#E8E8E8' }}>
        <div className="px-5 py-3 border-b" style={{ borderColor: '#E8E8E8' }}>
          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#858585' }}>All Users ({users.length})</p>
        </div>
        <div className="divide-y" style={{ borderColor: '#F5F5F5' }}>
          {users.map((u) => (
            <div key={u.id} className="px-5 py-4">
              {editingId === u.id ? (
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <p className="text-sm font-medium" style={{ color: '#1A1A1A' }}>{u.full_name}</p>
                    <p className="text-xs" style={{ color: '#858585' }}>{u.email}</p>
                  </div>
                  <Select value={editRole} onChange={(e) => setEditRole(e.target.value)} className="w-36 !py-1.5 text-xs">
                    <option value="viewer">Viewer</option>
                    <option value="editor">Editor</option>
                    <option value="super_admin">Super Admin</option>
                  </Select>
                  <div className="flex items-center gap-1.5">
                    <input type="checkbox" id={`active-${u.id}`} checked={editActive} onChange={(e) => setEditActive(e.target.checked)} className="w-4 h-4" />
                    <label htmlFor={`active-${u.id}`} className="text-xs" style={{ color: '#858585' }}>Active</label>
                  </div>
                  <SaveButton saving={saving} onClick={() => handleEditSave(u.id)} className="!py-1.5 !px-3 !text-xs">Save</SaveButton>
                  <button onClick={() => setEditingId(null)} className="text-xs" style={{ color: '#858585' }}>Cancel</button>
                </div>
              ) : (
                <div className="flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium" style={{ color: '#1A1A1A' }}>{u.full_name}</p>
                      {!u.is_active && <span className="text-xs px-1.5 rounded" style={{ backgroundColor: '#FEE2E2', color: '#E7182A' }}>Inactive</span>}
                      {u.id === currentUser?.id && <span className="text-xs px-1.5 rounded" style={{ backgroundColor: '#E0FAF4', color: '#00A882' }}>You</span>}
                    </div>
                    <p className="text-xs mt-0.5" style={{ color: '#858585' }}>{u.email}</p>
                  </div>
                  <RoleBadge role={u.role} />
                  <p className="text-xs w-28 text-right" style={{ color: '#ABABAB' }}>Last login: {timeAgo(u.last_login_at)}</p>
                  {u.id !== currentUser?.id && (
                    <button
                      onClick={() => { setEditingId(u.id); setEditRole(u.role); setEditActive(u.is_active); }}
                      className="text-xs font-medium px-3 py-1.5 border"
                      style={{ color: '#01298A', borderColor: '#01298A' }}
                    >
                      Edit
                    </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
