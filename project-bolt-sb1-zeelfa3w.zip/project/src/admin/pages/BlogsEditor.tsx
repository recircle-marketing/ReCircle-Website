import { useEffect, useState } from 'react';
import { Plus, Trash2, Eye, EyeOff } from 'lucide-react';
import { getBlogs, upsertBlog, deleteBlog, getBlogPageSettings, upsertBlogPageSettings } from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { Blog, BlogPageSettings } from '../../cms/types';
import { FormField, Input, Textarea, Select, SaveButton, SectionCard } from '../components/FormField';

function slugify(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

const emptyBlog = (): Partial<Blog> => ({
  title: '', slug: '', author: '', category: '', tags: [],
  featured_image_url: '', featured_image_alt: '',
  body_content: '', status: 'draft',
  seo_title: '', seo_description: '', seo_og_image: '',
  publish_date: new Date().toISOString().slice(0, 10),
});

export default function BlogsEditor() {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [editing, setEditing] = useState<Partial<Blog> | null>(null);
  const [pageSettings, setPageSettings] = useState<Partial<BlogPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [pageSettingsSaving, setPageSettingsSaving] = useState(false);
  const [pageSettingsSaved, setPageSettingsSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    Promise.all([getBlogs(true), getBlogPageSettings()]).then(([b, s]) => {
      setBlogs(b);
      if (s) setPageSettings(s);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    await upsertBlog(editing);
    await logAudit('blog', editing.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, editing.id);
    const fresh = await getBlogs(true);
    setBlogs(fresh);
    setSaving(false);
    setSaved(true);
    setTimeout(() => { setSaved(false); setEditing(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this blog post? This cannot be undone.')) return;
    await deleteBlog(id);
    setBlogs((prev) => prev.filter((b) => b.id !== id));
  };

  const handlePageSettingsSave = async () => {
    setPageSettingsSaving(true);
    await upsertBlogPageSettings(pageSettings);
    setPageSettingsSaving(false);
    setPageSettingsSaved(true);
    setTimeout(() => setPageSettingsSaved(false), 1500);
  };

  const statusColors: Record<string, { bg: string; text: string }> = {
    published: { bg: '#E0FAF4', text: '#00A882' },
    review: { bg: '#FFF9E0', text: '#B08B00' },
    draft: { bg: '#F5F5F5', text: '#5F5F5F' },
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  if (editing) {
    return (
      <div className="max-w-3xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>{editing.id ? 'Edit Post' : 'New Blog Post'}</h1>
            <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Fill in all required fields before publishing.</p>
          </div>
          <button onClick={() => setEditing(null)} className="text-sm px-4 py-2 border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
        </div>

        <SectionCard title="Post Details">
          <div className="space-y-4">
            <FormField label="Title" required>
              <Input value={editing.title ?? ''} onChange={(e) => { const t = e.target.value; setEditing({ ...editing, title: t, slug: editing.slug || slugify(t) }); }} disabled={!editable} />
            </FormField>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="URL Slug" hint="Auto-generated from title" required>
                <Input value={editing.slug ?? ''} onChange={(e) => setEditing({ ...editing, slug: slugify(e.target.value) })} disabled={!editable} />
              </FormField>
              <FormField label="Status">
                <Select value={editing.status ?? 'draft'} onChange={(e) => setEditing({ ...editing, status: e.target.value as Blog['status'] })} disabled={!editable}>
                  <option value="draft">Draft</option>
                  <option value="review">In Review</option>
                  <option value="published">Published</option>
                </Select>
              </FormField>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Author" required>
                <Input value={editing.author ?? ''} onChange={(e) => setEditing({ ...editing, author: e.target.value })} disabled={!editable} />
              </FormField>
              <FormField label="Publish Date">
                <Input type="date" value={editing.publish_date ?? ''} onChange={(e) => setEditing({ ...editing, publish_date: e.target.value })} disabled={!editable} />
              </FormField>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Category / Tag" required>
                <Input value={editing.category ?? ''} onChange={(e) => setEditing({ ...editing, category: e.target.value })} disabled={!editable} placeholder="EPR, Sustainability…" />
              </FormField>
              <FormField label="Tags" hint="Comma separated">
                <Input value={(editing.tags ?? []).join(', ')} onChange={(e) => setEditing({ ...editing, tags: e.target.value.split(',').map((t) => t.trim()).filter(Boolean) })} disabled={!editable} />
              </FormField>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Featured Image">
          <div className="space-y-3">
            <FormField label="Image URL" required>
              <Input value={editing.featured_image_url ?? ''} onChange={(e) => setEditing({ ...editing, featured_image_url: e.target.value })} disabled={!editable} placeholder="https://images.pexels.com/…" />
            </FormField>
            <FormField label="Image Alt Text">
              <Input value={editing.featured_image_alt ?? ''} onChange={(e) => setEditing({ ...editing, featured_image_alt: e.target.value })} disabled={!editable} />
            </FormField>
            {editing.featured_image_url && (
              <img src={editing.featured_image_url} alt={editing.featured_image_alt} className="w-full max-w-xs aspect-video object-cover mt-2" />
            )}
          </div>
        </SectionCard>

        <SectionCard title="Short Summary" description="2–3 sentences shown on the blog listing card and used as meta description if SEO description is empty.">
          <Textarea value={editing.seo_description ?? ''} onChange={(e) => setEditing({ ...editing, seo_description: e.target.value })} disabled={!editable} rows={3} placeholder="A concise summary of the article…" />
        </SectionCard>

        <SectionCard title="Article Body" description="Write full article content here. HTML is supported for rich formatting.">
          <Textarea value={editing.body_content ?? ''} onChange={(e) => setEditing({ ...editing, body_content: e.target.value })} disabled={!editable} rows={20} className="font-mono text-xs" placeholder="<p>Your article content here…</p>" />
        </SectionCard>

        <SectionCard title="SEO Settings">
          <div className="space-y-4">
            <FormField label="Meta Title">
              <Input value={editing.seo_title ?? ''} onChange={(e) => setEditing({ ...editing, seo_title: e.target.value })} disabled={!editable} placeholder="Article title | ReCircle" />
            </FormField>
            <FormField label="OG Image URL">
              <Input value={editing.seo_og_image ?? ''} onChange={(e) => setEditing({ ...editing, seo_og_image: e.target.value })} disabled={!editable} />
            </FormField>
          </div>
        </SectionCard>

        {editable && (
          <div className="flex items-center gap-3">
            <SaveButton saving={saving} saved={saved} onClick={handleSave} />
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Blogs</h1>
          <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Create, edit, and publish blog posts for the Knowledge Centre.</p>
        </div>
        {editable && (
          <button onClick={() => setEditing(emptyBlog())} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white" style={{ backgroundColor: '#01298A' }}>
            <Plus size={14} /> New Post
          </button>
        )}
      </div>

      {/* Hero settings */}
      <SectionCard title="Blog Listing Page Hero">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Hero Heading">
              <Input value={pageSettings.hero_heading ?? ''} onChange={(e) => setPageSettings({ ...pageSettings, hero_heading: e.target.value })} disabled={!editable} />
            </FormField>
            <FormField label="Hero Subheading">
              <Input value={pageSettings.hero_subheading ?? ''} onChange={(e) => setPageSettings({ ...pageSettings, hero_subheading: e.target.value })} disabled={!editable} />
            </FormField>
          </div>
          <FormField label="Hero Image URL">
            <Input value={pageSettings.hero_image_url ?? ''} onChange={(e) => setPageSettings({ ...pageSettings, hero_image_url: e.target.value })} disabled={!editable} />
          </FormField>
          {editable && (
            <div className="flex items-center gap-3 pt-1">
              <SaveButton saving={pageSettingsSaving} saved={pageSettingsSaved} onClick={handlePageSettingsSave} />
            </div>
          )}
        </div>
      </SectionCard>

      {/* Posts list */}
      <div className="bg-white border overflow-hidden" style={{ borderColor: '#E8E8E8' }}>
        <div className="px-5 py-3 border-b" style={{ borderColor: '#E8E8E8' }}>
          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#858585' }}>All Posts ({blogs.length})</p>
        </div>
        {blogs.length === 0 ? (
          <div className="px-5 py-10 text-center">
            <p className="text-sm" style={{ color: '#ABABAB' }}>No posts yet. Click "New Post" to get started.</p>
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: '#F5F5F5' }}>
            {blogs.map((blog) => {
              const sc = statusColors[blog.status] ?? statusColors.draft;
              return (
                <div key={blog.id} className="px-5 py-4 flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-semibold truncate" style={{ color: '#1A1A1A' }}>{blog.title}</p>
                      <span className="text-xs px-2 py-0.5 rounded-full flex-shrink-0" style={{ backgroundColor: sc.bg, color: sc.text }}>
                        {blog.status === 'published' ? <><Eye size={10} className="inline mr-1" />Published</> : blog.status === 'review' ? 'In Review' : <><EyeOff size={10} className="inline mr-1" />Draft</>}
                      </span>
                    </div>
                    <p className="text-xs" style={{ color: '#ABABAB' }}>{blog.author} · {blog.category} · {blog.publish_date ?? 'No date'}</p>
                  </div>
                  {editable && (
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button onClick={() => setEditing(blog)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                      <button onClick={() => handleDelete(blog.id)} className="p-1.5 transition-colors" style={{ color: '#ABABAB' }}
                        onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                        <Trash2 size={14} />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
