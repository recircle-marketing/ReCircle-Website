import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getTextileWastePageSettings, upsertTextileWastePageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { TextileWastePageSettings } from '../../cms/queries';

export default function TextileWasteEditor() {
  const [settings, setSettings] = useState<Partial<TextileWastePageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getTextileWastePageSettings().then(s => {
      if (s) setSettings(s);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertTextileWastePageSettings(settings);
    await logAudit(
      'textile_waste_page',
      settings.id ? 'updated' : 'created',
      user?.full_name ?? '',
      user?.id,
      settings.id,
    );
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{ color: '#858585' }}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#1A1A1A' }}>Textile Waste Management</h1>
          <p className="text-sm" style={{ color: '#858585' }}>Manage content for the Textile Waste Management parent page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      {/* Hero Section */}
      <SectionCard title="Hero Section">
        <FormField label="Hero Stat" hint="e.g. 134 million tonnes">
          <Input
            value={settings.hero_stat ?? ''}
            onChange={e => setSettings(s => ({ ...s, hero_stat: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Fact 1">
          <Input
            value={settings.hero_fact_1 ?? ''}
            onChange={e => setSettings(s => ({ ...s, hero_fact_1: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Fact 2">
          <Input
            value={settings.hero_fact_2 ?? ''}
            onChange={e => setSettings(s => ({ ...s, hero_fact_2: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Closing">
          <Textarea
            rows={2}
            value={settings.hero_closing ?? ''}
            onChange={e => setSettings(s => ({ ...s, hero_closing: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Problem Statement */}
      <SectionCard title="Problem Statement">
        <FormField label="Problem Body">
          <Textarea
            rows={4}
            value={settings.problem_body ?? ''}
            onChange={e => setSettings(s => ({ ...s, problem_body: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Problem Closing">
          <Textarea
            rows={2}
            value={settings.problem_closing ?? ''}
            onChange={e => setSettings(s => ({ ...s, problem_closing: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Our Model */}
      <SectionCard title="Our Model">
        <FormField label="Model Intro">
          <Textarea
            rows={3}
            value={settings.model_intro ?? ''}
            onChange={e => setSettings(s => ({ ...s, model_intro: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Model Pillars" hint="Array of {num, title, body} objects">
          <Textarea
            rows={10}
            value={JSON.stringify(settings.model_pillars ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, model_pillars: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* TRF Statistics */}
      <SectionCard title="TRF Statistics">
        <FormField label="Stat 1 Value">
          <Input
            value={settings.trf_stat_1_value ?? ''}
            onChange={e => setSettings(s => ({ ...s, trf_stat_1_value: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Stat 1 Label">
          <Input
            value={settings.trf_stat_1_label ?? ''}
            onChange={e => setSettings(s => ({ ...s, trf_stat_1_label: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Stat 2 Value">
          <Input
            value={settings.trf_stat_2_value ?? ''}
            onChange={e => setSettings(s => ({ ...s, trf_stat_2_value: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Stat 2 Label">
          <Input
            value={settings.trf_stat_2_label ?? ''}
            onChange={e => setSettings(s => ({ ...s, trf_stat_2_label: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="TRF Body">
          <Textarea
            rows={4}
            value={settings.trf_body ?? ''}
            onChange={e => setSettings(s => ({ ...s, trf_body: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Partner Categories */}
      <SectionCard title="Partner Categories">
        <FormField label="Partner Categories" hint="Array of {title, subtypes, desc} objects">
          <Textarea
            rows={14}
            value={JSON.stringify(settings.partner_categories ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, partner_categories: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Community Section */}
      <SectionCard title="Community Section">
        <FormField label="Community Heading">
          <Textarea
            rows={2}
            value={settings.community_heading ?? ''}
            onChange={e => setSettings(s => ({ ...s, community_heading: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Community Body 1">
          <Textarea
            rows={3}
            value={settings.community_body_1 ?? ''}
            onChange={e => setSettings(s => ({ ...s, community_body_1: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Community Body 2">
          <Textarea
            rows={3}
            value={settings.community_body_2 ?? ''}
            onChange={e => setSettings(s => ({ ...s, community_body_2: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Supporters */}
      <SectionCard title="Supporters">
        <FormField label="Supporters" hint="Array of {name} objects">
          <Textarea
            rows={5}
            value={JSON.stringify(settings.supporters ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, supporters: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
