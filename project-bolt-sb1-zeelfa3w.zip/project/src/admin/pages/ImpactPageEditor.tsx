import { useEffect, useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import {
  getImpactPageSettings, upsertImpactPageSettings,
  getImpactMetrics, upsertImpactMetric, deleteImpactMetric,
  getImpactPreviousReports, upsertImpactPreviousReport, deleteImpactPreviousReport,
  getImpactReportLeads,
} from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { ImpactPageSettings, ImpactMetric, ImpactPreviousReport, ImpactReportLead } from '../../cms/types';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';

const emptyMetric = (): Partial<ImpactMetric> => ({ sort_order: 99, is_active: true, number_value: '', suffix: '', unit: '', label: '' });
const emptyReport = (): Partial<ImpactPreviousReport> => ({ sort_order: 99, is_active: true, year_label: '', button_text: '', report_url: '' });

type Tab = 'settings' | 'metrics' | 'reports' | 'leads';

function formatDate(str: string): string {
  const d = new Date(str);
  return `${String(d.getDate()).padStart(2,'0')} ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()]} ${d.getFullYear()}`;
}

export default function ImpactPageEditor() {
  const [tab, setTab] = useState<Tab>('settings');
  const [settings, setSettings] = useState<Partial<ImpactPageSettings>>({});
  const [metrics, setMetrics] = useState<ImpactMetric[]>([]);
  const [prevReports, setPrevReports] = useState<ImpactPreviousReport[]>([]);
  const [leads, setLeads] = useState<ImpactReportLead[]>([]);
  const [editingMetric, setEditingMetric] = useState<Partial<ImpactMetric> | null>(null);
  const [editingReport, setEditingReport] = useState<Partial<ImpactPreviousReport> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [subSaving, setSubSaving] = useState(false);
  const [subSaved, setSubSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    Promise.all([
      getImpactPageSettings(),
      getImpactMetrics(),
      getImpactPreviousReports(),
      getImpactReportLeads(),
    ]).then(([s, m, r, l]) => {
      if (s) setSettings(s);
      setMetrics(m);
      setPrevReports(r);
      setLeads(l);
      setLoading(false);
    });
  }, []);

  const handleSettingsSave = async () => {
    setSaving(true);
    await upsertImpactPageSettings(settings);
    await logAudit('impact_page', settings.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, settings.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const handleMetricSave = async () => {
    if (!editingMetric) return;
    setSubSaving(true);
    await upsertImpactMetric(editingMetric);
    const fresh = await getImpactMetrics();
    setMetrics(fresh);
    setSubSaving(false);
    setSubSaved(true);
    setTimeout(() => { setSubSaved(false); setEditingMetric(null); }, 1200);
  };

  const handleReportSave = async () => {
    if (!editingReport) return;
    setSubSaving(true);
    await upsertImpactPreviousReport(editingReport);
    const fresh = await getImpactPreviousReports();
    setPrevReports(fresh);
    setSubSaving(false);
    setSubSaved(true);
    setTimeout(() => { setSubSaved(false); setEditingReport(null); }, 1200);
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  const tabs: { key: Tab; label: string }[] = [
    { key: 'settings', label: 'Page Content' },
    { key: 'metrics', label: 'Impact Metrics' },
    { key: 'reports', label: 'Previous Reports' },
    { key: 'leads', label: `Report Leads (${leads.length})` },
  ];

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Impact Page</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Edit all impact page sections and view report download leads.</p>
      </div>

      {/* Tab nav */}
      <div className="flex gap-1 border-b" style={{ borderColor: '#E8E8E8' }}>
        {tabs.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className="px-4 py-2.5 text-xs font-semibold border-b-2 -mb-px transition-colors"
            style={{
              borderColor: tab === key ? '#01298A' : 'transparent',
              color: tab === key ? '#01298A' : '#858585',
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'settings' && (
        <div className="space-y-6">
          <SectionCard title="Annual Report Feature (Hero)">
            <div className="space-y-4">
              <FormField label="Heading"><Input value={settings.annual_feature_heading ?? ''} onChange={(e) => setSettings({ ...settings, annual_feature_heading: e.target.value })} disabled={!editable} /></FormField>
              <FormField label="Subheading"><Input value={settings.annual_feature_subheading ?? ''} onChange={(e) => setSettings({ ...settings, annual_feature_subheading: e.target.value })} disabled={!editable} /></FormField>
              <FormField label="Body Text"><Textarea value={settings.annual_feature_body ?? ''} onChange={(e) => setSettings({ ...settings, annual_feature_body: e.target.value })} disabled={!editable} rows={4} /></FormField>
              <div className="grid grid-cols-2 gap-4">
                <FormField label="CTA Button Label"><Input value={settings.annual_feature_cta_label ?? ''} onChange={(e) => setSettings({ ...settings, annual_feature_cta_label: e.target.value })} disabled={!editable} /></FormField>
                <FormField label="Report URL"><Input value={settings.annual_feature_report_url ?? ''} onChange={(e) => setSettings({ ...settings, annual_feature_report_url: e.target.value })} disabled={!editable} /></FormField>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Impact Metrics Section">
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Heading"><Input value={settings.metrics_heading ?? ''} onChange={(e) => setSettings({ ...settings, metrics_heading: e.target.value })} disabled={!editable} /></FormField>
              <FormField label="Subheading"><Input value={settings.metrics_subheading ?? ''} onChange={(e) => setSettings({ ...settings, metrics_subheading: e.target.value })} disabled={!editable} /></FormField>
            </div>
          </SectionCard>

          <SectionCard title="Report Feature Block">
            <div className="space-y-4">
              <FormField label="Heading"><Input value={settings.report_block_heading ?? ''} onChange={(e) => setSettings({ ...settings, report_block_heading: e.target.value })} disabled={!editable} /></FormField>
              <FormField label="Subheading"><Input value={settings.report_block_subheading ?? ''} onChange={(e) => setSettings({ ...settings, report_block_subheading: e.target.value })} disabled={!editable} /></FormField>
              <FormField label="Body Text"><Textarea value={settings.report_block_body ?? ''} onChange={(e) => setSettings({ ...settings, report_block_body: e.target.value })} disabled={!editable} rows={4} /></FormField>
              <FormField label="CTA Text"><Input value={settings.report_block_cta_text ?? ''} onChange={(e) => setSettings({ ...settings, report_block_cta_text: e.target.value })} disabled={!editable} /></FormField>
            </div>
          </SectionCard>

          <SectionCard title="Gated Download Form">
            <div className="space-y-4">
              <FormField label="Form Heading"><Input value={settings.gated_form_heading ?? ''} onChange={(e) => setSettings({ ...settings, gated_form_heading: e.target.value })} disabled={!editable} /></FormField>
              <FormField label="Submit Button Label"><Input value={settings.gated_form_button_label ?? ''} onChange={(e) => setSettings({ ...settings, gated_form_button_label: e.target.value })} disabled={!editable} /></FormField>
              <FormField label="Report Download URL" hint="Shown to users after form submission"><Input value={settings.gated_report_url ?? ''} onChange={(e) => setSettings({ ...settings, gated_report_url: e.target.value })} disabled={!editable} /></FormField>
            </div>
          </SectionCard>

          <SectionCard title="Previous Reports Section Heading">
            <FormField label="Heading"><Input value={settings.previous_reports_heading ?? ''} onChange={(e) => setSettings({ ...settings, previous_reports_heading: e.target.value })} disabled={!editable} /></FormField>
          </SectionCard>

          {editable && (
            <div className="flex items-center gap-3">
              <SaveButton saving={saving} saved={saved} onClick={handleSettingsSave} />
            </div>
          )}
        </div>
      )}

      {tab === 'metrics' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm" style={{ color: '#858585' }}>Animated counter metrics shown on the Impact page.</p>
            {editable && !editingMetric && (
              <button onClick={() => setEditingMetric(emptyMetric())} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white" style={{ backgroundColor: '#01298A' }}>
                <Plus size={14} /> Add Metric
              </button>
            )}
          </div>

          {editingMetric && (
            <SectionCard title={editingMetric.id ? 'Edit Metric' : 'New Metric'}>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <FormField label="Number Value" required><Input value={editingMetric.number_value ?? ''} onChange={(e) => setEditingMetric({ ...editingMetric, number_value: e.target.value })} disabled={!editable} placeholder="291217" /></FormField>
                  <FormField label="Suffix" hint='e.g. "+"'><Input value={editingMetric.suffix ?? ''} onChange={(e) => setEditingMetric({ ...editingMetric, suffix: e.target.value })} disabled={!editable} /></FormField>
                  <FormField label="Unit" hint='e.g. " MT"'><Input value={editingMetric.unit ?? ''} onChange={(e) => setEditingMetric({ ...editingMetric, unit: e.target.value })} disabled={!editable} /></FormField>
                </div>
                <FormField label="Label" required><Input value={editingMetric.label ?? ''} onChange={(e) => setEditingMetric({ ...editingMetric, label: e.target.value })} disabled={!editable} /></FormField>
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Sort Order"><Input type="number" value={editingMetric.sort_order ?? 99} onChange={(e) => setEditingMetric({ ...editingMetric, sort_order: parseInt(e.target.value) })} disabled={!editable} /></FormField>
                  <FormField label="Active">
                    <div className="flex items-center gap-2 pt-2.5">
                      <input type="checkbox" checked={editingMetric.is_active ?? true} onChange={(e) => setEditingMetric({ ...editingMetric, is_active: e.target.checked })} disabled={!editable} className="w-4 h-4" />
                      <span className="text-sm" style={{ color: '#1A1A1A' }}>Visible</span>
                    </div>
                  </FormField>
                </div>
                <div className="flex items-center gap-3 pt-2">
                  <SaveButton saving={subSaving} saved={subSaved} onClick={handleMetricSave} />
                  <button onClick={() => setEditingMetric(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
                </div>
              </div>
            </SectionCard>
          )}

          {!editingMetric && (
            <div className="space-y-2">
              {metrics.map((m) => (
                <div key={m.id} className="bg-white border p-4 flex items-center gap-4" style={{ borderColor: '#E8E8E8' }}>
                  <GripVertical size={16} className="text-gray-300" />
                  <div className="flex-1">
                    <span className="text-xl font-bold mr-1" style={{ color: '#01298A' }}>{m.number_value}</span>
                    <span className="text-base font-bold" style={{ color: '#00C499' }}>{m.suffix}{m.unit}</span>
                    <p className="text-xs mt-0.5" style={{ color: '#858585' }}>{m.label}</p>
                  </div>
                  {editable && (
                    <div className="flex items-center gap-2">
                      <button onClick={() => setEditingMetric(m)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                      <button onClick={async () => { if (!confirm('Delete?')) return; await deleteImpactMetric(m.id); setMetrics((prev) => prev.filter((x) => x.id !== m.id)); }} className="p-1.5" style={{ color: '#ABABAB' }}
                        onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                        <Trash2 size={14} />
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'reports' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm" style={{ color: '#858585' }}>Downloadable previous impact reports.</p>
            {editable && !editingReport && (
              <button onClick={() => setEditingReport(emptyReport())} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white" style={{ backgroundColor: '#01298A' }}>
                <Plus size={14} /> Add Report
              </button>
            )}
          </div>

          {editingReport && (
            <SectionCard title={editingReport.id ? 'Edit Report' : 'New Report'}>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Year Label"><Input value={editingReport.year_label ?? ''} onChange={(e) => setEditingReport({ ...editingReport, year_label: e.target.value })} disabled={!editable} /></FormField>
                  <FormField label="Button Text"><Input value={editingReport.button_text ?? ''} onChange={(e) => setEditingReport({ ...editingReport, button_text: e.target.value })} disabled={!editable} /></FormField>
                </div>
                <FormField label="Report URL"><Input value={editingReport.report_url ?? ''} onChange={(e) => setEditingReport({ ...editingReport, report_url: e.target.value })} disabled={!editable} /></FormField>
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="pr-active" checked={editingReport.is_active ?? true} onChange={(e) => setEditingReport({ ...editingReport, is_active: e.target.checked })} disabled={!editable} className="w-4 h-4" />
                  <label htmlFor="pr-active" className="text-sm" style={{ color: '#1A1A1A' }}>Visible on website</label>
                </div>
                <div className="flex items-center gap-3 pt-2">
                  <SaveButton saving={subSaving} saved={subSaved} onClick={handleReportSave} />
                  <button onClick={() => setEditingReport(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
                </div>
              </div>
            </SectionCard>
          )}

          {!editingReport && (
            <div className="bg-white border" style={{ borderColor: '#E8E8E8' }}>
              {prevReports.length === 0 ? (
                <div className="px-5 py-10 text-center"><p className="text-sm" style={{ color: '#ABABAB' }}>No previous reports added yet.</p></div>
              ) : (
                <div className="divide-y" style={{ borderColor: '#F5F5F5' }}>
                  {prevReports.map((r) => (
                    <div key={r.id} className="px-5 py-4 flex items-center gap-4">
                      <div className="flex-1">
                        <p className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>{r.button_text}</p>
                        <p className="text-xs mt-0.5 truncate" style={{ color: '#ABABAB' }}>{r.report_url || 'No URL'}</p>
                      </div>
                      {editable && (
                        <div className="flex items-center gap-2">
                          <button onClick={() => setEditingReport(r)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                          <button onClick={async () => { if (!confirm('Delete?')) return; await deleteImpactPreviousReport(r.id); setPrevReports((prev) => prev.filter((x) => x.id !== r.id)); }} className="p-1.5" style={{ color: '#ABABAB' }}
                            onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                            <Trash2 size={14} />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {tab === 'leads' && (
        <div className="space-y-4">
          <p className="text-sm" style={{ color: '#858585' }}>Leads who filled the gated report download form.</p>
          {leads.length === 0 ? (
            <div className="bg-white border border-dashed p-10 text-center" style={{ borderColor: '#D1D1D1' }}>
              <p className="text-sm" style={{ color: '#ABABAB' }}>No leads yet.</p>
            </div>
          ) : (
            <div className="bg-white border overflow-hidden" style={{ borderColor: '#E8E8E8' }}>
              <div className="px-5 py-3 border-b" style={{ borderColor: '#E8E8E8' }}>
                <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#858585' }}>All Leads ({leads.length})</p>
              </div>
              <div className="divide-y" style={{ borderColor: '#F5F5F5' }}>
                {leads.map((lead) => (
                  <div key={lead.id} className="px-5 py-3 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium" style={{ color: '#1A1A1A' }}>{lead.full_name}</p>
                      <a href={`mailto:${lead.email}`} className="text-xs hover:underline" style={{ color: '#01298A' }}>{lead.email}</a>
                    </div>
                    <p className="text-xs" style={{ color: '#ABABAB' }}>{formatDate(lead.created_at)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
