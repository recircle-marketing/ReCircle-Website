import { useEffect, useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { getAccolades, upsertAccolade, deleteAccolade, getAccoladesMeta } from '../../cms/queries';
import { supabase } from '../../lib/supabase';
import { canEdit } from '../../lib/auth';
import type { Accolade, AccoladesSectionMeta } from '../../cms/types';
import { FormField, Input, SaveButton, SectionCard } from '../components/FormField';

export default function AccoladesEditor() {
  const [meta, setMeta] = useState<Partial<AccoladesSectionMeta>>({});
  const [accolades, setAccolades] = useState<Accolade[]>([]);
  const [editing, setEditing] = useState<Partial<Accolade> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [metaSaving, setMetaSaving] = useState(false);
  const [metaSaved, setMetaSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const editable = canEdit();

  useEffect(() => {
    Promise.all([getAccoladesMeta(), getAccolades()]).then(([m, a]) => {
      if (m) setMeta(m);
      setAccolades(a);
      setLoading(false);
    });
  }, []);

  const handleMetaSave = async () => {
    setMetaSaving(true);
    const { id, ...rest } = meta as AccoladesSectionMeta;
    if (id) await supabase.from('cms_accolades_section').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
    else await supabase.from('cms_accolades_section').insert(rest);
    setMetaSaving(false);
    setMetaSaved(true);
    setTimeout(() => setMetaSaved(false), 1500);
  };

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    await upsertAccolade(editing);
    const fresh = await getAccolades();
    setAccolades(fresh);
    setSaving(false);
    setSaved(true);
    setTimeout(() => { setSaved(false); setEditing(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Remove this award?')) return;
    await deleteAccolade(id);
    setAccolades((prev) => prev.filter((a) => a.id !== id));
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Accolades & Mentions</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Manage awards and recognition entries.</p>
      </div>

      <SectionCard title="Section Heading & Description">
        <div className="space-y-4">
          <FormField label="Section Heading"><Input value={meta.heading ?? ''} onChange={(e) => setMeta({ ...meta, heading: e.target.value })} disabled={!editable} /></FormField>
          <FormField label="Body Copy"><Input value={meta.body_copy ?? ''} onChange={(e) => setMeta({ ...meta, body_copy: e.target.value })} disabled={!editable} /></FormField>
          {editable && <SaveButton saving={metaSaving} saved={metaSaved} onClick={handleMetaSave}>Save Section Text</SaveButton>}
        </div>
      </SectionCard>

      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>Awards ({accolades.length})</h2>
        {editable && !editing && (
          <button onClick={() => setEditing({ sort_order: accolades.length + 1, is_active: true, org: '', award: '', detail: '', year: '', color: '#01298A', image_url: '', image_alt: '' })}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white" style={{ backgroundColor: '#01298A' }}>
            <Plus size={12} /> Add Award
          </button>
        )}
      </div>

      {!editing && (
        <div className="space-y-2">
          {accolades.map((acc) => (
            <div key={acc.id} className="bg-white border p-4 flex items-center gap-3" style={{ borderColor: '#E8E8E8' }}>
              <GripVertical size={16} className="text-gray-300 cursor-grab flex-shrink-0" />
              <div className="w-2 h-10 flex-shrink-0 rounded" style={{ backgroundColor: acc.color }} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold" style={{ color: '#858585' }}>{acc.org}</span>
                  <span className="text-xs px-1.5 py-0.5 rounded" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>{acc.year}</span>
                </div>
                <p className="text-sm font-medium mt-0.5 truncate" style={{ color: '#1A1A1A' }}>{acc.award}</p>
              </div>
              {editable && (
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button onClick={() => setEditing(acc)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                  <button onClick={() => handleDelete(acc.id)} className="p-1.5" style={{ color: '#ABABAB' }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {editing && (
        <SectionCard title={editing.id ? 'Edit Award' : 'New Award'}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Sort Order"><Input type="number" value={editing.sort_order ?? ''} onChange={(e) => setEditing({ ...editing, sort_order: parseInt(e.target.value) })} disabled={!editable} /></FormField>
              <FormField label="Year"><Input value={editing.year ?? ''} onChange={(e) => setEditing({ ...editing, year: e.target.value })} disabled={!editable} placeholder="2024" /></FormField>
            </div>
            <FormField label="Issuing Organisation" required><Input value={editing.org ?? ''} onChange={(e) => setEditing({ ...editing, org: e.target.value })} disabled={!editable} placeholder="BW Business World" /></FormField>
            <FormField label="Award Name" required><Input value={editing.award ?? ''} onChange={(e) => setEditing({ ...editing, award: e.target.value })} disabled={!editable} placeholder="Best Community Efforts for Recycling" /></FormField>
            <FormField label="Detail / Subtitle" hint="Optional sub-label (e.g. Finalists Top 5)">
              <Input value={editing.detail ?? ''} onChange={(e) => setEditing({ ...editing, detail: e.target.value })} disabled={!editable} placeholder="Finalists Top 5" />
            </FormField>
            <FormField label="Brand / Accent Color">
              <Input type="color" value={editing.color ?? '#01298A'} onChange={(e) => setEditing({ ...editing, color: e.target.value })} disabled={!editable} className="h-10 p-1 cursor-pointer" />
            </FormField>
            <FormField label="Award Image URL" hint="Photo of the award or certificate"><Input value={editing.image_url ?? ''} onChange={(e) => setEditing({ ...editing, image_url: e.target.value })} disabled={!editable} placeholder="https://..." /></FormField>
            <FormField label="Image Alt Text" required><Input value={editing.image_alt ?? ''} onChange={(e) => setEditing({ ...editing, image_alt: e.target.value })} disabled={!editable} placeholder="BW Business World award certificate" /></FormField>
            {editable && (
              <div className="flex items-center gap-3 pt-2">
                <SaveButton saving={saving} saved={saved} onClick={handleSave} />
                <button onClick={() => setEditing(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
              </div>
            )}
          </div>
        </SectionCard>
      )}
    </div>
  );
}
