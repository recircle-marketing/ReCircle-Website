import { useEffect, useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { getInvestors, upsertInvestor, deleteInvestor, getInvestorsMeta } from '../../cms/queries';
import { supabase } from '../../lib/supabase';
import { canEdit } from '../../lib/auth';
import type { Investor, InvestorsSectionMeta } from '../../cms/types';
import { FormField, Input, SaveButton, SectionCard } from '../components/FormField';

export default function InvestorsEditor() {
  const [meta, setMeta] = useState<Partial<InvestorsSectionMeta>>({});
  const [investors, setInvestors] = useState<Investor[]>([]);
  const [editing, setEditing] = useState<Partial<Investor> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [metaSaving, setMetaSaving] = useState(false);
  const [metaSaved, setMetaSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const editable = canEdit();

  useEffect(() => {
    Promise.all([getInvestorsMeta(), getInvestors()]).then(([m, inv]) => {
      if (m) setMeta(m);
      setInvestors(inv);
      setLoading(false);
    });
  }, []);

  const handleMetaSave = async () => {
    setMetaSaving(true);
    const { id, ...rest } = meta as InvestorsSectionMeta;
    if (id) await supabase.from('cms_investors_section').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
    else await supabase.from('cms_investors_section').insert(rest);
    setMetaSaving(false);
    setMetaSaved(true);
    setTimeout(() => setMetaSaved(false), 1500);
  };

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    await upsertInvestor(editing);
    const fresh = await getInvestors();
    setInvestors(fresh);
    setSaving(false);
    setSaved(true);
    setTimeout(() => { setSaved(false); setEditing(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Remove this investor?')) return;
    await deleteInvestor(id);
    setInvestors((prev) => prev.filter((i) => i.id !== id));
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Investors</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Manage the investors section and logo ticker.</p>
      </div>

      <SectionCard title="Section Heading & Description">
        <div className="space-y-4">
          <FormField label="Section Heading"><Input value={meta.heading ?? ''} onChange={(e) => setMeta({ ...meta, heading: e.target.value })} disabled={!editable} /></FormField>
          <FormField label="Body Copy"><Input value={meta.body_copy ?? ''} onChange={(e) => setMeta({ ...meta, body_copy: e.target.value })} disabled={!editable} /></FormField>
          {editable && <SaveButton saving={metaSaving} saved={metaSaved} onClick={handleMetaSave}>Save Section Text</SaveButton>}
        </div>
      </SectionCard>

      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>Investors ({investors.length})</h2>
        {editable && !editing && (
          <button onClick={() => setEditing({ sort_order: investors.length + 1, is_active: true, name: '', abbr: '', color: '#01298A', logo_url: '', logo_alt: '' })}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white" style={{ backgroundColor: '#01298A' }}>
            <Plus size={12} /> Add Investor
          </button>
        )}
      </div>

      {!editing && (
        <div className="space-y-2">
          {investors.map((inv) => (
            <div key={inv.id} className="bg-white border p-4 flex items-center gap-3" style={{ borderColor: '#E8E8E8' }}>
              <GripVertical size={16} className="text-gray-300 cursor-grab" />
              <div className="w-8 h-8 rounded flex items-center justify-center text-white text-xs font-bold flex-shrink-0" style={{ backgroundColor: inv.color }}>{inv.abbr}</div>
              <span className="flex-1 text-sm font-medium" style={{ color: '#1A1A1A' }}>{inv.name}</span>
              {editable && (
                <div className="flex items-center gap-2">
                  <button onClick={() => setEditing(inv)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                  <button onClick={() => handleDelete(inv.id)} className="p-1.5" style={{ color: '#ABABAB' }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {editing && (
        <SectionCard title={editing.id ? 'Edit Investor' : 'New Investor'}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Sort Order"><Input type="number" value={editing.sort_order ?? ''} onChange={(e) => setEditing({ ...editing, sort_order: parseInt(e.target.value) })} disabled={!editable} /></FormField>
              <FormField label="Abbreviation" hint="2-3 letter mark (e.g. FV, AC)">
                <Input value={editing.abbr ?? ''} onChange={(e) => setEditing({ ...editing, abbr: e.target.value })} disabled={!editable} placeholder="FV" maxLength={4} />
              </FormField>
            </div>
            <FormField label="Investor Name" required><Input value={editing.name ?? ''} onChange={(e) => setEditing({ ...editing, name: e.target.value })} disabled={!editable} placeholder="Flipkart Ventures" /></FormField>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Brand Color" hint="Hex color for the logo mark">
                <Input type="color" value={editing.color ?? '#01298A'} onChange={(e) => setEditing({ ...editing, color: e.target.value })} disabled={!editable} className="h-10 p-1 cursor-pointer" />
              </FormField>
            </div>
            <FormField label="Logo Image URL" hint="Optional — leave blank to show the text abbreviation mark">
              <Input value={editing.logo_url ?? ''} onChange={(e) => setEditing({ ...editing, logo_url: e.target.value })} disabled={!editable} placeholder="https://..." />
            </FormField>
            <FormField label="Logo Alt Text" required>
              <Input value={editing.logo_alt ?? ''} onChange={(e) => setEditing({ ...editing, logo_alt: e.target.value })} disabled={!editable} placeholder="Flipkart Ventures logo" />
            </FormField>
            {editable && (
              <div className="flex items-center gap-3 pt-2">
                <SaveButton saving={saving} saved={saved} onClick={handleSave} />
                <button onClick={() => setEditing(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
              </div>
            )}
          </div>
        </SectionCard>
      )}
    </div>
  );
}
