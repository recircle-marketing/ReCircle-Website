import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import {
  getWebinarsPageSettings, upsertWebinarsPageSettings,
  getWebinarItems, upsertWebinarItem, deleteWebinarItem,
} from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { WebinarsPageSettings, WebinarItem } from '../../cms/types';
import { FormField, Input, Textarea, Select, SaveButton, SectionCard } from '../components/FormField';

const emptyWebinar = (): Partial<WebinarItem> => ({
  title: '', youtube_url: '', thumbnail_url: '', thumbnail_alt: '',
  description: '', publish_date: null, is_active: true, webinar_status: 'past',
});

export default function WebinarsEditor() {
  const [settings, setSettings] = useState<Partial<WebinarsPageSettings>>({});
  const [items, setItems] = useState<WebinarItem[]>([]);
  const [editingItem, setEditingItem] = useState<Partial<WebinarItem> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [iSaving, setISaving] = useState(false);
  const [iSaved, setISaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    Promise.all([getWebinarsPageSettings(), getWebinarItems(true)]).then(([s, i]) => {
      if (s) setSettings(s);
      setItems(i);
      setLoading(false);
    });
  }, []);

  const handleSettingsSave = async () => {
    setSaving(true);
    await upsertWebinarsPageSettings(settings);
    await logAudit('webinars_page', settings.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, settings.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const handleItemSave = async () => {
    if (!editingItem) return;
    setISaving(true);
    await upsertWebinarItem(editingItem);
    const fresh = await getWebinarItems(true);
    setItems(fresh);
    setISaving(false);
    setISaved(true);
    setTimeout(() => { setISaved(false); setEditingItem(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this webinar?')) return;
    await deleteWebinarItem(id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Webinars</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Configure YouTube source or manage manual webinar entries.</p>
      </div>

      <SectionCard title="Page Settings">
        <div className="space-y-4">
          <FormField label="Page Heading"><Input value={settings.page_heading ?? ''} onChange={(e) => setSettings({ ...settings, page_heading: e.target.value })} disabled={!editable} /></FormField>
          <FormField label="Page Intro"><Textarea value={settings.page_intro ?? ''} onChange={(e) => setSettings({ ...settings, page_intro: e.target.value })} disabled={!editable} rows={2} /></FormField>
        </div>
      </SectionCard>

      <SectionCard title="Entry Mode" description="Choose how webinars are sourced — auto-fetched from YouTube or manually entered below.">
        <div className="space-y-4">
          <FormField label="Mode">
            <Select value={settings.entry_mode ?? 'manual'} onChange={(e) => setSettings({ ...settings, entry_mode: e.target.value as 'auto' | 'manual' })} disabled={!editable}>
              <option value="manual">Manual entries (managed below)</option>
              <option value="auto">Auto-fetch from YouTube (requires API key)</option>
            </Select>
          </FormField>
          {settings.entry_mode === 'auto' && (
            <>
              {/* YOUTUBE_API_KEY_NOTICE: Set VITE_YOUTUBE_API_KEY in your .env file to enable auto-fetch. */}
              <FormField label="YouTube Source Type">
                <Select value={settings.source_type ?? 'channel'} onChange={(e) => setSettings({ ...settings, source_type: e.target.value })} disabled={!editable}>
                  <option value="channel">Channel ID</option>
                  <option value="playlist">Playlist ID</option>
                </Select>
              </FormField>
              <FormField label="Channel or Playlist ID" hint="Paste the YouTube channel ID or playlist ID here">
                <Input value={settings.youtube_source_id ?? ''} onChange={(e) => setSettings({ ...settings, youtube_source_id: e.target.value })} disabled={!editable} placeholder="UCxxxxxxxxxxxxxxxx" />
              </FormField>
            </>
          )}
        </div>
      </SectionCard>

      {editable && (
        <div className="flex items-center gap-3">
          <SaveButton saving={saving} saved={saved} onClick={handleSettingsSave} />
        </div>
      )}

      {/* Manual entries */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold" style={{ color: '#1A1A1A' }}>Manual Entries ({items.length})</h2>
          {editable && !editingItem && (
            <button onClick={() => setEditingItem(emptyWebinar())} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white" style={{ backgroundColor: '#01298A' }}>
              <Plus size={14} /> Add Webinar
            </button>
          )}
        </div>

        {editingItem && (
          <SectionCard title={editingItem.id ? 'Edit Webinar' : 'New Webinar'}>
            <div className="space-y-4">
              <FormField label="Title" required><Input value={editingItem.title ?? ''} onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })} disabled={!editable} /></FormField>
              <FormField label="YouTube URL"><Input value={editingItem.youtube_url ?? ''} onChange={(e) => setEditingItem({ ...editingItem, youtube_url: e.target.value })} disabled={!editable} placeholder="https://www.youtube.com/watch?v=…" /></FormField>
              <div className="grid grid-cols-2 gap-4">
                <FormField label="Thumbnail URL"><Input value={editingItem.thumbnail_url ?? ''} onChange={(e) => setEditingItem({ ...editingItem, thumbnail_url: e.target.value })} disabled={!editable} /></FormField>
                <FormField label="Publish Date"><Input type="date" value={editingItem.publish_date ?? ''} onChange={(e) => setEditingItem({ ...editingItem, publish_date: e.target.value })} disabled={!editable} /></FormField>
              </div>
              <FormField label="Description"><Textarea value={editingItem.description ?? ''} onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })} disabled={!editable} rows={2} /></FormField>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="web-active" checked={editingItem.is_active ?? true} onChange={(e) => setEditingItem({ ...editingItem, is_active: e.target.checked })} disabled={!editable} className="w-4 h-4" />
                <label htmlFor="web-active" className="text-sm" style={{ color: '#1A1A1A' }}>Active (visible)</label>
              </div>
              <div className="flex items-center gap-3 pt-2">
                <SaveButton saving={iSaving} saved={iSaved} onClick={handleItemSave} />
                <button onClick={() => setEditingItem(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
              </div>
            </div>
          </SectionCard>
        )}

        {!editingItem && (
          <div className="bg-white border overflow-hidden" style={{ borderColor: '#E8E8E8' }}>
            {items.length === 0 ? (
              <div className="px-5 py-10 text-center"><p className="text-sm" style={{ color: '#ABABAB' }}>No manual entries yet.</p></div>
            ) : (
              <div className="divide-y" style={{ borderColor: '#F5F5F5' }}>
                {items.map((item) => (
                  <div key={item.id} className="px-5 py-4 flex items-center gap-4">
                    {item.thumbnail_url && (
                      <img src={item.thumbnail_url} alt={item.title} className="w-16 h-10 object-cover flex-shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate" style={{ color: '#1A1A1A' }}>{item.title}</p>
                      <p className="text-xs mt-0.5" style={{ color: '#ABABAB' }}>{item.publish_date ?? 'No date'}</p>
                    </div>
                    {editable && (
                      <div className="flex items-center gap-2">
                        <button onClick={() => setEditingItem(item)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                        <button onClick={() => handleDelete(item.id)} className="p-1.5" style={{ color: '#ABABAB' }}
                          onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
