import { useEffect, useState } from 'react';
import { Save, Plus, Trash2, ChevronDown, ChevronUp, Image as ImageIcon } from 'lucide-react';
import {
  getRpetPageSettings, upsertRpetPageSettings,
  getRpetApplicationsAll, upsertRpetApplication, deleteRpetApplication,
  getRpetAdvantageCardsAll, upsertRpetAdvantageCard, deleteRpetAdvantageCard,
  getRpetBenchmarkCardsAll, upsertRpetBenchmarkCard, deleteRpetBenchmarkCard,
  logAudit,
} from '../../cms/queries';
import { getCurrentUser } from '../../lib/auth';
import type { RpetPageSettings, RpetApplication, RpetAdvantageCard, RpetBenchmarkCard } from '../../cms/types';

// ── Tab definition ───────────────────────────────────────────────────────────
const TABS = ['Page Content', 'Applications', 'Advantage Cards', 'Benchmark Cards'] as const;
type Tab = typeof TABS[number];

// ── Shared helpers ───────────────────────────────────────────────────────────
const inputCls = 'w-full px-4 py-2.5 border text-sm focus:outline-none';
const inputStyle = { borderColor: '#D1D1D1' };
const inputFocus = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => { e.currentTarget.style.borderColor = '#01298A'; };
const inputBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => { e.currentTarget.style.borderColor = '#D1D1D1'; };

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>{label}</label>
      {children}
    </div>
  );
}

function SaveBar({ saving, saved, onSave }: { saving: boolean; saved: boolean; onSave: () => void }) {
  return (
    <div className="flex items-center gap-3 pt-5 mt-6 border-t" style={{ borderColor: '#F0F0F0' }}>
      <button
        onClick={onSave}
        disabled={saving}
        className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white transition-opacity disabled:opacity-60"
        style={{ backgroundColor: '#01298A' }}
      >
        <Save size={14} />
        {saving ? 'Saving…' : saved ? 'Saved!' : 'Save Changes'}
      </button>
      {saved && <span className="text-xs font-medium" style={{ color: '#00C499' }}>Changes saved successfully</span>}
    </div>
  );
}

// ── Collapsible section ───────────────────────────────────────────────────────
function Collapsible({ title, defaultOpen = false, children }: { title: string; defaultOpen?: boolean; children: React.ReactNode }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border mb-4" style={{ borderColor: '#E8E8E8' }}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-6 py-4 text-left bg-white"
      >
        <span className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>{title}</span>
        {open ? <ChevronUp size={15} style={{ color: '#858585' }} /> : <ChevronDown size={15} style={{ color: '#858585' }} />}
      </button>
      {open && <div className="px-6 pb-6 bg-white border-t" style={{ borderColor: '#F0F0F0' }}><div className="pt-5">{children}</div></div>}
    </div>
  );
}

// ── Page Content Tab ─────────────────────────────────────────────────────────
function PageContentTab({ settings, settingsId }: { settings: RpetPageSettings; settingsId: string | null }) {
  const [form, setForm] = useState<RpetPageSettings>(settings);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const user = getCurrentUser();

  const set = (key: keyof RpetPageSettings, val: string) => { setForm((f) => ({ ...f, [key]: val })); setSaved(false); };

  const handleSave = async () => {
    setSaving(true);
    await upsertRpetPageSettings({ ...form, id: settingsId ?? form.id });
    await logAudit('rpet_page_settings', 'updated', user?.full_name ?? 'Admin', user?.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="space-y-4">
      {/* Hero */}
      <Collapsible title="Hero Section" defaultOpen>
        <div className="space-y-4">
          <Field label="Heading">
            <input type="text" value={form.hero_heading} onChange={(e) => set('hero_heading', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Body Copy">
            <textarea rows={4} value={form.hero_body} onChange={(e) => set('hero_body', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="CTA Label">
              <input type="text" value={form.hero_cta_label} onChange={(e) => set('hero_cta_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
            <Field label="CTA URL">
              <input type="text" value={form.hero_cta_href} onChange={(e) => set('hero_cta_href', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
          </div>
          <Field label="Hero Image URL">
            <input type="url" value={form.hero_image_url} onChange={(e) => set('hero_image_url', e.target.value)} placeholder="https://…" className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          {form.hero_image_url && (
            <img src={form.hero_image_url} alt="Hero preview" className="h-32 object-cover mt-2 border" style={{ borderColor: '#E8E8E8' }} />
          )}
        </div>
      </Collapsible>

      {/* Applications (intro only — items managed in own tab) */}
      <Collapsible title="Applications Section">
        <div className="space-y-4">
          <Field label="Section Label">
            <input type="text" value={form.applications_label} onChange={(e) => set('applications_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Intro Text">
            <input type="text" value={form.applications_intro} onChange={(e) => set('applications_intro', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
        </div>
      </Collapsible>

      {/* Technical Specs */}
      <Collapsible title="Technical Specifications Section">
        <div className="space-y-4">
          <Field label="Section Label">
            <input type="text" value={form.tech_specs_label} onChange={(e) => set('tech_specs_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Heading">
            <input type="text" value={form.tech_specs_heading} onChange={(e) => set('tech_specs_heading', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Body Copy">
            <textarea rows={4} value={form.tech_specs_body} onChange={(e) => set('tech_specs_body', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="CTA Label">
              <input type="text" value={form.tech_specs_cta_label} onChange={(e) => set('tech_specs_cta_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
            <Field label="CTA URL">
              <input type="text" value={form.tech_specs_cta_href} onChange={(e) => set('tech_specs_cta_href', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
          </div>
          <Field label="Spec Sheet Image URL">
            <input type="url" value={form.tech_specs_image_url} onChange={(e) => set('tech_specs_image_url', e.target.value)} placeholder="https://…" className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          {form.tech_specs_image_url && (
            <img src={form.tech_specs_image_url} alt="Spec sheet preview" className="h-24 object-cover mt-2 border" style={{ borderColor: '#E8E8E8' }} />
          )}
        </div>
      </Collapsible>

      {/* Operational Advantages (heading/body only — cards in own tab) */}
      <Collapsible title="Operational Advantages Section">
        <div className="space-y-4">
          <Field label="Section Label">
            <input type="text" value={form.advantages_label} onChange={(e) => set('advantages_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Heading">
            <input type="text" value={form.advantages_heading} onChange={(e) => set('advantages_heading', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Body Copy">
            <textarea rows={4} value={form.advantages_body} onChange={(e) => set('advantages_body', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
        </div>
      </Collapsible>

      {/* Quality Benchmarks */}
      <Collapsible title="Quality Benchmarks Section">
        <div className="space-y-4">
          <Field label="Section Label">
            <input type="text" value={form.benchmarks_label} onChange={(e) => set('benchmarks_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Heading">
            <input type="text" value={form.benchmarks_heading} onChange={(e) => set('benchmarks_heading', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Intro Text">
            <textarea rows={3} value={form.benchmarks_intro} onChange={(e) => set('benchmarks_intro', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="CTA Label">
              <input type="text" value={form.benchmarks_cta_label} onChange={(e) => set('benchmarks_cta_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
            <Field label="CTA URL">
              <input type="text" value={form.benchmarks_cta_href} onChange={(e) => set('benchmarks_cta_href', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
          </div>
        </div>
      </Collapsible>

      {/* ClimaOne */}
      <Collapsible title="ClimaOne Traceability Section">
        <div className="space-y-4">
          <Field label="Section Label">
            <input type="text" value={form.climaone_label} onChange={(e) => set('climaone_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Heading">
            <input type="text" value={form.climaone_heading} onChange={(e) => set('climaone_heading', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Body Paragraph 1">
            <textarea rows={3} value={form.climaone_body_1} onChange={(e) => set('climaone_body_1', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Body Paragraph 2">
            <textarea rows={3} value={form.climaone_body_2} onChange={(e) => set('climaone_body_2', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="CTA Label">
              <input type="text" value={form.climaone_cta_label} onChange={(e) => set('climaone_cta_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
            <Field label="CTA URL">
              <input type="text" value={form.climaone_cta_href} onChange={(e) => set('climaone_cta_href', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
          </div>
          <Field label="Platform Image URL">
            <input type="url" value={form.climaone_image_url} onChange={(e) => set('climaone_image_url', e.target.value)} placeholder="https://…" className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          {form.climaone_image_url && (
            <img src={form.climaone_image_url} alt="ClimaOne preview" className="h-24 object-cover mt-2 border" style={{ borderColor: '#E8E8E8' }} />
          )}
        </div>
      </Collapsible>

      {/* Certifications */}
      <Collapsible title="Certifications Section">
        <div className="space-y-4">
          <Field label="Section Label">
            <input type="text" value={form.certifications_label} onChange={(e) => set('certifications_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Heading">
            <input type="text" value={form.certifications_heading} onChange={(e) => set('certifications_heading', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Body Copy">
            <textarea rows={4} value={form.certifications_body} onChange={(e) => set('certifications_body', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Certification Image URL">
            <input type="url" value={form.certifications_image_url} onChange={(e) => set('certifications_image_url', e.target.value)} placeholder="https://…" className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          {form.certifications_image_url && (
            <img src={form.certifications_image_url} alt="Certs preview" className="h-24 object-cover mt-2 border" style={{ borderColor: '#E8E8E8' }} />
          )}
        </div>
      </Collapsible>

      {/* Contact Band */}
      <Collapsible title="Contact CTA Band">
        <div className="space-y-4">
          <Field label="Section Label">
            <input type="text" value={form.contact_band_label} onChange={(e) => set('contact_band_label', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Heading">
            <input type="text" value={form.contact_band_heading} onChange={(e) => set('contact_band_heading', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <Field label="Body Copy">
            <textarea rows={3} value={form.contact_band_body} onChange={(e) => set('contact_band_body', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Email">
              <input type="email" value={form.contact_band_email} onChange={(e) => set('contact_band_email', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
            <Field label="Phone">
              <input type="text" value={form.contact_band_phone} onChange={(e) => set('contact_band_phone', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
          </div>
        </div>
      </Collapsible>

      <SaveBar saving={saving} saved={saved} onSave={handleSave} />
    </div>
  );
}

// ── Applications Tab ─────────────────────────────────────────────────────────
function ApplicationsTab() {
  const [items, setItems] = useState<RpetApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const user = getCurrentUser();

  useEffect(() => {
    getRpetApplicationsAll().then((data) => { setItems(data); setLoading(false); });
  }, []);

  const update = (id: string, key: keyof RpetApplication, val: string | boolean) => {
    setItems((prev) => prev.map((x) => (x.id === id ? { ...x, [key]: val } : x)));
  };

  const handleSave = async (item: RpetApplication) => {
    setSaving(item.id);
    await upsertRpetApplication(item);
    await logAudit('rpet_application', 'updated', user?.full_name ?? 'Admin', user?.id, item.id);
    setSaving(null);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this application tab?')) return;
    await deleteRpetApplication(id);
    setItems((prev) => prev.filter((x) => x.id !== id));
  };

  const handleAdd = () => {
    const temp = 'new-' + Date.now();
    setItems((prev) => [...prev, {
      id: temp, sort_order: prev.length + 1, is_active: true,
      title: '', spec_callout: '', image_url: '', image_alt: '', created_at: '', updated_at: '',
    }]);
  };

  if (loading) return <div className="flex items-center justify-center py-12"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {items.map((item) => (
        <div key={item.id} className="bg-white border p-6" style={{ borderColor: '#E8E8E8' }}>
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold uppercase tracking-wider" style={{ color: '#858585' }}>Tab #{item.sort_order}</span>
            <div className="flex items-center gap-3">
              <button
                onClick={() => update(item.id, 'is_active', !item.is_active)}
                className="w-9 h-5 relative rounded-full transition-colors duration-200"
                style={{ backgroundColor: item.is_active ? '#00C499' : '#D1D1D1' }}
              >
                <span className="absolute top-0.5 w-4 h-4 bg-white rounded-full transition-all duration-200" style={{ left: item.is_active ? '17px' : '2px' }} />
              </button>
              <button onClick={() => handleDelete(item.id)} className="text-gray-300 hover:text-red-500 transition-colors" title="Delete">
                <Trash2 size={15} />
              </button>
            </div>
          </div>
          <div className="space-y-4">
            <Field label="Title">
              <input type="text" value={item.title} onChange={(e) => update(item.id, 'title', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
            <Field label="Spec Callout">
              <textarea rows={2} value={item.spec_callout} onChange={(e) => update(item.id, 'spec_callout', e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Image URL">
                <input type="url" value={item.image_url} onChange={(e) => update(item.id, 'image_url', e.target.value)} placeholder="https://…" className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
              </Field>
              <Field label="Image Alt Text">
                <input type="text" value={item.image_alt} onChange={(e) => update(item.id, 'image_alt', e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
              </Field>
            </div>
            {item.image_url && <img src={item.image_url} alt={item.image_alt} className="h-20 object-cover border" style={{ borderColor: '#E8E8E8' }} />}
          </div>
          <button
            onClick={() => handleSave(item)}
            disabled={saving === item.id}
            className="mt-4 inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
            style={{ backgroundColor: '#01298A' }}
          >
            <Save size={13} />
            {saving === item.id ? 'Saving…' : 'Save Tab'}
          </button>
        </div>
      ))}
      <button
        onClick={handleAdd}
        className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed text-sm font-medium transition-colors"
        style={{ borderColor: '#D1D1D1', color: '#858585' }}
        onMouseEnter={(e) => { e.currentTarget.style.borderColor = '#01298A'; e.currentTarget.style.color = '#01298A'; }}
        onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; e.currentTarget.style.color = '#858585'; }}
      >
        <Plus size={15} /> Add Application Tab
      </button>
    </div>
  );
}

// ── Generic card list tab ─────────────────────────────────────────────────────
type AnyCard = RpetAdvantageCard | RpetBenchmarkCard;

function CardListTab<T extends AnyCard>({
  fetchAll, upsert, remove, auditType, addLabel,
}: {
  fetchAll: () => Promise<T[]>;
  upsert: (item: Partial<T> & { id?: string }) => Promise<unknown>;
  remove: (id: string) => Promise<unknown>;
  auditType: string;
  addLabel: string;
}) {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const user = getCurrentUser();

  useEffect(() => {
    fetchAll().then((data) => { setItems(data); setLoading(false); });
  }, []);

  const update = (id: string, key: keyof T, val: string | boolean) => {
    setItems((prev) => prev.map((x) => (x.id === id ? { ...x, [key]: val } : x)));
  };

  const handleSave = async (item: T) => {
    setSaving(item.id);
    await upsert(item);
    await logAudit(auditType, 'updated', user?.full_name ?? 'Admin', user?.id, item.id);
    setSaving(null);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this card?')) return;
    await remove(id);
    setItems((prev) => prev.filter((x) => x.id !== id));
  };

  const handleAdd = () => {
    const temp = 'new-' + Date.now();
    setItems((prev) => [...prev, {
      id: temp, sort_order: prev.length + 1, is_active: true,
      icon_name: 'CheckCircle', heading: '', body: '', created_at: '', updated_at: '',
    } as unknown as T]);
  };

  if (loading) return <div className="flex items-center justify-center py-12"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {items.map((item) => (
        <div key={item.id} className="bg-white border p-6" style={{ borderColor: '#E8E8E8' }}>
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold uppercase tracking-wider" style={{ color: '#858585' }}>Card #{item.sort_order}</span>
            <div className="flex items-center gap-3">
              <button
                onClick={() => update(item.id, 'is_active' as keyof T, !item.is_active)}
                className="w-9 h-5 relative rounded-full transition-colors duration-200"
                style={{ backgroundColor: item.is_active ? '#00C499' : '#D1D1D1' }}
              >
                <span className="absolute top-0.5 w-4 h-4 bg-white rounded-full transition-all duration-200" style={{ left: item.is_active ? '17px' : '2px' }} />
              </button>
              <button onClick={() => handleDelete(item.id)} className="text-gray-300 hover:text-red-500 transition-colors" title="Delete">
                <Trash2 size={15} />
              </button>
            </div>
          </div>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Field label="Icon Name">
                <input type="text" value={item.icon_name} onChange={(e) => update(item.id, 'icon_name' as keyof T, e.target.value)} placeholder="e.g. Filter, Recycle, Eye…" className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
              </Field>
              <Field label="Sort Order">
                <input type="number" value={item.sort_order} onChange={(e) => update(item.id, 'sort_order' as keyof T, e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
              </Field>
            </div>
            <Field label="Heading">
              <input type="text" value={item.heading} onChange={(e) => update(item.id, 'heading' as keyof T, e.target.value)} className={inputCls} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
            <Field label="Body Copy">
              <textarea rows={3} value={item.body} onChange={(e) => update(item.id, 'body' as keyof T, e.target.value)} className={`${inputCls} resize-none`} style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
            </Field>
          </div>
          <button
            onClick={() => handleSave(item)}
            disabled={saving === item.id}
            className="mt-4 inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
            style={{ backgroundColor: '#01298A' }}
          >
            <Save size={13} />
            {saving === item.id ? 'Saving…' : 'Save Card'}
          </button>
        </div>
      ))}
      <button
        onClick={handleAdd}
        className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed text-sm font-medium transition-colors"
        style={{ borderColor: '#D1D1D1', color: '#858585' }}
        onMouseEnter={(e) => { e.currentTarget.style.borderColor = '#01298A'; e.currentTarget.style.color = '#01298A'; }}
        onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; e.currentTarget.style.color = '#858585'; }}
      >
        <Plus size={15} /> {addLabel}
      </button>
    </div>
  );
}

// ── Main Editor ───────────────────────────────────────────────────────────────
export default function RPetFlakesEditor() {
  const [activeTab, setActiveTab] = useState<Tab>('Page Content');
  const [settings, setSettings] = useState<RpetPageSettings | null>(null);
  const [settingsId, setSettingsId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getRpetPageSettings().then((data) => {
      if (data) { setSettings(data); setSettingsId(data.id); }
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-7 h-7 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1" style={{ color: '#1A1A1A' }}>rPET Flakes Page</h1>
          <p className="text-sm" style={{ color: '#858585' }}>Manage all content for the /rpet-flakes product page.</p>
        </div>
        <a
          href="/rpet-flakes"
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs font-medium px-3 py-1.5 border transition-colors"
          style={{ color: '#858585', borderColor: '#D1D1D1' }}
          onMouseEnter={(e) => { e.currentTarget.style.color = '#01298A'; e.currentTarget.style.borderColor = '#01298A'; }}
          onMouseLeave={(e) => { e.currentTarget.style.color = '#858585'; e.currentTarget.style.borderColor = '#D1D1D1'; }}
        >
          View Page ↗
        </a>
      </div>

      {/* Tab nav */}
      <div className="flex border-b mb-6 gap-0" style={{ borderColor: '#E8E8E8' }}>
        {TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className="px-5 py-3 text-sm font-medium border-b-2 transition-colors duration-150 -mb-px"
            style={{
              borderBottomColor: activeTab === tab ? '#01298A' : 'transparent',
              color: activeTab === tab ? '#01298A' : '#858585',
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'Page Content' && settings && (
        <PageContentTab settings={settings} settingsId={settingsId} />
      )}
      {activeTab === 'Applications' && <ApplicationsTab />}
      {activeTab === 'Advantage Cards' && (
        <CardListTab<RpetAdvantageCard>
          fetchAll={getRpetAdvantageCardsAll}
          upsert={upsertRpetAdvantageCard}
          remove={deleteRpetAdvantageCard}
          auditType="rpet_advantage_card"
          addLabel="Add Advantage Card"
        />
      )}
      {activeTab === 'Benchmark Cards' && (
        <CardListTab<RpetBenchmarkCard>
          fetchAll={getRpetBenchmarkCardsAll}
          upsert={upsertRpetBenchmarkCard}
          remove={deleteRpetBenchmarkCard}
          auditType="rpet_benchmark_card"
          addLabel="Add Benchmark Card"
        />
      )}

      {/* Image note */}
      <div className="mt-6 p-4 border border-dashed flex items-start gap-3 text-xs" style={{ borderColor: '#D1D1D1', color: '#858585' }}>
        <ImageIcon size={14} className="mt-0.5 shrink-0" />
        <span>Image fields accept any public URL. Stock images from Pexels are currently used as placeholders — paste your final product images here to replace them.</span>
      </div>
    </div>
  );
}
