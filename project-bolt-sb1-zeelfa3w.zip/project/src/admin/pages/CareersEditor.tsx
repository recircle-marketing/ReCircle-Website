import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import {
  getCareersPageSettings, upsertCareersPageSettings,
  getCareers, upsertCareer, deleteCareer,
} from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { CareersPageSettings, Career, QuestionCard } from '../../cms/types';
import { FormField, Input, Textarea, Select, SaveButton, SectionCard } from '../components/FormField';

const emptyJob = (): Partial<Career> => ({
  title: '', department: '', location: '', job_type: 'full-time',
  description: '', application_link: '', status: 'draft',
});

export default function CareersEditor() {
  const [settings, setSettings] = useState<Partial<CareersPageSettings>>({});
  const [jobs, setJobs] = useState<Career[]>([]);
  const [editingJob, setEditingJob] = useState<Partial<Career> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [jobSaving, setJobSaving] = useState(false);
  const [jobSaved, setJobSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    Promise.all([getCareersPageSettings(), getCareers(true)]).then(([s, j]) => {
      if (s) setSettings(s);
      setJobs(j);
      setLoading(false);
    });
  }, []);

  const handleSettingsSave = async () => {
    setSaving(true);
    await upsertCareersPageSettings(settings);
    await logAudit('careers_page', settings.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, settings.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const handleJobSave = async () => {
    if (!editingJob) return;
    setJobSaving(true);
    await upsertCareer(editingJob);
    await logAudit('career_job', editingJob.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, editingJob.id);
    const fresh = await getCareers(true);
    setJobs(fresh);
    setJobSaving(false);
    setJobSaved(true);
    setTimeout(() => { setJobSaved(false); setEditingJob(null); }, 1200);
  };

  const handleDeleteJob = async (id: string) => {
    if (!confirm('Delete this job listing?')) return;
    await deleteCareer(id);
    setJobs((prev) => prev.filter((j) => j.id !== id));
  };

  const cards: QuestionCard[] = Array.isArray(settings.question_cards) ? settings.question_cards as QuestionCard[] : [];

  const updateCard = (i: number, field: keyof QuestionCard, val: string) => {
    const arr = [...cards];
    arr[i] = { ...arr[i], [field]: val };
    setSettings({ ...settings, question_cards: arr });
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  if (editingJob) {
    return (
      <div className="max-w-3xl space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>{editingJob.id ? 'Edit Job' : 'New Job Listing'}</h1>
          <button onClick={() => setEditingJob(null)} className="text-sm px-4 py-2 border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
        </div>
        <SectionCard title="Job Details">
          <div className="space-y-4">
            <FormField label="Job Title" required>
              <Input value={editingJob.title ?? ''} onChange={(e) => setEditingJob({ ...editingJob, title: e.target.value })} disabled={!editable} />
            </FormField>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Department">
                <Input value={editingJob.department ?? ''} onChange={(e) => setEditingJob({ ...editingJob, department: e.target.value })} disabled={!editable} placeholder="Marketing, Engineering…" />
              </FormField>
              <FormField label="Location">
                <Input value={editingJob.location ?? ''} onChange={(e) => setEditingJob({ ...editingJob, location: e.target.value })} disabled={!editable} placeholder="Mumbai, Remote…" />
              </FormField>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Employment Type">
                <Select value={editingJob.job_type ?? 'full-time'} onChange={(e) => setEditingJob({ ...editingJob, job_type: e.target.value as Career['job_type'] })} disabled={!editable}>
                  <option value="full-time">Full Time</option>
                  <option value="part-time">Part Time</option>
                  <option value="contract">Contract</option>
                  <option value="internship">Internship</option>
                </Select>
              </FormField>
              <FormField label="Status">
                <Select value={editingJob.status ?? 'draft'} onChange={(e) => setEditingJob({ ...editingJob, status: e.target.value as Career['status'] })} disabled={!editable}>
                  <option value="draft">Draft (hidden)</option>
                  <option value="active">Active (visible)</option>
                </Select>
              </FormField>
            </div>
            <FormField label="Short Description" required>
              <Textarea value={editingJob.description ?? ''} onChange={(e) => setEditingJob({ ...editingJob, description: e.target.value })} disabled={!editable} rows={3} />
            </FormField>
            <FormField label="Application URL">
              <Input value={editingJob.application_link ?? ''} onChange={(e) => setEditingJob({ ...editingJob, application_link: e.target.value })} disabled={!editable} placeholder="https://forms.google.com/…" />
            </FormField>
          </div>
        </SectionCard>
        {editable && (
          <div className="flex items-center gap-3">
            <SaveButton saving={jobSaving} saved={jobSaved} onClick={handleJobSave} />
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Careers Page</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Edit page content and manage job listings.</p>
      </div>

      <SectionCard title="Hero Section">
        <div className="space-y-4">
          <FormField label="Heading" required><Input value={settings.hero_heading ?? ''} onChange={(e) => setSettings({ ...settings, hero_heading: e.target.value })} disabled={!editable} /></FormField>
          <FormField label="Body Text"><Textarea value={settings.hero_body ?? ''} onChange={(e) => setSettings({ ...settings, hero_body: e.target.value })} disabled={!editable} rows={3} /></FormField>
          <div className="grid grid-cols-2 gap-4">
            <FormField label="CTA Label"><Input value={settings.hero_cta_label ?? ''} onChange={(e) => setSettings({ ...settings, hero_cta_label: e.target.value })} disabled={!editable} /></FormField>
            <FormField label="CTA URL"><Input value={settings.hero_cta_url ?? ''} onChange={(e) => setSettings({ ...settings, hero_cta_url: e.target.value })} disabled={!editable} /></FormField>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Team Culture Section">
        <div className="space-y-4">
          <FormField label="Heading"><Input value={settings.culture_heading ?? ''} onChange={(e) => setSettings({ ...settings, culture_heading: e.target.value })} disabled={!editable} /></FormField>
          <FormField label="Body Text"><Textarea value={settings.culture_body ?? ''} onChange={(e) => setSettings({ ...settings, culture_body: e.target.value })} disabled={!editable} rows={3} /></FormField>
        </div>
      </SectionCard>

      <SectionCard title="Work at ReCircle Section">
        <div className="space-y-4">
          <FormField label="Heading"><Input value={settings.work_heading ?? ''} onChange={(e) => setSettings({ ...settings, work_heading: e.target.value })} disabled={!editable} /></FormField>
          <FormField label="Body Text"><Textarea value={settings.work_body ?? ''} onChange={(e) => setSettings({ ...settings, work_body: e.target.value })} disabled={!editable} rows={3} /></FormField>
          <div className="grid grid-cols-2 gap-4">
            <FormField label="CTA Label"><Input value={settings.work_cta_label ?? ''} onChange={(e) => setSettings({ ...settings, work_cta_label: e.target.value })} disabled={!editable} /></FormField>
            <FormField label="CTA URL"><Input value={settings.work_cta_url ?? ''} onChange={(e) => setSettings({ ...settings, work_cta_url: e.target.value })} disabled={!editable} /></FormField>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Question Cards">
        <div className="space-y-4">
          {cards.map((card, i) => (
            <div key={i} className="grid grid-cols-2 gap-4">
              <FormField label={`Card ${i + 1} Label`}><Input value={card.label} onChange={(e) => updateCard(i, 'label', e.target.value)} disabled={!editable} /></FormField>
              <FormField label="Question Text"><Input value={card.question} onChange={(e) => updateCard(i, 'question', e.target.value)} disabled={!editable} /></FormField>
            </div>
          ))}
        </div>
      </SectionCard>

      <SectionCard title="Open Positions Heading">
        <FormField label="Section Heading"><Input value={settings.listings_heading ?? ''} onChange={(e) => setSettings({ ...settings, listings_heading: e.target.value })} disabled={!editable} /></FormField>
      </SectionCard>

      {editable && (
        <div className="flex items-center gap-3">
          <SaveButton saving={saving} saved={saved} onClick={handleSettingsSave} />
        </div>
      )}

      {/* Job listings */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold" style={{ color: '#1A1A1A' }}>Job Listings ({jobs.length})</h2>
          {editable && (
            <button onClick={() => setEditingJob(emptyJob())} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white" style={{ backgroundColor: '#01298A' }}>
              <Plus size={14} /> Add Job
            </button>
          )}
        </div>
        {jobs.length === 0 ? (
          <div className="bg-white border border-dashed p-8 text-center" style={{ borderColor: '#D1D1D1' }}>
            <p className="text-sm" style={{ color: '#ABABAB' }}>No job listings yet.</p>
          </div>
        ) : (
          <div className="bg-white border overflow-hidden" style={{ borderColor: '#E8E8E8' }}>
            <div className="divide-y" style={{ borderColor: '#F5F5F5' }}>
              {jobs.map((job) => (
                <div key={job.id} className="px-5 py-4 flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>{job.title}</p>
                      <span className="text-xs px-2 py-0.5" style={{ backgroundColor: job.status === 'active' ? '#E0FAF4' : '#F5F5F5', color: job.status === 'active' ? '#00A882' : '#5F5F5F' }}>
                        {job.status === 'active' ? 'Active' : 'Draft'}
                      </span>
                    </div>
                    <p className="text-xs mt-0.5" style={{ color: '#858585' }}>{job.department} · {job.location} · {job.job_type}</p>
                  </div>
                  {editable && (
                    <div className="flex items-center gap-2">
                      <button onClick={() => setEditingJob(job)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                      <button onClick={() => handleDeleteJob(job.id)} className="p-1.5" style={{ color: '#ABABAB' }}
                        onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                        <Trash2 size={14} />
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
