import { useEffect, useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { getSolutions, upsertSolution, deleteSolution, getSolutionsMeta, upsertSolutionsMeta } from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { Solution, SolutionsSectionMeta } from '../../cms/types';
import { FormField, Input, Textarea, Select, SaveButton, SectionCard } from '../components/FormField';

export default function SolutionsEditor() {
  const [meta, setMeta] = useState<Partial<SolutionsSectionMeta>>({});
  const [solutions, setSolutions] = useState<Solution[]>([]);
  const [editing, setEditing] = useState<Partial<Solution> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [metaSaving, setMetaSaving] = useState(false);
  const [metaSaved, setMetaSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    Promise.all([getSolutionsMeta(), getSolutions()]).then(([m, s]) => {
      if (m) setMeta(m);
      setSolutions(s);
      setLoading(false);
    });
  }, []);

  const handleMetaSave = async () => {
    setMetaSaving(true);
    await upsertSolutionsMeta(meta);
    await logAudit('solutions_section', meta.id ? 'updated' : 'created', user?.full_name ?? '', user?.id);
    setMetaSaving(false);
    setMetaSaved(true);
    setTimeout(() => setMetaSaved(false), 1500);
  };

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    await upsertSolution(editing);
    const fresh = await getSolutions();
    setSolutions(fresh);
    setSaving(false);
    setSaved(true);
    setTimeout(() => { setSaved(false); setEditing(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this solution?')) return;
    await deleteSolution(id);
    setSolutions((prev) => prev.filter((s) => s.id !== id));
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Solutions Pathway</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Edit the section heading and manage each solution node in the pathway.</p>
      </div>

      <SectionCard title="Section Heading & Description">
        <div className="space-y-4">
          <FormField label="Section Heading" required>
            <Input value={meta.heading ?? ''} onChange={(e) => setMeta({ ...meta, heading: e.target.value })} disabled={!editable} />
          </FormField>
          <FormField label="Section Body Copy">
            <Textarea value={meta.body_copy ?? ''} onChange={(e) => setMeta({ ...meta, body_copy: e.target.value })} disabled={!editable} rows={3} />
          </FormField>
          {editable && <SaveButton saving={metaSaving} saved={metaSaved} onClick={handleMetaSave}>Save Section Text</SaveButton>}
        </div>
      </SectionCard>

      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>Solution Nodes ({solutions.length})</h2>
        {editable && !editing && (
          <button onClick={() => setEditing({ sort_order: solutions.length + 1, is_active: true, side: 'left', tag: '', heading: '', expanded_description: '', href: '#' })}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white" style={{ backgroundColor: '#01298A' }}>
            <Plus size={12} /> Add Solution
          </button>
        )}
      </div>

      {!editing && (
        <div className="space-y-2">
          {solutions.map((sol) => (
            <div key={sol.id} className="bg-white border p-4 flex items-start gap-3" style={{ borderColor: '#E8E8E8' }}>
              <GripVertical size={16} className="text-gray-300 cursor-grab mt-0.5" />
              <div className="flex-1 min-w-0">
                <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#00C499' }}>{sol.tag}</span>
                <p className="text-sm font-semibold mt-0.5 truncate" style={{ color: '#1A1A1A' }}>{sol.heading}</p>
                <p className="text-xs mt-0.5 line-clamp-1" style={{ color: '#858585' }}>{sol.expanded_description}</p>
              </div>
              {editable && (
                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={() => setEditing(sol)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                  <button onClick={() => handleDelete(sol.id)} className="p-1.5" style={{ color: '#ABABAB' }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {editing && (
        <SectionCard title={editing.id ? 'Edit Solution' : 'New Solution'}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Sort Order"><Input type="number" value={editing.sort_order ?? ''} onChange={(e) => setEditing({ ...editing, sort_order: parseInt(e.target.value) })} disabled={!editable} /></FormField>
              <FormField label="Side on Pathway" hint="Which side of the center line">
                <Select value={editing.side ?? 'left'} onChange={(e) => setEditing({ ...editing, side: e.target.value as 'left' | 'right' })} disabled={!editable}>
                  <option value="left">Left</option>
                  <option value="right">Right</option>
                </Select>
              </FormField>
            </div>
            <FormField label="Tag / Category Label" hint="Small label above the solution name (e.g. Service — Plastic)" required>
              <Input value={editing.tag ?? ''} onChange={(e) => setEditing({ ...editing, tag: e.target.value })} disabled={!editable} placeholder="Service — Plastic" />
            </FormField>
            <FormField label="Solution Name" required>
              <Input value={editing.heading ?? ''} onChange={(e) => setEditing({ ...editing, heading: e.target.value })} disabled={!editable} placeholder="Extended Producer Responsibility (EPR)" />
            </FormField>
            <FormField label="Expanded Description" hint="Shown when the user clicks + to open the node" required>
              <Textarea value={editing.expanded_description ?? ''} onChange={(e) => setEditing({ ...editing, expanded_description: e.target.value })} disabled={!editable} rows={3} />
            </FormField>
            <FormField label="Link URL">
              <Input value={editing.href ?? ''} onChange={(e) => setEditing({ ...editing, href: e.target.value })} disabled={!editable} placeholder="#epr" />
            </FormField>
            {editable && (
              <div className="flex items-center gap-3 pt-2">
                <SaveButton saving={saving} saved={saved} onClick={handleSave} />
                <button onClick={() => setEditing(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
              </div>
            )}
          </div>
        </SectionCard>
      )}
    </div>
  );
}
