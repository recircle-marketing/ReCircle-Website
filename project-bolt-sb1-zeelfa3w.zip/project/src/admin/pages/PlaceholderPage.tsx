import { Construction } from 'lucide-react';

interface PlaceholderPageProps {
  title: string;
  description?: string;
}

export default function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <div className="max-w-2xl">
      <h1 className="text-xl font-bold mb-1" style={{ color: '#1A1A1A' }}>{title}</h1>
      {description && <p className="text-sm mb-8" style={{ color: '#858585' }}>{description}</p>}
      <div className="bg-white border border-dashed p-12 flex flex-col items-center text-center" style={{ borderColor: '#D1D1D1' }}>
        <Construction size={32} className="mb-4" style={{ color: '#D1D1D1' }} />
        <h3 className="text-sm font-semibold mb-1" style={{ color: '#1A1A1A' }}>Coming in a future phase</h3>
        <p className="text-xs leading-relaxed max-w-xs" style={{ color: '#ABABAB' }}>
          The schema for this content type has been created and is ready. This editor page will be built when the corresponding public-facing page is developed.
        </p>
      </div>
    </div>
  );
}
