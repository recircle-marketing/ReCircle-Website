import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getTrfPageSettings, upsertTrfPageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { TrfPageSettings } from '../../cms/queries';

export default function TrfEditor() {
  const [settings, setSettings] = useState<Partial<TrfPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getTrfPageSettings().then(s => { if (s) setSettings(s); setLoading(false); });
  }, []);

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertTrfPageSettings(settings);
    await logAudit('trf_page', settings.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, settings.id);
    setSaving(false); setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{color:'#858585'}}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{color:'#1A1A1A'}}>Textile Recovery Facility (TRF)</h1>
          <p className="text-sm" style={{color:'#858585'}}>Manage content for the TRF page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      <SectionCard title="Hero">
        <FormField label="Hero Label">
          <Input
            value={settings.hero_label ?? ''}
            onChange={e => setSettings(s => ({...s, hero_label: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Heading">
          <Input
            value={settings.hero_heading ?? ''}
            onChange={e => setSettings(s => ({...s, hero_heading: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Body">
          <Textarea
            rows={3}
            value={settings.hero_body ?? ''}
            onChange={e => setSettings(s => ({...s, hero_body: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Key Statistics">
        <div className="grid grid-cols-2 gap-4">
          <FormField label="Stat 1 Value">
            <Input
              value={settings.stat_1_value ?? ''}
              onChange={e => setSettings(s => ({...s, stat_1_value: e.target.value}))}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 1 Label">
            <Input
              value={settings.stat_1_label ?? ''}
              onChange={e => setSettings(s => ({...s, stat_1_label: e.target.value}))}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 2 Value">
            <Input
              value={settings.stat_2_value ?? ''}
              onChange={e => setSettings(s => ({...s, stat_2_value: e.target.value}))}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 2 Label">
            <Input
              value={settings.stat_2_label ?? ''}
              onChange={e => setSettings(s => ({...s, stat_2_label: e.target.value}))}
              disabled={!editable}
            />
          </FormField>
        </div>
      </SectionCard>

      <SectionCard title="Overview">
        <FormField label="Overview Heading">
          <Input
            value={settings.overview_heading ?? ''}
            onChange={e => setSettings(s => ({...s, overview_heading: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Overview Body">
          <Textarea
            rows={4}
            value={settings.overview_body ?? ''}
            onChange={e => setSettings(s => ({...s, overview_body: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Output Categories">
        <FormField label="Categories Heading">
          <Input
            value={settings.categories_heading ?? ''}
            onChange={e => setSettings(s => ({...s, categories_heading: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Categories" hint="Array of {label, color, bg, desc} objects">
          <Textarea
            rows={10}
            value={JSON.stringify(settings.categories ?? [], null, 2)}
            onChange={e => { try { const v = JSON.parse(e.target.value); setSettings(s => ({...s, categories: v})); } catch {} }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
