import { useEffect, useState } from 'react';
import { Save, Search, Globe, ChevronDown, ChevronUp } from 'lucide-react';
import { getAllSeoMetadata, upsertSeoMetadata } from '../../cms/queries';
import { logAudit } from '../../cms/queries';
import { getCurrentUser } from '../../lib/auth';
import type { SeoMetadata } from '../../cms/types';

const PAGE_LABELS: Record<string, string> = {
  '/': 'Home',
  '/about': 'Our Story / About Us',
  '/contact': 'Contact',
  '/blog': 'Blog Listing',
  '/careers': 'Careers',
  '/annual-reports': 'Annual Reports',
  '/webinars': 'Webinars',
  '/impact': 'Our Impact',
  // Infrastructure
  '/infrastructure/mrf': 'Infrastructure — MRF',
  '/infrastructure/trf': 'Infrastructure — TRF',
  '/infrastructure/recycling-plant': 'Infrastructure — Recycling Plant',
  // Plastic
  '/plastic-waste': 'Plastic Waste Management',
  '/epr': 'EPR Services',
  '/pnp': 'Plastic Neutral Program (PNP)',
  // Textile
  '/textile': 'Textile Waste Management',
  '/textile/pitw': 'Textile — Post-Industrial (PITW)',
  '/textile/pctw': 'Textile — Post-Consumer (PCTW)',
  // ESG
  '/esg-projects': 'ESG Projects',
};

function SeoPageCard({ meta, onSave }: { meta: SeoMetadata; onSave: (updated: SeoMetadata) => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<SeoMetadata>(meta);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const user = getCurrentUser();

  const displayLabel = form.page_label || PAGE_LABELS[form.page_slug] || form.page_slug;

  const set = (key: keyof SeoMetadata, val: string) => {
    setForm((f) => ({ ...f, [key]: val }));
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    await upsertSeoMetadata(form);
    await logAudit('seo_metadata', 'updated', user?.full_name ?? 'Admin', user?.id, form.id);
    onSave(form);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="bg-white border" style={{ borderColor: '#E8E8E8' }}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-6 py-4 text-left"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 flex items-center justify-center rounded-full" style={{ backgroundColor: '#E8EDF8' }}>
            <Globe size={14} style={{ color: '#01298A' }} />
          </div>
          <div>
            <p className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>{displayLabel}</p>
            <p className="text-xs mt-0.5 truncate max-w-xs" style={{ color: '#858585' }}>
              {form.page_slug}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {form.page_title && (
            <span className="hidden sm:block text-xs truncate max-w-[240px]" style={{ color: '#ABABAB' }}>
              {form.page_title}
            </span>
          )}
          {open ? <ChevronUp size={16} style={{ color: '#858585' }} /> : <ChevronDown size={16} style={{ color: '#858585' }} />}
        </div>
      </button>

      {open && (
        <div className="px-6 pb-6 border-t" style={{ borderColor: '#F0F0F0' }}>
          <div className="pt-5 grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Page Title */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Page Title
              </label>
              <input
                type="text"
                value={form.page_title ?? ''}
                onChange={(e) => set('page_title', e.target.value)}
                placeholder="e.g. Contact Us | ReCircle"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
              <p className="text-xs mt-1" style={{ color: '#ABABAB' }}>Recommended: 50–60 characters</p>
            </div>

            {/* Meta Description */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Meta Description
              </label>
              <textarea
                rows={3}
                value={form.meta_description ?? ''}
                onChange={(e) => set('meta_description', e.target.value)}
                placeholder="Brief description of the page for search results…"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none resize-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
              <p className="text-xs mt-1" style={{ color: '#ABABAB' }}>Recommended: 150–160 characters ({(form.meta_description ?? '').length} used)</p>
            </div>

            {/* Keywords */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Keywords
              </label>
              <input
                type="text"
                value={form.keywords ?? ''}
                onChange={(e) => set('keywords', e.target.value)}
                placeholder="e.g. EPR compliance, plastic recycling India, circular economy"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
              <p className="text-xs mt-1" style={{ color: '#ABABAB' }}>Comma-separated keywords</p>
            </div>

            {/* OG Title */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                OG Title
              </label>
              <input
                type="text"
                value={form.og_title ?? ''}
                onChange={(e) => set('og_title', e.target.value)}
                placeholder="Leave blank to use Page Title"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>

            {/* Canonical URL */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Canonical URL
              </label>
              <input
                type="text"
                value={form.canonical_url ?? ''}
                onChange={(e) => set('canonical_url', e.target.value)}
                placeholder="https://recircle.in/contact"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>

            {/* OG Description */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                OG Description
              </label>
              <textarea
                rows={2}
                value={form.og_description ?? ''}
                onChange={(e) => set('og_description', e.target.value)}
                placeholder="Leave blank to use Meta Description"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none resize-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>

            {/* OG Image */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                OG Image URL
              </label>
              <input
                type="text"
                value={form.og_image ?? ''}
                onChange={(e) => set('og_image', e.target.value)}
                placeholder="https://recircle.in/og-image.jpg (1200×630 recommended)"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>
          </div>

          <div className="mt-5 flex items-center gap-3">
            <button
              onClick={handleSave}
              disabled={saving}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white transition-opacity disabled:opacity-60"
              style={{ backgroundColor: '#01298A' }}
            >
              <Save size={14} />
              {saving ? 'Saving…' : saved ? 'Saved!' : 'Save Changes'}
            </button>
            {saved && <span className="text-xs font-medium" style={{ color: '#00C499' }}>Changes saved successfully</span>}
          </div>
        </div>
      )}
    </div>
  );
}

export default function SeoDefaultsEditor() {
  const [pages, setPages] = useState<SeoMetadata[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    getAllSeoMetadata().then((data) => {
      // Merge DB records with all known page slugs so new pages appear even without a DB row
      const existing = new Set(data.map((d) => d.page_slug));
      const stubs: SeoMetadata[] = Object.entries(PAGE_LABELS)
        .filter(([slug]) => !existing.has(slug))
        .map(([slug, label]) => ({
          id: '',
          page_slug: slug,
          page_label: label,
          page_title: '',
          meta_description: '',
          keywords: '',
          og_title: '',
          og_description: '',
          og_image: '',
          canonical_url: '',
          updated_at: '',
        }));
      setPages([...data, ...stubs]);
      setLoading(false);
    });
  }, []);

  const filtered = pages.filter((p) => {
    const q = search.toLowerCase();
    return (
      p.page_slug.toLowerCase().includes(q) ||
      (p.page_label ?? '').toLowerCase().includes(q) ||
      (PAGE_LABELS[p.page_slug] ?? '').toLowerCase().includes(q)
    );
  });

  const handleSave = (updated: SeoMetadata) => {
    setPages((prev) => prev.map((p) => (p.page_slug === updated.page_slug ? updated : p)));
  };

  return (
    <div className="max-w-4xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1" style={{ color: '#1A1A1A' }}>SEO Defaults</h1>
        <p className="text-sm" style={{ color: '#858585' }}>
          Manage per-page meta titles, descriptions, keywords, and Open Graph data for all website pages.
        </p>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: '#ABABAB' }} />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search pages…"
          className="w-full pl-10 pr-4 py-2.5 border bg-white text-sm focus:outline-none"
          style={{ borderColor: '#D1D1D1' }}
          onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
          onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
        />
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-7 h-7 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 border border-dashed" style={{ borderColor: '#D1D1D1' }}>
          <Globe size={32} className="mx-auto mb-3" style={{ color: '#D1D1D1' }} />
          <p className="text-sm font-semibold" style={{ color: '#5F5F5F' }}>No pages found</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((page) => (
            <SeoPageCard key={page.page_slug} meta={page} onSave={handleSave} />
          ))}
        </div>
      )}
    </div>
  );
}
