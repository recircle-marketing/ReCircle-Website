import { useEffect, useState } from 'react';
import { getFooterContent, upsertFooterContent } from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { FooterContent } from '../../cms/types';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';

export default function FooterEditor() {
  const [content, setContent] = useState<Partial<FooterContent>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getFooterContent().then((data) => {
      if (data) setContent(data);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await upsertFooterContent(content);
    await logAudit('footer', content.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, content.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Footer</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Edit the footer content including grievance details, newsletter CTA, and legal text.</p>
      </div>

      <SectionCard title="Company Tagline">
        <Textarea value={content.tagline ?? ''} onChange={(e) => setContent({ ...content, tagline: e.target.value })} disabled={!editable} rows={2} />
      </SectionCard>

      <SectionCard title="Grievance Officer Details">
        <div className="space-y-4">
          <FormField label="Officer Name" required>
            <Input value={content.grievance_officer_name ?? ''} onChange={(e) => setContent({ ...content, grievance_officer_name: e.target.value })} disabled={!editable} placeholder="Rahul Nainani" />
          </FormField>
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Phone Number">
              <Input value={content.grievance_officer_phone ?? ''} onChange={(e) => setContent({ ...content, grievance_officer_phone: e.target.value })} disabled={!editable} placeholder="+91 90042 40004" />
            </FormField>
            <FormField label="Email Address">
              <Input type="email" value={content.grievance_officer_email ?? ''} onChange={(e) => setContent({ ...content, grievance_officer_email: e.target.value })} disabled={!editable} placeholder="info@recircle.in" />
            </FormField>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Newsletter Subscription">
        <FormField label="CTA Text" hint="Short sentence shown above the email input field">
          <Input value={content.newsletter_cta_text ?? ''} onChange={(e) => setContent({ ...content, newsletter_cta_text: e.target.value })} disabled={!editable} placeholder="Subscribe for industry insights." />
        </FormField>
      </SectionCard>

      <SectionCard title="Legal Information">
        <div className="space-y-4">
          <FormField label="Registered Company Name">
            <Input value={content.legal_company_name ?? ''} onChange={(e) => setContent({ ...content, legal_company_name: e.target.value })} disabled={!editable} placeholder="Swachh Sustainable Solutions Pvt. Ltd." />
          </FormField>
          <FormField label="CIN Number">
            <Input value={content.legal_cin ?? ''} onChange={(e) => setContent({ ...content, legal_cin: e.target.value })} disabled={!editable} placeholder="U74900MH2016PTC273536" />
          </FormField>
          <FormField label="Copyright Line">
            <Input value={content.legal_copyright ?? ''} onChange={(e) => setContent({ ...content, legal_copyright: e.target.value })} disabled={!editable} placeholder="© All Rights Reserved 2026–2027" />
          </FormField>
        </div>
      </SectionCard>

      <div className="bg-white border p-5" style={{ borderColor: '#E8E8E8' }}>
        <p className="text-xs font-semibold mb-2" style={{ color: '#858585' }}>Note</p>
        <p className="text-xs leading-relaxed" style={{ color: '#ABABAB' }}>
          Footer navigation links and social media links are managed through the <strong style={{ color: '#1A1A1A' }}>Site Settings</strong> section. Changes to those settings will reflect in the footer automatically.
        </p>
      </div>

      {editable && <SaveButton saving={saving} saved={saved} onClick={handleSave} />}
    </div>
  );
}
