import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getEprPageSettings, upsertEprPageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { EprPageSettings } from '../../cms/queries';

export default function EprEditor() {
  const [settings, setSettings] = useState<Partial<EprPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getEprPageSettings().then(s => {
      if (s) setSettings(s);
      setLoading(false);
    });
  }, []);

  const update = (field: string, val: string) =>
    setSettings(s => ({ ...s, [field]: val }));

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertEprPageSettings(settings);
    await logAudit(
      'epr_page',
      settings.id ? 'updated' : 'created',
      user?.full_name ?? '',
      user?.id,
      settings.id,
    );
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{ color: '#858585' }}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#1A1A1A' }}>EPR Services</h1>
          <p className="text-sm" style={{ color: '#858585' }}>Manage content for the EPR compliance services page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      <SectionCard title="Hero Section">
        <FormField label="Hero Heading">
          <Textarea
            rows={2}
            value={settings.hero_heading ?? ''}
            onChange={e => update('hero_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Body">
          <Textarea
            rows={4}
            value={settings.hero_body ?? ''}
            onChange={e => update('hero_body', e.target.value)}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Key Statistics">
        <div className="grid grid-cols-2 gap-4">
          <FormField label="Stat 1 Value">
            <Input
              value={settings.stat_1_value ?? ''}
              onChange={e => update('stat_1_value', e.target.value)}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 1 Label">
            <Input
              value={settings.stat_1_label ?? ''}
              onChange={e => update('stat_1_label', e.target.value)}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 2 Value">
            <Input
              value={settings.stat_2_value ?? ''}
              onChange={e => update('stat_2_value', e.target.value)}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 2 Label">
            <Input
              value={settings.stat_2_label ?? ''}
              onChange={e => update('stat_2_label', e.target.value)}
              disabled={!editable}
            />
          </FormField>
        </div>
      </SectionCard>

      <SectionCard title="Compliance Process">
        <FormField label="Process Heading">
          <Input
            value={settings.process_heading ?? ''}
            onChange={e => update('process_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Process Steps" hint="Array of {step, title, body} objects">
          <Textarea
            rows={12}
            value={JSON.stringify(settings.process_steps ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, process_steps: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Benefits">
        <FormField label="Benefits Heading">
          <Input
            value={settings.benefits_heading ?? ''}
            onChange={e => update('benefits_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Benefits" hint="Array of {title, body} objects">
          <Textarea
            rows={10}
            value={JSON.stringify(settings.benefits ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, benefits: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
