import { useEffect, useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { getClients, upsertClient, deleteClient, getClientsMeta } from '../../cms/queries';
import { supabase } from '../../lib/supabase';
import { canEdit } from '../../lib/auth';
import type { Client, ClientsSectionMeta } from '../../cms/types';
import { FormField, Input, SaveButton, SectionCard } from '../components/FormField';

export default function ClientsEditor() {
  const [meta, setMeta] = useState<Partial<ClientsSectionMeta>>({});
  const [clients, setClients] = useState<Client[]>([]);
  const [editing, setEditing] = useState<Partial<Client> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [metaSaving, setMetaSaving] = useState(false);
  const [metaSaved, setMetaSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const editable = canEdit();

  useEffect(() => {
    Promise.all([getClientsMeta(), getClients()]).then(([m, c]) => {
      if (m) setMeta(m);
      setClients(c);
      setLoading(false);
    });
  }, []);

  const handleMetaSave = async () => {
    setMetaSaving(true);
    const { id, ...rest } = meta as ClientsSectionMeta;
    if (id) await supabase.from('cms_clients_section').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id);
    else await supabase.from('cms_clients_section').insert(rest);
    setMetaSaving(false);
    setMetaSaved(true);
    setTimeout(() => setMetaSaved(false), 1500);
  };

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    await upsertClient(editing);
    const fresh = await getClients();
    setClients(fresh);
    setSaving(false);
    setSaved(true);
    setTimeout(() => { setSaved(false); setEditing(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Remove this client?')) return;
    await deleteClient(id);
    setClients((prev) => prev.filter((c) => c.id !== id));
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Clients</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Manage the clients logo ticker section.</p>
      </div>

      <SectionCard title="Section Heading & Description">
        <div className="space-y-4">
          <FormField label="Section Heading"><Input value={meta.heading ?? ''} onChange={(e) => setMeta({ ...meta, heading: e.target.value })} disabled={!editable} /></FormField>
          <FormField label="Body Copy"><Input value={meta.body_copy ?? ''} onChange={(e) => setMeta({ ...meta, body_copy: e.target.value })} disabled={!editable} /></FormField>
          {editable && <SaveButton saving={metaSaving} saved={metaSaved} onClick={handleMetaSave}>Save Section Text</SaveButton>}
        </div>
      </SectionCard>

      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>Clients ({clients.length})</h2>
        {editable && !editing && (
          <button onClick={() => setEditing({ sort_order: clients.length + 1, is_active: true, name: '', logo_url: '', logo_alt: '' })}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white" style={{ backgroundColor: '#01298A' }}>
            <Plus size={12} /> Add Client
          </button>
        )}
      </div>

      {!editing && (
        <div className="grid grid-cols-2 gap-2">
          {clients.map((client) => (
            <div key={client.id} className="bg-white border p-3 flex items-center gap-3" style={{ borderColor: '#E8E8E8' }}>
              <GripVertical size={14} className="text-gray-300 cursor-grab flex-shrink-0" />
              <span className="flex-1 text-sm font-medium truncate" style={{ color: '#1A1A1A' }}>{client.name}</span>
              {editable && (
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button onClick={() => setEditing(client)} className="px-2 py-1 text-xs border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                  <button onClick={() => handleDelete(client.id)} className="p-1" style={{ color: '#ABABAB' }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                    <Trash2 size={12} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {editing && (
        <SectionCard title={editing.id ? 'Edit Client' : 'New Client'}>
          <div className="space-y-4">
            <FormField label="Sort Order"><Input type="number" value={editing.sort_order ?? ''} onChange={(e) => setEditing({ ...editing, sort_order: parseInt(e.target.value) })} disabled={!editable} /></FormField>
            <FormField label="Client / Brand Name" required><Input value={editing.name ?? ''} onChange={(e) => setEditing({ ...editing, name: e.target.value })} disabled={!editable} placeholder="Colgate-Palmolive" /></FormField>
            <FormField label="Logo Image URL" hint="Optional — leave blank to show name as text in the ticker">
              <Input value={editing.logo_url ?? ''} onChange={(e) => setEditing({ ...editing, logo_url: e.target.value })} disabled={!editable} placeholder="https://..." />
            </FormField>
            <FormField label="Logo Alt Text" required>
              <Input value={editing.logo_alt ?? ''} onChange={(e) => setEditing({ ...editing, logo_alt: e.target.value })} disabled={!editable} placeholder="Colgate-Palmolive logo" />
            </FormField>
            {editable && (
              <div className="flex items-center gap-3 pt-2">
                <SaveButton saving={saving} saved={saved} onClick={handleSave} />
                <button onClick={() => setEditing(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
              </div>
            )}
          </div>
        </SectionCard>
      )}
    </div>
  );
}
