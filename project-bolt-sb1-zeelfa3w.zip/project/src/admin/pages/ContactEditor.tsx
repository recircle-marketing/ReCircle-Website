import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { getContactPageSettings, upsertContactPageSettings } from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { ContactPageSettings } from '../../cms/types';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';

export default function ContactEditor() {
  const [settings, setSettings] = useState<Partial<ContactPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getContactPageSettings().then((data) => {
      if (data) setSettings(data);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await upsertContactPageSettings(settings);
    await logAudit('contact_page', settings.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, settings.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const options: string[] = Array.isArray(settings.service_options) ? settings.service_options as string[] : [];

  const updateOption = (i: number, val: string) => {
    const arr = [...options];
    arr[i] = val;
    setSettings({ ...settings, service_options: arr });
  };

  const addOption = () => setSettings({ ...settings, service_options: [...options, ''] });
  const removeOption = (i: number) => {
    const arr = [...options];
    arr.splice(i, 1);
    setSettings({ ...settings, service_options: arr });
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Contact Page</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Edit contact details, form text, and map configuration.</p>
      </div>

      <SectionCard title="Contact Details">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Email Address" required>
              <Input value={settings.email ?? ''} onChange={(e) => setSettings({ ...settings, email: e.target.value })} disabled={!editable} placeholder="info@recircle.in" />
            </FormField>
            <FormField label="Phone Number" required>
              <Input value={settings.phone ?? ''} onChange={(e) => setSettings({ ...settings, phone: e.target.value })} disabled={!editable} placeholder="+91 90042 40004" />
            </FormField>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <FormField label="LinkedIn URL">
              <Input value={settings.linkedin_url ?? ''} onChange={(e) => setSettings({ ...settings, linkedin_url: e.target.value })} disabled={!editable} />
            </FormField>
            <FormField label="Facebook URL">
              <Input value={settings.facebook_url ?? ''} onChange={(e) => setSettings({ ...settings, facebook_url: e.target.value })} disabled={!editable} />
            </FormField>
            <FormField label="Instagram URL">
              <Input value={settings.instagram_url ?? ''} onChange={(e) => setSettings({ ...settings, instagram_url: e.target.value })} disabled={!editable} />
            </FormField>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Contact Form Text">
        <div className="space-y-4">
          <FormField label="Form Heading" required>
            <Input value={settings.form_heading ?? ''} onChange={(e) => setSettings({ ...settings, form_heading: e.target.value })} disabled={!editable} />
          </FormField>
          <FormField label="Form Subheading">
            <Textarea value={settings.form_subheading ?? ''} onChange={(e) => setSettings({ ...settings, form_subheading: e.target.value })} disabled={!editable} rows={2} />
          </FormField>
        </div>
      </SectionCard>

      <SectionCard title="Service Dropdown Options" description="These appear in the 'I Need Help With' dropdown on the contact form.">
        <div className="space-y-2">
          {options.map((opt, i) => (
            <div key={i} className="flex gap-2">
              <Input value={opt} onChange={(e) => updateOption(i, e.target.value)} disabled={!editable} className="flex-1" />
              {editable && (
                <button onClick={() => removeOption(i)} className="p-2 transition-colors" style={{ color: '#ABABAB' }}
                  onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          ))}
          {editable && (
            <button onClick={addOption} className="flex items-center gap-1.5 text-xs font-medium mt-1" style={{ color: '#01298A' }}>
              <Plus size={12} /> Add option
            </button>
          )}
        </div>
      </SectionCard>

      <SectionCard title="Google Maps Embed" description="Paste the full iframe src URL from Google Maps.">
        <FormField label="Map Embed URL" hint="Go to Google Maps → Share → Embed a map → copy the src= URL only">
          <Input value={settings.map_embed_url ?? ''} onChange={(e) => setSettings({ ...settings, map_embed_url: e.target.value })} disabled={!editable} placeholder="https://www.google.com/maps/embed?pb=..." />
        </FormField>
      </SectionCard>

      {editable && (
        <div className="flex items-center gap-3">
          <SaveButton saving={saving} saved={saved} onClick={handleSave} />
        </div>
      )}
    </div>
  );
}
