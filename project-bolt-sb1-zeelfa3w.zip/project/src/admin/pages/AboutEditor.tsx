import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { getAboutContent, upsertAboutContent } from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { AboutContent, CtaButton, Highlight } from '../../cms/types';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';

export default function AboutEditor() {
  const [content, setContent] = useState<Partial<AboutContent>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getAboutContent().then((data) => {
      if (data) setContent(data);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await upsertAboutContent(content);
    await logAudit('about_section', content.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, content.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const updateParagraph = (i: number, val: string) => {
    const paras = [...(content.body_paragraphs ?? [])];
    paras[i] = val;
    setContent({ ...content, body_paragraphs: paras });
  };

  const addParagraph = () => setContent({ ...content, body_paragraphs: [...(content.body_paragraphs ?? []), ''] });
  const removeParagraph = (i: number) => {
    const paras = [...(content.body_paragraphs ?? [])];
    paras.splice(i, 1);
    setContent({ ...content, body_paragraphs: paras });
  };

  const updateCta = (i: number, field: keyof CtaButton, val: string) => {
    const btns = [...(content.cta_buttons as CtaButton[] ?? [])];
    btns[i] = { ...btns[i], [field]: val };
    setContent({ ...content, cta_buttons: btns });
  };

  const updateHighlight = (i: number, field: keyof Highlight, val: string) => {
    const hs = [...(content.highlights as Highlight[] ?? [])];
    hs[i] = { ...hs[i], [field]: val };
    setContent({ ...content, highlights: hs });
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>About ReCircle</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Edit the About section that appears on the homepage.</p>
      </div>

      <SectionCard title="Section Labels & Heading">
        <div className="space-y-4">
          <FormField label="Section Label" hint="Small label above the heading (e.g. About ReCircle)">
            <Input value={content.section_label ?? ''} onChange={(e) => setContent({ ...content, section_label: e.target.value })} disabled={!editable} />
          </FormField>
          <FormField label="Main Heading" required>
            <Input value={content.heading ?? ''} onChange={(e) => setContent({ ...content, heading: e.target.value })} disabled={!editable} />
          </FormField>
        </div>
      </SectionCard>

      <SectionCard title="Body Paragraphs" description="Each paragraph appears as a separate block of text.">
        <div className="space-y-3">
          {(content.body_paragraphs ?? []).map((para, i) => (
            <div key={i} className="flex gap-2">
              <Textarea value={para} onChange={(e) => updateParagraph(i, e.target.value)} disabled={!editable} rows={3} className="flex-1" />
              {editable && (
                <button onClick={() => removeParagraph(i)} className="p-2 self-start mt-0.5 transition-colors" style={{ color: '#ABABAB' }}
                  onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          ))}
          {editable && (
            <button onClick={addParagraph} className="flex items-center gap-1.5 text-xs font-medium mt-1" style={{ color: '#01298A' }}>
              <Plus size={12} /> Add paragraph
            </button>
          )}
        </div>
      </SectionCard>

      <SectionCard title="Closing Line" description="Bold sentence at the end of the body copy.">
        <Input value={content.closing_line ?? ''} onChange={(e) => setContent({ ...content, closing_line: e.target.value })} disabled={!editable} />
      </SectionCard>

      <SectionCard title="CTA Buttons" description="Up to 3 buttons shown below the body copy.">
        <div className="space-y-3">
          {(content.cta_buttons as CtaButton[] ?? []).map((btn, i) => (
            <div key={i} className="grid grid-cols-2 gap-3">
              <FormField label={`Button ${i + 1} Label`}>
                <Input value={btn.label ?? ''} onChange={(e) => updateCta(i, 'label', e.target.value)} disabled={!editable} placeholder="Services" />
              </FormField>
              <FormField label="URL">
                <Input value={btn.href ?? ''} onChange={(e) => updateCta(i, 'href', e.target.value)} disabled={!editable} placeholder="#solutions" />
              </FormField>
            </div>
          ))}
        </div>
      </SectionCard>

      <SectionCard title="Highlight Statistics" description="3 key numbers shown in the strip below the text.">
        <div className="space-y-4">
          {(content.highlights as Highlight[] ?? []).map((h, i) => (
            <div key={i} className="grid grid-cols-3 gap-3">
              <FormField label={`Stat ${i + 1} Value`}>
                <Input value={h.value ?? ''} onChange={(e) => updateHighlight(i, 'value', e.target.value)} disabled={!editable} placeholder="3,608" />
              </FormField>
              <FormField label="Unit / Suffix">
                <Input value={h.unit ?? ''} onChange={(e) => updateHighlight(i, 'unit', e.target.value)} disabled={!editable} placeholder="+" />
              </FormField>
              <FormField label="Label">
                <Input value={h.label ?? ''} onChange={(e) => updateHighlight(i, 'label', e.target.value)} disabled={!editable} placeholder="Safai Saathis in network" />
              </FormField>
            </div>
          ))}
        </div>
      </SectionCard>

      {editable && (
        <div className="flex items-center gap-3">
          <SaveButton saving={saving} saved={saved} onClick={handleSave} />
        </div>
      )}
    </div>
  );
}
