import { useEffect, useState } from 'react';
import { Mail, Phone, Building2 } from 'lucide-react';
import { getContactEnquiries } from '../../cms/queries';
import type { ContactEnquiry } from '../../cms/types';

function formatDate(str: string): string {
  const d = new Date(str);
  const day = String(d.getDate()).padStart(2, '0');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${day} ${months[d.getMonth()]} ${d.getFullYear()}, ${d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`;
}

export default function ContactEnquiriesViewer() {
  const [enquiries, setEnquiries] = useState<ContactEnquiry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getContactEnquiries().then((data) => { setEnquiries(data); setLoading(false); });
  }, []);

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Contact Enquiries</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>All submissions from the public contact form. {enquiries.length} total.</p>
      </div>

      {enquiries.length === 0 ? (
        <div className="bg-white border border-dashed p-12 text-center" style={{ borderColor: '#D1D1D1' }}>
          <p className="text-sm font-medium" style={{ color: '#1A1A1A' }}>No enquiries yet</p>
          <p className="text-xs mt-1" style={{ color: '#ABABAB' }}>Form submissions will appear here.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {enquiries.map((enq) => (
            <div key={enq.id} className="bg-white border p-5" style={{ borderColor: '#E8E8E8' }}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-sm font-bold" style={{ color: '#1A1A1A' }}>{enq.name}</p>
                  <div className="flex flex-wrap gap-4 mt-1.5 text-xs" style={{ color: '#858585' }}>
                    <span className="flex items-center gap-1"><Building2 size={11} />{enq.company_name}</span>
                    <a href={`mailto:${enq.email}`} className="flex items-center gap-1 hover:underline" style={{ color: '#01298A' }}><Mail size={11} />{enq.email}</a>
                    <a href={`tel:${enq.phone}`} className="flex items-center gap-1 hover:underline" style={{ color: '#01298A' }}><Phone size={11} />{enq.phone}</a>
                  </div>
                </div>
                <p className="text-xs flex-shrink-0 ml-4" style={{ color: '#ABABAB' }}>{formatDate(enq.created_at)}</p>
              </div>
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="text-xs px-2 py-0.5 font-medium" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>{enq.service}</span>
              </div>
              <p className="text-sm leading-relaxed" style={{ color: '#3A3A3A' }}>{enq.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
