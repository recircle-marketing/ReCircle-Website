import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getPitwPageSettings, upsertPitwPageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { PitwPageSettings } from '../../cms/queries';

export default function PitwEditor() {
  const [settings, setSettings] = useState<Partial<PitwPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getPitwPageSettings().then(s => {
      if (s) setSettings(s);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertPitwPageSettings(settings);
    await logAudit(
      'pitw_page',
      settings.id ? 'updated' : 'created',
      user?.full_name ?? '',
      user?.id,
      settings.id,
    );
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{ color: '#858585' }}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#1A1A1A' }}>PITW — Post-Industrial Textile Waste</h1>
          <p className="text-sm" style={{ color: '#858585' }}>Manage content for the Post-Industrial Textile Waste page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      {/* Hero Section */}
      <SectionCard title="Hero Section">
        <FormField label="Hero Heading">
          <Textarea
            rows={2}
            value={settings.hero_heading ?? ''}
            onChange={e => setSettings(s => ({ ...s, hero_heading: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <div className="grid grid-cols-2 gap-4">
          <FormField label="Stat 1 Value">
            <Input
              value={settings.stat_1_value ?? ''}
              onChange={e => setSettings(s => ({ ...s, stat_1_value: e.target.value }))}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 1 Label">
            <Input
              value={settings.stat_1_label ?? ''}
              onChange={e => setSettings(s => ({ ...s, stat_1_label: e.target.value }))}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 2 Value">
            <Input
              value={settings.stat_2_value ?? ''}
              onChange={e => setSettings(s => ({ ...s, stat_2_value: e.target.value }))}
              disabled={!editable}
            />
          </FormField>
          <FormField label="Stat 2 Label">
            <Input
              value={settings.stat_2_label ?? ''}
              onChange={e => setSettings(s => ({ ...s, stat_2_label: e.target.value }))}
              disabled={!editable}
            />
          </FormField>
        </div>
      </SectionCard>

      {/* Process */}
      <SectionCard title="Process">
        <FormField label="Process Heading">
          <Input
            value={settings.process_heading ?? ''}
            onChange={e => setSettings(s => ({ ...s, process_heading: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Process Intro">
          <Textarea
            rows={3}
            value={settings.process_intro ?? ''}
            onChange={e => setSettings(s => ({ ...s, process_intro: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Scope Note">
          <Textarea
            rows={2}
            value={settings.scope_note ?? ''}
            onChange={e => setSettings(s => ({ ...s, scope_note: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Comparison: Current vs ReCircle */}
      <SectionCard title="Comparison: Current vs ReCircle">
        <FormField label="Comparison: Current" hint="Array of {text} objects">
          <Textarea
            rows={8}
            value={JSON.stringify(settings.comparison_current ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, comparison_current: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Comparison: ReCircle" hint="Array of {text} objects">
          <Textarea
            rows={8}
            value={JSON.stringify(settings.comparison_recircle ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, comparison_recircle: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Recycled Fibre Outputs */}
      <SectionCard title="Recycled Fibre Outputs">
        <FormField label="Outputs" hint="Array of {name, application} objects">
          <Textarea
            rows={8}
            value={JSON.stringify(settings.outputs ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, outputs: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
        <FormField label="GRS Note">
          <Textarea
            rows={2}
            value={settings.grs_note ?? ''}
            onChange={e => setSettings(s => ({ ...s, grs_note: e.target.value }))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      {/* Ways to Work */}
      <SectionCard title="Ways to Work">
        <FormField label="Work Models" hint="Array of {num, title, body} objects">
          <Textarea
            rows={10}
            value={JSON.stringify(settings.work_models ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, work_models: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
