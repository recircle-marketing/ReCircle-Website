import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import {
  getAnnualReportsPageSettings, upsertAnnualReportsPageSettings,
  getAnnualReportItems, upsertAnnualReportItem, deleteAnnualReportItem,
} from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { AnnualReportsPageSettings, AnnualReportItem } from '../../cms/types';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';

const emptyReport = (): Partial<AnnualReportItem> => ({
  year_label: '', button_text: '', report_url: '', title: '', report_year: new Date().getFullYear(),
  is_active: true, sort_order: 99,
});

export default function AnnualReportsEditor() {
  const [settings, setSettings] = useState<Partial<AnnualReportsPageSettings>>({});
  const [reports, setReports] = useState<AnnualReportItem[]>([]);
  const [editingReport, setEditingReport] = useState<Partial<AnnualReportItem> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [rSaving, setRSaving] = useState(false);
  const [rSaved, setRSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    Promise.all([getAnnualReportsPageSettings(), getAnnualReportItems()]).then(([s, r]) => {
      if (s) setSettings(s);
      setReports(r);
      setLoading(false);
    });
  }, []);

  const handleSettingsSave = async () => {
    setSaving(true);
    await upsertAnnualReportsPageSettings(settings);
    await logAudit('annual_reports_page', settings.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, settings.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const handleReportSave = async () => {
    if (!editingReport) return;
    setRSaving(true);
    await upsertAnnualReportItem(editingReport);
    const fresh = await getAnnualReportItems();
    setReports(fresh);
    setRSaving(false);
    setRSaved(true);
    setTimeout(() => { setRSaved(false); setEditingReport(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this report entry?')) return;
    await deleteAnnualReportItem(id);
    setReports((prev) => prev.filter((r) => r.id !== id));
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Annual Reports</h1>
        <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Edit page content and manage downloadable report links.</p>
      </div>

      <SectionCard title="Hero Section">
        <div className="space-y-4">
          <FormField label="Heading"><Input value={settings.hero_heading ?? ''} onChange={(e) => setSettings({ ...settings, hero_heading: e.target.value })} disabled={!editable} /></FormField>
          <FormField label="Body Text"><Textarea value={settings.hero_body ?? ''} onChange={(e) => setSettings({ ...settings, hero_body: e.target.value })} disabled={!editable} rows={4} /></FormField>
          <FormField label="CTA Text (displayed below body)"><Input value={settings.hero_cta_text ?? ''} onChange={(e) => setSettings({ ...settings, hero_cta_text: e.target.value })} disabled={!editable} /></FormField>
        </div>
      </SectionCard>

      <SectionCard title="Reports Section Heading">
        <FormField label="Heading"><Input value={settings.reports_heading ?? ''} onChange={(e) => setSettings({ ...settings, reports_heading: e.target.value })} disabled={!editable} /></FormField>
      </SectionCard>

      {editable && (
        <div className="flex items-center gap-3">
          <SaveButton saving={saving} saved={saved} onClick={handleSettingsSave} />
        </div>
      )}

      {/* Report items */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold" style={{ color: '#1A1A1A' }}>Report Downloads ({reports.length})</h2>
          {editable && !editingReport && (
            <button onClick={() => setEditingReport(emptyReport())} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white" style={{ backgroundColor: '#01298A' }}>
              <Plus size={14} /> Add Report
            </button>
          )}
        </div>

        {editingReport && (
          <SectionCard title={editingReport.id ? 'Edit Report' : 'New Report'}>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField label="Year Label" hint='e.g. "2023-24"'><Input value={editingReport.year_label ?? ''} onChange={(e) => setEditingReport({ ...editingReport, year_label: e.target.value })} disabled={!editable} /></FormField>
                <FormField label="Button Text"><Input value={editingReport.button_text ?? ''} onChange={(e) => setEditingReport({ ...editingReport, button_text: e.target.value })} disabled={!editable} placeholder="Download for 2023-24" /></FormField>
              </div>
              <FormField label="Report URL (Heyzine or PDF link)"><Input value={editingReport.report_url ?? ''} onChange={(e) => setEditingReport({ ...editingReport, report_url: e.target.value })} disabled={!editable} placeholder="https://heyzine.com/…" /></FormField>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="rep-active" checked={editingReport.is_active ?? true} onChange={(e) => setEditingReport({ ...editingReport, is_active: e.target.checked })} disabled={!editable} className="w-4 h-4" />
                <label htmlFor="rep-active" className="text-sm" style={{ color: '#1A1A1A' }}>Visible on website</label>
              </div>
              <div className="flex items-center gap-3 pt-2">
                <SaveButton saving={rSaving} saved={rSaved} onClick={handleReportSave} />
                <button onClick={() => setEditingReport(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
              </div>
            </div>
          </SectionCard>
        )}

        {!editingReport && (
          <div className="bg-white border overflow-hidden" style={{ borderColor: '#E8E8E8' }}>
            {reports.length === 0 ? (
              <div className="px-5 py-10 text-center"><p className="text-sm" style={{ color: '#ABABAB' }}>No reports added yet.</p></div>
            ) : (
              <div className="divide-y" style={{ borderColor: '#F5F5F5' }}>
                {reports.map((r) => (
                  <div key={r.id} className="px-5 py-4 flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>{r.button_text || r.year_label}</p>
                        {!r.is_active && <span className="text-xs px-1.5" style={{ backgroundColor: '#FEE2E2', color: '#E7182A' }}>Hidden</span>}
                      </div>
                      <p className="text-xs mt-0.5 truncate" style={{ color: '#ABABAB' }}>{r.report_url || 'No URL set'}</p>
                    </div>
                    {editable && (
                      <div className="flex items-center gap-2">
                        <button onClick={() => setEditingReport(r)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                        <button onClick={() => handleDelete(r.id)} className="p-1.5" style={{ color: '#ABABAB' }}
                          onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
