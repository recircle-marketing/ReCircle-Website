import { useEffect, useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { getImpactStats, upsertImpactStat, deleteImpactStat } from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { ImpactStat } from '../../cms/types';
import { FormField, Input, SaveButton, SectionCard } from '../components/FormField';

const emptyStat = (): Partial<ImpactStat> => ({
  sort_order: 99, is_active: true, number_value: '', suffix: '+', unit: '', label: '',
});

export default function ImpactEditor() {
  const [stats, setStats] = useState<ImpactStat[]>([]);
  const [editing, setEditing] = useState<Partial<ImpactStat> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getImpactStats().then((data) => { setStats(data); setLoading(false); });
  }, []);

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    await upsertImpactStat(editing);
    await logAudit('impact_stats', editing.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, editing.id);
    const fresh = await getImpactStats();
    setStats(fresh);
    setSaving(false);
    setSaved(true);
    setTimeout(() => { setSaved(false); setEditing(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this stat?')) return;
    await deleteImpactStat(id);
    setStats((prev) => prev.filter((s) => s.id !== id));
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Impact Numbers</h1>
          <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Manage the animated impact statistics ticker on the homepage.</p>
        </div>
        {editable && !editing && (
          <button onClick={() => setEditing(emptyStat())} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white" style={{ backgroundColor: '#01298A' }}>
            <Plus size={14} /> Add Stat
          </button>
        )}
      </div>

      {!editing && (
        <div className="space-y-2">
          {stats.map((stat) => (
            <div key={stat.id} className="bg-white border p-4 flex items-center gap-4" style={{ borderColor: '#E8E8E8' }}>
              <GripVertical size={16} className="text-gray-300 cursor-grab" />
              <div className="flex-1">
                <span className="text-xl font-bold mr-1" style={{ color: '#01298A' }}>{stat.number_value}</span>
                <span className="text-base font-bold" style={{ color: '#00C499' }}>{stat.suffix}{stat.unit}</span>
                <p className="text-xs mt-0.5" style={{ color: '#858585' }}>{stat.label}</p>
              </div>
              {editable && (
                <div className="flex items-center gap-2">
                  <button onClick={() => setEditing(stat)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                  <button onClick={() => handleDelete(stat.id)} className="p-1.5 transition-colors" style={{ color: '#ABABAB' }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {editing && (
        <SectionCard title={editing.id ? 'Edit Stat' : 'New Stat'}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Sort Order" hint="Controls display order (lower = first)">
                <Input type="number" value={editing.sort_order ?? ''} onChange={(e) => setEditing({ ...editing, sort_order: parseInt(e.target.value) })} disabled={!editable} />
              </FormField>
              <FormField label="Active">
                <div className="flex items-center gap-2 pt-2.5">
                  <input type="checkbox" checked={editing.is_active ?? true} onChange={(e) => setEditing({ ...editing, is_active: e.target.checked })} disabled={!editable} className="w-4 h-4" />
                  <span className="text-sm" style={{ color: '#1A1A1A' }}>Visible on website</span>
                </div>
              </FormField>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <FormField label="Number Value" hint="The raw number (no commas needed)" required>
                <Input value={editing.number_value ?? ''} onChange={(e) => setEditing({ ...editing, number_value: e.target.value })} disabled={!editable} placeholder="291000" />
              </FormField>
              <FormField label="Suffix" hint="e.g. + or leave blank">
                <Input value={editing.suffix ?? ''} onChange={(e) => setEditing({ ...editing, suffix: e.target.value })} disabled={!editable} placeholder="+" />
              </FormField>
              <FormField label="Unit" hint="e.g. MT or leave blank">
                <Input value={editing.unit ?? ''} onChange={(e) => setEditing({ ...editing, unit: e.target.value })} disabled={!editable} placeholder=" MT" />
              </FormField>
            </div>
            <FormField label="Descriptive Label" required>
              <Input value={editing.label ?? ''} onChange={(e) => setEditing({ ...editing, label: e.target.value })} disabled={!editable} placeholder="of waste diverted from landfills & oceans" />
            </FormField>
            {editable && (
              <div className="flex items-center gap-3 pt-2">
                <SaveButton saving={saving} saved={saved} onClick={handleSave} />
                <button onClick={() => setEditing(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
              </div>
            )}
          </div>
        </SectionCard>
      )}
    </div>
  );
}
