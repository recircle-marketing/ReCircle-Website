import { useEffect, useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { getHeroSlides, upsertHeroSlide, deleteHeroSlide } from '../../cms/queries';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit } from '../../cms/queries';
import type { HeroSlide } from '../../cms/types';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';

const emptySlide = (): Partial<HeroSlide> => ({
  sort_order: 99, is_active: true, tag: '', headline: '', subheading: '',
  cta_label: '', cta_href: '#', cta_secondary_label: '', cta_secondary_href: '#',
  image_url: '', image_alt: '',
});

export default function HeroEditor() {
  const [slides, setSlides] = useState<HeroSlide[]>([]);
  const [editing, setEditing] = useState<Partial<HeroSlide> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getHeroSlides().then((data) => { setSlides(data); setLoading(false); });
  }, []);

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    await upsertHeroSlide(editing);
    await logAudit('hero_slides', editing.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, editing.id);
    const fresh = await getHeroSlides();
    setSlides(fresh);
    setSaving(false);
    setSaved(true);
    setTimeout(() => { setSaved(false); setEditing(null); }, 1200);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this slide? This cannot be undone.')) return;
    await deleteHeroSlide(id);
    await logAudit('hero_slides', 'deleted', user?.full_name ?? '', user?.id, id);
    setSlides((prev) => prev.filter((s) => s.id !== id));
  };

  if (loading) return <div className="flex items-center justify-center h-40"><div className="w-6 h-6 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold" style={{ color: '#1A1A1A' }}>Hero / Banner</h1>
          <p className="text-sm mt-0.5" style={{ color: '#858585' }}>Manage the homepage hero carousel slides.</p>
        </div>
        {editable && !editing && (
          <button
            onClick={() => setEditing(emptySlide())}
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white"
            style={{ backgroundColor: '#01298A' }}
          >
            <Plus size={14} /> Add Slide
          </button>
        )}
      </div>

      {/* Slides list */}
      {!editing && (
        <div className="space-y-3">
          {slides.map((slide) => (
            <div key={slide.id} className="bg-white border p-4 flex items-start gap-4" style={{ borderColor: '#E8E8E8' }}>
              <div className="text-gray-300 mt-1 cursor-grab">
                <GripVertical size={16} />
              </div>
              <div className="w-24 h-16 flex-shrink-0 overflow-hidden bg-gray-100">
                {slide.image_url && <img src={slide.image_url} alt={slide.image_alt} className="w-full h-full object-cover" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: '#00C499' }}>{slide.tag}</p>
                <p className="text-sm font-semibold truncate" style={{ color: '#1A1A1A' }}>{slide.headline}</p>
                <p className="text-xs mt-0.5 truncate" style={{ color: '#858585' }}>{slide.subheading}</p>
              </div>
              {editable && (
                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={() => setEditing(slide)} className="px-3 py-1.5 text-xs font-medium border" style={{ color: '#01298A', borderColor: '#01298A' }}>Edit</button>
                  <button onClick={() => handleDelete(slide.id)} className="p-1.5 transition-colors" style={{ color: '#ABABAB' }} onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }} onMouseLeave={(e) => { e.currentTarget.style.color = '#ABABAB'; }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          ))}
          {slides.length === 0 && (
            <div className="bg-white border border-dashed p-8 text-center" style={{ borderColor: '#D1D1D1' }}>
              <p className="text-sm" style={{ color: '#ABABAB' }}>No slides yet. Add your first slide.</p>
            </div>
          )}
        </div>
      )}

      {/* Edit form */}
      {editing && (
        <SectionCard title={editing.id ? 'Edit Slide' : 'New Slide'}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Sort Order" hint="Lower numbers appear first">
                <Input type="number" value={editing.sort_order ?? ''} onChange={(e) => setEditing({ ...editing, sort_order: parseInt(e.target.value) })} disabled={!editable} />
              </FormField>
              <FormField label="Status">
                <div className="flex items-center gap-2 pt-2.5">
                  <input type="checkbox" id="active" checked={editing.is_active ?? true} onChange={(e) => setEditing({ ...editing, is_active: e.target.checked })} disabled={!editable} className="w-4 h-4" />
                  <label htmlFor="active" className="text-sm" style={{ color: '#1A1A1A' }}>Active / Visible</label>
                </div>
              </FormField>
            </div>
            <FormField label="Slide Tag" hint="Short label shown above the headline (e.g. Circular Economy Infrastructure)" required>
              <Input value={editing.tag ?? ''} onChange={(e) => setEditing({ ...editing, tag: e.target.value })} disabled={!editable} placeholder="Circular Economy Infrastructure" />
            </FormField>
            <FormField label="Headline" required>
              <Input value={editing.headline ?? ''} onChange={(e) => setEditing({ ...editing, headline: e.target.value })} disabled={!editable} placeholder="Building India's Resource Recovery Systems" />
            </FormField>
            <FormField label="Subheading">
              <Textarea value={editing.subheading ?? ''} onChange={(e) => setEditing({ ...editing, subheading: e.target.value })} disabled={!editable} rows={3} />
            </FormField>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Primary CTA Label">
                <Input value={editing.cta_label ?? ''} onChange={(e) => setEditing({ ...editing, cta_label: e.target.value })} disabled={!editable} placeholder="Explore Our Solutions" />
              </FormField>
              <FormField label="Primary CTA URL">
                <Input value={editing.cta_href ?? ''} onChange={(e) => setEditing({ ...editing, cta_href: e.target.value })} disabled={!editable} placeholder="#solutions" />
              </FormField>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Secondary CTA Label">
                <Input value={editing.cta_secondary_label ?? ''} onChange={(e) => setEditing({ ...editing, cta_secondary_label: e.target.value })} disabled={!editable} />
              </FormField>
              <FormField label="Secondary CTA URL">
                <Input value={editing.cta_secondary_href ?? ''} onChange={(e) => setEditing({ ...editing, cta_secondary_href: e.target.value })} disabled={!editable} />
              </FormField>
            </div>
            <FormField label="Background Image URL" hint="Use a Pexels image URL or upload your own hosted image">
              <Input value={editing.image_url ?? ''} onChange={(e) => setEditing({ ...editing, image_url: e.target.value })} disabled={!editable} placeholder="https://images.pexels.com/..." />
            </FormField>
            <FormField label="Image Alt Text" hint="Describe the image for accessibility and SEO" required>
              <Input value={editing.image_alt ?? ''} onChange={(e) => setEditing({ ...editing, image_alt: e.target.value })} disabled={!editable} placeholder="Workers sorting recyclable materials" />
            </FormField>

            {editable && (
              <div className="flex items-center gap-3 pt-2">
                <SaveButton saving={saving} saved={saved} onClick={handleSave} />
                <button onClick={() => setEditing(null)} className="px-4 py-2.5 text-sm border" style={{ color: '#858585', borderColor: '#D1D1D1' }}>Cancel</button>
              </div>
            )}
          </div>
        </SectionCard>
      )}
    </div>
  );
}
