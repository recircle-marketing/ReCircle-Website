import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getAboutPageSettings, upsertAboutPageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { AboutPageSettings } from '../../cms/queries';

export default function StoryEditor() {
  const [settings, setSettings] = useState<Partial<AboutPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getAboutPageSettings().then(s => { if (s) setSettings(s); setLoading(false); });
  }, []);

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertAboutPageSettings(settings);
    await logAudit('about_page', settings.id ? 'updated' : 'created', user?.full_name ?? '', user?.id, settings.id);
    setSaving(false); setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{color:'#858585'}}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{color:'#1A1A1A'}}>Our Story / About Us</h1>
          <p className="text-sm" style={{color:'#858585'}}>Manage content for the About Us page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      <SectionCard title="Hero Section">
        <FormField label="Hero Stat">
          <Input
            value={settings.hero_stat ?? ''}
            onChange={e => setSettings(s => ({...s, hero_stat: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Stat Label">
          <Input
            value={settings.hero_stat_label ?? ''}
            onChange={e => setSettings(s => ({...s, hero_stat_label: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Stat Note">
          <Input
            value={settings.hero_stat_note ?? ''}
            onChange={e => setSettings(s => ({...s, hero_stat_note: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Paragraph 1">
          <Textarea
            rows={3}
            value={settings.hero_paragraph_1 ?? ''}
            onChange={e => setSettings(s => ({...s, hero_paragraph_1: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Paragraph 2">
          <Textarea
            rows={2}
            value={settings.hero_paragraph_2 ?? ''}
            onChange={e => setSettings(s => ({...s, hero_paragraph_2: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Vision Statement">
        <FormField label="Vision Quote">
          <Textarea
            rows={3}
            value={settings.vision_quote ?? ''}
            onChange={e => setSettings(s => ({...s, vision_quote: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Commitments" hint="Array of {num, text} objects">
          <Textarea
            rows={6}
            value={JSON.stringify(settings.commitments ?? [], null, 2)}
            onChange={e => { try { const v = JSON.parse(e.target.value); setSettings(s => ({...s, commitments: v})); } catch {} }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Our Roots">
        <FormField label="Roots Heading">
          <Input
            value={settings.roots_heading ?? ''}
            onChange={e => setSettings(s => ({...s, roots_heading: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Roots Body">
          <Textarea
            rows={3}
            value={settings.roots_body ?? ''}
            onChange={e => setSettings(s => ({...s, roots_body: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Roots Closing">
          <Textarea
            rows={2}
            value={settings.roots_closing ?? ''}
            onChange={e => setSettings(s => ({...s, roots_closing: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="On Our Mind">
        <FormField label="Mind Heading">
          <Textarea
            rows={2}
            value={settings.mind_heading ?? ''}
            onChange={e => setSettings(s => ({...s, mind_heading: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Mind Body">
          <Textarea
            rows={4}
            value={settings.mind_body ?? ''}
            onChange={e => setSettings(s => ({...s, mind_body: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Our Growth">
        <FormField label="Growth Heading">
          <Textarea
            rows={2}
            value={settings.growth_heading ?? ''}
            onChange={e => setSettings(s => ({...s, growth_heading: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Growth Body">
          <Textarea
            rows={3}
            value={settings.growth_body ?? ''}
            onChange={e => setSettings(s => ({...s, growth_body: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Growth Closing">
          <Textarea
            rows={2}
            value={settings.growth_closing ?? ''}
            onChange={e => setSettings(s => ({...s, growth_closing: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Growth Stat">
          <Input
            value={settings.growth_stat ?? ''}
            onChange={e => setSettings(s => ({...s, growth_stat: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Growth Stat Unit">
          <Input
            value={settings.growth_stat_unit ?? ''}
            onChange={e => setSettings(s => ({...s, growth_stat_unit: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Growth Stat Descriptor">
          <Input
            value={settings.growth_stat_descriptor ?? ''}
            onChange={e => setSettings(s => ({...s, growth_stat_descriptor: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Our Reach">
        <FormField label="Reach Heading">
          <Input
            value={settings.reach_heading ?? ''}
            onChange={e => setSettings(s => ({...s, reach_heading: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Reach Body">
          <Textarea
            rows={2}
            value={settings.reach_body ?? ''}
            onChange={e => setSettings(s => ({...s, reach_body: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Reach Stats" hint="Array of {value, label} objects">
          <Textarea
            rows={6}
            value={JSON.stringify(settings.reach_stats ?? [], null, 2)}
            onChange={e => { try { const v = JSON.parse(e.target.value); setSettings(s => ({...s, reach_stats: v})); } catch {} }}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Reach Footnote">
          <Input
            value={settings.reach_footnote ?? ''}
            onChange={e => setSettings(s => ({...s, reach_footnote: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Team Section">
        <FormField label="Team Section Heading">
          <Input
            value={settings.team_section_heading ?? ''}
            onChange={e => setSettings(s => ({...s, team_section_heading: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Team Section Intro 1">
          <Textarea
            rows={2}
            value={settings.team_section_intro_1 ?? ''}
            onChange={e => setSettings(s => ({...s, team_section_intro_1: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Team Section Intro 2">
          <Textarea
            rows={2}
            value={settings.team_section_intro_2 ?? ''}
            onChange={e => setSettings(s => ({...s, team_section_intro_2: e.target.value}))}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
