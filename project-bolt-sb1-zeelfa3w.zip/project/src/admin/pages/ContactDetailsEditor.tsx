import { useEffect, useState } from 'react';
import { Save, Phone, Mail, MapPin, Clock } from 'lucide-react';
import { getSiteSettings, upsertSiteSettings } from '../../cms/queries';
import { logAudit } from '../../cms/queries';
import { getCurrentUser } from '../../lib/auth';
import type { SiteSettings } from '../../cms/types';

const EMPTY: Partial<SiteSettings> = {
  primary_email: '',
  primary_phone: '',
  secondary_phone: '',
  address_line_1: '',
  address_line_2: '',
  city: '',
  state: '',
  country: 'India',
  pincode: '',
  working_hours: '',
};

export default function ContactDetailsEditor() {
  const [form, setForm] = useState<Partial<SiteSettings>>(EMPTY);
  const [settingsId, setSettingsId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const user = getCurrentUser();

  useEffect(() => {
    getSiteSettings().then((data) => {
      if (data) {
        setSettingsId(data.id);
        setForm({
          primary_email: data.primary_email ?? '',
          primary_phone: data.primary_phone ?? '',
          secondary_phone: data.secondary_phone ?? '',
          address_line_1: data.address_line_1 ?? '',
          address_line_2: data.address_line_2 ?? '',
          city: data.city ?? '',
          state: data.state ?? '',
          country: data.country ?? 'India',
          pincode: data.pincode ?? '',
          working_hours: data.working_hours ?? '',
        });
      }
      setLoading(false);
    });
  }, []);

  const set = (key: keyof SiteSettings, val: string) => {
    setForm((f) => ({ ...f, [key]: val }));
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    if (settingsId) {
      await upsertSiteSettings({ id: settingsId, ...form });
    } else {
      await upsertSiteSettings(form);
    }
    await logAudit('site_settings_contact', 'updated', user?.full_name ?? 'Admin', user?.id, settingsId ?? undefined);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-7 h-7 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1" style={{ color: '#1A1A1A' }}>Contact Details</h1>
        <p className="text-sm" style={{ color: '#858585' }}>
          Manage global contact information displayed across the website — phone numbers, email, address, and working hours.
        </p>
      </div>

      <div className="bg-white border p-6 space-y-6" style={{ borderColor: '#E8E8E8' }}>
        {/* Email & Phone */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Mail size={15} style={{ color: '#01298A' }} />
            <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: '#1A1A1A' }}>Email & Phone</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Primary Email
              </label>
              <input
                type="email"
                value={form.primary_email ?? ''}
                onChange={(e) => set('primary_email', e.target.value)}
                placeholder="info@recircle.in"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Primary Phone
              </label>
              <input
                type="tel"
                value={form.primary_phone ?? ''}
                onChange={(e) => set('primary_phone', e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Secondary Phone
              </label>
              <input
                type="tel"
                value={form.secondary_phone ?? ''}
                onChange={(e) => set('secondary_phone', e.target.value)}
                placeholder="+91 98765 43211"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>
          </div>
        </div>

        <div className="border-t" style={{ borderColor: '#F0F0F0' }} />

        {/* Address */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <MapPin size={15} style={{ color: '#01298A' }} />
            <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: '#1A1A1A' }}>Address</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Address Line 1
              </label>
              <input
                type="text"
                value={form.address_line_1 ?? ''}
                onChange={(e) => set('address_line_1', e.target.value)}
                placeholder="Building name, street"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                Address Line 2
              </label>
              <input
                type="text"
                value={form.address_line_2 ?? ''}
                onChange={(e) => set('address_line_2', e.target.value)}
                placeholder="Area, locality"
                className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                style={{ borderColor: '#D1D1D1' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
              />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="col-span-2 sm:col-span-1">
                <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                  City
                </label>
                <input
                  type="text"
                  value={form.city ?? ''}
                  onChange={(e) => set('city', e.target.value)}
                  placeholder="Mumbai"
                  className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                  style={{ borderColor: '#D1D1D1' }}
                  onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                  onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                  State
                </label>
                <input
                  type="text"
                  value={form.state ?? ''}
                  onChange={(e) => set('state', e.target.value)}
                  placeholder="Maharashtra"
                  className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                  style={{ borderColor: '#D1D1D1' }}
                  onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                  onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                  Pincode
                </label>
                <input
                  type="text"
                  value={form.pincode ?? ''}
                  onChange={(e) => set('pincode', e.target.value)}
                  placeholder="400001"
                  className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                  style={{ borderColor: '#D1D1D1' }}
                  onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                  onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
                  Country
                </label>
                <input
                  type="text"
                  value={form.country ?? ''}
                  onChange={(e) => set('country', e.target.value)}
                  placeholder="India"
                  className="w-full px-4 py-2.5 border text-sm focus:outline-none"
                  style={{ borderColor: '#D1D1D1' }}
                  onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                  onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="border-t" style={{ borderColor: '#F0F0F0' }} />

        {/* Working Hours */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Clock size={15} style={{ color: '#01298A' }} />
            <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: '#1A1A1A' }}>Working Hours</h2>
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#5F5F5F' }}>
              Hours Text
            </label>
            <input
              type="text"
              value={form.working_hours ?? ''}
              onChange={(e) => set('working_hours', e.target.value)}
              placeholder="Mon–Fri, 9:00 AM – 6:00 PM IST"
              className="w-full px-4 py-2.5 border text-sm focus:outline-none"
              style={{ borderColor: '#D1D1D1' }}
              onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
              onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
            />
          </div>
        </div>

        <div className="border-t pt-5 flex items-center gap-3" style={{ borderColor: '#F0F0F0' }}>
          <button
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white transition-opacity disabled:opacity-60"
            style={{ backgroundColor: '#01298A' }}
          >
            <Save size={14} />
            {saving ? 'Saving…' : saved ? 'Saved!' : 'Save Changes'}
          </button>
          {saved && <span className="text-xs font-medium" style={{ color: '#00C499' }}>Contact details updated</span>}
        </div>
      </div>

      <div className="mt-4 p-4 border border-dashed text-sm" style={{ borderColor: '#D1D1D1', color: '#858585' }}>
        <strong style={{ color: '#5F5F5F' }}>Note:</strong> The phone and email fields displayed in the Contact Page form are managed separately under <strong>Contact Page &rsaquo; Page Settings</strong>. These settings are used globally across the site.
      </div>
    </div>
  );
}
