import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getPnpPageSettings, upsertPnpPageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { PnpPageSettings } from '../../cms/queries';

export default function PnpEditor() {
  const [settings, setSettings] = useState<Partial<PnpPageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getPnpPageSettings().then(s => {
      if (s) setSettings(s);
      setLoading(false);
    });
  }, []);

  const update = (field: string, val: string) =>
    setSettings(s => ({ ...s, [field]: val }));

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertPnpPageSettings(settings);
    await logAudit(
      'pnp_page',
      settings.id ? 'updated' : 'created',
      user?.full_name ?? '',
      user?.id,
      settings.id,
    );
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{ color: '#858585' }}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#1A1A1A' }}>Plastic Neutral Program (PNP)</h1>
          <p className="text-sm" style={{ color: '#858585' }}>Manage content for the Plastic Neutral Programme page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      <SectionCard title="Hero Section">
        <FormField label="Hero Heading">
          <Input
            value={settings.hero_heading ?? ''}
            onChange={e => update('hero_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Tag" hint="e.g. Voluntary">
          <Input
            value={settings.hero_tag ?? ''}
            onChange={e => update('hero_tag', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Body">
          <Textarea
            rows={4}
            value={settings.hero_body ?? ''}
            onChange={e => update('hero_body', e.target.value)}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Programme Overview">
        <FormField label="Programme Heading">
          <Input
            value={settings.programme_heading ?? ''}
            onChange={e => update('programme_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Programme Body">
          <Textarea
            rows={4}
            value={settings.programme_body ?? ''}
            onChange={e => update('programme_body', e.target.value)}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="How It Works">
        <FormField label="Steps Heading">
          <Input
            value={settings.steps_heading ?? ''}
            onChange={e => update('steps_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Steps" hint="Array of {step, title, body} objects">
          <Textarea
            rows={10}
            value={JSON.stringify(settings.steps ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, steps: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Benefits">
        <FormField label="Benefits Heading">
          <Input
            value={settings.benefits_heading ?? ''}
            onChange={e => update('benefits_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Benefits" hint="Array of {title, body} objects">
          <Textarea
            rows={10}
            value={JSON.stringify(settings.benefits ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, benefits: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
