import { useEffect, useState } from 'react';
import { getCurrentUser, canEdit } from '../../lib/auth';
import { logAudit, getPlasticWastePageSettings, upsertPlasticWastePageSettings } from '../../cms/queries';
import { FormField, Input, Textarea, SaveButton, SectionCard } from '../components/FormField';
import type { PlasticWastePageSettings } from '../../cms/queries';

export default function PlasticWasteEditor() {
  const [settings, setSettings] = useState<Partial<PlasticWastePageSettings>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();
  const editable = canEdit();

  useEffect(() => {
    getPlasticWastePageSettings().then(s => {
      if (s) setSettings(s);
      setLoading(false);
    });
  }, []);

  const update = (field: string, val: string) =>
    setSettings(s => ({ ...s, [field]: val }));

  const handleSave = async () => {
    if (!editable) return;
    setSaving(true);
    await upsertPlasticWastePageSettings(settings);
    await logAudit(
      'plastic_waste_page',
      settings.id ? 'updated' : 'created',
      user?.full_name ?? '',
      user?.id,
      settings.id,
    );
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  if (loading) return <div className="p-8 text-sm" style={{ color: '#858585' }}>Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#1A1A1A' }}>Plastic Waste Management</h1>
          <p className="text-sm" style={{ color: '#858585' }}>Manage content for the Plastic Waste Management parent page</p>
        </div>
        <SaveButton saving={saving} saved={saved} onClick={handleSave} disabled={!editable} />
      </div>

      <SectionCard title="Hero Section">
        <FormField label="Hero Heading">
          <Textarea
            rows={2}
            value={settings.hero_heading ?? ''}
            onChange={e => update('hero_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Stat">
          <Input
            value={settings.hero_stat ?? ''}
            onChange={e => update('hero_stat', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Stat Label">
          <Input
            value={settings.hero_stat_label ?? ''}
            onChange={e => update('hero_stat_label', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Stat Descriptor">
          <Input
            value={settings.hero_stat_descriptor ?? ''}
            onChange={e => update('hero_stat_descriptor', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Paragraph 1">
          <Textarea
            rows={3}
            value={settings.hero_para_1 ?? ''}
            onChange={e => update('hero_para_1', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero Paragraph 2">
          <Textarea
            rows={3}
            value={settings.hero_para_2 ?? ''}
            onChange={e => update('hero_para_2', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Hero CTA Label">
          <Input
            value={settings.hero_cta_label ?? ''}
            onChange={e => update('hero_cta_label', e.target.value)}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Regulatory Compliance Context">
        <FormField label="Compliance Heading">
          <Textarea
            rows={2}
            value={settings.compliance_heading ?? ''}
            onChange={e => update('compliance_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Compliance Body">
          <Textarea
            rows={5}
            value={settings.compliance_body ?? ''}
            onChange={e => update('compliance_body', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Compliance Closing">
          <Textarea
            rows={3}
            value={settings.compliance_closing ?? ''}
            onChange={e => update('compliance_closing', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Consequences" hint="Array of {text} objects">
          <Textarea
            rows={6}
            value={JSON.stringify(settings.consequences ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, consequences: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Why ReCircle">
        <FormField label="Why Heading">
          <Input
            value={settings.why_heading ?? ''}
            onChange={e => update('why_heading', e.target.value)}
            disabled={!editable}
          />
        </FormField>
        <FormField label="Why Advantages" hint="Array of {num, title, body} objects">
          <Textarea
            rows={10}
            value={JSON.stringify(settings.why_advantages ?? [], null, 2)}
            onChange={e => {
              try {
                const v = JSON.parse(e.target.value);
                setSettings(s => ({ ...s, why_advantages: v }));
              } catch {}
            }}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>

      <SectionCard title="Infrastructure Strip">
        <FormField label="Infrastructure Body">
          <Textarea
            rows={4}
            value={settings.infra_body ?? ''}
            onChange={e => update('infra_body', e.target.value)}
            disabled={!editable}
          />
        </FormField>
      </SectionCard>
    </div>
  );
}
