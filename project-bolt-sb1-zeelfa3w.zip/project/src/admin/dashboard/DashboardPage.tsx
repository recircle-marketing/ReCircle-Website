import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Home, Building2, Briefcase, BookOpen, Settings, Users, ArrowRight, Clock,
} from 'lucide-react';
import { getCurrentUser } from '../../lib/auth';
import { getRecentAuditEntries } from '../../cms/queries';
import type { ContentAuditEntry } from '../../cms/types';

const quickLinks = [
  {
    label: 'Homepage', icon: <Home size={20} />, href: '/admin/content/hero',
    description: 'Hero, About, Impact, Solutions, Investors, Clients, Accolades, Footer',
    color: '#01298A',
  },
  {
    label: 'Know Us', icon: <Building2 size={20} />, href: '/admin/know-us/story',
    description: 'Our Story, Impact, Infrastructure, Careers, Brand Kit',
    color: '#00C499',
  },
  {
    label: 'Solutions', icon: <Briefcase size={20} />, href: '/admin/solutions/epr',
    description: 'EPR, PNP, Textile, ESG Projects',
    color: '#DCEB4B',
  },
  {
    label: 'Knowledge Centre', icon: <BookOpen size={20} />, href: '/admin/knowledge/blogs',
    description: 'Blogs, Webinars, Annual Reports',
    color: '#01298A',
  },
  {
    label: 'Site Settings', icon: <Settings size={20} />, href: '/admin/settings/seo',
    description: 'SEO defaults, contact details, social links',
    color: '#5F5F5F',
  },
  {
    label: 'User Management', icon: <Users size={20} />, href: '/admin/users',
    description: 'Manage admin accounts and permissions',
    color: '#E7182A',
  },
];

const contentSections = [
  { label: 'Hero / Banner', href: '/admin/content/hero' },
  { label: 'About ReCircle', href: '/admin/content/about' },
  { label: 'Impact Numbers', href: '/admin/content/impact' },
  { label: 'Solutions Pathway', href: '/admin/content/solutions' },
  { label: 'Investors', href: '/admin/content/investors' },
  { label: 'Clients', href: '/admin/content/clients' },
  { label: 'Accolades & Mentions', href: '/admin/content/accolades' },
  { label: 'Footer', href: '/admin/content/footer' },
];

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export default function DashboardPage() {
  const user = getCurrentUser();
  const [auditEntries, setAuditEntries] = useState<ContentAuditEntry[]>([]);
  const [loadingAudit, setLoadingAudit] = useState(true);

  useEffect(() => {
    getRecentAuditEntries(8).then((entries) => {
      setAuditEntries(entries);
      setLoadingAudit(false);
    });
  }, []);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="max-w-5xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1" style={{ color: '#1A1A1A' }}>
          {greeting}, {user?.full_name?.split(' ')[0] ?? 'there'}.
        </h1>
        <p className="text-sm" style={{ color: '#858585' }}>
          Welcome to the ReCircle Content Management System. Select a section below to start editing.
        </p>
      </div>

      {/* Quick links grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {quickLinks.map((link) => (
          <Link
            key={link.label}
            to={link.href}
            className="group flex flex-col justify-between p-5 bg-white border transition-all duration-200"
            style={{ borderColor: '#E8E8E8' }}
            onMouseEnter={(e) => { e.currentTarget.style.borderColor = link.color; e.currentTarget.style.boxShadow = `0 4px 16px ${link.color}18`; }}
            onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#E8E8E8'; e.currentTarget.style.boxShadow = 'none'; }}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-9 h-9 flex items-center justify-center rounded" style={{ backgroundColor: `${link.color}15`, color: link.color }}>
                {link.icon}
              </div>
              <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity duration-200" style={{ color: link.color }} />
            </div>
            <div>
              <h3 className="text-sm font-semibold mb-1" style={{ color: '#1A1A1A' }}>{link.label}</h3>
              <p className="text-xs leading-relaxed" style={{ color: '#858585' }}>{link.description}</p>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Homepage sections quick access */}
        <div className="bg-white border" style={{ borderColor: '#E8E8E8' }}>
          <div className="px-5 py-4 border-b flex items-center justify-between" style={{ borderColor: '#E8E8E8' }}>
            <h2 className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>Homepage Sections</h2>
            <span className="text-xs" style={{ color: '#858585' }}>{contentSections.length} sections</span>
          </div>
          <ul className="divide-y" style={{ borderColor: '#F5F5F5' }}>
            {contentSections.map((s) => (
              <li key={s.label}>
                <Link
                  to={s.href}
                  className="flex items-center justify-between px-5 py-3 text-sm transition-colors duration-150 group"
                  style={{ color: '#3D3D3D' }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#F5F5F5'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                >
                  <span className="font-medium">{s.label}</span>
                  <ArrowRight size={13} className="opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: '#01298A' }} />
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Recent activity */}
        <div className="bg-white border" style={{ borderColor: '#E8E8E8' }}>
          <div className="px-5 py-4 border-b flex items-center gap-2" style={{ borderColor: '#E8E8E8' }}>
            <Clock size={14} style={{ color: '#858585' }} />
            <h2 className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>Recent Activity</h2>
          </div>
          <div className="divide-y" style={{ borderColor: '#F5F5F5' }}>
            {loadingAudit ? (
              <div className="px-5 py-8 text-center">
                <div className="w-5 h-5 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto" />
              </div>
            ) : auditEntries.length === 0 ? (
              <div className="px-5 py-8 text-center">
                <p className="text-sm" style={{ color: '#ABABAB' }}>No activity yet. Start editing content to see changes here.</p>
              </div>
            ) : (
              auditEntries.map((entry) => (
                <div key={entry.id} className="px-5 py-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate" style={{ color: '#1A1A1A' }}>
                        {entry.content_type.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                      </p>
                      <p className="text-xs mt-0.5" style={{ color: '#858585' }}>
                        {entry.action.charAt(0).toUpperCase() + entry.action.slice(1)} by {entry.performed_by_name ?? 'System'}
                      </p>
                    </div>
                    <span className="text-xs shrink-0" style={{ color: '#ABABAB' }}>
                      {timeAgo(entry.performed_at)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Role info */}
      {user && (
        <div className="mt-6 px-4 py-3 border text-xs flex items-center gap-2" style={{ borderColor: '#E8E8E8', backgroundColor: '#FDFBFA', color: '#858585' }}>
          <div className="w-1.5 h-1.5 rounded-full bg-green-400" />
          You are signed in as <strong style={{ color: '#1A1A1A' }}>{user.full_name}</strong> with <strong style={{ color: '#01298A' }}>
            {user.role === 'super_admin' ? 'Super Admin' : user.role === 'editor' ? 'Editor' : 'Viewer'}
          </strong> access.
          {user.role === 'viewer' && ' You can view content but cannot make changes.'}
          {user.role === 'editor' && ' You can create and edit content but cannot publish or delete.'}
          {user.role === 'super_admin' && ' You have full access to all content and user management.'}
        </div>
      )}
    </div>
  );
}
