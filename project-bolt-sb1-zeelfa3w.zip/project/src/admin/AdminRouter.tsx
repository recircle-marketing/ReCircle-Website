import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './login/LoginPage';
import AuthGuard from './guards/AuthGuard';
import AdminLayout from './components/AdminLayout';
import DashboardPage from './dashboard/DashboardPage';
import HeroEditor from './pages/HeroEditor';
import AboutEditor from './pages/AboutEditor';
import ImpactEditor from './pages/ImpactEditor';
import SolutionsEditor from './pages/SolutionsEditor';
import InvestorsEditor from './pages/InvestorsEditor';
import ClientsEditor from './pages/ClientsEditor';
import AccoladesEditor from './pages/AccoladesEditor';
import FooterEditor from './pages/FooterEditor';
import UserManagement from './pages/UserManagement';
import PlaceholderPage from './pages/PlaceholderPage';
import ContactEditor from './pages/ContactEditor';
import ContactEnquiriesViewer from './pages/ContactEnquiriesViewer';
import BlogsEditor from './pages/BlogsEditor';
import CareersEditor from './pages/CareersEditor';
import AnnualReportsEditor from './pages/AnnualReportsEditor';
import WebinarsEditor from './pages/WebinarsEditor';
import ImpactPageEditor from './pages/ImpactPageEditor';
import SeoDefaultsEditor from './pages/SeoDefaultsEditor';
import ContactDetailsEditor from './pages/ContactDetailsEditor';
import SocialLinksEditor from './pages/SocialLinksEditor';
import BrandKitEditor from './pages/BrandKitEditor';
import RPetFlakesEditor from './pages/RPetFlakesEditor';
// New page editors
import StoryEditor from './pages/StoryEditor';
import MrfEditor from './pages/MrfEditor';
import TrfEditor from './pages/TrfEditor';
import RecyclingPlantEditor from './pages/RecyclingPlantEditor';
import PlasticWasteEditor from './pages/PlasticWasteEditor';
import EprEditor from './pages/EprEditor';
import PnpEditor from './pages/PnpEditor';
import TextileWasteEditor from './pages/TextileWasteEditor';
import PitwEditor from './pages/PitwEditor';
import PctwEditor from './pages/PctwEditor';
import EsgEditor from './pages/EsgEditor';

function AdminPages() {
  return (
    <AdminLayout>
      <Routes>
        <Route path="dashboard" element={<DashboardPage />} />

        {/* Homepage content */}
        <Route path="content/hero" element={<HeroEditor />} />
        <Route path="content/about" element={<AboutEditor />} />
        <Route path="content/impact" element={<ImpactEditor />} />
        <Route path="content/solutions" element={<SolutionsEditor />} />
        <Route path="content/investors" element={<InvestorsEditor />} />
        <Route path="content/clients" element={<ClientsEditor />} />
        <Route path="content/accolades" element={<AccoladesEditor />} />
        <Route path="content/footer" element={<FooterEditor />} />

        {/* Know Us */}
        <Route path="know-us/story" element={<StoryEditor />} />
        <Route path="know-us/impact" element={<ImpactPageEditor />} />
        <Route path="know-us/mrf" element={<MrfEditor />} />
        <Route path="know-us/trf" element={<TrfEditor />} />
        <Route path="know-us/recycling-plant" element={<RecyclingPlantEditor />} />
        <Route path="know-us/careers" element={<CareersEditor />} />
        <Route path="know-us/brand-kit" element={<BrandKitEditor />} />

        {/* Solutions */}
        <Route path="solutions/plastic-waste" element={<PlasticWasteEditor />} />
        <Route path="solutions/epr" element={<EprEditor />} />
        <Route path="solutions/pnp" element={<PnpEditor />} />
        <Route path="solutions/pitw" element={<PitwEditor />} />
        <Route path="solutions/pctw" element={<PctwEditor />} />
        <Route path="solutions/textile-waste" element={<TextileWasteEditor />} />
        <Route path="solutions/esg" element={<EsgEditor />} />

        {/* Products */}
        <Route path="products/rpet" element={<RPetFlakesEditor />} />
        <Route path="products/climaone-epr" element={<PlaceholderPage title="ClimaOne for EPR" description="Edit the ClimaOne for EPR product page." />} />
        <Route path="products/climaone-rpet" element={<PlaceholderPage title="ClimaOne for rPET" description="Edit the ClimaOne for rPET product page." />} />

        {/* Knowledge Centre */}
        <Route path="knowledge/blogs" element={<BlogsEditor />} />
        <Route path="knowledge/webinars" element={<WebinarsEditor />} />
        <Route path="knowledge/reports" element={<AnnualReportsEditor />} />

        {/* Contact */}
        <Route path="contact/settings" element={<ContactEditor />} />
        <Route path="contact/enquiries" element={<ContactEnquiriesViewer />} />

        {/* Settings */}
        <Route path="settings/seo" element={<SeoDefaultsEditor />} />
        <Route path="settings/contact" element={<ContactDetailsEditor />} />
        <Route path="settings/social" element={<SocialLinksEditor />} />

        {/* Users */}
        <Route path="users" element={<UserManagement />} />

        {/* Default redirect */}
        <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
      </Routes>
    </AdminLayout>
  );
}

export default function AdminRouter() {
  return (
    <Routes>
      <Route path="login" element={<LoginPage />} />
      <Route
        path="*"
        element={
          <AuthGuard>
            <AdminPages />
          </AuthGuard>
        }
      />
    </Routes>
  );
}
