import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Eye, EyeOff, ArrowRight, AlertCircle } from 'lucide-react';
import { loginWithCredentials, isAuthenticated } from '../../lib/auth';

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string })?.from ?? '/admin/dashboard';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isAuthenticated()) navigate(from, { replace: true });
  }, [navigate, from]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const { error: loginError } = loginWithCredentials(email, password);

    setLoading(false);

    if (loginError) {
      setError(loginError);
      return;
    }

    navigate(from, { replace: true });
  };

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: '#F7F1EE' }}>
      {/* Left panel — branding */}
      <div className="hidden lg:flex lg:w-1/2 relative flex-col justify-between p-12" style={{ backgroundColor: '#01298A' }}>
        <div>
          <img
            src="/images/ReCircle_Logo_Identity_RGB-05.png"
            alt="ReCircle"
            className="h-14 w-auto"
          />
        </div>

        <div>
          <h1 className="text-4xl font-bold text-white leading-tight mb-6">
            Content Management System
          </h1>
          <p className="text-lg text-white/60 leading-relaxed mb-10">
            Manage all website content, sections, pages, and media from one secure, centralized platform.
          </p>

          <div className="space-y-4">
            {[
              'Homepage content and media',
              'Blog posts, webinars, and reports',
              'Solutions, services, and products',
              'SEO metadata and site settings',
            ].map((item) => (
              <div key={item} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full border border-white/30 flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full bg-green-400" />
                </div>
                <span className="text-white/70 text-sm">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <p className="text-white/25 text-xs">
          Swachh Sustainable Solutions Pvt. Ltd. — Authorised Access Only
        </p>
      </div>

      {/* Right panel — login form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Mobile logo — light background, use coloured logo */}
          <div className="mb-10 lg:hidden">
            <img
              src="/images/ReCircle_Logo_Identity_RGB-01.png"
              alt="ReCircle"
              className="h-12 w-auto"
            />
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-1" style={{ color: '#1A1A1A' }}>Sign in to CMS</h2>
            <p className="text-sm" style={{ color: '#858585' }}>
              Authorised team members only. Contact your administrator if you need access.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5" noValidate>
            {/* Error */}
            {error && (
              <div className="flex items-start gap-3 px-4 py-3 rounded border" style={{ backgroundColor: '#FEE2E2', borderColor: '#FECACA' }}>
                <AlertCircle size={16} className="shrink-0 mt-0.5" style={{ color: '#DC2626' }} />
                <p className="text-sm" style={{ color: '#DC2626' }}>{error}</p>
              </div>
            )}

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-1.5" style={{ color: '#1A1A1A' }}>
                Email address
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@recircle.in"
                className="w-full px-4 py-3 border text-sm transition-colors duration-150 focus:outline-none"
                style={{
                  backgroundColor: '#FFFFFF',
                  borderColor: error ? '#FECACA' : '#D1D1D1',
                  color: '#1A1A1A',
                }}
                onFocus={(e) => { e.target.style.borderColor = '#01298A'; }}
                onBlur={(e) => { e.target.style.borderColor = error ? '#FECACA' : '#D1D1D1'; }}
              />
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="password" className="block text-sm font-medium" style={{ color: '#1A1A1A' }}>
                  Password
                </label>
              </div>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full px-4 py-3 pr-11 border text-sm transition-colors duration-150 focus:outline-none"
                  style={{
                    backgroundColor: '#FFFFFF',
                    borderColor: error ? '#FECACA' : '#D1D1D1',
                    color: '#1A1A1A',
                  }}
                  onFocus={(e) => { e.target.style.borderColor = '#01298A'; }}
                  onBlur={(e) => { e.target.style.borderColor = error ? '#FECACA' : '#D1D1D1'; }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 transition-colors"
                  style={{ color: '#858585' }}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading || !email || !password}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 font-medium text-sm text-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ backgroundColor: loading ? '#3F67BE' : '#01298A' }}
              onMouseEnter={(e) => { if (!loading) e.currentTarget.style.backgroundColor = '#011F6B'; }}
              onMouseLeave={(e) => { if (!loading) e.currentTarget.style.backgroundColor = '#01298A'; }}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Signing in…
                </>
              ) : (
                <>
                  Sign in
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t" style={{ borderColor: '#E8E8E8' }}>
            <p className="text-xs text-center" style={{ color: '#ABABAB' }}>
              This is a restricted system. Unauthorised access is prohibited.<br />
              Sessions expire after 8 hours of inactivity.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}