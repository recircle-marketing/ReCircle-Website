interface FormFieldProps {
  label: string;
  hint?: string;
  required?: boolean;
  children: React.ReactNode;
  error?: string;
}

export function FormField({ label, hint, required, children, error }: FormFieldProps) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5" style={{ color: '#1A1A1A' }}>
        {label}
        {required && <span className="ml-1" style={{ color: '#E7182A' }}>*</span>}
      </label>
      {hint && <p className="text-xs mb-2" style={{ color: '#858585' }}>{hint}</p>}
      {children}
      {error && <p className="text-xs mt-1" style={{ color: '#E7182A' }}>{error}</p>}
    </div>
  );
}

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
}

export function Input({ error, className = '', ...props }: InputProps) {
  return (
    <input
      className={`w-full px-3 py-2.5 border text-sm focus:outline-none transition-colors duration-150 ${className}`}
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: error ? '#FECACA' : '#D1D1D1',
        color: '#1A1A1A',
      }}
      onFocus={(e) => { e.target.style.borderColor = '#01298A'; }}
      onBlur={(e) => { e.target.style.borderColor = error ? '#FECACA' : '#D1D1D1'; }}
      {...props}
    />
  );
}

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: boolean;
}

export function Textarea({ error, className = '', ...props }: TextareaProps) {
  return (
    <textarea
      className={`w-full px-3 py-2.5 border text-sm focus:outline-none transition-colors duration-150 resize-none ${className}`}
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: error ? '#FECACA' : '#D1D1D1',
        color: '#1A1A1A',
      }}
      onFocus={(e) => { e.target.style.borderColor = '#01298A'; }}
      onBlur={(e) => { e.target.style.borderColor = error ? '#FECACA' : '#D1D1D1'; }}
      rows={4}
      {...props}
    />
  );
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {}

export function Select({ className = '', children, ...props }: SelectProps) {
  return (
    <select
      className={`w-full px-3 py-2.5 border text-sm focus:outline-none transition-colors duration-150 ${className}`}
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#D1D1D1',
        color: '#1A1A1A',
      }}
      onFocus={(e) => { e.target.style.borderColor = '#01298A'; }}
      onBlur={(e) => { e.target.style.borderColor = '#D1D1D1'; }}
      {...props}
    >
      {children}
    </select>
  );
}

interface SaveButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  saving?: boolean;
  saved?: boolean;
}

export function SaveButton({ saving, saved, children = 'Save Changes', className = '', ...props }: SaveButtonProps) {
  return (
    <button
      className={`inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
      style={{ backgroundColor: saved ? '#00A882' : '#01298A' }}
      disabled={saving}
      {...props}
    >
      {saving ? (
        <>
          <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          Saving…
        </>
      ) : saved ? (
        <>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2 7L5.5 10.5L12 4" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Saved
        </>
      ) : (
        <>{children}</>
      )}
    </button>
  );
}

export function SectionCard({ title, children, description }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border" style={{ borderColor: '#E8E8E8' }}>
      <div className="px-6 py-4 border-b" style={{ borderColor: '#E8E8E8' }}>
        <h3 className="text-sm font-semibold" style={{ color: '#1A1A1A' }}>{title}</h3>
        {description && <p className="text-xs mt-0.5" style={{ color: '#858585' }}>{description}</p>}
      </div>
      <div className="p-6">{children}</div>
    </div>
  );
}
