import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Home, BookOpen, Users, Settings, ChevronDown,
  LogOut, Menu, Building2, Briefcase, Package, ChevronRight, Mail,
} from 'lucide-react';
import { getCurrentUser, logout, canManageUsers } from '../../lib/auth';

interface NavSection {
  id: string;
  label: string;
  icon: React.ReactNode;
  href?: string;
  children?: { label: string; href: string }[];
}

const navSections: NavSection[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={16} />, href: '/admin/dashboard' },
  {
    id: 'homepage', label: 'Homepage', icon: <Home size={16} />,
    children: [
      { label: 'Hero / Banner', href: '/admin/content/hero' },
      { label: 'About ReCircle', href: '/admin/content/about' },
      { label: 'Impact Numbers', href: '/admin/content/impact' },
      { label: 'Solutions Pathway', href: '/admin/content/solutions' },
      { label: 'Investors', href: '/admin/content/investors' },
      { label: 'Clients', href: '/admin/content/clients' },
      { label: 'Accolades', href: '/admin/content/accolades' },
      { label: 'Footer', href: '/admin/content/footer' },
    ],
  },
  {
    id: 'know-us', label: 'Know Us', icon: <Building2 size={16} />,
    children: [
      { label: 'Our Story', href: '/admin/know-us/story' },
      { label: 'Our Impact', href: '/admin/know-us/impact' },
      { label: 'Infrastructure — MRF', href: '/admin/know-us/mrf' },
      { label: 'Infrastructure — TRF', href: '/admin/know-us/trf' },
      { label: 'Recycling Plant', href: '/admin/know-us/recycling-plant' },
      { label: 'Careers', href: '/admin/know-us/careers' },
      { label: 'Brand Kit Link', href: '/admin/know-us/brand-kit' },
    ],
  },
  {
    id: 'solutions', label: 'Solutions', icon: <Briefcase size={16} />,
    children: [
      { label: 'Plastic Waste Management', href: '/admin/solutions/plastic-waste' },
      { label: 'EPR Service', href: '/admin/solutions/epr' },
      { label: 'Plastic Neutral Programme', href: '/admin/solutions/pnp' },
      { label: 'Textile Waste Management', href: '/admin/solutions/textile-waste' },
      { label: 'Textile — PITW', href: '/admin/solutions/pitw' },
      { label: 'Textile — PCTW', href: '/admin/solutions/pctw' },
      { label: 'ESG Projects', href: '/admin/solutions/esg' },
    ],
  },
  {
    id: 'products', label: 'Products', icon: <Package size={16} />,
    children: [
      { label: 'rPET Flakes', href: '/admin/products/rpet' },
      { label: 'ClimaOne for EPR', href: '/admin/products/climaone-epr' },
      { label: 'ClimaOne for rPET', href: '/admin/products/climaone-rpet' },
    ],
  },
  {
    id: 'knowledge', label: 'Knowledge Centre', icon: <BookOpen size={16} />,
    children: [
      { label: 'Blogs', href: '/admin/knowledge/blogs' },
      { label: 'Webinars', href: '/admin/knowledge/webinars' },
      { label: 'Annual Reports', href: '/admin/knowledge/reports' },
    ],
  },
  {
    id: 'contact', label: 'Contact Page', icon: <Mail size={16} />,
    children: [
      { label: 'Page Settings', href: '/admin/contact/settings' },
      { label: 'Enquiries', href: '/admin/contact/enquiries' },
    ],
  },
  {
    id: 'settings', label: 'Site Settings', icon: <Settings size={16} />,
    children: [
      { label: 'SEO Defaults', href: '/admin/settings/seo' },
      { label: 'Contact Details', href: '/admin/settings/contact' },
      { label: 'Social Links', href: '/admin/settings/social' },
    ],
  },
];

function RoleBadge({ role }: { role: string }) {
  const styles: Record<string, { bg: string; text: string; label: string }> = {
    super_admin: { bg: '#E8EDF8', text: '#01298A', label: 'Super Admin' },
    editor: { bg: '#E0FAF4', text: '#00A882', label: 'Editor' },
    viewer: { bg: '#F5F5F5', text: '#5F5F5F', label: 'Viewer' },
  };
  const s = styles[role] ?? styles.viewer;
  return (
    <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: s.bg, color: s.text }}>
      {s.label}
    </span>
  );
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const user = getCurrentUser();
  const [expanded, setExpanded] = useState<string | null>('homepage');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/admin/login', { replace: true });
  };

  const isActive = (href: string) => location.pathname === href;
  const isParentActive = (section: NavSection) =>
    section.children?.some((c) => location.pathname.startsWith(c.href)) ?? false;

  const filteredSections = navSections.filter(
    (s) => s.id !== 'users' || canManageUsers()
  );

  const Sidebar = () => (
    <aside className="flex flex-col h-full" style={{ backgroundColor: '#1A1A1A', width: '240px' }}>
      {/* Logo */}
      <div className="flex items-center justify-between px-5 py-5 border-b" style={{ borderColor: '#2E2E2E' }}>
        <img
          src="/images/ReCircle_Logo_Identity_RGB-05.png"
          alt="ReCircle"
          className="h-9 w-auto flex-shrink-0"
        />
        <span className="text-xs font-medium" style={{ color: '#858585' }}>CMS</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 no-scrollbar">
        {filteredSections.map((section) => {
          const parentActive = isParentActive(section);
          const isOpen = expanded === section.id || parentActive;

          return (
            <div key={section.id} className="mb-0.5">
              {section.href ? (
                <Link
                  to={section.href}
                  className="flex items-center gap-2.5 px-5 py-2.5 text-sm font-medium transition-colors duration-150"
                  style={{
                    color: isActive(section.href) ? '#00C499' : '#ABABAB',
                    backgroundColor: isActive(section.href) ? 'rgba(0,196,153,0.08)' : 'transparent',
                  }}
                  onClick={() => setSidebarOpen(false)}
                >
                  <span style={{ color: isActive(section.href) ? '#00C499' : '#858585' }}>{section.icon}</span>
                  {section.label}
                </Link>
              ) : (
                <>
                  <button
                    onClick={() => setExpanded(isOpen ? null : section.id)}
                    className="w-full flex items-center justify-between px-5 py-2.5 text-sm font-medium transition-colors duration-150"
                    style={{ color: parentActive ? '#00C499' : '#ABABAB' }}
                  >
                    <div className="flex items-center gap-2.5">
                      <span style={{ color: parentActive ? '#00C499' : '#858585' }}>{section.icon}</span>
                      {section.label}
                    </div>
                    <ChevronDown
                      size={13}
                      className="transition-transform duration-200"
                      style={{
                        transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
                        color: '#5F5F5F',
                      }}
                    />
                  </button>

                  {isOpen && section.children && (
                    <div className="pb-1">
                      {section.children.map((child) => (
                        <Link
                          key={child.href}
                          to={child.href}
                          className="flex items-center gap-2 pl-11 pr-5 py-2 text-xs transition-colors duration-150"
                          style={{
                            color: isActive(child.href) ? '#00C499' : '#858585',
                            backgroundColor: isActive(child.href) ? 'rgba(0,196,153,0.06)' : 'transparent',
                          }}
                          onClick={() => setSidebarOpen(false)}
                        >
                          <ChevronRight size={10} style={{ color: isActive(child.href) ? '#00C499' : '#5F5F5F' }} />
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>
          );
        })}

        {/* User Management — super admin only */}
        {canManageUsers() && (
          <div className="mt-2 border-t pt-2" style={{ borderColor: '#2E2E2E' }}>
            <Link
              to="/admin/users"
              className="flex items-center gap-2.5 px-5 py-2.5 text-sm font-medium transition-colors duration-150"
              style={{
                color: location.pathname.startsWith('/admin/users') ? '#00C499' : '#ABABAB',
              }}
              onClick={() => setSidebarOpen(false)}
            >
              <Users size={16} style={{ color: location.pathname.startsWith('/admin/users') ? '#00C499' : '#858585' }} />
              User Management
            </Link>
          </div>
        )}
      </nav>

      {/* User info + logout */}
      <div className="border-t p-4" style={{ borderColor: '#2E2E2E' }}>
        {user && (
          <div className="flex items-center justify-between">
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-white truncate">{user.full_name}</p>
              <p className="text-xs truncate mt-0.5" style={{ color: '#858585' }}>{user.email}</p>
              <div className="mt-1">
                <RoleBadge role={user.role} />
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="ml-3 p-2 rounded transition-colors duration-150 shrink-0"
              style={{ color: '#858585' }}
              onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }}
              onMouseLeave={(e) => { e.currentTarget.style.color = '#858585'; }}
              title="Sign out"
            >
              <LogOut size={16} />
            </button>
          </div>
        )}
      </div>
    </aside>
  );

  return (
    <div className="flex h-screen overflow-hidden" style={{ backgroundColor: '#F5F5F5' }}>
      {/* Desktop sidebar */}
      <div className="hidden lg:flex flex-shrink-0">
        <Sidebar />
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="flex-shrink-0">
            <Sidebar />
          </div>
          <div className="flex-1 bg-black/50" onClick={() => setSidebarOpen(false)} />
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center justify-between px-6 py-4 bg-white border-b flex-shrink-0" style={{ borderColor: '#E8E8E8' }}>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-1.5 transition-colors duration-150"
              style={{ color: '#858585' }}
            >
              <Menu size={20} />
            </button>

            {/* Breadcrumb — show section from path */}
            <div className="text-sm" style={{ color: '#858585' }}>
              <span style={{ color: '#1A1A1A', fontWeight: 500 }}>
                {location.pathname.split('/').filter(Boolean).slice(1).join(' / ').replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) || 'Dashboard'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {user && <RoleBadge role={user.role} />}
            <a
              href="/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-medium px-3 py-1.5 border transition-colors duration-150"
              style={{ color: '#858585', borderColor: '#D1D1D1' }}
              onMouseEnter={(e) => { e.currentTarget.style.color = '#01298A'; e.currentTarget.style.borderColor = '#01298A'; }}
              onMouseLeave={(e) => { e.currentTarget.style.color = '#858585'; e.currentTarget.style.borderColor = '#D1D1D1'; }}
            >
              View Website ↗
            </a>
            <button
              onClick={handleLogout}
              className="hidden lg:flex items-center gap-1.5 text-xs font-medium transition-colors duration-150"
              style={{ color: '#858585' }}
              onMouseEnter={(e) => { e.currentTarget.style.color = '#E7182A'; }}
              onMouseLeave={(e) => { e.currentTarget.style.color = '#858585'; }}
            >
              <LogOut size={14} />
              Sign out
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
