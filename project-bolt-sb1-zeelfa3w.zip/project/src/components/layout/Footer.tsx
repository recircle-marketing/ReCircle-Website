import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Instagram, Facebook, Linkedin, Mail, Send } from 'lucide-react';

const BRAND_KIT_URL = 'https://drive.google.com/drive/folders/1tfDGoJ2VPTv65OE2B-gjiApT9btxRxRt?usp=drive_link';
import { getFooterContent } from '../../cms/queries';
import type { FooterContent } from '../../cms/types';

const FALLBACK: FooterContent = {
  id: '',
  tagline: 'Accelerating India\'s transition toward a circular economy through technology, infrastructure, and ground-level operations.',
  grievance_officer_name: 'Rahul Nainani',
  grievance_officer_phone: '+91 90042 40004',
  grievance_officer_email: 'info@recircle.in',
  newsletter_cta_text: 'Subscribe for industry insights.',
  social_links: [
    { platform: 'Instagram', url: 'https://instagram.com' },
    { platform: 'Facebook', url: 'https://facebook.com' },
    { platform: 'LinkedIn', url: 'https://linkedin.com' },
    { platform: 'Email', url: 'mailto:info@recircle.in' },
  ],
  nav_columns: [],
  legal_company_name: 'Swachh Sustainable Solutions Pvt. Ltd.',
  legal_cin: 'U74900MH2016PTC273536',
  legal_copyright: '© All Rights Reserved 2026–2027',
  updated_at: '',
};

const knowUsLinks = [
  { label: 'Our Story', href: '/about' },
  { label: 'Our Impact', href: '/impact' },
  { label: 'Infrastructure', href: '#infrastructure', children: [
    { label: 'MRF', href: '/infrastructure/mrf' },
    { label: 'TRF', href: '/infrastructure/trf' },
    { label: 'Recycling Plant', href: '/infrastructure/recycling-plant' },
  ]},
  { label: 'Careers', href: '/careers' },
  { label: 'Brand Kit', href: BRAND_KIT_URL, external: true },
];

const solutionServices = {
  plastic: [{ label: 'EPR', href: '/epr' }, { label: 'PNP', href: '/pnp' }],
  textile: [{ label: 'PITW', href: '/textile/pitw' }, { label: 'PCTW', href: '/textile/pctw' }],
};

const solutionProducts = [
  { label: 'rPET Flakes', href: '/rpet-flakes', internal: true },
  { label: 'ClimaOne for EPR', href: '/climaone-epr', internal: true },
  { label: 'ClimaOne for rPET', href: 'https://climaonev2.recircle.in/', internal: false },
];

const knowledgeLinks = [
  { label: 'Blogs', href: '/knowledge-centre' },
  { label: 'Webinars', href: '/webinars' },
  { label: 'Annual Reports', href: '/annual-reports' },
];

const socialIconMap: Record<string, React.ReactNode> = {
  Instagram: <Instagram size={14} />,
  Facebook: <Facebook size={14} />,
  LinkedIn: <Linkedin size={14} />,
  Email: <Mail size={14} />,
};

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [content, setContent] = useState<FooterContent>(FALLBACK);

  useEffect(() => {
    getFooterContent().then((data) => {
      if (data) setContent(data);
    });
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <footer id="contact" className="bg-charcoal-900 text-white">
      {/* Main footer content */}
      <div className="container-site py-16 lg:py-20">
        <div className="grid lg:grid-cols-[280px_1fr] gap-12 lg:gap-16">

          {/* Left section */}
          <div>
            {/* Logo */}
            <div className="mb-8">
              <img
                src="/images/ReCircle_Logo_Identity_RGB-05.png"
                alt="ReCircle"
                className="h-14 w-auto"
              />
            </div>

            <p className="text-body-sm text-white/50 leading-relaxed mb-8 font-light">{content.tagline}</p>

            {/* Newsletter */}
            <div>
              <p className="text-body-sm font-medium text-white/70 mb-3">{content.newsletter_cta_text}</p>
              {subscribed ? (
                <div className="flex items-center gap-2 text-green-primary text-body-sm font-medium">
                  <div className="w-4 h-4 rounded-full bg-green-primary flex items-center justify-center">
                    <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
                      <path d="M1 4L3 6L7 2" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  You're subscribed. Thank you.
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="flex-1 bg-white/10 border border-white/15 px-4 py-2.5 text-body-sm text-white placeholder-white/35 focus:outline-none focus:border-green-primary transition-colors duration-200 min-w-0"
                    required
                  />
                  <button type="submit" className="px-4 py-2.5 bg-green-primary text-white hover:bg-green-600 transition-colors duration-200 flex items-center justify-center shrink-0" aria-label="Subscribe">
                    <Send size={14} />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Right section — nav columns */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-6">

            {/* Know Us */}
            <div>
              <h3 className="text-body-sm font-semibold text-white tracking-wide mb-5 pb-3 border-b border-white/10">Know Us</h3>
              <ul className="space-y-2.5">
                {knowUsLinks.map((link) => {
                  const isExternal = 'external' in link && link.external;
                  const isAnchor = link.href.startsWith('#');
                  return (
                    <li key={link.label}>
                      {isExternal ? (
                        <a href={link.href} target="_blank" rel="noopener noreferrer" className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block">{link.label}</a>
                      ) : isAnchor ? (
                        <a href={link.href} className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block">{link.label}</a>
                      ) : (
                        <Link to={link.href} className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block">{link.label}</Link>
                      )}
                      {'children' in link && link.children && (
                        <ul className="mt-1.5 ml-3 space-y-1.5 border-l border-white/10 pl-3">
                          {link.children.map((child) => (
                            <li key={child.label}>
                              {child.href.startsWith('/') ? (
                                <Link to={child.href} className="text-caption text-white/35 hover:text-white/70 transition-colors duration-200 block">{child.label}</Link>
                              ) : (
                                <a href={child.href} className="text-caption text-white/35 hover:text-white/70 transition-colors duration-200 block">{child.label}</a>
                              )}
                            </li>
                          ))}
                        </ul>
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Solutions */}
            <div>
              <h3 className="text-body-sm font-semibold text-white tracking-wide mb-5 pb-3 border-b border-white/10">Solutions</h3>
              <p className="text-caption font-semibold tracking-widest uppercase text-white/35 mb-2">Services</p>
              <div className="mb-4">
                <a href="/plastic-waste" className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block mb-1.5">Plastic</a>
                <ul className="ml-3 space-y-1.5 border-l border-white/10 pl-3">
                  {solutionServices.plastic.map((s) => (
                    <li key={s.label}>
                      {s.href.startsWith('/') ? (
                        <Link to={s.href} className="text-caption text-white/35 hover:text-white/70 transition-colors duration-200 block">{s.label}</Link>
                      ) : (
                        <a href={s.href} className="text-caption text-white/35 hover:text-white/70 transition-colors duration-200 block">{s.label}</a>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mb-5">
                <a href="/textile" className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block mb-1.5">Textile</a>
                <ul className="ml-3 space-y-1.5 border-l border-white/10 pl-3">
                  {solutionServices.textile.map((s) => (
                    <li key={s.label}><a href={s.href} className="text-caption text-white/35 hover:text-white/70 transition-colors duration-200 block">{s.label}</a></li>
                  ))}
                </ul>
              </div>
              <p className="text-caption font-semibold tracking-widest uppercase text-white/35 mb-2">Products</p>
              <ul className="space-y-2 mb-4">
                {solutionProducts.map((p) => (
                  <li key={p.label}>
                    {p.internal ? (
                      <Link to={p.href} className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block">{p.label}</Link>
                    ) : (
                      <a href={p.href} target="_blank" rel="noopener noreferrer" className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block">{p.label}</a>
                    )}
                  </li>
                ))}
              </ul>
              <Link to="/esg-projects" className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block">ESG Projects</Link>
            </div>

            {/* Knowledge Centre */}
            <div>
              <h3 className="text-body-sm font-semibold text-white tracking-wide mb-5 pb-3 border-b border-white/10">Knowledge Centre</h3>
              <ul className="space-y-2.5">
                {knowledgeLinks.map((link) => (
                  <li key={link.label}>
                    <Link to={link.href} className="text-body-sm text-white/50 hover:text-white transition-colors duration-200 block">{link.label}</Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Us */}
            <div>
              <h3 className="text-body-sm font-semibold text-white tracking-wide mb-5 pb-3 border-b border-white/10">Contact Us</h3>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-4 py-2.5 border border-white/20 text-white text-body-sm font-medium hover:bg-white hover:text-charcoal transition-all duration-300 group mb-5"
              >
                Contact Us
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
              <div className="space-y-2 mt-4">
                <p className="text-caption text-white/35 leading-relaxed">Mumbai, Maharashtra, India</p>
                <a href={`tel:${content.grievance_officer_phone}`} className="text-body-sm text-white/50 hover:text-green-primary transition-colors duration-200 block">
                  {content.grievance_officer_phone}
                </a>
                <a href={`mailto:${content.grievance_officer_email}`} className="text-body-sm text-white/50 hover:text-green-primary transition-colors duration-200 block">
                  {content.grievance_officer_email}
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Social links */}
        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <span className="text-caption text-white/30 tracking-wider uppercase font-medium">Follow Us</span>
            <div className="flex items-center gap-3">
              {content.social_links.map((social) => (
                <a
                  key={social.platform}
                  href={social.url}
                  target={social.platform !== 'Email' ? '_blank' : undefined}
                  rel={social.platform !== 'Email' ? 'noopener noreferrer' : undefined}
                  className="w-8 h-8 border border-white/15 flex items-center justify-center text-white/40 hover:text-white hover:border-white/40 transition-all duration-200"
                  aria-label={social.platform}
                >
                  {socialIconMap[social.platform] ?? <Mail size={14} />}
                </a>
              ))}
            </div>
          </div>
          <div className="flex flex-wrap gap-4">
            <Link to="/privacy-policy" className="text-caption text-white/30 hover:text-white/60 transition-colors duration-200">Privacy Policy</Link>
            <Link to="/terms-of-use" className="text-caption text-white/30 hover:text-white/60 transition-colors duration-200">Terms of Use</Link>
          </div>
        </div>
      </div>

      {/* Legal strip */}
      <div className="border-t border-white/8 bg-charcoal-900">
        <div className="container-site py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <p className="text-caption text-white/25 font-light">
            {content.legal_company_name} (CIN – {content.legal_cin})
          </p>
          <p className="text-caption text-white/25 font-light">{content.legal_copyright}</p>
        </div>
      </div>
    </footer>
  );
}
