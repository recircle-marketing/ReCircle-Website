import { useState, useEffect, useRef } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Menu, X, ChevronDown, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const BRAND_KIT_URL = 'https://drive.google.com/drive/folders/1tfDGoJ2VPTv65OE2B-gjiApT9btxRxRt?usp=drive_link';

function NavLinkEl({ href, children, onClick, className }: { href: string; children: React.ReactNode; onClick?: () => void; className?: string }) {
  const isExternal = href.startsWith('http') || href.startsWith('mailto');
  const isAnchor = href.startsWith('#');
  if (isExternal || isAnchor) {
    return <a href={href} target={isExternal ? '_blank' : undefined} rel={isExternal ? 'noopener noreferrer' : undefined} onClick={onClick} className={className}>{children}</a>;
  }
  return <Link to={href} onClick={onClick} className={className}>{children}</Link>;
}

interface NavItem {
  label: string;
  href: string;
  children?: NavColumn[];
}

interface NavColumn {
  heading: string;
  links: NavLink[];
}

interface NavLink {
  label: string;
  href: string;
  description?: string;
  sub?: NavLink[];
}

const navItems: NavItem[] = [
  {
    label: 'Know Us',
    href: '#know-us',
    children: [
      {
        heading: 'Company',
        links: [
          { label: 'Our Story', href: '/about', description: 'How we started and where we are going' },
          { label: 'Our Impact', href: '/impact', description: 'Measurable environmental and social impact' },
          { label: 'Careers', href: '/careers', description: 'Join the circular economy movement' },
          { label: 'Brand Kit', href: '/brand-kit', description: 'Assets, guidelines, and resources' },
        ],
      },
      {
        heading: 'Infrastructure',
        links: [
          { label: 'MRF — Material Recovery Facility', href: '/infrastructure/mrf', description: 'Sorting and processing infrastructure' },
          { label: 'TRF — Textile Recovery Facility', href: '/infrastructure/trf', description: 'Textile waste recovery systems' },
          { label: 'Recycling Plant', href: '/infrastructure/recycling-plant', description: 'End-to-end recycling operations' },
        ],
      },
    ],
  },
  {
    label: 'Solutions',
    href: '#solutions',
    children: [
      {
        heading: 'Services',
        links: [
          {
            label: 'Plastic',
            href: '/plastic-waste',
            sub: [
              { label: 'EPR — Extended Producer Responsibility', href: '/epr' },
              { label: 'PNP — Plastic Neutral Programme', href: '/pnp' },
            ],
          },
          {
            label: 'Textile',
            href: '/textile',
            sub: [
              { label: 'PITW — Post-Industrial Textile Waste', href: '/textile/pitw' },
              { label: 'PCTW — Post-Consumer Textile Waste', href: '/textile/pctw' },
            ],
          },
        ],
      },
      {
        heading: 'Products',
        links: [
          { label: 'rPET Flakes', href: '/rpet-flakes', description: 'Food-grade recycled PET for circular packaging' },
          { label: 'ClimaOne for EPR', href: '/climaone-epr', description: 'Traceability platform for EPR compliance' },
          { label: 'ClimaOne for rPET', href: 'https://climaonev2.recircle.in/', description: 'Supply chain visibility for recycled materials' },
        ],
      },
      {
        heading: 'ESG',
        links: [
          { label: 'ESG Projects', href: '/esg-projects', description: 'Custom CSR and ESG impact projects' },
        ],
      },
    ],
  },
  {
    label: 'Knowledge Centre',
    href: '#knowledge',
    children: [
      {
        heading: 'Resources',
        links: [
          { label: 'Blogs', href: '/knowledge-centre', description: 'Thought leadership and industry insights' },
          { label: 'Webinars', href: '/webinars', description: 'Expert sessions on circularity' },
          { label: 'Annual Reports', href: '/annual-reports', description: 'Impact reports and data publications' },
        ],
      },
    ],
  },
];

// Pages with a full-bleed dark hero image — nav starts transparent with white text
const TRANSPARENT_NAV_ROUTES = ['/'];

export default function Navigation() {
  const location = useLocation();
  const isTransparentRoute = TRANSPARENT_NAV_ROUTES.includes(location.pathname);
  const [scrolled, setScrolled] = useState(false);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileExpanded, setMobileExpanded] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // On route change reset scroll detection
  useEffect(() => {
    setScrolled(window.scrollY > 24);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Solid when: scrolled, mobile open, or not on a transparent-nav route
  const isSolid = scrolled || mobileOpen || !isTransparentRoute;

  const handleMouseEnter = (label: string) => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setActiveMenu(label);
  };

  const handleMouseLeave = () => {
    closeTimer.current = setTimeout(() => setActiveMenu(null), 150);
  };

  const activeItem = navItems.find((i) => i.label === activeMenu);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isSolid
            ? 'bg-white shadow-nav border-b border-charcoal-100'
            : 'bg-transparent'
        }`}
      >
        <div className="container-site">
          <div className="flex items-center justify-between h-18">
            {/* Logo */}
            <a href="/" className="flex items-center shrink-0" aria-label="ReCircle Home">
              <img
                src={isSolid ? '/images/ReCircle_Logo_Identity_RGB-01.png' : '/images/ReCircle_Logo_Identity_RGB-05.png'}
                alt="ReCircle"
                className="h-12 w-auto transition-opacity duration-300"
              />
            </a>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1" ref={menuRef}>
              {navItems.map((item) => (
                <div
                  key={item.label}
                  className="relative"
                  onMouseEnter={() => handleMouseEnter(item.label)}
                  onMouseLeave={handleMouseLeave}
                >
                  <button
                    className={`flex items-center gap-1 px-4 py-2 text-body-sm font-medium transition-colors duration-200 ${
                      isSolid
                        ? 'text-charcoal-700 hover:text-blue-primary'
                        : 'text-white/90 hover:text-white'
                    } ${activeMenu === item.label ? (isSolid ? 'text-blue-primary' : 'text-white') : ''}`}
                  >
                    {item.label}
                    <ChevronDown
                      size={14}
                      className={`transition-transform duration-200 ${activeMenu === item.label ? 'rotate-180' : ''}`}
                    />
                  </button>
                </div>
              ))}
            </nav>

            {/* CTA + Mobile Toggle */}
            <div className="flex items-center gap-4">
              <a
                href="/contact"
                className={`hidden lg:inline-flex items-center gap-2 px-5 py-2.5 text-body-sm font-medium transition-all duration-200 ${
                  isSolid
                    ? 'bg-blue-primary text-white hover:bg-blue-800'
                    : 'bg-white/10 border border-white/30 text-white hover:bg-white hover:text-blue-primary backdrop-blur-sm'
                }`}
              >
                Contact Us
                <ArrowRight size={14} />
              </a>
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className={`lg:hidden p-2 transition-colors duration-200 ${
                  isSolid ? 'text-charcoal' : 'text-white'
                }`}
                aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
              >
                {mobileOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Desktop Dropdown Mega Menu */}
        <AnimatePresence>
          {activeMenu && activeItem?.children && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              className="absolute top-full left-0 right-0 bg-white shadow-dropdown border-t border-charcoal-100 hidden lg:block"
              onMouseEnter={() => { if (closeTimer.current) clearTimeout(closeTimer.current); }}
              onMouseLeave={handleMouseLeave}
            >
              <div className="container-site py-8">
                <div className="flex gap-12">
                  {activeItem.children.map((col) => (
                    <div key={col.heading} className="min-w-[200px]">
                      <p className="text-caption font-semibold tracking-widest uppercase text-charcoal-400 mb-4">
                        {col.heading}
                      </p>
                      <ul className="space-y-1">
                        {col.links.map((link) => {
                          const isBrandKit = link.href === '/brand-kit';
                          const finalHref = isBrandKit ? BRAND_KIT_URL : link.href;
                          return (
                            <li key={link.label}>
                              <NavLinkEl
                                href={finalHref}
                                className="group block py-2"
                                onClick={() => setActiveMenu(null)}
                              >
                                <span className="text-body-sm font-medium text-charcoal group-hover:text-blue-primary transition-colors duration-150 flex items-center gap-1">
                                  {link.label}
                                  <ArrowRight size={12} className="opacity-0 group-hover:opacity-100 transition-opacity -translate-x-1 group-hover:translate-x-0 transition-transform duration-150" />
                                </span>
                                {link.description && (
                                  <span className="text-caption text-charcoal-400 mt-0.5 block">{link.description}</span>
                                )}
                                {link.sub && (
                                  <ul className="mt-2 ml-3 space-y-1 border-l border-charcoal-100 pl-3">
                                    {link.sub.map((s) => (
                                      <li key={s.label}>
                                        <NavLinkEl href={s.href} className="text-body-sm text-charcoal-500 hover:text-blue-primary transition-colors duration-150 block py-0.5">
                                          {s.label}
                                        </NavLinkEl>
                                      </li>
                                    ))}
                                  </ul>
                                )}
                              </NavLinkEl>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="fixed inset-0 z-40 bg-white lg:hidden"
            style={{ top: '72px' }}
          >
            <div className="h-full overflow-y-auto">
              <nav className="container-site py-6">
                {navItems.map((item) => (
                  <div key={item.label} className="border-b border-charcoal-100">
                    <button
                      onClick={() => setMobileExpanded(mobileExpanded === item.label ? null : item.label)}
                      className="flex items-center justify-between w-full py-4 text-heading-md font-medium text-charcoal"
                    >
                      {item.label}
                      <ChevronDown
                        size={18}
                        className={`transition-transform duration-200 text-charcoal-400 ${mobileExpanded === item.label ? 'rotate-180' : ''}`}
                      />
                    </button>
                    <AnimatePresence>
                      {mobileExpanded === item.label && item.children && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.25 }}
                          className="overflow-hidden"
                        >
                          <div className="pb-4 space-y-4">
                            {item.children.map((col) => (
                              <div key={col.heading}>
                                <p className="text-caption font-semibold tracking-widest uppercase text-charcoal-400 mb-2 ml-2">
                                  {col.heading}
                                </p>
                                <ul>
                                  {col.links.map((link) => {
                                    const isBrandKit = link.href === '/brand-kit';
                                    const finalHref = isBrandKit ? BRAND_KIT_URL : link.href;
                                    return (
                                      <li key={link.label}>
                                        <NavLinkEl
                                          href={finalHref}
                                          className="block py-2.5 px-2 text-body-lg font-medium text-charcoal-700 hover:text-blue-primary transition-colors duration-150"
                                          onClick={() => setMobileOpen(false)}
                                        >
                                          {link.label}
                                        </NavLinkEl>
                                        {link.sub && (
                                          <ul className="ml-4 border-l border-charcoal-100 pl-4">
                                            {link.sub.map((s) => (
                                              <li key={s.label}>
                                                <NavLinkEl
                                                  href={s.href}
                                                  className="block py-2 text-body-sm text-charcoal-500 hover:text-blue-primary transition-colors duration-150"
                                                  onClick={() => setMobileOpen(false)}
                                                >
                                                  {s.label}
                                                </NavLinkEl>
                                              </li>
                                            ))}
                                          </ul>
                                        )}
                                      </li>
                                    );
                                  })}
                                </ul>
                              </div>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
                <div className="pt-6">
                  <Link
                    to="/contact"
                    className="btn-primary w-full justify-center"
                    onClick={() => setMobileOpen(false)}
                  >
                    Contact Us
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
