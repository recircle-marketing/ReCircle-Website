import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Mail } from 'lucide-react';

const TEAL = '#00C499';
const NAVY = '#01298A';

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.5, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] },
  }),
};

interface Section {
  number: string;
  heading: string;
  content: React.ReactNode;
}

function SectionBlock({ section, index }: { section: Section; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-40px' });

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={inView ? 'visible' : 'hidden'}
      variants={fadeUp}
      custom={index % 4}
      className="scroll-mt-24"
      id={`section-${section.number}`}
    >
      <div className="flex gap-5 items-baseline mb-4">
        <span className="text-xs font-bold tabular-nums flex-shrink-0 w-6" style={{ color: TEAL }}>
          {section.number}
        </span>
        <h2 className="text-base font-bold" style={{ color: NAVY, letterSpacing: '-0.01em' }}>
          {section.heading}
        </h2>
      </div>
      <div className="ml-11 space-y-3 text-sm leading-relaxed" style={{ color: '#4A4A4A' }}>
        {section.content}
      </div>
    </motion.div>
  );
}

function Bullet({ children }: { children: React.ReactNode }) {
  return (
    <li className="flex gap-2.5 items-start">
      <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: TEAL }} />
      <span>{children}</span>
    </li>
  );
}

function SubHeading({ children }: { children: React.ReactNode }) {
  return (
    <p className="font-semibold text-sm mb-2" style={{ color: '#1A1A1A' }}>{children}</p>
  );
}

const SECTIONS: Section[] = [
  {
    number: '01',
    heading: 'Introduction',
    content: (
      <>
        <p>Welcome to ReCircle (ReCircle Recyclables Pvt. Ltd.). We are committed to protecting your personal information.</p>
        <p>This Privacy Policy explains how we collect, use, disclose, and protect your personal data when you interact with our website, mobile application, and services.</p>
        <p>By accessing or using our services, you agree to the collection and use of information in accordance with this policy.</p>
      </>
    ),
  },
  {
    number: '02',
    heading: 'Information We Collect',
    content: (
      <>
        <div>
          <SubHeading>a) Information You Provide Directly</SubHeading>
          <ul className="space-y-2">
            <Bullet>Name, email address, phone number, and other contact details</Bullet>
            <Bullet>Company name and business details where applicable</Bullet>
            <Bullet>Account credentials if you register</Bullet>
            <Bullet>Enquiry details submitted through our contact or service forms</Bullet>
            <Bullet>Feedback, survey responses, and communications with our team</Bullet>
          </ul>
        </div>
        <div>
          <SubHeading>b) Information Collected Automatically</SubHeading>
          <ul className="space-y-2">
            <Bullet>Device and browser information</Bullet>
            <Bullet>IP address and approximate location</Bullet>
            <Bullet>Pages visited, time spent, and navigation patterns</Bullet>
            <Bullet>Referral URLs and search terms used to find our site</Bullet>
            <Bullet>Cookie data and similar tracking technologies</Bullet>
          </ul>
        </div>
        <div>
          <SubHeading>c) Information from Third Parties</SubHeading>
          <ul className="space-y-2">
            <Bullet>Business partner referrals</Bullet>
            <Bullet>Publicly available professional information</Bullet>
            <Bullet>Data from integrated platforms where you have granted access</Bullet>
          </ul>
        </div>
      </>
    ),
  },
  {
    number: '03',
    heading: 'How We Use Your Information',
    content: (
      <ul className="space-y-2">
        <Bullet>Provide, operate, and improve our services</Bullet>
        <Bullet>Respond to enquiries and support requests</Bullet>
        <Bullet>Send service-related notifications, updates, and communications</Bullet>
        <Bullet>Process transactions and maintain records</Bullet>
        <Bullet>Comply with legal and regulatory obligations, including under the EPR framework</Bullet>
        <Bullet>Analyse usage patterns to improve platform performance and user experience</Bullet>
        <Bullet>Send marketing communications where you have opted in</Bullet>
        <Bullet>Conduct research and develop new features or offerings</Bullet>
      </ul>
    ),
  },
  {
    number: '04',
    heading: 'Legal Basis for Processing',
    content: (
      <>
        <p>We process your personal data under the following legal bases under applicable data protection law, including the Digital Personal Data Protection Act 2023 (India):</p>
        <ul className="space-y-2 mt-3">
          <Bullet>Your consent where provided</Bullet>
          <Bullet>Performance of a contract to which you are a party</Bullet>
          <Bullet>Compliance with legal obligations</Bullet>
          <Bullet>Our legitimate business interests where they do not override your rights</Bullet>
        </ul>
      </>
    ),
  },
  {
    number: '05',
    heading: 'Sharing Your Information',
    content: (
      <>
        <p>We do not sell your personal data. We may share your information with:</p>
        <ul className="space-y-2 mt-3">
          <Bullet>Service providers and technology partners who assist in delivering our services</Bullet>
          <Bullet>Government and regulatory bodies as required by law, including CPCB and other authorities</Bullet>
          <Bullet>Business partners with your consent</Bullet>
          <Bullet>Successors in the event of a merger, acquisition, or restructuring</Bullet>
        </ul>
      </>
    ),
  },
  {
    number: '06',
    heading: 'Data Retention',
    content: (
      <>
        <p>We retain personal data for as long as necessary to fulfil the purposes for which it was collected, or as required by law.</p>
        <p>When data is no longer required, it is securely deleted or anonymised.</p>
      </>
    ),
  },
  {
    number: '07',
    heading: 'Your Rights',
    content: (
      <>
        <p>Subject to applicable law, you may have the right to:</p>
        <ul className="space-y-2 mt-3">
          <Bullet>Access the personal data we hold about you</Bullet>
          <Bullet>Request correction of inaccurate data</Bullet>
          <Bullet>Request deletion of your data</Bullet>
          <Bullet>Object to or restrict certain types of processing</Bullet>
          <Bullet>Withdraw consent at any time where processing is based on consent</Bullet>
        </ul>
        <p className="mt-3">
          To exercise any of these rights, please contact us at{' '}
          <a href="mailto:privacy@recircle.in" className="font-medium underline underline-offset-2 hover:opacity-75 transition-opacity" style={{ color: NAVY }}>
            privacy@recircle.in
          </a>
        </p>
      </>
    ),
  },
  {
    number: '08',
    heading: 'Cookies',
    content: (
      <>
        <p>Our website uses cookies and similar technologies to improve your experience and analyse usage.</p>
        <p>You may manage cookie preferences through your browser settings. Disabling cookies may affect the functionality of certain parts of our website.</p>
      </>
    ),
  },
  {
    number: '09',
    heading: 'Data Security',
    content: (
      <>
        <p>We implement appropriate technical and organisational measures to protect your data from unauthorised access, loss, or misuse.</p>
        <p>Despite our efforts, no method of internet transmission or electronic storage is completely secure.</p>
      </>
    ),
  },
  {
    number: '10',
    heading: 'Third Party Links',
    content: (
      <>
        <p>Our website may contain links to third-party websites. We are not responsible for the privacy practices of those websites and encourage you to review their policies.</p>
      </>
    ),
  },
  {
    number: '11',
    heading: "Children's Privacy",
    content: (
      <>
        <p>Our services are not directed to children under 18. We do not knowingly collect personal data from minors.</p>
      </>
    ),
  },
  {
    number: '12',
    heading: 'Changes to This Policy',
    content: (
      <>
        <p>We may update this Privacy Policy periodically. We will notify you of material changes by updating the "Last Updated" date at the top of this page.</p>
        <p>Continued use of our services after changes constitutes acceptance of the revised policy.</p>
      </>
    ),
  },
  {
    number: '13',
    heading: 'Contact Us',
    content: (
      <div className="p-5 border" style={{ borderColor: '#E8E8E8', backgroundColor: '#F8F6F3' }}>
        <p className="mb-3">If you have questions about this Privacy Policy or wish to exercise your rights, please contact us at:</p>
        <div className="space-y-1.5">
          <a
            href="mailto:privacy@recircle.in"
            className="flex items-center gap-2 text-sm font-medium hover:opacity-75 transition-opacity"
            style={{ color: NAVY }}
          >
            <Mail size={14} />
            privacy@recircle.in
          </a>
          <p className="text-sm" style={{ color: '#5F5F5F' }}>ReCircle Recyclables Pvt. Ltd., Mumbai, India</p>
        </div>
      </div>
    ),
  },
];

export default function PrivacyPolicyPage() {
  const heroRef = useRef<HTMLElement>(null);
  const inView = useInView(heroRef, { once: true });

  return (
    <main className="pt-[72px] min-h-screen" style={{ backgroundColor: '#F7F1EE' }}>

      {/* ── Hero ──────────────────────────────────────────────────────────── */}
      <section ref={heroRef} className="border-b" style={{ borderColor: '#E8E8E8', backgroundColor: 'white' }}>
        <div className="container-site py-14 md:py-20">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
          >
            <Link
              to="/"
              className="inline-flex items-center gap-1.5 text-xs font-medium mb-8 hover:opacity-75 transition-opacity"
              style={{ color: '#858585' }}
            >
              <ArrowLeft size={13} />
              Back to Home
            </Link>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-1 h-8" style={{ backgroundColor: TEAL }} />
              <span className="text-xs font-bold uppercase tracking-[0.15em]" style={{ color: TEAL }}>Legal</span>
            </div>

            <h1
              className="font-display font-bold leading-tight mb-4"
              style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.8rem)', letterSpacing: '-0.03em', color: '#1A1A1A' }}
            >
              Privacy Policy
            </h1>
            <p className="text-sm" style={{ color: '#858585' }}>Last Updated: April 2025</p>
          </motion.div>
        </div>
      </section>

      {/* ── Main content ─────────────────────────────────────────────────── */}
      <div className="container-site py-14 md:py-20">
        <div className="max-w-3xl">

          {/* TOC */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.1 }}
            className="mb-14 p-6 bg-white border"
            style={{ borderColor: '#E8E8E8' }}
          >
            <p className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: NAVY }}>Contents</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2">
              {SECTIONS.map((s) => (
                <a
                  key={s.number}
                  href={`#section-${s.number}`}
                  className="flex items-center gap-2.5 text-xs hover:opacity-70 transition-opacity group"
                  style={{ color: '#5F5F5F' }}
                >
                  <span className="font-mono text-xs" style={{ color: TEAL }}>{s.number}</span>
                  <span className="group-hover:underline underline-offset-2">{s.heading}</span>
                </a>
              ))}
            </div>
          </motion.div>

          {/* Sections */}
          <div className="space-y-12">
            {SECTIONS.map((section, i) => (
              <div key={section.number}>
                <SectionBlock section={section} index={i} />
                {i < SECTIONS.length - 1 && (
                  <div className="mt-12 h-px" style={{ backgroundColor: '#E8E8E8' }} />
                )}
              </div>
            ))}
          </div>

          {/* Bottom note */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 0.3 }}
            className="mt-16 pt-8 border-t text-xs"
            style={{ borderColor: '#E8E8E8', color: '#ABABAB' }}
          >
            This policy is effective as of April 2025 and applies to all users of the ReCircle platform and services.
          </motion.div>
        </div>
      </div>

    </main>
  );
}
