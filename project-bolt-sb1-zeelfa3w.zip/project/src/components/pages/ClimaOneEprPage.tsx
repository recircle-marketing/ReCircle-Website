import { useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { ShieldCheck, Recycle, Landmark, ArrowRight, Check, Activity, BarChart3, Link as LinkIcon, LayoutDashboard, ChevronRight } from 'lucide-react';

const CONSULTATION_URL = 'https://recircle.in/climaone/#form';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

const slideLeft = {
  hidden: { opacity: 0, x: -36 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

// ── Dot-grid SVG background pattern ─────────────────────────────────────────
function DotGrid({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
      <defs>
        <pattern id="dots" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
          <circle cx="1" cy="1" r="1" fill="rgba(0,196,153,0.18)" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#dots)" />
    </svg>
  );
}

// ── Arc decoration ────────────────────────────────────────────────────────────
function ArcDecoration({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 600 600" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="300" cy="300" r="250" stroke="rgba(0,196,153,0.07)" strokeWidth="1" />
      <circle cx="300" cy="300" r="180" stroke="rgba(0,196,153,0.05)" strokeWidth="1" />
      <circle cx="300" cy="300" r="110" stroke="rgba(0,196,153,0.04)" strokeWidth="1" />
    </svg>
  );
}

// ── Abstract dashboard mockup ─────────────────────────────────────────────────
function DashboardMockup() {
  return (
    <div
      className="relative w-full max-w-lg mx-auto"
      style={{
        background: 'linear-gradient(135deg, rgba(0,196,153,0.08) 0%, rgba(1,41,138,0.15) 100%)',
        border: '1px solid rgba(0,196,153,0.25)',
        boxShadow: '0 0 60px rgba(0,196,153,0.12), 0 0 120px rgba(1,41,138,0.08)',
        borderRadius: 2,
      }}
    >
      {/* Top bar */}
      <div className="flex items-center gap-2 px-4 py-3 border-b" style={{ borderColor: 'rgba(0,196,153,0.15)' }}>
        <div className="flex gap-1.5">
          {['#E7182A', '#DCEB4B', '#00C499'].map((c) => (
            <div key={c} className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c, opacity: 0.6 }} />
          ))}
        </div>
        <div className="flex-1 h-3 rounded-sm mx-4" style={{ backgroundColor: 'rgba(255,255,255,0.06)' }} />
        <div className="w-16 h-3 rounded-sm" style={{ backgroundColor: 'rgba(0,196,153,0.2)' }} />
      </div>

      <div className="p-5 grid grid-cols-3 gap-3">
        {/* Stat cards */}
        {[
          { label: 'Plastic Credits', value: '12,450', color: '#00C499' },
          { label: 'EPR Compliance', value: '94.2%', color: '#DCEB4B' },
          { label: 'Certifications', value: '38', color: '#01298A' },
        ].map((stat) => (
          <div key={stat.label} className="p-3 rounded-sm" style={{ backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
            <p className="text-xs mb-1" style={{ color: 'rgba(255,255,255,0.4)' }}>{stat.label}</p>
            <p className="text-base font-bold" style={{ color: stat.color }}>{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Chart simulation */}
      <div className="px-5 pb-4">
        <div className="p-3 rounded-sm" style={{ backgroundColor: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
          <div className="flex items-end gap-1.5 h-20">
            {[40, 65, 45, 80, 55, 90, 70, 95, 60, 85, 75, 100].map((h, i) => (
              <motion.div
                key={i}
                className="flex-1 rounded-sm"
                style={{ backgroundColor: i % 3 === 0 ? 'rgba(0,196,153,0.6)' : 'rgba(0,196,153,0.25)' }}
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                transition={{ duration: 0.6, delay: 0.8 + i * 0.04, ease: 'easeOut' }}
              />
            ))}
          </div>
          <p className="text-xs mt-2" style={{ color: 'rgba(255,255,255,0.25)' }}>Monthly Credit Collection — FY 2025–26</p>
        </div>
      </div>

      {/* Progress bars */}
      <div className="px-5 pb-5 space-y-2.5">
        {[
          { label: 'Brand Compliance', pct: 87 },
          { label: 'Processor Efficiency', pct: 73 },
          { label: 'CPCB Integration', pct: 100 },
        ].map((bar) => (
          <div key={bar.label}>
            <div className="flex justify-between mb-1">
              <span className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>{bar.label}</span>
              <span className="text-xs font-semibold" style={{ color: '#00C499' }}>{bar.pct}%</span>
            </div>
            <div className="h-1.5 w-full rounded-full" style={{ backgroundColor: 'rgba(255,255,255,0.06)' }}>
              <motion.div
                className="h-full rounded-full"
                style={{ backgroundColor: '#00C499' }}
                initial={{ width: 0 }}
                animate={{ width: `${bar.pct}%` }}
                transition={{ duration: 0.8, delay: 1.2, ease: 'easeOut' }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Glow accent */}
      <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle, rgba(0,196,153,0.2) 0%, transparent 70%)' }} />
    </div>
  );
}

// ── Animated counter ──────────────────────────────────────────────────────────
function StatStrip() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });

  const stats = [
    { icon: <ShieldCheck size={18} />, label: 'EPR Compliant' },
    { icon: <Recycle size={18} />, label: 'Plastic Neutrality Tracking' },
    { icon: <Landmark size={18} />, label: 'CPCB Portal Integrated' },
  ];

  return (
    <div ref={ref} className="border-y" style={{ backgroundColor: '#0A1F5A', borderColor: 'rgba(0,196,153,0.2)' }}>
      <div className="container-site py-0">
        <div className="grid grid-cols-1 sm:grid-cols-3">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial="hidden"
              animate={inView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={i}
              className={`flex items-center justify-center gap-3 py-5 ${i < 2 ? 'sm:border-r' : ''}`}
              style={{ borderColor: 'rgba(0,196,153,0.15)' }}
            >
              <span style={{ color: '#00C499' }}>{s.icon}</span>
              <span className="text-sm font-semibold" style={{ color: 'rgba(255,255,255,0.85)' }}>{s.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Section label ─────────────────────────────────────────────────────────────
function SectionLabel({ text }: { text: string }) {
  return (
    <p className="text-caption font-semibold uppercase tracking-[0.15em] mb-3" style={{ color: '#00C499' }}>{text}</p>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function ClimaOneEprPage() {
  // Hero parallax
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroY = useTransform(scrollYProgress, [0, 1], ['0%', '25%']);

  // Section in-view refs
  const overviewRef = useRef<HTMLElement>(null);
  const featuresRef = useRef<HTMLElement>(null);
  const stepsRef = useRef<HTMLElement>(null);
  const closingRef = useRef<HTMLElement>(null);

  const overviewInView = useInView(overviewRef, { once: true, margin: '-60px' });
  const featuresInView = useInView(featuresRef, { once: true, margin: '-60px' });
  const stepsInView = useInView(stepsRef, { once: true, margin: '-60px' });
  const closingInView = useInView(closingRef, { once: true, margin: '-60px' });

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Section 1: Hero ──────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-screen flex items-center overflow-hidden" style={{ backgroundColor: '#060F2E' }}>
        {/* Parallax bg layer */}
        <motion.div className="absolute inset-0 pointer-events-none" style={{ y: heroY }}>
          <DotGrid className="absolute inset-0 w-full h-full opacity-60" />
          <ArcDecoration className="absolute -right-40 -top-40 w-[700px] h-[700px] opacity-50" />
          <ArcDecoration className="absolute -left-60 bottom-0 w-[500px] h-[500px] opacity-30" />
        </motion.div>

        <div className="container-site relative z-10 section-padding">
          <div className="flex flex-col lg:flex-row items-center gap-14 lg:gap-20">
            {/* Left — text */}
            <div className="flex-1 max-w-xl">
              {/* Badge */}
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45 }}
                className="inline-flex items-center gap-2 px-4 py-1.5 mb-6 border text-xs font-semibold uppercase tracking-widest"
                style={{ borderColor: 'rgba(0,196,153,0.4)', color: '#00C499', backgroundColor: 'rgba(0,196,153,0.06)' }}
              >
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: '#00C499' }} />
                ClimaOne Dashboard Overview
              </motion.div>

              {/* Headline */}
              <motion.h1
                initial={{ opacity: 0, y: 32 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
                className="font-display font-bold text-white leading-tight mb-6"
                style={{ fontSize: 'clamp(2.2rem, 5vw, 3.5rem)', letterSpacing: '-0.025em' }}
              >
                Supply Chain Optimizer.<br />
                <span style={{ color: '#00C499' }}>Circular Economy Enabler.</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.22 }}
                className="text-body-lg leading-relaxed mb-10"
                style={{ color: 'rgba(255,255,255,0.65)' }}
              >
                Every time your supply chain faced inefficiencies, limited transparency, and a lack of data-driven insights, you longed for a solution. ClimaOne delivers it.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.34 }}
                className="flex flex-col sm:flex-row gap-3"
              >
                <a
                  href={CONSULTATION_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 font-medium text-body-sm transition-all duration-300"
                  style={{ backgroundColor: '#00C499', color: '#060F2E' }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#00A882'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = '#00C499'; }}
                >
                  Book Free Consultation
                  <ArrowRight size={16} />
                </a>
                <a
                  href="#features"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 font-medium text-body-sm border transition-all duration-300"
                  style={{ borderColor: 'rgba(255,255,255,0.2)', color: 'rgba(255,255,255,0.8)' }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.06)'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                >
                  See How It Works
                  <ChevronRight size={16} />
                </a>
              </motion.div>
            </div>

            {/* Right — dashboard mockup */}
            <motion.div
              className="flex-1 w-full"
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.18, ease: [0.22, 1, 0.36, 1] }}
            >
              <DashboardMockup />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 2: Value Strip ────────────────────────────────────────── */}
      <StatStrip />

      {/* ── Section 3: Dashboard Overview ────────────────────────────────── */}
      <section ref={overviewRef} className="section-padding relative overflow-hidden" style={{ backgroundColor: '#080E2A' }}>
        <DotGrid className="absolute inset-0 w-full h-full opacity-30 pointer-events-none" />
        <div className="container-site relative z-10">
          <div className="flex flex-col lg:flex-row gap-16 items-start">
            {/* Left */}
            <motion.div
              className="flex-1 max-w-xl"
              initial="hidden"
              animate={overviewInView ? 'visible' : 'hidden'}
              variants={slideLeft}
            >
              <SectionLabel text="DASHBOARD OVERVIEW" />
              <h2 className="font-display text-display-sm font-bold text-white mb-6 leading-tight">
                Gain control over your sustainability targets with ease
              </h2>
              <p className="text-body-lg leading-relaxed" style={{ color: 'rgba(255,255,255,0.65)' }}>
                Say goodbye to guesswork and welcome data-driven decision-making. Manage your EPR Compliances, achieve Plastic Neutrality and opt for ethically recycled plastic on ClimaOne. This advanced platform brings inbuilt traceability, analytics, and data capabilities into one place.
              </p>
            </motion.div>

            {/* Right — feature cards 2×2 */}
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { icon: <LinkIcon size={20} />, title: 'End-to-End Traceability', body: 'Track every plastic credit from collection to compliance certification.' },
                { icon: <Activity size={20} />, title: 'Live Data Tracking', body: 'Real-time updates across your entire circular supply chain.' },
                { icon: <Landmark size={20} />, title: 'CPCB Portal Integration', body: 'EPR plastic credits directly linked to the government compliance portal.' },
                { icon: <LayoutDashboard size={20} />, title: 'Dashboard and Reporting', body: 'Compliance progress and SDG delivery tracked in one view.' },
              ].map((card, i) => (
                <motion.div
                  key={card.title}
                  initial="hidden"
                  animate={overviewInView ? 'visible' : 'hidden'}
                  variants={fadeUp}
                  custom={i}
                  className="p-6 relative overflow-hidden"
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(0,196,153,0.15)',
                  }}
                  whileHover={{ borderColor: 'rgba(0,196,153,0.4)', backgroundColor: 'rgba(0,196,153,0.04)' }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="w-10 h-10 flex items-center justify-center mb-4" style={{ backgroundColor: 'rgba(0,196,153,0.12)', color: '#00C499' }}>
                    {card.icon}
                  </div>
                  <h3 className="text-sm font-bold mb-2 text-white">{card.title}</h3>
                  <p className="text-xs leading-relaxed" style={{ color: 'rgba(255,255,255,0.5)' }}>{card.body}</p>
                  {/* Corner glow */}
                  <div className="absolute -bottom-4 -right-4 w-16 h-16 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle, rgba(0,196,153,0.1) 0%, transparent 70%)' }} />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Section 4: Feature Set ───────────────────────────────────────── */}
      <section id="features" ref={featuresRef} className="section-padding relative" style={{ backgroundColor: '#060F2E' }}>
        <ArcDecoration className="absolute right-0 top-0 w-[500px] h-[500px] opacity-40 pointer-events-none" />
        <div className="container-site relative z-10">
          <motion.div
            className="max-w-2xl mb-14"
            initial="hidden"
            animate={featuresInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="FEATURE SET" />
            <h2 className="font-display text-display-sm font-bold text-white mb-4 leading-tight">
              Advanced capabilities across every portal
            </h2>
            <p className="text-body-lg" style={{ color: 'rgba(255,255,255,0.6)' }}>
              Say goodbye to manual processes and embrace efficiency with ClimaOne's intuitive features across Brand, Processor, and Collection portals.
            </p>
          </motion.div>

          {/* Three portal cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {[
              {
                title: 'Brands',
                img: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600&q=80',
                features: [
                  'Comprehensive Plastic Credits Traceability',
                  'Integration to the CPCB Board with a Compliance Dashboard',
                  'Instant Insights, Reporting and Data Visualization',
                  'Efficient Certificate Tracking and Query Resolution',
                ],
              },
              {
                title: 'Processors',
                img: 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg?auto=compress&cs=tinysrgb&w=600&q=80',
                features: [
                  'Streamlined Vehicle Tracking and Inventory Management',
                  'Simplified Certification Validation and Data Availability',
                  'Comprehensive record-keeping via Audit Logs and Ledger Systems',
                ],
              },
              {
                title: 'Collectors',
                img: 'https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg?auto=compress&cs=tinysrgb&w=600&q=80',
                features: [
                  'Seamless Integration with Processor and Brand Portals',
                  'Connect with Key Stakeholders to maximize your reach',
                  'Heightened Security measures and Increased Income Opportunities',
                ],
              },
            ].map((portal, i) => (
              <motion.div
                key={portal.title}
                initial="hidden"
                animate={featuresInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="flex flex-col overflow-hidden group"
                style={{ backgroundColor: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}
              >
                {/* Top accent bar */}
                <div className="h-0.5 w-0 group-hover:w-full transition-all duration-500" style={{ backgroundColor: '#00C499' }} />

                {/* Image */}
                <div className="aspect-[16/9] overflow-hidden" style={{ backgroundColor: '#0A1F5A' }}>
                  <img src={portal.img} alt={portal.title} className="w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity duration-400" loading="lazy" />
                </div>

                <div className="p-6 flex flex-col flex-1">
                  <h3 className="text-lg font-bold text-white mb-5">{portal.title}</h3>
                  <ul className="space-y-3 flex-1">
                    {portal.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
                        <Check size={14} className="mt-0.5 shrink-0" style={{ color: '#00C499' }} />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={featuresInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 14 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="text-center"
          >
            <a
              href={CONSULTATION_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-3.5 font-medium text-body-sm transition-all duration-300"
              style={{ backgroundColor: '#00C499', color: '#060F2E' }}
              onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#00A882'; }}
              onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = '#00C499'; }}
            >
              Book Your Free Consultation
              <ArrowRight size={16} />
            </a>
          </motion.div>
        </div>
      </section>

      {/* ── Section 5: Onboarding Steps ──────────────────────────────────── */}
      <section ref={stepsRef} className="section-padding relative overflow-hidden" style={{ backgroundColor: '#080E2A' }}>
        <DotGrid className="absolute inset-0 w-full h-full opacity-25 pointer-events-none" />
        <div className="container-site relative z-10">
          <motion.div
            className="max-w-2xl mb-16"
            initial="hidden"
            animate={stepsInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="ONBOARD" />
            <h2 className="font-display text-display-sm font-bold text-white mb-4 leading-tight">
              Join the ClimaOne community
            </h2>
            <p className="text-body-lg" style={{ color: 'rgba(255,255,255,0.6)' }}>
              Start managing your waste effectively with ClimaOne's simple and quick onboarding.
            </p>
          </motion.div>

          {/* Steps */}
          <div className="relative grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-0">
            {/* Connecting line (desktop) */}
            <div className="absolute top-10 left-[calc(16.67%+20px)] right-[calc(16.67%+20px)] h-px hidden md:block" style={{ backgroundColor: 'rgba(0,196,153,0.2)' }}>
              <div className="absolute inset-0 flex items-center justify-center gap-0">
                <div className="w-full border-dashed border-t" style={{ borderColor: 'rgba(0,196,153,0.3)' }} />
              </div>
            </div>

            {[
              {
                num: '01',
                title: 'Register on the Platform',
                desc: 'Create your account on ClimaOne in minutes. Set up your Brand, Processor, or Collector profile.',
              },
              {
                num: '02',
                title: 'Connect to the CPCB Portal',
                desc: 'Seamlessly integrate with the government\'s Central Pollution Control Board portal for verified compliance tracking.',
              },
              {
                num: '03',
                title: 'Track, Manage and Validate',
                desc: 'Monitor your Plastic Credits, validate EPR compliance, and work toward Plastic Neutrality from your dashboard.',
              },
            ].map((step, i) => (
              <motion.div
                key={step.num}
                initial="hidden"
                animate={stepsInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="relative flex flex-col items-start md:items-center md:text-center px-0 md:px-8"
              >
                {/* Number circle */}
                <div
                  className="w-20 h-20 flex items-center justify-center mb-6 relative z-10"
                  style={{
                    backgroundColor: '#060F2E',
                    border: '1px solid rgba(0,196,153,0.4)',
                    boxShadow: '0 0 20px rgba(0,196,153,0.15)',
                  }}
                >
                  <span className="font-display font-bold text-xl" style={{ color: '#00C499' }}>{step.num}</span>
                </div>
                <h3 className="text-base font-bold text-white mb-3">{step.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.55)' }}>{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 6: Closing ───────────────────────────────────────────── */}
      <section ref={closingRef} className="section-padding relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #004D3D 0%, #060F2E 60%)' }}>
        <ArcDecoration className="absolute left-0 top-0 w-[600px] h-[600px] opacity-20 pointer-events-none" />
        <DotGrid className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" />

        <div className="container-site relative z-10">
          <motion.div
            className="max-w-3xl mx-auto text-center mb-14"
            initial="hidden"
            animate={closingInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="UNLEASH CLIMAONE" />
            <h2 className="font-display text-display-sm font-bold text-white mb-0 leading-tight">
              Monitor your compliance progress and deliver on your SDGs
            </h2>
          </motion.div>

          {/* 2×2 feature grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-px mb-14" style={{ backgroundColor: 'rgba(0,196,153,0.12)' }}>
            {[
              {
                label: 'End-to-End Traceability for Plastic Credits',
                body: 'Every credit is tracked from source collection to final certification.',
                icon: <LinkIcon size={20} />,
              },
              {
                label: 'Live Data Tracking',
                body: 'Your supply chain data updates in real time, always current.',
                icon: <Activity size={20} />,
              },
              {
                label: 'EPR Credits Linked to CPCB Portal',
                body: 'Verified plastic credits connect directly to your official compliance record.',
                icon: <BarChart3 size={20} />,
              },
              {
                label: 'Dashboard and SDG Reporting',
                body: 'Measure your compliance progress and track your contribution to global sustainability goals.',
                icon: <LayoutDashboard size={20} />,
              },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                initial="hidden"
                animate={closingInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="flex gap-5 p-8"
                style={{ backgroundColor: 'rgba(6,15,46,0.85)' }}
              >
                <div className="w-11 h-11 flex-shrink-0 flex items-center justify-center mt-0.5" style={{ backgroundColor: 'rgba(0,196,153,0.12)', color: '#00C499' }}>
                  {item.icon}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white mb-2">{item.label}</h3>
                  <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.55)' }}>{item.body}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={closingInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 14 }}
            transition={{ duration: 0.5, delay: 0.45 }}
            className="text-center"
          >
            <a
              href={CONSULTATION_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-3.5 font-medium text-body-sm transition-all duration-300"
              style={{ backgroundColor: '#00C499', color: '#060F2E' }}
              onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#00A882'; }}
              onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = '#00C499'; }}
            >
              Book Your Free Consultation
              <ArrowRight size={16} />
            </a>
          </motion.div>
        </div>
      </section>

    </main>
  );
}
