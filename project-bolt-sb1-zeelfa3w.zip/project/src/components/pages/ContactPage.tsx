import ContactSection from '../sections/ContactSection';

export default function ContactPage() {
  return (
    <main>
      <div className="pt-20">
        <ContactSection />
      </div>
    </main>
  );
}
