import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { getBlogs, getBlogPageSettings } from '../../cms/queries';
import type { Blog, BlogPageSettings } from '../../cms/types';

const BLOGS_PER_PAGE = 9;

function formatDate(dateStr: string | null): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const day = String(d.getDate()).padStart(2, '0');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${day}-${months[d.getMonth()]}-${d.getFullYear()}`;
}

interface BlogCardProps { blog: Blog; index: number; }
function BlogCard({ blog, index }: BlogCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.5, delay: (index % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
    >
      <Link to={`/blog/${blog.slug}`} className="group flex flex-col h-full bg-white border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300">
        <div className="overflow-hidden aspect-[16/9]">
          {blog.featured_image_url ? (
            <img
              src={blog.featured_image_url}
              alt={blog.featured_image_alt || blog.title}
              loading="lazy"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: '#E8EDF8' }}>
              <span className="text-xs font-medium" style={{ color: '#01298A' }}>ReCircle</span>
            </div>
          )}
        </div>
        <div className="flex flex-col flex-1 p-6">
          <div className="flex items-center gap-3 mb-3">
            {blog.category && (
              <span className="text-xs font-semibold uppercase tracking-widest px-2 py-0.5" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                {blog.category}
              </span>
            )}
            <span className="text-xs" style={{ color: '#ABABAB' }}>{formatDate(blog.publish_date)}</span>
          </div>
          <h3 className="font-bold text-base leading-snug mb-2 line-clamp-2" style={{ color: '#1A1A1A' }}>{blog.title}</h3>
          {blog.author && (
            <p className="text-xs mb-3" style={{ color: '#858585' }}>By {blog.author}</p>
          )}
          <p className="text-sm leading-relaxed flex-1 line-clamp-3" style={{ color: '#5F5F5F' }}>{blog.seo_description || blog.title}</p>
          <div className="mt-5 flex items-center gap-1.5 text-sm font-semibold transition-colors group-hover:gap-2.5" style={{ color: '#01298A' }}>
            Read More <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

export default function BlogListingPage() {
  const [settings, setSettings] = useState<BlogPageSettings | null>(null);
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();
  const page = parseInt(searchParams.get('page') ?? '1');

  useEffect(() => {
    Promise.all([getBlogPageSettings(), getBlogs()]).then(([s, b]) => {
      setSettings(s);
      setBlogs(b);
      setLoading(false);
    });
  }, []);

  const totalPages = Math.ceil(blogs.length / BLOGS_PER_PAGE);
  const paginated = blogs.slice((page - 1) * BLOGS_PER_PAGE, page * BLOGS_PER_PAGE);

  const heroImage = settings?.hero_image_url || 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg?auto=compress&cs=tinysrgb&w=1920&q=85';

  return (
    <main className="pt-20">
      {/* Hero */}
      <section className="relative flex items-center justify-center" style={{ minHeight: '360px' }}>
        <div className="absolute inset-0">
          <img src={heroImage} alt="Blog hero" className="w-full h-full object-cover" loading="lazy" />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(26,26,26,0.45) 0%, rgba(26,26,26,0.55) 100%)' }} />
        </div>
        <div className="relative z-10 text-center text-white px-6 py-24">
          <motion.h1
            className="font-display text-display-md font-bold mb-4"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            {settings?.hero_heading ?? 'Blogs'}
          </motion.h1>
          <motion.h2
            className="text-xl font-normal max-w-2xl mx-auto"
            style={{ color: 'rgba(255,255,255,0.85)' }}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
          >
            {settings?.hero_subheading ?? "Insights from India's evolving waste ecosystem"}
          </motion.h2>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="section-padding bg-ivory">
        <div className="container-site">
          {loading ? (
            <div className="flex items-center justify-center py-24">
              <div className="w-8 h-8 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
            </div>
          ) : blogs.length === 0 ? (
            <div className="text-center py-24">
              <p className="text-lg font-medium" style={{ color: '#858585' }}>No articles published yet. Check back soon.</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {paginated.map((blog, i) => <BlogCard key={blog.id} blog={blog} index={i} />)}
              </div>

              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-4 mt-16">
                  <button
                    onClick={() => { setSearchParams({ page: String(page - 1) }); window.scrollTo(0, 0); }}
                    disabled={page <= 1}
                    className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold border transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{ borderColor: '#01298A', color: '#01298A' }}
                  >
                    <ChevronLeft size={16} /> Previous
                  </button>
                  <span className="text-sm" style={{ color: '#858585' }}>Page {page} of {totalPages}</span>
                  <button
                    onClick={() => { setSearchParams({ page: String(page + 1) }); window.scrollTo(0, 0); }}
                    disabled={page >= totalPages}
                    className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold border transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{ borderColor: '#01298A', color: '#01298A' }}
                  >
                    Next <ChevronRight size={16} />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </section>
    </main>
  );
}
