import { useRef, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, ChevronRight, AlertTriangle, Ban, TrendingDown } from 'lucide-react';
import { getClients, getPlasticWastePageSettings } from '../../cms/queries';
import type { Client } from '../../cms/types';
import type { PlasticWastePageSettings } from '../../cms/types';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

const TEAL = '#00C499';
const NAVY = '#01298A';

const DUMMY_LOGO_URLS = [
  'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5726837/pexels-photo-5726837.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/6863183/pexels-photo-6863183.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/4491881/pexels-photo-4491881.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
];

const FALLBACK_CLIENTS: Client[] = [
  'Colgate-Palmolive', 'Dabur', 'Castrol', 'Hindustan Coca-Cola Beverages', 'FirstCry',
  'Kimberly Clark', 'Mondelez', 'PepsiCo', 'Samsung', 'Tata Starbucks', 'Zepto', 'Symphony', 'Bisleri',
].map((name, i) => ({
  id: String(i + 1), sort_order: i + 1, is_active: true,
  name, logo_url: DUMMY_LOGO_URLS[i % DUMMY_LOGO_URLS.length], logo_alt: `${name} logo`, created_at: '', updated_at: '',
}));

const FALLBACK: PlasticWastePageSettings = {
  id: '',
  hero_heading: 'Comprehensive Plastic Waste Management Solutions for Businesses in India',
  hero_stat: '3.5M',
  hero_stat_label: 'tonnes',
  hero_stat_descriptor: 'of plastic waste generated in India annually',
  hero_para_1: 'India generates over 3.5 million tonnes of plastic waste every year, yet a significant share still remains outside formal recovery systems.',
  hero_para_2: 'At the same time, regulations are tightening, reporting expectations are growing, and sustainability claims are being examined more closely than ever before.',
  hero_cta_label: 'Book a Free Consultation',
  compliance_heading: 'Plastic waste regulation is now a business responsibility.',
  compliance_body: 'Under the Plastic Waste Management Rules 2016, businesses introducing plastic into the Indian market are required to take responsibility for its recovery and recycling. Producers, importers, and brand owners are now expected to meet clear EPR obligations under the CPCB framework, with stricter scrutiny around documentation, reporting, and traceability.',
  compliance_closing: 'ReCircle simplifies the operational side of plastic waste management by helping businesses manage compliance, recovery targets, and reporting through one integrated ecosystem.',
  consequences: [
    { text: 'Financial penalties and regulatory action from the CPCB.' },
    { text: 'Restricted business operations and delayed product approvals.' },
    { text: 'Reputational damage as sustainability scrutiny from buyers and investors increases.' },
  ],
  why_heading: 'Why Choose ReCircle',
  why_advantages: [
    { num: '01', title: 'Integrated Recovery Ecosystem', body: 'A connected network of collectors, aggregators, processors, and recyclers enables traceable plastic recovery across the value chain.' },
    { num: '02', title: 'Solutions That Scale With You', body: 'From growing businesses to multinational enterprises, our waste management systems adapt to different operational and compliance requirements.' },
    { num: '03', title: 'Pan-India Operations', body: 'With a presence across 400+ cities and towns, ReCircle delivers measurable impact wherever your business operates.' },
    { num: '04', title: 'People at the Centre', body: 'Every recovery system is designed with worker wellbeing, fair livelihoods, and safer working conditions built into the process.' },
  ],
  infra_body: "The above services are backed by physical infrastructure. ReCircle's Material Recovery Facility (MRF) is where plastic waste is sorted, processed, and routed to verified recycling partners — creating the operational backbone behind our compliance and recovery programmes.",
  updated_at: '',
};

function SectionLabel({ text, center, light }: { text: string; center?: boolean; light?: boolean }) {
  return (
    <p
      className={`text-caption font-semibold uppercase tracking-[0.15em] mb-4 ${center ? 'text-center' : ''}`}
      style={{ color: light ? 'rgba(255,255,255,0.5)' : TEAL }}
    >
      {text}
    </p>
  );
}

export default function PlasticWastePage() {
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '15%']);

  const contextRef = useRef<HTMLElement>(null);
  const redirectRef = useRef<HTMLElement>(null);
  const whyRef = useRef<HTMLElement>(null);
  const infraRef = useRef<HTMLElement>(null);
  const clientsRef = useRef<HTMLElement>(null);

  const contextInView = useInView(contextRef, { once: true, margin: '-60px' });
  const redirectInView = useInView(redirectRef, { once: true, margin: '-60px' });
  const whyInView = useInView(whyRef, { once: true, margin: '-60px' });
  const infraInView = useInView(infraRef, { once: true, margin: '-60px' });
  const clientsInView = useInView(clientsRef, { once: true, margin: '-60px' });

  const [clients, setClients] = useState<Client[]>(FALLBACK_CLIENTS);
  useEffect(() => {
    getClients().then((c) => { if (c.length > 0) setClients(c); });
  }, []);

  const [cms, setCms] = useState<PlasticWastePageSettings>(FALLBACK);
  useEffect(() => {
    getPlasticWastePageSettings().then(d => { if (d) setCms(d); });
  }, []);

  const doubled = [...clients, ...clients, ...clients];

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Section 1: Hero ───────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[82vh] flex items-end overflow-hidden">
        <motion.div className="absolute inset-0" style={{ y: bgY }}>
          <img
            src="https://images.pexels.com/photos/3850512/pexels-photo-3850512.jpeg?auto=compress&cs=tinysrgb&w=1800&q=85"
            alt="Plastic waste management operations"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(1,41,138,0.95) 0%, rgba(1,41,138,0.65) 45%, rgba(1,41,138,0.15) 100%)' }} />
        </motion.div>

        <div className="container-site relative z-10 pb-16 pt-40">
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45 }}
            className="text-caption font-semibold uppercase tracking-[0.15em] mb-5"
            style={{ color: TEAL }}
          >
            Plastic Waste Management
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white leading-tight mb-6"
            style={{ fontSize: 'clamp(2.2rem, 4.5vw, 3.6rem)', letterSpacing: '-0.03em', maxWidth: 680 }}
          >
            {cms.hero_heading}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.22 }}
            className="text-body-lg leading-relaxed mb-4 max-w-2xl"
            style={{ color: 'rgba(255,255,255,0.78)' }}
          >
            {cms.hero_para_1}
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-body-lg leading-relaxed mb-10 max-w-2xl"
            style={{ color: 'rgba(255,255,255,0.65)' }}
          >
            {cms.hero_para_2}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.42 }}
            className="flex flex-col sm:flex-row gap-3"
          >
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-7 py-3.5 font-semibold text-sm transition-all duration-300 hover:opacity-90"
              style={{ backgroundColor: TEAL, color: '#0A1F3C' }}
            >
              {cms.hero_cta_label}
              <ArrowRight size={16} />
            </Link>
            <a
              href="#services"
              className="inline-flex items-center gap-2 px-7 py-3.5 font-medium text-sm border text-white transition-all duration-300 hover:bg-white/10"
              style={{ borderColor: 'rgba(255,255,255,0.3)' }}
            >
              Explore Solutions
              <ChevronRight size={16} />
            </a>
          </motion.div>
        </div>
      </section>

      {/* ── Section 2: Regulatory Context ────────────────────────────────── */}
      <section ref={contextRef} className="section-padding bg-white">
        <div className="container-site">
          {/* Top — regulatory text */}
          <div className="flex flex-col lg:flex-row gap-14 items-start mb-14">
            <motion.div
              className="flex-1 max-w-xl"
              initial="hidden"
              animate={contextInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="REGULATORY CONTEXT" />
              <h2
                className="font-display font-bold leading-tight mb-6"
                style={{ fontSize: 'clamp(1.6rem, 2.8vw, 2.2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
              >
                {cms.compliance_heading}
              </h2>
            </motion.div>
            <motion.div
              className="flex-1"
              initial="hidden"
              animate={contextInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={1}
            >
              <p className="text-body-lg leading-relaxed mb-4" style={{ color: '#5F5F5F' }}>
                {cms.compliance_body}
              </p>
              <p className="text-body-lg leading-relaxed" style={{ color: '#5F5F5F' }}>
                {cms.compliance_closing}
              </p>
            </motion.div>
          </div>

          {/* Consequences — red icon boxes */}
          <motion.div
            initial="hidden"
            animate={contextInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={2}
            className="p-8 mb-2"
            style={{ backgroundColor: '#FEF2F2', border: '1px solid #FECACA' }}
          >
            <p className="text-xs font-bold uppercase tracking-[0.15em] mb-6" style={{ color: '#DC2626' }}>
              Consequences of Non-Compliance
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { icon: <AlertTriangle size={20} />, text: (cms.consequences as {text: string}[])[0]?.text ?? '' },
                { icon: <Ban size={20} />, text: (cms.consequences as {text: string}[])[1]?.text ?? '' },
                { icon: <TrendingDown size={20} />, text: (cms.consequences as {text: string}[])[2]?.text ?? '' },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial="hidden"
                  animate={contextInView ? 'visible' : 'hidden'}
                  variants={fadeUp}
                  custom={i + 3}
                  className="flex items-start gap-4 p-5 bg-white"
                  style={{ border: '1px solid #FECACA' }}
                >
                  <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: '#FEE2E2', color: '#DC2626' }}>
                    {item.icon}
                  </div>
                  <p className="text-sm leading-relaxed pt-1" style={{ color: '#7F1D1D' }}>{item.text}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Section 3: Two-Service Redirect ──────────────────────────────── */}
      <section ref={redirectRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            className="mb-12"
            initial="hidden"
            animate={redirectInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="OUR SERVICES" />
            <h2
              className="font-display font-bold leading-tight mb-3"
              style={{ fontSize: 'clamp(1.6rem, 2.8vw, 2.2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
            >
              Two ways businesses approach plastic responsibility.
            </h2>
            <p className="text-body-lg" style={{ color: '#5F5F5F' }}>
              ReCircle offers two distinct services under plastic waste management. Choose the one that matches your needs.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Card 1 — EPR (Mandatory) */}
            <motion.div
              initial="hidden"
              animate={redirectInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={1}
              className="flex flex-col p-10 bg-white border"
              style={{ borderColor: '#E8E8E8', boxShadow: '0 2px 12px rgba(1,41,138,0.05)' }}
              whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.1)', y: -3 }}
              transition={{ duration: 0.2 }}
            >
              <p className="text-sm font-bold mb-2" style={{ color: '#1A1A1A' }}>EPR Services</p>
              {/* Mandatory tag */}
              <div className="inline-flex mb-6">
                <span
                  className="text-xs font-bold uppercase tracking-widest px-2.5 py-1"
                  style={{ backgroundColor: '#FEF2F2', color: '#DC2626', border: '1px solid #FECACA' }}
                >
                  Mandatory
                </span>
              </div>
              <p className="text-sm leading-relaxed mb-4" style={{ color: '#5F5F5F' }}>
                Built for businesses that need to meet legal obligations under India's EPR regulation for plastic waste. ReCircle manages the full EPR registration process, CPCB documentation, credit procurement, reporting, and compliance support required under the Plastic Waste Management Rules.
              </p>
              <p className="text-sm leading-relaxed mb-auto pb-6" style={{ color: '#858585' }}>
                Designed for producers, importers, brand owners, and manufacturers handling plastic packaging and other regulated materials.
              </p>
              <Link
                to="/epr"
                className="inline-flex items-center gap-2 font-semibold text-sm transition-all duration-200"
                style={{ color: NAVY }}
              >
                Go to EPR Services
                <ChevronRight size={15} />
              </Link>
            </motion.div>

            {/* Card 2 — PNP (Voluntary) */}
            <motion.div
              initial="hidden"
              animate={redirectInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={2}
              className="flex flex-col p-10 bg-white border"
              style={{ borderColor: '#E8E8E8', boxShadow: '0 2px 12px rgba(1,41,138,0.05)' }}
              whileHover={{ boxShadow: '0 8px 32px rgba(0,196,153,0.12)', y: -3 }}
              transition={{ duration: 0.2 }}
            >
              <p className="text-sm font-bold mb-2" style={{ color: '#1A1A1A' }}>Plastic Neutral Program (PNP)</p>
              {/* Voluntary tag */}
              <div className="inline-flex mb-6">
                <span
                  className="text-xs font-bold uppercase tracking-widest px-2.5 py-1"
                  style={{ backgroundColor: '#F0FDF4', color: '#16A34A', border: '1px solid #BBF7D0' }}
                >
                  Voluntary
                </span>
              </div>
              <p className="text-sm leading-relaxed mb-4" style={{ color: '#5F5F5F' }}>
                For businesses looking to go beyond compliance and actively reduce their plastic footprint. ReCircle's Plastic Neutral Program enables verified plastic recovery backed by traceable impact, helping brands strengthen sustainability commitments and build long-term credibility.
              </p>
              <p className="text-sm leading-relaxed mb-auto pb-6" style={{ color: '#858585' }}>
                Chosen by companies that want measurable environmental action, not just claims.
              </p>
              <Link
                to="/pnp"
                className="inline-flex items-center gap-2 font-semibold text-sm transition-all duration-200"
                style={{ color: TEAL }}
              >
                Go to Plastic Neutral Program
                <ChevronRight size={15} />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 4: Why ReCircle ───────────────────────────────────────── */}
      <section ref={whyRef} className="section-padding" style={{ backgroundColor: NAVY }}>
        <div className="container-site">
          <motion.div
            className="mb-14 text-center"
            initial="hidden"
            animate={whyInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="WHY RECIRCLE" center light />
            <h2
              className="font-display font-bold text-white leading-tight"
              style={{ fontSize: 'clamp(1.6rem, 2.8vw, 2.2rem)', letterSpacing: '-0.025em' }}
            >
              {cms.why_heading}
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {(cms.why_advantages as {num: string; title: string; body: string}[]).map((col, i) => (
              <motion.div
                key={col.num}
                initial="hidden"
                animate={whyInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="p-7 flex flex-col"
                style={{ backgroundColor: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}
                whileHover={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
                transition={{ duration: 0.18 }}
              >
                <div
                  className="w-12 h-12 flex items-center justify-center font-display font-black text-lg mb-5"
                  style={{ backgroundColor: TEAL, color: '#0A1F3C', letterSpacing: '-0.03em' }}
                >
                  {col.num}
                </div>
                <h3 className="text-sm font-bold text-white mb-3">{col.title}</h3>
                <p className="text-sm leading-relaxed flex-1" style={{ color: 'rgba(255,255,255,0.65)' }}>{col.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 5: Infrastructure (MRF) ──────────────────────────────── */}
      <section ref={infraRef} className="section-padding bg-white">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            {/* Left — content */}
            <motion.div
              className="flex-1 max-w-lg"
              initial="hidden"
              animate={infraInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="INFRASTRUCTURE" />
              <h2
                className="font-display font-bold leading-tight mb-5"
                style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
              >
                Infrastructure that supports traceable recovery.
              </h2>
              <p className="text-body-lg leading-relaxed mb-8" style={{ color: '#5F5F5F' }}>
                {cms.infra_body}
              </p>
              <Link
                to="/infrastructure/mrf"
                className="inline-flex items-center gap-2 px-7 py-3.5 font-semibold text-sm text-white transition-all duration-300 hover:opacity-90"
                style={{ backgroundColor: NAVY }}
              >
                Explore the MRF
                <ArrowRight size={16} />
              </Link>
            </motion.div>

            {/* Right — MRF image */}
            <motion.div
              className="flex-1 w-full"
              initial={{ opacity: 0, x: 24 }}
              animate={infraInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 24 }}
              transition={{ duration: 0.65, delay: 0.15 }}
            >
              <div className="overflow-hidden aspect-[16/10]">
                <img
                  src="https://images.pexels.com/photos/802221/pexels-photo-802221.jpeg?auto=compress&cs=tinysrgb&w=1200&q=85"
                  alt="Material Recovery Facility"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 6: Our Clients ────────────────────────────────────────── */}
      <section ref={clientsRef} className="section-padding" style={{ backgroundColor: '#F8F6F3' }}>
        <div className="container-site mb-10">
          <motion.div
            className="text-center"
            initial="hidden"
            animate={clientsInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="OUR CLIENTS" center />
            <h2
              className="font-display font-bold leading-tight"
              style={{ fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
            >
              Join the industry leaders who trust ReCircle.
            </h2>
          </motion.div>
        </div>

        {/* Ticker row 1 */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={clientsInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="ticker-container border-t border-b"
          style={{ borderColor: '#E8E8E8' }}
        >
          <div className="ticker-track py-5">
            {doubled.map((client, i) => (
              <div
                key={`${client.id}-${i}`}
                className="flex-shrink-0 flex items-center justify-center px-10 border-r"
                style={{ borderColor: '#E8E8E8', minWidth: 160 }}
              >
                <img
                  src={client.logo_url || DUMMY_LOGO_URLS[Number(client.id) % DUMMY_LOGO_URLS.length]}
                  alt={client.logo_alt}
                  className="h-8 w-auto object-contain grayscale opacity-50 hover:opacity-80 hover:grayscale-0 transition-all duration-300"
                />
              </div>
            ))}
          </div>
        </motion.div>

        {/* Ticker row 2 — reversed */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={clientsInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.35 }}
          className="ticker-container border-b"
          style={{ borderColor: '#E8E8E8', direction: 'rtl' }}
        >
          <div className="ticker-track-slow py-5">
            {[...doubled].reverse().map((client, i) => (
              <div
                key={`r-${client.id}-${i}`}
                className="flex-shrink-0 flex items-center justify-center px-10 border-r"
                style={{ borderColor: '#E8E8E8', minWidth: 160 }}
              >
                <img
                  src={client.logo_url || DUMMY_LOGO_URLS[Number(client.id) % DUMMY_LOGO_URLS.length]}
                  alt={client.logo_alt}
                  className="h-8 w-auto object-contain grayscale opacity-50 hover:opacity-80 hover:grayscale-0 transition-all duration-300"
                />
              </div>
            ))}
          </div>
        </motion.div>

        <div className="container-site mt-8 text-center">
          <motion.p
            initial={{ opacity: 0 }}
            animate={clientsInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="text-sm font-medium"
            style={{ color: '#ABABAB' }}
          >
            Building a compliant, circular future for plastic waste in India.
          </motion.p>
        </div>
      </section>

    </main>
  );
}
