import { useRef, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight, CheckCircle, ClipboardList, BarChart2, Recycle,
  ShieldCheck, FileText, Cpu, Globe, Leaf, ChevronRight,
  Users, Building2,
} from 'lucide-react';
import { getEprPageSettings } from '../../cms/queries';
import type { EprPageSettings } from '../../cms/types';

// ── Animation variants ────────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

// ── Brand colours ─────────────────────────────────────────────────────────────
const TEAL = '#00C499';
const NAVY = '#01298A';

// ── Default / fallback CMS content ───────────────────────────────────────────
const DEFAULT_CMS: EprPageSettings = {
  id: '',
  hero_heading: 'End-to-End EPR Compliance for Plastic Waste',
  hero_body: "India's Plastic Waste Management Rules require producers, importers, and brand owners to meet EPR targets. ReCircle manages every stage of the process — from CPCB registration and footprint assessment to waste recovery, credit verification, and annual return filing — with full traceability and accuracy.",
  stat_1_value: '500+',
  stat_1_label: 'businesses supported with EPR compliance',
  stat_2_value: '100%',
  stat_2_label: 'CPCB documentation accuracy',
  process_heading: 'Our EPR Compliance Process',
  process_steps: [
    { step: '01', title: 'EPR Registration', body: 'We register your entity on the CPCB EPR portal, ensuring all documentation is accurate and submitted correctly the first time.' },
    { step: '02', title: 'Target Assessment', body: 'We assess your annual plastic introduction volume to determine your precise EPR obligations under the Plastic Waste Management Rules.' },
    { step: '03', title: 'Waste Recovery', body: 'We source waste recovery from verified partners across our pan-India network, ensuring traceable and compliant collection volumes.' },
    { step: '04', title: 'Credit Verification', body: 'CPCB EPR credits are verified for authenticity and matched against your targets, ensuring full and documented compliance.' },
    { step: '05', title: 'Annual Return Filing', body: 'We file your annual returns with full documentation, audit-ready reports, and timely portal uploads — so you are always compliant.' },
  ],
  benefits_heading: 'What You Get with ReCircle EPR',
  benefits: [
    { title: 'Full Regulatory Coverage', body: 'We manage every step from registration to annual filing, so nothing falls through the cracks.' },
    { title: 'Verified EPR Credits', body: 'Every credit is authenticated and traceable, providing defensible proof of compliance.' },
    { title: 'Pan-India Recovery Network', body: 'Access our extensive network of verified waste recovery partners across India.' },
    { title: 'Real-Time Tracking', body: 'Monitor your EPR compliance status and recovery volumes through our ClimaOne platform.' },
  ],
  updated_at: '',
};

function SectionLabel({ text, center, light }: { text: string; center?: boolean; light?: boolean }) {
  return (
    <p
      className={`text-caption font-semibold uppercase tracking-[0.15em] mb-4 ${center ? 'text-center' : ''}`}
      style={{ color: light ? 'rgba(255,255,255,0.5)' : TEAL }}
    >
      {text}
    </p>
  );
}

// ── Service card ──────────────────────────────────────────────────────────────
function ServiceCard({ icon, title, i, inView }: { icon: React.ReactNode; title: string; i: number; inView: boolean }) {
  return (
    <motion.div
      initial="hidden"
      animate={inView ? 'visible' : 'hidden'}
      variants={fadeUp}
      custom={i}
      className="flex items-start gap-4 p-6 bg-white border group transition-all duration-200 hover:-translate-y-0.5"
      style={{ borderColor: '#E8E8E8', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}
      whileHover={{ boxShadow: '0 6px 24px rgba(1,41,138,0.09)' }}
    >
      <div
        className="w-10 h-10 flex-shrink-0 flex items-center justify-center transition-colors duration-200"
        style={{ backgroundColor: '#E8EDF8', color: NAVY }}
      >
        {icon}
      </div>
      <p className="text-sm font-semibold leading-snug pt-1.5" style={{ color: '#1A1A1A' }}>{title}</p>
    </motion.div>
  );
}

// ── Process step ──────────────────────────────────────────────────────────────
function ProcessStep({
  num, title, body, i, inView, isLast,
}: { num: string; title: string; body: string; i: number; inView: boolean; isLast?: boolean }) {
  return (
    <motion.div
      initial="hidden"
      animate={inView ? 'visible' : 'hidden'}
      variants={fadeUp}
      custom={i}
      className="relative flex gap-8 items-start"
    >
      {/* Number col */}
      <div className="flex flex-col items-center flex-shrink-0 w-14">
        <div
          className="w-14 h-14 flex items-center justify-center font-display font-black text-xl"
          style={{ backgroundColor: NAVY, color: '#DCEB4B', letterSpacing: '-0.04em' }}
        >
          {num}
        </div>
        {!isLast && <div className="w-px flex-1 mt-1" style={{ backgroundColor: 'rgba(1,41,138,0.12)', minHeight: 48 }} />}
      </div>

      {/* Content */}
      <div className="pb-10">
        <h3 className="text-base font-bold mb-2" style={{ color: '#FFFFFF' }}>{title}</h3>
        <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.65)' }}>{body}</p>
      </div>
    </motion.div>
  );
}

// ── Addon card ────────────────────────────────────────────────────────────────
function AddonCard({ icon, title, body, i, inView }: { icon: React.ReactNode; title: string; body: string; i: number; inView: boolean }) {
  return (
    <motion.div
      initial="hidden"
      animate={inView ? 'visible' : 'hidden'}
      variants={fadeUp}
      custom={i}
      className="p-8 border"
      style={{ borderColor: 'rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.04)' }}
      whileHover={{ backgroundColor: 'rgba(255,255,255,0.07)' }}
      transition={{ duration: 0.18 }}
    >
      <div
        className="w-10 h-10 flex items-center justify-center mb-5"
        style={{ backgroundColor: 'rgba(0,196,153,0.12)', color: TEAL }}
      >
        {icon}
      </div>
      <h3 className="text-sm font-bold text-white mb-2">{title}</h3>
      <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.6)' }}>{body}</p>
    </motion.div>
  );
}

// ── Benefit icon map (cycles through available icons) ─────────────────────────
const BENEFIT_ICONS = [
  <Users size={20} />,
  <Building2 size={20} />,
  <Recycle size={20} />,
  <ShieldCheck size={20} />,
  <Globe size={20} />,
  <Cpu size={20} />,
  <Leaf size={20} />,
  <CheckCircle size={20} />,
];

// ─────────────────────────────────────────────────────────────────────────────
// MAIN PAGE
// ─────────────────────────────────────────────────────────────────────────────
const EPR_DUMMY_LOGOS = [
  'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5726837/pexels-photo-5726837.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/6863183/pexels-photo-6863183.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/4491881/pexels-photo-4491881.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
];

export default function EprPage() {
  const [cms, setCms] = useState<EprPageSettings>(DEFAULT_CMS);

  useEffect(() => {
    getEprPageSettings().then((data) => {
      if (data) setCms(data);
    });
  }, []);

  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '22%']);

  const overviewRef = useRef<HTMLElement>(null);
  const servicesRef = useRef<HTMLElement>(null);
  const partnersRef = useRef<HTMLElement>(null);
  const processRef = useRef<HTMLElement>(null);
  const addonsRef = useRef<HTMLElement>(null);
  const ctaRef = useRef<HTMLElement>(null);

  const overviewInView = useInView(overviewRef, { once: true, margin: '-60px' });
  const servicesInView = useInView(servicesRef, { once: true, margin: '-60px' });
  const partnersInView = useInView(partnersRef, { once: true, margin: '-60px' });
  const processInView = useInView(processRef, { once: true, margin: '-60px' });
  const addonsInView = useInView(addonsRef, { once: true, margin: '-60px' });
  const ctaInView = useInView(ctaRef, { once: true, margin: '-60px' });

  const processSteps = (cms.process_steps as { step: string; title: string; body: string }[]);
  const benefits = (cms.benefits as { title: string; body: string }[]);

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Section 1: Hero ───────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[78vh] flex items-end overflow-hidden">
        <motion.div className="absolute inset-0" style={{ y: bgY }}>
          <img
            src="https://images.pexels.com/photos/3850512/pexels-photo-3850512.jpeg?auto=compress&cs=tinysrgb&w=1800&q=85"
            alt="EPR compliance operations"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(1,41,138,0.96) 0%, rgba(1,41,138,0.7) 45%, rgba(1,41,138,0.15) 100%)' }} />
        </motion.div>

        <div className="container-site relative z-10 pb-14 pt-36">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="text-caption font-semibold uppercase tracking-[0.15em] mb-5"
            style={{ color: '#DCEB4B' }}
          >
            EPR Compliance
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 36 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white leading-tight mb-6"
            style={{ fontSize: 'clamp(2.2rem, 4.5vw, 3.6rem)', letterSpacing: '-0.03em', maxWidth: 680 }}
          >
            {cms.hero_heading}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.22 }}
            className="text-body-lg leading-relaxed mb-10 max-w-2xl"
            style={{ color: 'rgba(255,255,255,0.78)' }}
          >
            {cms.hero_body}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.34 }}
            className="flex flex-col sm:flex-row gap-3"
          >
            <Link
              to="/contact"
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 font-semibold text-sm transition-all duration-300 hover:opacity-90"
              style={{ backgroundColor: TEAL, color: '#0A1F3C' }}
            >
              Book Your Free Consultation
              <ArrowRight size={16} />
            </Link>
            <a
              href="#services"
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 font-medium text-sm border text-white transition-all duration-300 hover:bg-white/10"
              style={{ borderColor: 'rgba(255,255,255,0.3)' }}
            >
              Explore Our Services
              <ChevronRight size={16} />
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.55 }}
            className="mt-10 flex items-center gap-6 flex-wrap"
          >
            {[
              { icon: <ShieldCheck size={13} />, text: 'CPCB Compliant' },
              { icon: <Globe size={13} />, text: 'Pan-India Network' },
              { icon: <CheckCircle size={13} />, text: 'Fully Traceable' },
            ].map((sig) => (
              <div key={sig.text} className="flex items-center gap-2">
                <span style={{ color: TEAL }}>{sig.icon}</span>
                <span className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.55)' }}>{sig.text}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Section 2: Expert Overview ────────────────────────────────────── */}
      <section ref={overviewRef} className="section-padding bg-ivory">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-16 items-start">
            {/* Left */}
            <motion.div
              className="flex-1"
              initial="hidden"
              animate={overviewInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="OUR APPROACH" />
              <h2
                className="font-display font-bold leading-tight mb-6"
                style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
              >
                Expert EPR Solutions for Plastic Waste Management in India
              </h2>
              <p className="text-body-lg leading-relaxed mb-5" style={{ color: '#5F5F5F' }}>
                From registration to compliance reporting, ReCircle manages every stage of the EPR process with accuracy, traceability, and transparency aligned with India's Plastic Waste Management Rules, 2016.
              </p>
              <p className="text-body-lg leading-relaxed" style={{ color: '#5F5F5F' }}>
                Our end-to-end EPR services support producers, importers, brand owners, and manufacturers through CPCB registration, plastic waste recovery, recycling, documentation, and EPR credit transfers. Backed by a pan-India recovery network and robust reporting systems, we ensure timely, compliant, and fully traceable EPR execution.
              </p>

              {/* Stat highlights inline below text */}
              <div className="grid grid-cols-2 gap-4 mt-8">
                {[
                  { value: cms.stat_1_value, desc: cms.stat_1_label },
                  { value: cms.stat_2_value, desc: cms.stat_2_label },
                  { value: 'CPCB', desc: 'Portal integrated reporting' },
                  { value: 'Pan-India', desc: 'Plastic waste recovery network' },
                ].map((s, i) => (
                  <motion.div
                    key={s.value + s.desc}
                    initial="hidden"
                    animate={overviewInView ? 'visible' : 'hidden'}
                    variants={fadeUp}
                    custom={i + 2}
                    className="p-6 border bg-white"
                    style={{ borderColor: '#E8E8E8' }}
                  >
                    <p className="font-display font-black text-2xl mb-1" style={{ color: NAVY, letterSpacing: '-0.03em' }}>{s.value}</p>
                    <p className="text-xs leading-snug" style={{ color: '#858585' }}>{s.desc}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 3: Services Suite ─────────────────────────────────────── */}
      <section ref={servicesRef} id="services" className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            className="mb-12"
            initial="hidden"
            animate={servicesInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="WHAT WE OFFER" />
            <h2
              className="font-display font-bold leading-tight mb-4"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em', color: '#1A1A1A', maxWidth: 600 }}
            >
              Our Suite of EPR Compliance Services
            </h2>
            <p className="text-body-lg max-w-2xl" style={{ color: '#5F5F5F' }}>
              From registration to reporting, we provide end-to-end support — making EPR compliance for plastic waste transparent, accurate, and hassle-free.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            <ServiceCard i={0} inView={servicesInView} icon={<ClipboardList size={18} />} title="EPR Registration on the CPCB Portal" />
            <ServiceCard i={1} inView={servicesInView} icon={<BarChart2 size={18} />} title="Data-Driven Footprint Assessment" />
            <ServiceCard i={2} inView={servicesInView} icon={<Globe size={18} />} title="Waste Recovery from Traceable Sources" />
            <ServiceCard i={3} inView={servicesInView} icon={<ShieldCheck size={18} />} title="CPCB EPR Credit Verification" />
            <ServiceCard i={4} inView={servicesInView} icon={<FileText size={18} />} title="Annual Return Filing" />
          </div>
        </div>
      </section>

      {/* ── Section 4: Partners in Compliance ────────────────────────────── */}
      <section ref={partnersRef} className="section-padding bg-white">
        <div className="container-site mb-10">
          <motion.div
            className="text-center"
            initial="hidden"
            animate={partnersInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="PARTNERS IN COMPLIANCE" center />
            <h2
              className="font-display font-bold leading-tight mb-3"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
            >
              Partners in Compliance
            </h2>
            <p className="text-body-lg max-w-xl mx-auto" style={{ color: '#5F5F5F' }}>
              Leading brands trust ReCircle for their EPR compliance services.
            </p>
          </motion.div>
        </div>

        {/* Logo ticker */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={partnersInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="ticker-container border-t border-b"
          style={{ borderColor: '#E8E8E8' }}
        >
          <div className="ticker-track py-5">
            {[...EPR_DUMMY_LOGOS, ...EPR_DUMMY_LOGOS, ...EPR_DUMMY_LOGOS].map((logo, i) => (
              <div
                key={i}
                className="flex-shrink-0 flex items-center justify-center px-10 border-r"
                style={{ borderColor: '#E8E8E8', minWidth: 140 }}
              >
                <img
                  src={logo}
                  alt={`Partner logo ${i + 1}`}
                  className="h-8 w-auto object-contain grayscale opacity-50 hover:opacity-80 hover:grayscale-0 transition-all duration-300"
                />
              </div>
            ))}
          </div>
        </motion.div>

        <div className="container-site mt-6 text-center">
          <motion.p
            initial={{ opacity: 0 }}
            animate={partnersInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="text-sm font-medium"
            style={{ color: '#ABABAB' }}
          >
            Join brands already building a compliant, circular future with ReCircle.
          </motion.p>
        </div>
      </section>

      {/* ── Section 5: EPR Compliance Process ────────────────────────────── */}
      <section ref={processRef} className="section-padding" style={{ backgroundColor: '#0A1F3C' }}>
        <div className="container-site">
          <motion.div
            className="mb-14"
            initial="hidden"
            animate={processInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="OUR PROCESS" light />
            <h2
              className="font-display font-bold text-white leading-tight mb-3"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em' }}
            >
              {cms.process_heading}
            </h2>
          </motion.div>

          <div className="max-w-2xl">
            {processSteps.map((s, i) => (
              <ProcessStep
                key={s.step}
                i={i}
                inView={processInView}
                num={s.step}
                title={s.title}
                body={s.body}
                isLast={i === processSteps.length - 1}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 6: What You Get (Benefits) ───────────────────────────── */}
      <section ref={addonsRef} className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <motion.div
            className="mb-12 max-w-2xl"
            initial="hidden"
            animate={addonsInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="BEYOND COMPLIANCE" light />
            <h2
              className="font-display font-bold text-white leading-tight mb-5"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em' }}
            >
              {cms.benefits_heading}
            </h2>
            <p className="text-body-lg leading-relaxed" style={{ color: 'rgba(255,255,255,0.65)' }}>
              Your EPR journey with ReCircle is just the beginning. For brands ready to make a bigger impact, we offer a suite of add-on services that go beyond regulations to build a truly circular brand.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {benefits.map((benefit, i) => (
              <AddonCard
                key={benefit.title}
                i={i}
                inView={addonsInView}
                icon={BENEFIT_ICONS[i % BENEFIT_ICONS.length]}
                title={benefit.title}
                body={benefit.body}
              />
            ))}
          </div>

          {/* Sub-links */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={addonsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-wrap gap-6 mt-8"
          >
            <Link to="/esg-projects" className="inline-flex items-center gap-1.5 text-sm font-medium transition-colors hover:opacity-100" style={{ color: 'rgba(255,255,255,0.4)' }}>
              Explore ESG Projects <ChevronRight size={13} />
            </Link>
            <Link to="/rpet-flakes" className="inline-flex items-center gap-1.5 text-sm font-medium transition-colors hover:opacity-100" style={{ color: 'rgba(255,255,255,0.4)' }}>
              View rPET Flakes <ChevronRight size={13} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* ── Section 7: Contact CTA ────────────────────────────────────────── */}
      <section ref={ctaRef} className="section-padding relative overflow-hidden" style={{ backgroundColor: NAVY }}>
        {/* Glow */}
        <div className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(ellipse at 30% 50%, rgba(0,196,153,0.1) 0%, transparent 65%)' }} />

        <div className="container-site relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
            {/* Left */}
            <motion.div
              className="max-w-xl"
              initial="hidden"
              animate={ctaInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="CONTACT US" light />
              <h2
                className="font-display font-bold text-white leading-tight mb-5"
                style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.8rem)', letterSpacing: '-0.025em' }}
              >
                Take the First Step
              </h2>
              <p className="text-body-lg leading-relaxed mb-3" style={{ color: 'rgba(255,255,255,0.7)' }}>
                Make EPR compliance easy with ReCircle. We handle the process so you can focus on your business.
              </p>
              <p className="text-body-lg font-semibold" style={{ color: 'rgba(255,255,255,0.9)' }}>
                Get Started Today and simplify your EPR journey with confidence.
              </p>
            </motion.div>

            {/* Right — CTA block */}
            <motion.div
              initial={{ opacity: 0, x: 24 }}
              animate={ctaInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 24 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="flex flex-col items-start lg:items-end gap-5 shrink-0"
            >
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-8 py-4 font-semibold text-sm transition-all duration-300 hover:opacity-90"
                style={{ backgroundColor: TEAL, color: '#0A1F3C' }}
              >
                Book Your Free Consultation
                <ArrowRight size={16} />
              </Link>

              {/* Trust signals */}
              <div className="flex flex-col gap-2">
                {[
                  { icon: <CheckCircle size={13} />, text: 'No commitment required' },
                  { icon: <Globe size={13} />, text: 'Pan-India coverage' },
                  { icon: <ShieldCheck size={13} />, text: 'CPCB certified process' },
                ].map((sig) => (
                  <div key={sig.text} className="flex items-center gap-2">
                    <span style={{ color: TEAL }}>{sig.icon}</span>
                    <span className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.5)' }}>{sig.text}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

    </main>
  );
}
