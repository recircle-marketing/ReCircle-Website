import { useRef, useEffect, useState, useCallback } from 'react';
import { motion, useInView, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { Linkedin, Mail, ChevronLeft, ChevronRight } from 'lucide-react';
import { getInvestors, getAboutPageSettings } from '../../cms/queries';
import type { Investor, AboutPageSettings } from '../../cms/types';

const TEAL = '#00C499';
const NAVY = '#01298A';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

function SectionLabel({ text, light, center }: { text: string; light?: boolean; center?: boolean }) {
  return (
    <p className={`text-caption font-semibold uppercase tracking-[0.15em] mb-4 ${center ? 'text-center' : ''}`}
      style={{ color: light ? 'rgba(255,255,255,0.5)' : TEAL }}>
      {text}
    </p>
  );
}

// ── Timeline ───────────────────────────────────────────────────────────────────
const TIMELINE = [
  { year: '2016', event: 'Incorporated as RadicConnect. Started as a B2C model after winning Google Startup Weekend.' },
  { year: '2017', event: 'Established the first Dry Waste Material Recovery Facility (MRF) in Mumbai.' },
  { year: '2019', event: 'Pivoted to a B2B model and launched the Extended Producer Responsibility (EPR) vertical.' },
  { year: '2021', event: 'Rebranded from RadicConnect to ReCircle to reflect expanded vision and scope.' },
  { year: '2022', event: 'Launched ClimaOne and upgraded the MRF with support from GSMA, UKAid, SecondMuse, and AEPW.' },
  { year: '2023', event: 'Secured first institutional funding from Flipkart Ventures, Acumen, and 3i Partners.' },
  { year: '2024', event: 'Raised a bridge funding round from Mumbai Angels and Venture Catalysts.' },
  { year: '2024', event: 'Established the Textile Waste Recovery Facility focused on segregation and processing.' },
  { year: '2025', event: 'Initiated setup of an rPET flakes recycling plant in Bhiwani.' },
  { year: '2026', event: 'Expanded the rPET flakes recycling plant setup in Hisar.' },
];

// ── Investor logos ─────────────────────────────────────────────────────────────
const FALLBACK_INVESTORS: Investor[] = [
  { id: '1', sort_order: 1, is_active: true, name: 'Mumbai Angels', abbr: 'MA', color: '#E7182A', logo_url: 'https://recircle.in/wp-content/uploads/2024/09/Mumbai-Angels_01.png', logo_alt: 'Mumbai Angels', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, name: 'Flipkart Ventures', abbr: 'FV', color: '#2874F0', logo_url: 'https://recircle.in/wp-content/uploads/2024/07/Flip_Ventures.svg', logo_alt: 'Flipkart Ventures', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, name: 'Acumen', abbr: 'AC', color: '#00A86B', logo_url: 'https://recircle.in/wp-content/uploads/2025/05/Acumen.jpg', logo_alt: 'Acumen', created_at: '', updated_at: '' },
  { id: '4', sort_order: 4, is_active: true, name: '3i Partners', abbr: '3i', color: '#1A1A1A', logo_url: 'https://recircle.in/wp-content/uploads/2024/07/3i.svg', logo_alt: '3i Partners', created_at: '', updated_at: '' },
  { id: '5', sort_order: 5, is_active: true, name: 'Venture Catalysts', abbr: 'VC', color: '#01298A', logo_url: 'https://recircle.in/wp-content/uploads/2024/09/Venture-catalysts1.png', logo_alt: 'Venture Catalysts', created_at: '', updated_at: '' },
];

// ── CMS fallback ──────────────────────────────────────────────────────────────
const FALLBACK: AboutPageSettings = {
  id: '',
  hero_stat: '465 crore',
  hero_stat_label: 'plastic bottles',
  hero_stat_note: 'annually',
  hero_paragraph_1: 'India ranks second globally in plastic waste production. And yet it imports plastic waste from other nations because the systems and incentives for waste retrieval do not exist at scale.',
  hero_paragraph_2: 'ReCircle found this unacceptable a decade ago. That is where our story begins.',
  vision_quote: 'See a world where no resources are wasted by pursuing and promoting ethical circularity.',
  commitments: [
    { num: '01', text: 'Divert waste away from landfills and oceans.' },
    { num: '02', text: 'Formalise the marginalised waste industry in India.' },
    { num: '03', text: 'Enable a circular economy where waste is recognised as a resource.' },
  ],
  roots_heading: 'Bridging the gap between economy and ecology.',
  roots_body: 'ReCircle is headquartered in Mumbai, operating between India\'s economic centre and its largest landfill. That contrast is not incidental. It is a constant reminder of the balance between economic development and environmental responsibility that ReCircle works to support every day.',
  roots_closing: 'We set the standard for brands to pursue excellence, responsibly.',
  mind_heading: 'Waste can either be a circular problem or a circular solution.',
  mind_body: 'Waste affects all life, whether we acknowledge it or not. Within every problem lies its solution. When reengineered, waste becomes a new raw material. At ReCircle, we have built on waste\'s evolving role. Where you see a discarded plastic packet, we see a repurposed item with a new life.',
  growth_heading: 'Every small step in waste management is a giant leap toward a sustainable future.',
  growth_body: 'ReCircle started as a grassroots-level waste collection aggregator in 2016. Today, with 8,800 kg recovered per hour, we have become the trusted choice for urban government bodies, global corporations, local business owners, and individuals.',
  growth_closing: 'Together, we are proving that waste is the new eco-currency.',
  growth_stat: '8,800 kg',
  growth_stat_unit: '/ hour',
  growth_stat_descriptor: 'of waste recovered across India',
  reach_heading: '',
  reach_body: '',
  reach_stats: [],
  reach_footnote: '',
  team_section_heading: 'The people behind ReCircle.',
  team_section_intro_1: 'We are a passionate group of professionals with expertise in finance, supply chain, logistics, management, and regulations, united by one goal: to re-establish waste as a resource.',
  team_section_intro_2: 'We lead by example. Meet us at our next waste collection drive or zero waste event.',
  updated_at: '',
};

// ── Team (40 members with dummy data) ─────────────────────────────────────────
const PHOTOS = [
  'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3778680/pexels-photo-3778680.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3756681/pexels-photo-3756681.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3760514/pexels-photo-3760514.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
];

const ROLES = [
  ['Co-Founder & CEO', 'Co-Founder & COO', 'Head of Compliance', 'Head of Operations'],
  ['Head of Sustainability', 'Head of Technology', 'Head of Finance', 'Head of Partnerships'],
  ['Senior Manager — EPR', 'Senior Manager — Textile', 'Manager — Collections', 'Manager — Logistics'],
  ['Data Analyst', 'Field Operations Lead', 'ESG Consultant', 'Marketing Manager'],
  ['Business Development', 'Compliance Analyst', 'Operations Analyst', 'HR Manager'],
  ['Product Manager', 'Software Engineer', 'QA Engineer', 'UI/UX Designer'],
  ['Supply Chain Lead', 'Procurement Manager', 'Legal Counsel', 'Finance Analyst'],
  ['Community Manager', 'Content Strategist', 'Brand Manager', 'Public Relations'],
  ['Regional Head — North', 'Regional Head — South', 'Regional Head — East', 'Regional Head — West'],
  ['Safai Saathi Coordinator', 'Impact Measurement Lead', 'Research Analyst', 'Training & Development'],
];

const FIRST_NAMES = ['Saurabh','Ashish','Priya','Rahul','Meera','Vikram','Anjali','Arjun','Nidhi','Deepak','Kavitha','Rohit','Sunita','Anil','Pooja','Sachin','Divya','Siddharth','Reena','Ajay','Neha','Vivek','Shruti','Kiran','Manish','Rekha','Vijay','Swati','Ankit','Leena','Rajan','Poonam','Suresh','Aarti','Mohit','Geeta','Tanmay','Nisha','Hitesh','Bhavna'];
const LAST_NAMES = ['Rai','Baheti','Desai','Sharma','Nair','Joshi','Singh','Kulkarni','Mehta','Gupta','Reddy','Verma','Patel','Iyer','Kapoor','Malhotra','Bose','Choudhary','Saxena','Mishra','Dubey','Pandey','Agarwal','Sinha','Trivedi','Pillai','Venkat','Banerjee','Das','Mukherjee','Chatterjee','Ghosh','Roy','Bhat','Nambiar','Krishnan','Menon','Namboodiri','Rao','Shah'];

const TEAM = FIRST_NAMES.map((first, i) => ({
  name: `${first} ${LAST_NAMES[i]}`,
  role: ROLES[Math.floor(i / 4)][i % 4],
  photo: PHOTOS[i % PHOTOS.length],
  linkedin: `https://linkedin.com/in/${first.toLowerCase()}-${LAST_NAMES[i].toLowerCase()}`,
  email: `${first.toLowerCase()}.${LAST_NAMES[i].toLowerCase()}@recircle.in`,
}));

const TEAM_PAGE_SIZE = 5;

// ── Team Carousel ─────────────────────────────────────────────────────────────
function TeamCarousel({ inView }: { inView: boolean }) {
  const [page, setPage] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const totalPages = Math.ceil(TEAM.length / TEAM_PAGE_SIZE);

  const next = useCallback(() => setPage((p) => (p + 1) % totalPages), [totalPages]);
  const prev = useCallback(() => setPage((p) => (p - 1 + totalPages) % totalPages), [totalPages]);

  useEffect(() => {
    if (isPaused) return;
    const t = setInterval(next, 4000);
    return () => clearInterval(t);
  }, [next, isPaused]);

  const start = page * TEAM_PAGE_SIZE;
  const visible = TEAM.slice(start, start + TEAM_PAGE_SIZE);

  return (
    <div
      className="relative"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Cards */}
      <AnimatePresence mode="wait">
        <motion.div
          key={page}
          initial={{ opacity: 0, x: 32 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -32 }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6"
        >
          {visible.map((member, i) => (
            <motion.div
              key={member.name}
              initial="hidden"
              animate={inView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={i * 0.5}
              className="flex flex-col items-center text-center group"
            >
              {/* Photo */}
              <div className="relative w-24 h-24 mb-4 overflow-hidden rounded-full flex-shrink-0"
                style={{ boxShadow: '0 4px 16px rgba(0,0,0,0.12)' }}>
                <img src={member.photo} alt={member.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108" />
                <div className="absolute inset-0 rounded-full ring-2 ring-transparent group-hover:ring-teal-400 transition-all duration-300"
                  style={{ '--tw-ring-color': TEAL } as React.CSSProperties} />
              </div>
              {/* Name & role */}
              <p className="text-sm font-bold leading-snug mb-0.5" style={{ color: '#1A1A1A' }}>{member.name}</p>
              <p className="text-xs mb-3 leading-snug" style={{ color: '#858585' }}>{member.role}</p>
              {/* Actions */}
              <div className="flex items-center gap-2">
                <a
                  href={member.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`${member.name} on LinkedIn`}
                  className="w-7 h-7 flex items-center justify-center border transition-all duration-200 hover:scale-110"
                  style={{ borderColor: '#D1D1D1' }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = NAVY; e.currentTarget.style.borderColor = NAVY; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.borderColor = '#D1D1D1'; }}
                >
                  <Linkedin size={13} style={{ color: '#5A5A5A' }} />
                </a>
                <a
                  href={`mailto:${member.email}`}
                  aria-label={`Email ${member.name}`}
                  className="w-7 h-7 flex items-center justify-center border transition-all duration-200 hover:scale-110"
                  style={{ borderColor: '#D1D1D1' }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = TEAL; e.currentTarget.style.borderColor = TEAL; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.borderColor = '#D1D1D1'; }}
                >
                  <Mail size={13} style={{ color: '#5A5A5A' }} />
                </a>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </AnimatePresence>

      {/* Controls */}
      <div className="flex items-center justify-between mt-10">
        {/* Dots */}
        <div className="flex items-center gap-2">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button
              key={i}
              onClick={() => setPage(i)}
              className={`transition-all duration-300 rounded-full ${i === page ? 'w-6 h-1.5' : 'w-1.5 h-1.5'}`}
              style={{ backgroundColor: i === page ? TEAL : '#D1D1D1' }}
              aria-label={`Go to page ${i + 1}`}
            />
          ))}
        </div>
        {/* Arrows */}
        <div className="flex items-center gap-2">
          <button onClick={prev}
            className="w-9 h-9 border flex items-center justify-center transition-all duration-200 hover:border-navy hover:bg-navy"
            style={{ borderColor: '#E0E0E0' }}
            onMouseEnter={(e) => { e.currentTarget.style.borderColor = NAVY; e.currentTarget.style.backgroundColor = NAVY; }}
            onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#E0E0E0'; e.currentTarget.style.backgroundColor = 'transparent'; }}
            aria-label="Previous">
            <ChevronLeft size={16} style={{ color: '#5A5A5A' }} />
          </button>
          <button onClick={next}
            className="w-9 h-9 border flex items-center justify-center transition-all duration-200"
            style={{ borderColor: '#E0E0E0' }}
            onMouseEnter={(e) => { e.currentTarget.style.borderColor = NAVY; e.currentTarget.style.backgroundColor = NAVY; }}
            onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#E0E0E0'; e.currentTarget.style.backgroundColor = 'transparent'; }}
            aria-label="Next">
            <ChevronRight size={16} style={{ color: '#5A5A5A' }} />
          </button>
        </div>
      </div>

      <p className="mt-3 text-xs" style={{ color: '#ABABAB' }}>
        Showing {start + 1}–{Math.min(start + TEAM_PAGE_SIZE, TEAM.length)} of {TEAM.length} team members
      </p>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function AboutPage() {
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '15%']);

  const visionRef = useRef<HTMLElement>(null);
  const rootsRef = useRef<HTMLElement>(null);
  const mindRef = useRef<HTMLElement>(null);
  const growthRef = useRef<HTMLElement>(null);
  const journeyRef = useRef<HTMLElement>(null);
  const investorsRef = useRef<HTMLElement>(null);
  const teamRef = useRef<HTMLElement>(null);

  const visionInView = useInView(visionRef, { once: true, margin: '-60px' });
  const rootsInView = useInView(rootsRef, { once: true, margin: '-60px' });
  const mindInView = useInView(mindRef, { once: true, margin: '-60px' });
  const growthInView = useInView(growthRef, { once: true, margin: '-60px' });
  const journeyInView = useInView(journeyRef, { once: true, margin: '-60px' });
  const investorsInView = useInView(investorsRef, { once: true, margin: '-60px' });
  const teamInView = useInView(teamRef, { once: true, margin: '-60px' });

  const [investors, setInvestors] = useState<Investor[]>(FALLBACK_INVESTORS);
  useEffect(() => {
    getInvestors().then((d) => {
      if (d.length > 0) {
        const withLogos = d.map((inv) => ({
          ...inv,
          logo_url: inv.logo_url || FALLBACK_INVESTORS.find((f) => f.name === inv.name)?.logo_url || '',
        }));
        setInvestors(withLogos);
      }
    });
  }, []);

  const [cms, setCms] = useState<AboutPageSettings>(FALLBACK);
  useEffect(() => {
    getAboutPageSettings().then((d) => { if (d) setCms(d); });
  }, []);

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Section 1: Hero ───────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[88vh] flex items-center overflow-hidden">
        {/* Background image with parallax */}
        <motion.div
          className="absolute inset-0"
          style={{ y: bgY }}
        >
          <img
            src="https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg?auto=compress&cs=tinysrgb&w=1920&q=80"
            alt="ReCircle waste recovery operations"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(13,31,60,0.88) 50%, rgba(13,31,60,0.5) 100%)' }} />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(13,31,60,0.6) 0%, transparent 50%)' }} />
        </motion.div>

        <div className="relative z-10 container-site section-padding w-full">
          <div className="max-w-3xl">
            {/* Stat anchor */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="mb-8"
            >
              <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: 'rgba(255,255,255,0.45)' }}>
                India imports
              </p>
              <div className="font-display font-black leading-none"
                style={{ fontSize: 'clamp(3.5rem, 9vw, 7.5rem)', letterSpacing: '-0.04em', color: 'white' }}>
                {cms.hero_stat}
                <br />
                <span style={{ color: TEAL }}>{cms.hero_stat_label}</span>
              </div>
              <p className="mt-3 text-sm font-medium" style={{ color: 'rgba(255,255,255,0.4)' }}>{cms.hero_stat_note}</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="space-y-4 max-w-xl"
            >
              <p className="text-body-lg leading-relaxed" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {cms.hero_paragraph_1}
              </p>
              <p className="text-body-lg leading-relaxed font-medium" style={{ color: 'rgba(255,255,255,0.9)' }}>
                {cms.hero_paragraph_2}
              </p>
            </motion.div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.9 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <div className="w-px h-12" style={{ background: `linear-gradient(to bottom, ${TEAL}99, transparent)` }} />
        </motion.div>
      </section>

      {/* ── Section 2: Vision ─────────────────────────────────────────────── */}
      <section ref={visionRef} className="section-padding" style={{ backgroundColor: '#F7F1EE' }}>
        <div className="container-site">
          <motion.div className="text-center mb-10" initial="hidden" animate={visionInView ? 'visible' : 'hidden'} variants={fadeUp}>
            <SectionLabel text="OUR VISION" center />
          </motion.div>

          {/* Vision quote */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={visionInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-center mb-16 px-4"
          >
            <div className="relative inline-block max-w-3xl mx-auto">
              <span className="absolute -top-6 -left-4 font-serif text-7xl leading-none select-none" style={{ color: TEAL, opacity: 0.25 }}>"</span>
              <p className="font-display font-bold leading-tight"
                style={{ fontSize: 'clamp(1.6rem, 3.5vw, 2.6rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}>
                {cms.vision_quote}
              </p>
              <span className="absolute -bottom-10 -right-4 font-serif text-7xl leading-none select-none" style={{ color: TEAL, opacity: 0.25 }}>"</span>
            </div>
          </motion.div>

          {/* Three commitments — prominent numbered boxes */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-4xl mx-auto">
            {(cms.commitments as { num: string; text: string }[]).map((item, i) => (
              <motion.div
                key={item.num}
                initial="hidden"
                animate={visionInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i + 2}
                className="bg-white border p-8 flex flex-col gap-4"
                style={{ borderColor: '#E8E8E8' }}
              >
                {/* Large number badge */}
                <div className="w-12 h-12 flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: NAVY }}>
                  <span className="text-sm font-black text-white">{item.num}</span>
                </div>
                <p className="text-base font-semibold leading-snug" style={{ color: '#1A1A1A' }}>{item.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 3: Our Roots ──────────────────────────────────────────── */}
      <section ref={rootsRef} className="section-padding bg-white border-t border-b" style={{ borderColor: '#E8E8E8' }}>
        <div className="container-site">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
            {/* Left — heading */}
            <motion.div
              initial="hidden"
              animate={rootsInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="OUR ROOTS" />
              <h2
                className="font-display font-bold leading-tight"
                style={{ fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
              >
                {cms.roots_heading}
              </h2>
            </motion.div>

            {/* Right — body text, aligned to same top as heading */}
            <motion.div
              initial="hidden"
              animate={rootsInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={1}
            >
              <p className="text-body-lg leading-relaxed mb-5" style={{ color: '#5F5F5F' }}>
                {cms.roots_body}
              </p>
              <p className="text-body-lg leading-relaxed font-semibold" style={{ color: '#1A1A1A' }}>
                {cms.roots_closing}
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 4: On Our Mind ────────────────────────────────────────── */}
      <section ref={mindRef} className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <div className="max-w-2xl mx-auto text-center">
            <motion.div initial="hidden" animate={mindInView ? 'visible' : 'hidden'} variants={fadeUp}>
              <SectionLabel text="ON OUR MIND" center light />
              <h2 className="font-display font-bold text-white leading-tight mb-8"
                style={{ fontSize: 'clamp(1.6rem, 3vw, 2.4rem)', letterSpacing: '-0.03em' }}>
                {cms.mind_heading}
              </h2>
            </motion.div>
            <motion.div initial="hidden" animate={mindInView ? 'visible' : 'hidden'} variants={fadeUp} custom={1}>
              <p className="text-body-lg leading-relaxed" style={{ color: 'rgba(255,255,255,0.65)' }}>
                {cms.mind_body}
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 5: Our Growth ─────────────────────────────────────────── */}
      <section ref={growthRef} className="section-padding bg-ivory">
        <div className="container-site">
          <div className="grid lg:grid-cols-2 gap-14 lg:gap-20 items-center">
            {/* Left — narrative */}
            <motion.div initial="hidden" animate={growthInView ? 'visible' : 'hidden'} variants={fadeUp}>
              <SectionLabel text="OUR GROWTH" />
              <h2 className="font-display font-bold leading-tight mb-6"
                style={{ fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}>
                {cms.growth_heading}
              </h2>
              <p className="text-body-lg leading-relaxed mb-4" style={{ color: '#5F5F5F' }}>{cms.growth_body}</p>
              <p className="text-body-lg font-semibold" style={{ color: '#1A1A1A' }}>{cms.growth_closing}</p>
            </motion.div>

            {/* Right — stat block, equal width column */}
            <motion.div
              initial={{ opacity: 0, x: 24 }}
              animate={growthInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="flex justify-center lg:justify-end"
            >
              <div className="w-full max-w-sm p-10 border-l-4 bg-white"
                style={{ borderColor: TEAL, boxShadow: '0 4px 24px rgba(1,41,138,0.07)' }}>
                <p className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: TEAL }}>Recovery Rate</p>
                <p className="font-display font-black leading-none mb-2"
                  style={{ fontSize: 'clamp(2.8rem, 5vw, 4.5rem)', color: NAVY, letterSpacing: '-0.04em' }}>
                  {cms.growth_stat}
                </p>
                <p className="text-sm font-semibold mb-2" style={{ color: TEAL }}>{cms.growth_stat_unit}</p>
                <p className="text-sm" style={{ color: '#858585' }}>{cms.growth_stat_descriptor}</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 6: Our Journey — Horizontal Timeline ─────────────────── */}
      <section ref={journeyRef} className="section-padding bg-white overflow-x-auto">
        <div className="container-site">
          <motion.div className="mb-14" initial="hidden" animate={journeyInView ? 'visible' : 'hidden'} variants={fadeUp}>
            <SectionLabel text="OUR JOURNEY" />
            <h2 className="font-display font-bold leading-tight"
              style={{ fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}>
              A decade of building circularity.
            </h2>
          </motion.div>

          {/* Horizontal timeline — alternating above/below */}
          <div className="relative overflow-x-auto pb-4">
            <div className="min-w-max px-4">
              {/* The central horizontal line */}
              <div className="relative flex items-center" style={{ height: 320 }}>
                {/* Line */}
                <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-px" style={{ backgroundColor: '#E8E8E8', zIndex: 0 }}>
                  <motion.div
                    initial={{ scaleX: 0 }}
                    animate={journeyInView ? { scaleX: 1 } : {}}
                    transition={{ duration: 1.5, delay: 0.3, ease: 'easeOut' }}
                    className="absolute inset-0 origin-left"
                    style={{ background: `linear-gradient(to right, ${NAVY}, ${TEAL})` }}
                  />
                </div>

                {/* Nodes */}
                <div className="relative flex items-center">
                  {TIMELINE.map((item, i) => {
                    const isAbove = i % 2 === 0;
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: isAbove ? -16 : 16 }}
                        animate={journeyInView ? { opacity: 1, y: 0 } : {}}
                        transition={{ duration: 0.5, delay: 0.3 + i * 0.1, ease: 'easeOut' }}
                        className="flex flex-col items-center"
                        style={{ width: 160, flexShrink: 0 }}
                      >
                        {isAbove ? (
                          <>
                            {/* Content above line */}
                            <div className="h-[120px] flex flex-col justify-end pb-3 px-2 text-center">
                              <span className="font-display font-black text-sm mb-1" style={{ color: NAVY }}>{item.year}</span>
                              <p className="text-xs leading-snug" style={{ color: '#5F5F5F' }}>{item.event}</p>
                            </div>
                            {/* Vertical connector + dot */}
                            <div className="flex flex-col items-center">
                              <div className="w-px h-6" style={{ backgroundColor: TEAL, opacity: 0.5 }} />
                              <div className="w-3 h-3 rounded-full border-2 z-10" style={{ backgroundColor: 'white', borderColor: TEAL }} />
                              <div className="w-px h-6 opacity-0" />
                            </div>
                            {/* Empty below */}
                            <div className="h-[120px]" />
                          </>
                        ) : (
                          <>
                            {/* Empty above */}
                            <div className="h-[120px]" />
                            {/* Vertical connector + dot */}
                            <div className="flex flex-col items-center">
                              <div className="w-px h-6 opacity-0" />
                              <div className="w-3 h-3 rounded-full border-2 z-10" style={{ backgroundColor: 'white', borderColor: NAVY }} />
                              <div className="w-px h-6" style={{ backgroundColor: NAVY, opacity: 0.5 }} />
                            </div>
                            {/* Content below line */}
                            <div className="h-[120px] flex flex-col justify-start pt-3 px-2 text-center">
                              <span className="font-display font-black text-sm mb-1" style={{ color: NAVY }}>{item.year}</span>
                              <p className="text-xs leading-snug" style={{ color: '#5F5F5F' }}>{item.event}</p>
                            </div>
                          </>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Section 7: Our Investors ──────────────────────────────────────── */}
      <section ref={investorsRef} className="section-padding border-t" style={{ borderColor: '#E8E8E8', backgroundColor: '#F8F6F3' }}>
        <div className="container-site">
          <motion.div className="text-center mb-12" initial="hidden" animate={investorsInView ? 'visible' : 'hidden'} variants={fadeUp}>
            <SectionLabel text="OUR INVESTORS" center />
            <h2 className="font-display font-bold leading-tight"
              style={{ fontSize: 'clamp(1.4rem, 2.2vw, 1.8rem)', letterSpacing: '-0.02em', color: '#1A1A1A' }}>
              Meet our valued investors.
            </h2>
          </motion.div>

          <motion.div
            className="flex flex-wrap items-center justify-center gap-8"
            initial="hidden"
            animate={investorsInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
          >
            {investors.map((inv, i) => (
              <motion.div
                key={inv.id}
                initial="hidden"
                animate={investorsInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={Math.floor(i / 2) + 1}
                className="flex items-center justify-center px-10 py-6 bg-white border group transition-all duration-300 hover:border-blue-primary hover:shadow-card"
                style={{ borderColor: '#E0E0E0', minWidth: 180 }}
              >
                {inv.logo_url ? (
                  <img src={inv.logo_url} alt={inv.logo_alt}
                    className="h-10 object-contain grayscale opacity-55 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-400 max-w-[150px]"
                  />
                ) : (
                  <span className="text-xs font-bold uppercase tracking-widest" style={{ color: '#5A5A5A' }}>{inv.name}</span>
                )}
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Section 8: Our Team ───────────────────────────────────────────── */}
      <section ref={teamRef} className="section-padding bg-white">
        <div className="container-site">
          <motion.div className="mb-3" initial="hidden" animate={teamInView ? 'visible' : 'hidden'} variants={fadeUp}>
            <SectionLabel text="OUR TEAM" />
            <h2 className="font-display font-bold leading-tight mb-4"
              style={{ fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}>
              {cms.team_section_heading}
            </h2>
          </motion.div>

          <motion.div className="mb-14 max-w-2xl" initial="hidden" animate={teamInView ? 'visible' : 'hidden'} variants={fadeUp} custom={1}>
            <p className="text-body-lg leading-relaxed mb-2" style={{ color: '#5F5F5F' }}>{cms.team_section_intro_1}</p>
            <p className="text-body-lg leading-relaxed" style={{ color: '#5F5F5F' }}>{cms.team_section_intro_2}</p>
          </motion.div>

          <TeamCarousel inView={teamInView} />
        </div>
      </section>

    </main>
  );
}
