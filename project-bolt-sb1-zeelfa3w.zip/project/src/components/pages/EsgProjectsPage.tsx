import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight, ChevronLeft, ChevronRight, Recycle, Users,
  BookOpen, Cpu, Leaf, ShieldCheck, TrendingUp, Package,
} from 'lucide-react';
import { getEsgPageSettings } from '../../cms/queries';
import type { EsgPageSettings } from '../../cms/types';

// ── Animation variants ────────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

// ── Brand colours ─────────────────────────────────────────────────────────────
const TEAL = '#00C499';
const NAVY = '#01298A';
const OLIVE = '#6B6B2A';

// ── Helper ────────────────────────────────────────────────────────────────────
function SectionLabel({ text, color = NAVY }: { text: string; color?: string }) {
  return (
    <p className="text-caption font-semibold uppercase tracking-[0.15em] mb-4" style={{ color }}>
      {text}
    </p>
  );
}

// ─── Project case study wrapper — reusable layout shell ──────────────────────
// Each case study has: bg color, label, logo slot, heading, body, optional
// callout, stat cards, closing italic. All variants are passed as props so
// new projects can be added without new layout code.

// ─── AEPW Stat Card ──────────────────────────────────────────────────────────
function AepwStatCard({
  icon, number, unit, desc, full,
}: {
  icon: React.ReactNode; number: string; unit?: string; desc: string; full?: boolean;
}) {
  return (
    <div
      className={`flex items-start gap-4 p-5 ${full ? 'col-span-full' : ''}`}
      style={{ backgroundColor: '#1B4D4A', border: '1px solid rgba(0,196,153,0.2)' }}
    >
      <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center border" style={{ borderColor: 'rgba(0,196,153,0.4)', color: TEAL }}>
        {icon}
      </div>
      <div>
        <p className="font-display font-black text-xl text-white leading-none mb-1">
          {number} <span className="font-normal text-base">{unit}</span>
        </p>
        <p className="text-xs leading-relaxed" style={{ color: 'rgba(255,255,255,0.65)' }}>{desc}</p>
      </div>
    </div>
  );
}

// ─── Metro Phase Card ─────────────────────────────────────────────────────────
function MetroPhaseCard({
  phase, dates, intro, boldIntro, metrics,
}: {
  phase: string;
  dates: string;
  intro: string;
  boldIntro: string;
  metrics: { icon: React.ReactNode; bold: string; rest: string }[];
}) {
  return (
    <div className="flex-1 bg-white border p-8" style={{ borderColor: '#D4DCF0' }}>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: NAVY }} />
        <div>
          <p className="text-xs font-bold uppercase tracking-widest" style={{ color: NAVY }}>{phase}</p>
          <p className="text-xs" style={{ color: '#858585' }}>{dates}</p>
        </div>
      </div>
      <p className="text-sm leading-relaxed mb-6" style={{ color: '#4A4A4A' }}>
        <span className="font-bold" style={{ color: NAVY }}>{boldIntro} </span>{intro}
      </p>
      <p className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: TEAL }}>Key Impact Metrics</p>
      <div className="space-y-0 divide-y" style={{ borderColor: '#EEF0F8' }}>
        {metrics.map((m, i) => (
          <div key={i} className="flex items-start gap-3 py-4">
            <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center mt-0.5" style={{ backgroundColor: '#E8EDF8', color: NAVY }}>
              {m.icon}
            </div>
            <div>
              <span className="font-bold text-sm" style={{ color: NAVY }}>{m.bold} </span>
              <span className="text-sm" style={{ color: '#5F5F5F' }}>{m.rest}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Ongoing project stat card ────────────────────────────────────────────────
function OngoingCard({
  icon, bold, rest, full,
}: {
  icon: React.ReactNode; bold: string; rest: string; full?: boolean;
}) {
  return (
    <div
      className={`flex items-start gap-4 p-5 ${full ? 'md:col-span-3' : ''}`}
      style={{ backgroundColor: OLIVE, border: '1px solid rgba(255,255,255,0.12)' }}
    >
      <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center border" style={{ borderColor: 'rgba(255,255,255,0.3)', color: 'rgba(255,255,255,0.85)' }}>
        {icon}
      </div>
      <div>
        <p className="text-sm font-bold text-white mb-0.5">{bold}</p>
        <p className="text-sm" style={{ color: 'rgba(255,255,255,0.7)' }}>{rest}</p>
      </div>
    </div>
  );
}

// ─── Photo Carousel ───────────────────────────────────────────────────────────
const CAROUSEL_IMAGES = [
  { src: 'https://images.pexels.com/photos/802221/pexels-photo-802221.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Project site — waste sorting operations' },
  { src: 'https://images.pexels.com/photos/8728562/pexels-photo-8728562.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Community workers in recovery program' },
  { src: 'https://images.pexels.com/photos/3965545/pexels-photo-3965545.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Textile recovery facility operations' },
  { src: 'https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Plastic waste collection drive' },
  { src: 'https://images.pexels.com/photos/3850512/pexels-photo-3850512.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Recycling plant interior' },
  { src: 'https://images.pexels.com/photos/6615233/pexels-photo-6615233.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Safai Saathi community members' },
];

function PhotoCarousel() {
  const [offset, setOffset] = useState(0);
  const visibleCount = 3;
  const max = CAROUSEL_IMAGES.length - visibleCount;

  const prev = () => setOffset((o) => Math.max(0, o - 1));
  const next = () => setOffset((o) => Math.min(max, o + 1));

  return (
    <div className="relative">
      <div className="overflow-hidden">
        <motion.div
          className="flex"
          animate={{ x: `${-offset * (100 / visibleCount)}%` }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        >
          {CAROUSEL_IMAGES.map((img, i) => (
            <div
              key={i}
              className="flex-shrink-0"
              style={{ width: `calc(${100 / visibleCount}% - 2px)`, marginRight: 2 }}
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Nav arrows */}
      <button
        onClick={prev}
        disabled={offset === 0}
        className="absolute -left-5 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-white border shadow-sm transition-opacity disabled:opacity-30"
        style={{ borderColor: '#E8E8E8' }}
        aria-label="Previous"
      >
        <ChevronLeft size={18} style={{ color: NAVY }} />
      </button>
      <button
        onClick={next}
        disabled={offset >= max}
        className="absolute -right-5 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-white border shadow-sm transition-opacity disabled:opacity-30"
        style={{ borderColor: '#E8E8E8' }}
        aria-label="Next"
      >
        <ChevronRight size={18} style={{ color: NAVY }} />
      </button>
    </div>
  );
}

// ── CMS fallback ──────────────────────────────────────────────────────────────
const FALLBACK: EsgPageSettings = {
  hero_heading: 'Customized Impact Solutions,\nCrafted for Your Brand',
  hero_body: 'ReCircle designs and delivers tailored solutions that align with your vision. Our expertise spans recovery & empowerment programs and more — all backed by transparent reporting and measurable outcomes.\n\nExplore how our team has empowered industry leaders to drive real change through our special projects below.',
  intro_heading: "Tomorrow's Impact Starts Today!",
  intro_body: 'From July 27, 2023, to March 31, 2024, ReCircle partnered with the Alliance to End Plastic Waste (AEPW) on a groundbreaking initiative aimed at transforming how India handles low-value plastics (LVP). The project aimed to divert 3,500 tons of LVP from landfills, thus closing the loop for plastics that are often discarded as unmanageable.',
  projects: [
    { title: 'AEPW X ReCircle: (September 2024 – March 2025)', category: 'ON-GOING', body: 'Divert 4,200 tons of low-value plastic, conduct 64 IEC activities across India, and formalize 250 Safai Saathis.' },
    { title: 'DBS Foundation Business for Impact Grant Award: April 2024 – April 2026', category: 'ON-GOING', body: 'A technology-driven approach to waste management including digital innovation, environmental goals, community upliftment, and social security.' },
  ],
  reporting_heading: 'Ready to create your own impact story?',
  reporting_body: 'Partner with ReCircle to design a customized ESG project that delivers measurable environmental and social outcomes — verified, reported, and built for scale.',
};

// ─────────────────────────────────────────────────────────────────────────────
// MAIN PAGE
// ─────────────────────────────────────────────────────────────────────────────
export default function EsgProjectsPage() {
  const [cms, setCms] = useState<EsgPageSettings>(FALLBACK);

  useEffect(() => {
    getEsgPageSettings().then((d) => {
      if (d) setCms(d);
    });
  }, []);

  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '22%']);

  const aepwRef = useRef<HTMLElement>(null);
  const metroRef = useRef<HTMLElement>(null);
  const carouselRef = useRef<HTMLElement>(null);
  const ongoingRef = useRef<HTMLElement>(null);
  const ctaRef = useRef<HTMLElement>(null);

  const aepwInView = useInView(aepwRef, { once: true, margin: '-60px' });
  const metroInView = useInView(metroRef, { once: true, margin: '-60px' });
  const carouselInView = useInView(carouselRef, { once: true, margin: '-60px' });
  const ongoingInView = useInView(ongoingRef, { once: true, margin: '-60px' });
  const ctaInView = useInView(ctaRef, { once: true, margin: '-60px' });

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Section 1: Hero ───────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-screen flex items-center overflow-hidden">
        <motion.div className="absolute inset-0" style={{ y: bgY }}>
          <img
            src="https://images.pexels.com/photos/8728562/pexels-photo-8728562.jpeg?auto=compress&cs=tinysrgb&w=1800&q=85"
            alt="Workers in waste recovery environment"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(0,0,0,0.82) 0%, rgba(0,0,0,0.55) 55%, rgba(0,0,0,0.15) 100%)' }} />
        </motion.div>

        <div className="container-site relative z-10 section-padding">
          <div className="max-w-xl">
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="inline-flex items-center gap-2 px-3 py-1.5 mb-8 border text-xs font-semibold uppercase tracking-widest"
              style={{ borderColor: 'rgba(220,235,75,0.4)', color: '#DCEB4B', backgroundColor: 'rgba(220,235,75,0.06)' }}
            >
              ESG Projects
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 36 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="font-display font-bold leading-tight mb-6"
              style={{ fontSize: 'clamp(2rem, 5vw, 3.6rem)', letterSpacing: '-0.03em', color: '#DCEB4B', whiteSpace: 'pre-line' }}
            >
              {cms.hero_heading}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-body-lg leading-relaxed mb-10 text-white"
              style={{ color: 'rgba(255,255,255,0.88)', whiteSpace: 'pre-line' }}
            >
              {cms.hero_body}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.32 }}
            >
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-6 py-3 font-medium text-body-sm border transition-all duration-300 hover:bg-white hover:text-charcoal"
                style={{ borderColor: 'white', color: 'white' }}
              >
                Start Your Impact Project Today
                <ArrowRight size={16} />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 2: AEPW Case Study ────────────────────────────────────── */}
      <section ref={aepwRef} className="section-padding" style={{ backgroundColor: '#E8F0ED' }}>
        <div className="container-site">
          {/* Top row: label + logo */}
          <div className="flex items-start justify-between mb-10 flex-wrap gap-6">
            <motion.div initial="hidden" animate={aepwInView ? 'visible' : 'hidden'} variants={fadeUp}>
              <SectionLabel text="RECIRCLE X AEPW" color="#1B6B5A" />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={aepwInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
              transition={{ duration: 0.5 }}
              className="bg-white border px-6 py-4 shadow-sm flex items-center"
              style={{ borderColor: '#D4E4DC' }}
            >
              <span className="font-bold text-sm tracking-tight" style={{ color: NAVY }}>Alliance to End Plastic Waste</span>
            </motion.div>
          </div>

          {/* Heading */}
          <motion.h2
            initial="hidden"
            animate={aepwInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
            className="font-display font-bold mb-6 leading-tight"
            style={{ fontSize: 'clamp(1.6rem, 3.5vw, 2.6rem)', letterSpacing: '-0.025em', color: '#0D1F3C', maxWidth: 700 }}
          >
            Revolutionizing{' '}
            <span style={{ color: TEAL }}>Low-Value Plastic Waste</span>{' '}
            Management
          </motion.h2>

          {/* Body */}
          <motion.p
            initial="hidden"
            animate={aepwInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={2}
            className="text-body-lg leading-relaxed mb-6 max-w-3xl"
            style={{ color: '#3A3A3A' }}
          >
            From July 27, 2023, to March 31, 2024, ReCircle partnered with the Alliance to End Plastic Waste (AEPW) on a groundbreaking initiative aimed at transforming how India handles low-value plastics (LVP). The project aimed to divert{' '}
            <span className="font-bold" style={{ color: TEAL }}>3,500 tons of LVP</span>{' '}
            from landfills, thus closing the loop for plastics that are often discarded as unmanageable.
          </motion.p>

          {/* Callout */}
          <motion.p
            initial="hidden"
            animate={aepwInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={3}
            className="font-bold text-xl mb-8 max-w-3xl leading-snug"
            style={{ color: TEAL }}
          >
            The project exceeded expectations by diverting 3,609 tons of Low-value plastic (LVP) waste.
          </motion.p>

          {/* Stat cards — 3 + 1 full */}
          <motion.div
            initial="hidden"
            animate={aepwInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={4}
            className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6"
          >
            <AepwStatCard icon={<Recycle size={18} />} number="2,838" unit="tons" desc="were sent for co-processing." />
            <AepwStatCard icon={<TrendingUp size={18} />} number="728.57" unit="tons" desc="were recycled, giving new life to low-value plastics." />
            <AepwStatCard icon={<Users size={18} />} number="518" unit="Safai Saathis" desc="were integrated into formal government schemes." />
            <AepwStatCard icon={<BookOpen size={18} />} number="45" unit="IEC" desc="activities on sanitation, healthcare, and plastic waste management training were conducted across multiple cities." full />
          </motion.div>

          {/* Closing italic */}
          <motion.p
            initial="hidden"
            animate={aepwInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={5}
            className="italic text-base font-medium max-w-3xl leading-relaxed"
            style={{ color: TEAL }}
          >
            By blending environmental innovation with community driven empowerment, this project set a new benchmark for low-value plastic waste management in India.
          </motion.p>
        </div>
      </section>

      {/* ── Section 3: Metro Shoes Case Study ────────────────────────────── */}
      <section ref={metroRef} className="section-padding bg-white">
        <div className="container-site">
          {/* Top row */}
          <div className="flex items-start justify-between mb-10 flex-wrap gap-6">
            <motion.div initial="hidden" animate={metroInView ? 'visible' : 'hidden'} variants={fadeUp}>
              <SectionLabel text="RECIRCLE X METRO SHOES" color={NAVY} />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={metroInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
              transition={{ duration: 0.5 }}
              className="bg-white border px-6 py-4 shadow-sm flex items-center gap-2"
              style={{ borderColor: '#E0E0E0' }}
            >
              <div className="w-6 h-6 flex items-center justify-center font-black text-sm" style={{ backgroundColor: '#E7182A', color: 'white' }}>M</div>
              <span className="font-bold text-sm tracking-tight" style={{ color: NAVY }}>METRO</span>
            </motion.div>
          </div>

          {/* Heading */}
          <motion.h2
            initial="hidden"
            animate={metroInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
            className="font-display font-bold mb-6 leading-tight"
            style={{ fontSize: 'clamp(1.6rem, 3.5vw, 2.6rem)', letterSpacing: '-0.025em', color: '#0D1F3C', maxWidth: 680 }}
          >
            Pioneering Circularity in{' '}
            <span className="font-black" style={{ color: NAVY }}>Footwear Recycling</span>
          </motion.h2>

          {/* Body */}
          <motion.p
            initial="hidden"
            animate={metroInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={2}
            className="text-body-lg leading-relaxed mb-10 max-w-3xl"
            style={{ color: '#3A3A3A' }}
          >
            In an industry where end-of-life footwear often means landfill destiny, ReCircle and Metro Shoes dared to imagine different. What began as a bold vision to recover old discarded footwear developed into a holistic two-phase partnership that reclaimed{' '}
            <span className="font-bold" style={{ color: NAVY }}>2,300 tonnes of footwear waste</span>{' '}
            from landfills through strategic collection and processing.
          </motion.p>

          {/* Phase cards */}
          <motion.div
            initial="hidden"
            animate={metroInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={3}
            className="flex flex-col md:flex-row gap-6 mb-8"
          >
            <MetroPhaseCard
              phase="PHASE 1"
              dates="August 2023 – October 2023"
              boldIntro="1,300 tonnes"
              intro="of footwear waste recovered from Ghaziabad and Uttar Pradesh."
              metrics={[
                { icon: <Package size={16} />, bold: '1,300 tons', rest: '— of footwear waste was recovered from the landfills.' },
                { icon: <Recycle size={16} />, bold: '630.88 tons (48.46%),', rest: '— discarded footwear recycled and converted into raw materials for manufacturing.' },
                { icon: <TrendingUp size={16} />, bold: '670.1 tons (51.54%),', rest: '— co-processed as alternative fuel in waste-to-energy facilities.' },
              ]}
            />
            <MetroPhaseCard
              phase="PHASE 2"
              dates="June 2024 – September 2024"
              boldIntro="1,000 tons"
              intro="tackled across Maharashtra, Gujarat, &amp; Tamil Nadu — showcasing the scalability of circular solutions."
              metrics={[
                { icon: <Package size={16} />, bold: '1,000 tons', rest: '— of footwear waste was recovered from the landfills.' },
                { icon: <Recycle size={16} />, bold: '500 tons', rest: '— discarded footwear recycled and converted into raw materials for manufacturing.' },
                { icon: <TrendingUp size={16} />, bold: '500 tons', rest: '— were sent for co-processing, serving as alternative fuel.' },
              ]}
            />
          </motion.div>

          {/* Closing italic */}
          <motion.p
            initial="hidden"
            animate={metroInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={4}
            className="italic text-base font-medium max-w-3xl leading-relaxed"
            style={{ color: NAVY }}
          >
            The entire process was meticulously documented with geotagged images, ensuring accountability and demonstrating the feasibility of large-scale footwear recycling.
          </motion.p>
        </div>
      </section>

      {/* ── Section 4: Photo Carousel ─────────────────────────────────────── */}
      <section ref={carouselRef} className="section-padding" style={{ backgroundColor: '#EDF2F7' }}>
        <div className="container-site">
          <motion.div
            className="mb-10"
            initial="hidden"
            animate={carouselInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="GLIMPSES FROM OUR PROJECTS" color={NAVY} />
          </motion.div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={carouselInView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="px-6"
          >
            <PhotoCarousel />
          </motion.div>
        </div>
      </section>

      {/* ── Section 6: On-Going Projects ─────────────────────────────────── */}
      <section ref={ongoingRef} className="section-padding" style={{ backgroundColor: '#F5F0E8' }}>
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={ongoingInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="mb-12"
          >
            <SectionLabel text="ON-GOING PROJECTS" color={OLIVE} />
            <h2
              className="font-display font-bold leading-tight mb-5"
              style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.8rem)', letterSpacing: '-0.025em', color: '#0D1F3C' }}
            >
              {cms.intro_heading}
            </h2>
            <p className="text-body-lg leading-relaxed max-w-3xl" style={{ color: '#3A3A3A' }}>
              {cms.intro_body}
            </p>
          </motion.div>

          {/* Sub-project 1 */}
          <motion.div
            initial="hidden"
            animate={ongoingInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
            className="mb-10"
          >
            <h3 className="text-base font-bold mb-5" style={{ color: OLIVE }}>
              AEPW X ReCircle: (September 2024 – March 2025)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <OngoingCard icon={<Recycle size={18} />} bold="Divert 4,200 tons" rest="of low-value plastic." />
              <OngoingCard icon={<BookOpen size={18} />} bold="Conduct 64 IEC activities" rest="across India." />
              <OngoingCard icon={<Users size={18} />} bold="Formalize 250 Safai Saathis" rest="by integrating them into Government schemes." />
            </div>
          </motion.div>

          {/* Sub-project 2 */}
          <motion.div
            initial="hidden"
            animate={ongoingInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={2}
          >
            <h3 className="text-base font-bold mb-2" style={{ color: OLIVE }}>
              DBS Foundation Business for Impact Grant Award: April 2024 – April 2026
            </h3>
            <p className="text-sm mb-5" style={{ color: '#4A4A4A' }}>
              A technology-driven approach to waste management that includes.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <OngoingCard icon={<Cpu size={18} />} bold="Digital Innovation:" rest="Enhancing our ClimaOne platform for improved tracking." />
              <OngoingCard icon={<Leaf size={18} />} bold="Environmental Goals:" rest="400 tons plastic waste diversion." />
              <OngoingCard icon={<BookOpen size={18} />} bold="Community upliftment:" rest="4 strategic IEC activities." />
              <OngoingCard icon={<ShieldCheck size={18} />} bold="Social Security:" rest="100 Safai Saathis to be formalized." />
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Section 7: Contact CTA ────────────────────────────────────────── */}
      <section ref={ctaRef} className="section-padding relative overflow-hidden" style={{ backgroundColor: '#0D1F3C' }}>
        <div className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(ellipse at 60% 50%, rgba(0,196,153,0.06) 0%, transparent 70%)' }} />
        <div className="container-site relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
            <motion.div
              initial="hidden"
              animate={ctaInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              className="max-w-xl"
            >
              <SectionLabel text="CONTACT US" color={TEAL} />
              <h2
                className="font-display font-bold text-white mb-5 leading-tight"
                style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.8rem)', letterSpacing: '-0.025em' }}
              >
                {cms.reporting_heading}
              </h2>
              <p className="text-body-lg leading-relaxed mb-0" style={{ color: 'rgba(255,255,255,0.65)' }}>
                {cms.reporting_body}
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={ctaInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 30 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="flex flex-col items-start lg:items-end gap-4 shrink-0"
            >
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-8 py-4 font-semibold text-sm transition-all duration-300 hover:opacity-90"
                style={{ backgroundColor: TEAL, color: '#0D1F3C' }}
              >
                Start Your Impact Project Today
                <ArrowRight size={16} />
              </Link>
              <div className="flex gap-6">
                {['Transparent Reporting', 'Measurable Outcomes', 'Pan-India Reach'].map((sig) => (
                  <span key={sig} className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.4)' }}>{sig}</span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

    </main>
  );
}
