import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Play, ExternalLink, Youtube } from 'lucide-react';
import { getWebinarsPageSettings, getWebinarItems } from '../../cms/queries';
import type { WebinarsPageSettings, WebinarItem } from '../../cms/types';

// YOUTUBE_API_KEY: Insert the YouTube Data API v3 key as VITE_YOUTUBE_API_KEY in the .env file.
// The key is used in auto-fetch mode to pull videos from the configured channel or playlist.
// In manual mode, entries are managed directly from the Webinars admin panel.

function formatDate(dateStr: string | null): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const day = String(d.getDate()).padStart(2, '0');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${day}-${months[d.getMonth()]}-${d.getFullYear()}`;
}

interface YoutubeVideo {
  id: string;
  title: string;
  thumbnail: string;
  publishedAt: string;
  url: string;
}

async function fetchYoutubeVideos(sourceId: string, sourceType: string): Promise<YoutubeVideo[]> {
  const apiKey = import.meta.env.VITE_YOUTUBE_API_KEY as string;
  if (!apiKey || !sourceId) return [];
  try {
    let url = '';
    if (sourceType === 'playlist') {
      url = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId=${sourceId}&key=${apiKey}`;
    } else {
      const chanRes = await fetch(`https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=${sourceId}&key=${apiKey}`);
      const chanData = await chanRes.json();
      const uploadPlaylistId = chanData.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
      if (!uploadPlaylistId) return [];
      url = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId=${uploadPlaylistId}&key=${apiKey}`;
    }
    const res = await fetch(url);
    const data = await res.json();
    return (data.items ?? []).map((item: { snippet: { title: string; publishedAt: string; resourceId?: { videoId: string }; videoOwnerChannelId?: string; thumbnails: { high?: { url: string }; medium?: { url: string } } } }) => {
      const videoId = item.snippet.resourceId?.videoId ?? '';
      return {
        id: videoId,
        title: item.snippet.title,
        thumbnail: item.snippet.thumbnails?.high?.url ?? item.snippet.thumbnails?.medium?.url ?? '',
        publishedAt: item.snippet.publishedAt,
        url: `https://www.youtube.com/watch?v=${videoId}`,
      };
    });
  } catch {
    return [];
  }
}

interface WebinarCardProps { title: string; thumbnail: string; date: string; url: string; description?: string; index: number; }
function WebinarCard({ title, thumbnail, date, url, description, index }: WebinarCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.5, delay: (index % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className="group bg-white border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col"
    >
      <div className="relative overflow-hidden aspect-video">
        {thumbnail ? (
          <img src={thumbnail} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
        ) : (
          <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: '#E8EDF8' }}>
            <Youtube size={40} style={{ color: '#01298A' }} />
          </div>
        )}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{ backgroundColor: 'rgba(1,41,138,0.7)' }}>
          <Play size={40} fill="white" color="white" />
        </div>
      </div>
      <div className="p-5 flex flex-col flex-1">
        <p className="text-xs mb-2" style={{ color: '#ABABAB' }}>{date}</p>
        <h3 className="font-bold text-sm leading-snug mb-2 line-clamp-2 flex-1" style={{ color: '#1A1A1A' }}>{title}</h3>
        {description && <p className="text-xs leading-relaxed mb-3 line-clamp-2" style={{ color: '#858585' }}>{description}</p>}
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 text-sm font-semibold mt-auto transition-colors hover:underline"
          style={{ color: '#01298A' }}
        >
          Watch Now <ExternalLink size={12} />
        </a>
      </div>
    </motion.div>
  );
}

export default function WebinarsPage() {
  const [settings, setSettings] = useState<WebinarsPageSettings | null>(null);
  const [manualItems, setManualItems] = useState<WebinarItem[]>([]);
  const [autoVideos, setAutoVideos] = useState<YoutubeVideo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getWebinarsPageSettings(), getWebinarItems()]).then(async ([s, items]) => {
      setSettings(s);
      setManualItems(items);
      if (s?.entry_mode === 'auto' && s.youtube_source_id) {
        const videos = await fetchYoutubeVideos(s.youtube_source_id, s.source_type);
        setAutoVideos(videos);
      }
      setLoading(false);
    });
  }, []);

  const isAuto = settings?.entry_mode === 'auto';
  const hasAutoVideos = isAuto && autoVideos.length > 0;
  const displayItems = hasAutoVideos ? autoVideos : manualItems;

  return (
    <main className="pt-20">
      {/* Header */}
      <section className="section-padding bg-ivory border-b" style={{ borderColor: '#E8E8E8' }}>
        <div className="container-site">
          <motion.p
            className="text-xs font-semibold uppercase tracking-widest mb-3"
            style={{ color: '#01298A' }}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Knowledge Centre
          </motion.p>
          <motion.h1
            className="font-display text-display-sm font-bold mb-4"
            style={{ color: '#1A1A1A' }}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            {settings?.page_heading ?? 'Webinars'}
          </motion.h1>
          <motion.p
            className="text-body-lg max-w-2xl"
            style={{ color: '#5F5F5F' }}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {settings?.page_intro ?? 'Watch our latest webinars and panel discussions on circular economy, EPR, and sustainability.'}
          </motion.p>
        </div>
      </section>

      {/* Grid */}
      <section className="section-padding bg-ivory">
        <div className="container-site">
          {loading ? (
            <div className="flex items-center justify-center py-24">
              <div className="w-8 h-8 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
            </div>
          ) : displayItems.length === 0 ? (
            <div className="text-center py-24 border border-dashed" style={{ borderColor: '#D1D1D1' }}>
              <Youtube size={40} className="mx-auto mb-4" style={{ color: '#D1D1D1' }} />
              <p className="text-lg font-semibold mb-2" style={{ color: '#1A1A1A' }}>No webinars yet</p>
              <p className="text-sm" style={{ color: '#858585' }}>Check back soon for upcoming sessions.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {hasAutoVideos
                ? (autoVideos as YoutubeVideo[]).map((v, i) => (
                    <WebinarCard key={v.id} title={v.title} thumbnail={v.thumbnail} date={formatDate(v.publishedAt)} url={v.url} index={i} />
                  ))
                : (manualItems as WebinarItem[]).map((item, i) => (
                    <WebinarCard
                      key={item.id}
                      title={item.title}
                      thumbnail={item.thumbnail_url}
                      date={formatDate(item.publish_date)}
                      url={item.youtube_url}
                      description={item.description}
                      index={i}
                    />
                  ))}
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
