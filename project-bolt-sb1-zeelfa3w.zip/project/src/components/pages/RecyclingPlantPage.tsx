import { useRef, useState, useEffect } from 'react';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import {
  MapPin, ArrowRight, CheckCircle, Factory,
  Zap, BarChart2, ShieldCheck, Recycle, Cpu, Clock,
} from 'lucide-react';
import { getRecyclingPlantPageSettings } from '../../cms/queries';
import type { RecyclingPlantPageSettings } from '../../cms/queries';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

function SectionLabel({ text, light }: { text: string; light?: boolean }) {
  return (
    <p className="text-caption font-semibold uppercase tracking-[0.15em] mb-4" style={{ color: light ? '#DCEB4B' : '#00C499' }}>
      {text}
    </p>
  );
}

const BHIWANI_HIGHLIGHTS = [
  { icon: <Factory size={18} />, label: 'Capacity', value: '5,000 MT / Year' },
  { icon: <Recycle size={18} />, label: 'Process', value: 'rPET Flakes Manufacturing' },
  { icon: <ShieldCheck size={18} />, label: 'Input', value: '100% Post-Consumer PET' },
  { icon: <Zap size={18} />, label: 'Output', value: 'Food-Grade Safe rPET Flakes' },
  { icon: <Cpu size={18} />, label: 'Traceability', value: 'ClimaOne Powered' },
  { icon: <ShieldCheck size={18} />, label: 'Compliance', value: 'BIS & CPCB Standards' },
];

const BHIWANI_FEATURES = [
  'rPET Flakes Manufacturing',
  '100% Post-Consumer PET Recycling',
  'Food-Grade Safe Recycled Plastic Flakes',
  'PET Waste Processing & Recycling',
  'Advanced Washing & Material Recovery Infrastructure',
  'Traceable Recycling Operations Powered by ClimaOne',
  'BIS & CPCB Compliant Processing Systems',
  'Circular Raw Material Production',
];

const HISAR_UPCOMING = [
  'Expanded rPET Flakes Production Capacity',
  'Advanced PET Recycling Infrastructure',
  'Food-Grade Safe rPET Processing Systems',
  'Strengthened Circular Supply Chains',
  'Scalable Recovery & Processing Operations',
  'Enhanced Traceability & Compliance Monitoring',
];

const FALLBACK: RecyclingPlantPageSettings = {
  hero_label: 'Recycling Plant',
  hero_heading: 'Closing the Loop on Plastic',
  hero_body: "ReCircle's recycling plant converts post-consumer PET bottles and plastic waste into food-grade rPET flakes.",
  stat_1_value: '5,000 MT',
  stat_1_label: 'annual rPET flakes production capacity',
  stat_2_value: '99.9%',
  stat_2_label: 'purity of food-grade rPET output',
  overview_heading: 'From Collected Bottles to rPET Flakes',
  overview_body: 'The plant processes washed and sorted PET bottles into high-quality recycled PET flakes.',
  process_heading: 'The Recycling Process',
  process_steps: [
    { step: '01', title: 'Feedstock Intake', body: 'Sorted PET bottles arrive from the MRF and are weighed and logged.' },
    { step: '02', title: 'Pre-Washing', body: 'Bottles are pre-washed to remove surface contaminants and labels.' },
    { step: '03', title: 'Shredding', body: 'Clean bottles are shredded into coarse flakes for further processing.' },
    { step: '04', title: 'Hot Washing', body: 'Flakes undergo hot caustic washing to remove adhesives and residues.' },
    { step: '05', title: 'Drying & Sorting', body: 'Flakes are dried and optically sorted to remove non-PET materials.' },
    { step: '06', title: 'Quality Control', body: 'Final flakes are tested for food-grade compliance before dispatch.' },
  ],
  certifications: [
    { name: 'GRS — Global Recycled Standard' },
    { name: 'FSSAI Compliant — Food-Grade' },
    { name: 'ISO 9001:2015' },
  ],
};

const CERT_LOGO_MAP = [
  {
    name: 'GRS — Global Recycled Standard',
    subtitle: 'Recycled content certified',
    logo: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=400&q=85',
  },
  {
    name: 'FSSAI Compliant',
    subtitle: 'Food-grade safe',
    logo: 'https://images.pexels.com/photos/5726837/pexels-photo-5726837.jpeg?auto=compress&cs=tinysrgb&w=400&q=85',
  },
  {
    name: 'ISO 9001:2015',
    subtitle: 'Quality management system',
    logo: 'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=400&q=85',
  },
];

export default function RecyclingPlantPage() {
  const [cms, setCms] = useState<RecyclingPlantPageSettings>(FALLBACK);

  useEffect(() => {
    getRecyclingPlantPageSettings().then((data) => {
      if (data) setCms(data);
    });
  }, []);

  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);

  const overviewRef = useRef<HTMLElement>(null);
  const bhiwaniRef = useRef<HTMLElement>(null);
  const hisarRef = useRef<HTMLElement>(null);
  const aboutRef = useRef<HTMLElement>(null);

  const overviewInView = useInView(overviewRef, { once: true, margin: '-60px' });
  const bhiwaniInView = useInView(bhiwaniRef, { once: true, margin: '-60px' });
  const hisarInView = useInView(hisarRef, { once: true, margin: '-60px' });
  const aboutInView = useInView(aboutRef, { once: true, margin: '-60px' });

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[70vh] flex items-end overflow-hidden">
        <motion.div className="absolute inset-0" style={{ y: bgY }}>
          <img
            src="https://images.pexels.com/photos/3850512/pexels-photo-3850512.jpeg?auto=compress&cs=tinysrgb&w=1600&q=85"
            alt="Recycling Plant Operations"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(1,41,138,0.95) 0%, rgba(1,41,138,0.6) 45%, rgba(1,41,138,0.1) 100%)' }} />
        </motion.div>

        <div className="container-site relative z-10 pb-16 pt-40">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 mb-6 border text-xs font-semibold uppercase tracking-widest"
            style={{ borderColor: 'rgba(220,235,75,0.5)', color: '#DCEB4B', backgroundColor: 'rgba(220,235,75,0.08)' }}
          >
            {cms.hero_label}
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white mb-2 leading-tight"
            style={{ fontSize: 'clamp(2.2rem, 5vw, 3.8rem)', letterSpacing: '-0.03em', maxWidth: 700 }}
          >
            {cms.hero_heading}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.18 }}
            className="text-lg font-medium mb-5"
            style={{ color: '#DCEB4B' }}
          >
            rPET Flakes Manufacturing &amp; Recycling Operations
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.22 }}
            className="text-body-lg max-w-2xl leading-relaxed"
            style={{ color: 'rgba(255,255,255,0.75)' }}
          >
            {cms.hero_body}
          </motion.p>
        </div>
      </section>

      {/* ── Stats strip ──────────────────────────────────────────────────── */}
      <div style={{ backgroundColor: '#0A1F5A' }}>
        <div className="container-site">
          <div className="grid grid-cols-2 md:grid-cols-4 divide-x" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            {[
              { value: cms.stat_1_value, label: cms.stat_1_label },
              { value: cms.stat_2_value, label: cms.stat_2_label },
              { value: 'ClimaOne', label: 'Powered traceability' },
              { value: 'BIS & CPCB', label: 'Compliant operations' },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="text-center py-7 px-4"
              >
                <p className="font-display font-black text-2xl mb-1" style={{ color: '#DCEB4B', letterSpacing: '-0.025em' }}>{stat.value}</p>
                <p className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Overview ─────────────────────────────────────────────────────── */}
      <section ref={overviewRef} className="section-padding bg-ivory">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-16 items-start">
            <motion.div
              className="flex-1 max-w-xl"
              initial="hidden"
              animate={overviewInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="OVERVIEW" />
              <h2 className="font-display text-display-sm font-bold mb-6 leading-tight" style={{ color: '#1A1A1A' }}>
                {cms.overview_heading}
              </h2>
              <div className="space-y-4">
                <motion.p
                  initial="hidden"
                  animate={overviewInView ? 'visible' : 'hidden'}
                  variants={fadeUp}
                  custom={1}
                  className="text-body-lg leading-relaxed"
                  style={{ color: '#5F5F5F' }}
                >
                  {cms.overview_body}
                </motion.p>
              </div>
            </motion.div>

            {/* Right — key differentiators */}
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { icon: <ShieldCheck size={20} />, title: 'Food-Grade Safe', desc: 'Tested and certified for food-contact applications per EU and BIS standards.' },
                { icon: <BarChart2 size={20} />, title: 'Consistent Quality', desc: 'Tight process controls ensure batch-to-batch uniformity across all specs.' },
                { icon: <Cpu size={20} />, title: 'Full Traceability', desc: 'ClimaOne tracks every batch from collection to final rPET output in real time.' },
                { icon: <Recycle size={20} />, title: 'Circular by Design', desc: '100% post-consumer input. Every flake is a step toward a closed-loop system.' },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  initial="hidden"
                  animate={overviewInView ? 'visible' : 'hidden'}
                  variants={fadeUp}
                  custom={i + 1}
                  className="p-6 bg-white border"
                  style={{ borderColor: '#E8E8E8' }}
                  whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.08)', y: -3 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="w-10 h-10 flex items-center justify-center mb-4" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                    {item.icon}
                  </div>
                  <h3 className="text-sm font-bold mb-2" style={{ color: '#1A1A1A' }}>{item.title}</h3>
                  <p className="text-xs leading-relaxed" style={{ color: '#858585' }}>{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Process Steps ─────────────────────────────────────────────────── */}
      {cms.process_steps && cms.process_steps.length > 0 && (
        <section className="section-padding bg-white overflow-hidden">
          <div className="container-site">
            <div className="mb-14 text-center">
              <SectionLabel text="HOW IT WORKS" />
              <h2 className="font-display text-display-sm font-bold leading-tight" style={{ color: '#1A1A1A' }}>
                {cms.process_heading}
              </h2>
            </div>

            {/* Desktop — horizontal timeline */}
            <div className="hidden lg:block">
              <div className="relative">
                {/* Connecting line */}
                <div
                  className="absolute top-[2.25rem] left-0 right-0 h-px"
                  style={{ background: 'linear-gradient(to right, transparent, #01298A 8%, #01298A 92%, transparent)' }}
                />
                <div className="grid grid-cols-6 gap-0">
                  {cms.process_steps.map((s, i) => (
                    <motion.div
                      key={s.step}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-40px' }}
                      transition={{ duration: 0.5, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                      className="flex flex-col items-center text-center px-3"
                    >
                      {/* Node */}
                      <div
                        className="relative z-10 w-[4.5rem] h-[4.5rem] flex items-center justify-center font-display font-black text-sm mb-5 shrink-0"
                        style={{ backgroundColor: '#01298A', color: '#DCEB4B', letterSpacing: '-0.02em' }}
                      >
                        {s.step}
                      </div>
                      <h3 className="text-xs font-bold mb-2 leading-snug" style={{ color: '#1A1A1A' }}>{s.title}</h3>
                      <p className="text-xs leading-relaxed" style={{ color: '#858585' }}>{s.body}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>

            {/* Mobile — vertical timeline */}
            <div className="lg:hidden space-y-0">
              {cms.process_steps.map((s, i) => (
                <motion.div
                  key={s.step}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-30px' }}
                  transition={{ duration: 0.45, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
                  className="flex gap-5"
                >
                  {/* Left — node + line */}
                  <div className="flex flex-col items-center">
                    <div
                      className="w-12 h-12 flex items-center justify-center font-display font-black text-xs shrink-0"
                      style={{ backgroundColor: '#01298A', color: '#DCEB4B' }}
                    >
                      {s.step}
                    </div>
                    {i < cms.process_steps.length - 1 && (
                      <div className="w-px flex-1 my-1" style={{ backgroundColor: '#E8E8E8', minHeight: 32 }} />
                    )}
                  </div>
                  {/* Right — content */}
                  <div className="pb-8 pt-2 flex-1">
                    <h3 className="text-sm font-bold mb-1.5" style={{ color: '#1A1A1A' }}>{s.title}</h3>
                    <p className="text-xs leading-relaxed" style={{ color: '#858585' }}>{s.body}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── Certifications ────────────────────────────────────────────────── */}
      {cms.certifications && cms.certifications.length > 0 && (
        <section className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
          <div className="container-site">
            <div className="mb-10">
              <SectionLabel text="CERTIFICATIONS & COMPLIANCE" />
              <h2 className="font-display text-display-sm font-bold leading-tight" style={{ color: '#1A1A1A' }}>
                Standards we operate by.
              </h2>
            </div>
            <div className="flex flex-wrap gap-6">
              {CERT_LOGO_MAP.map((cert, i) => (
                <motion.div
                  key={cert.name}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-30px' }}
                  transition={{ duration: 0.45, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                  className="bg-white border flex flex-col items-center justify-center gap-4 p-8 min-w-[200px] flex-1"
                  style={{ borderColor: '#E8E8E8' }}
                  whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.08)', borderColor: '#01298A' }}
                >
                  <img
                    src={cert.logo}
                    alt={cert.name}
                    className="h-16 w-auto object-contain grayscale hover:grayscale-0 transition-all duration-300"
                  />
                  <div className="text-center">
                    <p className="text-xs font-bold" style={{ color: '#1A1A1A' }}>{cert.name}</p>
                    {cert.subtitle && <p className="text-xs mt-0.5" style={{ color: '#858585' }}>{cert.subtitle}</p>}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── Bhiwani Plant ─────────────────────────────────────────────────── */}
      <section ref={bhiwaniRef} className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          {/* Header */}
          <motion.div
            className="mb-12"
            initial="hidden"
            animate={bhiwaniInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <div className="flex items-center gap-3 mb-4">
              <SectionLabel text="BHIWANI RECYCLING PLANT" light />
              <span className="px-2 py-0.5 text-xs font-bold uppercase tracking-widest" style={{ backgroundColor: 'rgba(0,196,153,0.15)', color: '#00C499' }}>
                Operational
              </span>
            </div>
            <h2 className="font-display text-display-sm font-bold text-white mb-4 leading-tight">
              Our flagship rPET recycling facility.
            </h2>
            <p className="text-body-lg max-w-2xl" style={{ color: 'rgba(255,255,255,0.65)' }}>
              The Bhiwani Recycling Plant is currently operational and specializes in the recycling of PET plastic waste into rPET flakes through integrated washing, sorting, and processing systems.
            </p>
          </motion.div>

          <div className="flex flex-col lg:flex-row gap-12">
            {/* Left — capacity highlights */}
            <div className="flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {BHIWANI_HIGHLIGHTS.map((h, i) => (
                  <motion.div
                    key={h.label}
                    initial="hidden"
                    animate={bhiwaniInView ? 'visible' : 'hidden'}
                    variants={fadeUp}
                    custom={i}
                    className="p-5 flex items-center gap-4"
                    style={{ backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                  >
                    <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,196,153,0.12)', color: '#00C499' }}>
                      {h.icon}
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider mb-0.5" style={{ color: 'rgba(255,255,255,0.3)' }}>{h.label}</p>
                      <p className="text-sm font-bold text-white">{h.value}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Right — features checklist */}
            <div className="flex-1">
              <motion.div
                initial="hidden"
                animate={bhiwaniInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={3}
                className="p-8"
                style={{ backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
              >
                <p className="text-caption font-semibold uppercase tracking-widest mb-5" style={{ color: '#DCEB4B' }}>Plant Highlights</p>
                <ul className="space-y-3">
                  {BHIWANI_FEATURES.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm" style={{ color: 'rgba(255,255,255,0.7)' }}>
                      <CheckCircle size={14} className="mt-0.5 shrink-0" style={{ color: '#00C499' }} />
                      {f}
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>
          </div>

          {/* Bhiwani map */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={bhiwaniInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-12"
          >
            <div className="flex items-center gap-3 mb-4">
              <MapPin size={14} style={{ color: '#00C499' }} />
              <span className="text-sm font-medium" style={{ color: 'rgba(255,255,255,0.6)' }}>Bhiwani Recycling Plant, Haryana</span>
            </div>
            <div className="w-full overflow-hidden border" style={{ borderColor: 'rgba(255,255,255,0.1)', height: 420 }}>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3500.0!2d75.7127!3d28.7908!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3912b6ba6b9c1e2b%3A0x4f7d9e8c2a1b3d5e!2sBhiwani%2C%20Haryana!5e0!3m2!1sen!2sin!4v1716000000002!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Bhiwani Recycling Plant Location"
              />
            </div>
            <a
              href="https://maps.app.goo.gl/pqVAHAWEK6sF7bKHA"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 mt-4 px-5 py-2.5 text-sm font-medium transition-opacity hover:opacity-90"
              style={{ backgroundColor: '#00C499', color: '#1A1A1A' }}
            >
              <MapPin size={14} />
              Open in Google Maps
              <ArrowRight size={14} />
            </a>
          </motion.div>
        </div>
      </section>

      {/* ── Hisar Plant ───────────────────────────────────────────────────── */}
      <section ref={hisarRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            className="mb-10"
            initial="hidden"
            animate={hisarInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <div className="flex items-center gap-3 mb-4">
              <SectionLabel text="HISAR RECYCLING PLANT" />
              <span className="px-2 py-0.5 text-xs font-bold uppercase tracking-widest" style={{ backgroundColor: 'rgba(220,235,75,0.2)', color: '#5F5F5F', border: '1px solid #E8E8E8' }}>
                Coming Soon
              </span>
            </div>
            <h2 className="font-display text-display-sm font-bold mb-4 leading-tight" style={{ color: '#1A1A1A' }}>
              Expanding our recycling capacity.
            </h2>
            <p className="text-body-lg max-w-2xl" style={{ color: '#5F5F5F' }}>
              ReCircle's second recycling plant in Hisar is currently under development and is expected to become operational in the coming months. The facility is being established to further strengthen rPET flakes manufacturing capabilities and expand PET recycling capacity across material streams.
            </p>
          </motion.div>

          <div className="flex flex-col lg:flex-row gap-10">
            <div className="flex-1">
              <motion.div
                initial="hidden"
                animate={hisarInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={1}
                className="p-8 bg-white border"
                style={{ borderColor: '#E8E8E8' }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 flex items-center justify-center" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                    <Clock size={18} />
                  </div>
                  <div>
                    <p className="text-sm font-bold" style={{ color: '#1A1A1A' }}>Upcoming Capabilities</p>
                    <p className="text-xs" style={{ color: '#858585' }}>Expected to be operational soon</p>
                  </div>
                </div>
                <ul className="space-y-3">
                  {HISAR_UPCOMING.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm" style={{ color: '#5F5F5F' }}>
                      <CheckCircle size={14} className="mt-0.5 shrink-0" style={{ color: '#00C499' }} />
                      {f}
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>

            <div className="flex-1">
              <motion.div
                initial="hidden"
                animate={hisarInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={2}
                className="mb-4"
              >
                <div className="flex items-center gap-2 mb-3 text-sm" style={{ color: '#5F5F5F' }}>
                  <MapPin size={14} style={{ color: '#01298A' }} />
                  Hisar, Haryana
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={hisarInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="w-full overflow-hidden border"
                style={{ borderColor: '#E8E8E8', height: 380 }}
              >
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3500.0!2d75.7217!3d29.1509!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391234abcdef0000%3A0x1234567890abcdef!2sHisar%2C%20Haryana!5e0!3m2!1sen!2sin!4v1716000000003!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Hisar Recycling Plant Location"
                />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* ── About Operations ─────────────────────────────────────────────── */}
      <section ref={aboutRef} className="section-padding" style={{ backgroundColor: '#01298A' }}>
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <motion.div
              className="flex-1 max-w-xl"
              initial="hidden"
              animate={aboutInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="ABOUT OUR OPERATIONS" light />
              <h2 className="font-display text-display-sm font-bold text-white mb-6 leading-tight">
                Recycling built for the circular economy.
              </h2>
              <p className="text-body-lg leading-relaxed" style={{ color: 'rgba(255,255,255,0.72)' }}>
                ReCircle's recycling plants are designed to strengthen circular economy systems by converting recovered PET waste into high-quality rPET flakes for reuse across industries. With fully traceable operations powered by ClimaOne, the facilities ensure transparency from waste collection to final processing while supporting responsible recycling practices aligned with BIS & CPCB standards across India.
              </p>
            </motion.div>

            {/* Right — three pillars */}
            <div className="flex-1 grid grid-cols-1 gap-4">
              {[
                { icon: <Recycle size={20} />, title: 'Post-Consumer Input', body: 'Every batch starts with 100% post-consumer PET — bottles collected through our nationwide recovery network.' },
                { icon: <Cpu size={20} />, title: 'ClimaOne Traceability', body: 'Real-time data from collection to processing. Every unit tracked, every batch verified, every audit defensible.' },
                { icon: <ShieldCheck size={20} />, title: 'BIS & CPCB Compliance', body: 'Operations aligned with Indian standards for plastic recycling, ensuring regulatory readiness across all output.' },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  initial="hidden"
                  animate={aboutInView ? 'visible' : 'hidden'}
                  variants={fadeUp}
                  custom={i}
                  className="flex items-start gap-4 p-6"
                  style={{ backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                >
                  <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(220,235,75,0.15)', color: '#DCEB4B' }}>
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white mb-2">{item.title}</h3>
                    <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.6)' }}>{item.body}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

    </main>
  );
}
