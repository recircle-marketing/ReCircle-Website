import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, Building2, Users, Heart } from 'lucide-react';
import { getPctwPageSettings } from '../../cms/queries';
import type { PctwPageSettings } from '../../cms/types';

const NAVY = '#01298A';
const TEAL = '#00C499';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

function SectionLabel({ text, center, light }: { text: string; center?: boolean; light?: boolean }) {
  return (
    <p
      className={`text-caption font-semibold uppercase tracking-[0.15em] mb-4 ${center ? 'text-center' : ''}`}
      style={{ color: light ? 'rgba(0,196,153,0.9)' : TEAL }}
    >
      {text}
    </p>
  );
}

// ── Icon lookup map ───────────────────────────────────────────────────────────
const iconMap: Record<string, React.ElementType> = { Building2, Users, Heart };

// ── Partner dummy logos ───────────────────────────────────────────────────────
const PARTNER_LOGOS = [
  'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/1181533/pexels-photo-1181533.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3182773/pexels-photo-3182773.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
];

// ── Commitment cards (hardcoded — not in CMS spec) ────────────────────────────
const commitments = [
  { num: '01', verb: 'Collect', detail: 'Post-consumer fabric from Waghris, integrated into formal operations.' },
  { num: '02', verb: 'Create', detail: 'Predictable incomes and stable livelihoods for community families.' },
  { num: '03', verb: 'Conduct', detail: 'Awareness programmes, skill-building, and community leadership.' },
  { num: '04', verb: 'Champion', detail: 'Safer conditions and integration into formal government schemes.' },
];

// ── Number accent colours ─────────────────────────────────────────────────────
const NUM_COLORS = ['#DCEB4B', TEAL, '#F97316', '#EC4899'];

// ── CMS fallback ──────────────────────────────────────────────────────────────
const FALLBACK: PctwPageSettings = {
  hero_heading: 'End-to-End Post-Consumer Textile Waste Management',
  hero_subheading: 'From the hands of consumers back into the supply chain.',
  channels: [
    { title: 'Institutions', icon: 'Building2', desc: 'Schools, offices, hotels, and NGOs donate discarded materials through scheduled collection drives.' },
    { title: 'Households via Volunteers', icon: 'Users', desc: 'Clothes are collected directly from households by trained volunteers.' },
    { title: 'Waghri Community', icon: 'Heart', desc: 'Waghris collect old garments from households through a barter system — a practice carried across generations.' },
  ],
  stats: [
    { value: '50,000+', label: 'Garments collected' },
    { value: '120 MT+', label: 'Textile waste processed' },
    { value: '30+', label: 'Institutions served' },
  ],
  institutions: [
    { name: 'Taj Project Mumbai' },
    { name: 'Oberoi International School' },
    { name: 'Symbiosis University' },
    { name: 'And more...' },
  ],
  community_heading: 'The Hands Behind Recovery',
  community_body_1: 'The Waghri community and Safai Saathis are at the heart of post-consumer collection and sorting. For generations, they have practiced circularity long before it had a name — moving through neighbourhoods, gathering what others discard, and returning it to productive use.',
  community_body_2: 'ReCircle integrates these communities into formal recovery operations, building on their existing expertise while providing structure, fair compensation, and social recognition for work that has always mattered.',
};

// ─────────────────────────────────────────────────────────────────────────────
// MAIN PAGE
// ─────────────────────────────────────────────────────────────────────────────
export default function PctwPage() {
  const [cms, setCms] = useState<PctwPageSettings>(FALLBACK);

  useEffect(() => {
    getPctwPageSettings().then((d) => {
      if (d) setCms(d);
    });
  }, []);

  // Hero parallax
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress: heroScroll } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroBgY = useTransform(heroScroll, [0, 1], ['0%', '20%']);

  const collectionRef = useRef(null);
  const partnersRef = useRef(null);
  const communityRef = useRef(null);
  const bannerRef = useRef(null);

  const collectionInView = useInView(collectionRef, { once: true, margin: '-80px' });
  const partnersInView = useInView(partnersRef, { once: true, margin: '-80px' });
  const communityInView = useInView(communityRef, { once: true, margin: '-80px' });
  const bannerInView = useInView(bannerRef, { once: true, margin: '-80px' });

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── SECTION 1: HERO ── */}
      <section ref={heroRef} className="relative min-h-[80vh] flex items-end overflow-hidden">
        {/* Background with parallax */}
        <motion.div
          className="absolute inset-0 bg-center bg-cover"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/6192337/pexels-photo-6192337.jpeg?auto=compress&cs=tinysrgb&w=1800&q=85)',
            y: heroBgY,
            scale: 1.08,
          }}
        />
        {/* Gradient overlay */}
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, rgba(1,25,70,0.97) 0%, rgba(1,25,70,0.72) 50%, rgba(1,25,70,0.2) 100%)' }}
        />

        <div className="relative z-10 container-site w-full pb-16 pt-32">
          <div className="max-w-2xl">
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
            >
              <SectionLabel text="POST-CONSUMER" light />
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="font-display font-bold text-white leading-tight mb-5"
              style={{ fontSize: 'clamp(2.2rem, 4.5vw, 3.6rem)', letterSpacing: '-0.03em' }}
            >
              {cms.hero_heading}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.2 }}
              className="text-body-lg"
              style={{ color: 'rgba(255,255,255,0.7)' }}
            >
              {cms.hero_subheading}
            </motion.p>
          </div>
        </div>
      </section>

      {/* ── SECTION 2: HOW COLLECTION WORKS ── */}
      <section ref={collectionRef} className="section-padding" style={{ background: '#ffffff' }}>
        <div className="container-site">

          <motion.div
            initial="hidden"
            animate={collectionInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={0}
          >
            <SectionLabel text="COLLECTION CHANNELS" />
            <h2
              className="font-display font-bold mb-3"
              style={{ color: NAVY, fontSize: 'clamp(1.6rem, 3vw, 2.4rem)', lineHeight: 1.15, letterSpacing: '-0.025em' }}
            >
              How Collection Works
            </h2>
            <p className="text-body-lg mb-12" style={{ color: '#6B7280', maxWidth: '560px' }}>
              Post-consumer textile waste reaches ReCircle through three channels.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {cms.channels.map((channel, i) => {
              const Icon = iconMap[channel.icon] ?? Building2;
              return (
                <motion.div
                  key={channel.title}
                  initial="hidden"
                  animate={collectionInView ? 'visible' : 'hidden'}
                  variants={fadeUp}
                  custom={i + 1}
                >
                  <div
                    className="w-10 h-10 flex items-center justify-center mb-4"
                    style={{ background: '#E8EDF8', color: NAVY, borderRadius: '6px' }}
                  >
                    <Icon size={20} />
                  </div>
                  <h3 className="font-bold text-lg mb-2" style={{ color: NAVY }}>
                    {channel.title}
                  </h3>
                  <p className="text-sm leading-relaxed" style={{ color: '#6B7280' }}>
                    {channel.desc}
                  </p>
                </motion.div>
              );
            })}
          </div>

        </div>
      </section>

      {/* ── SECTION 3: PARTNERS AND INSTITUTIONS ── */}
      <section ref={partnersRef} className="section-padding" style={{ background: '#F9F9F7' }}>
        <div className="container-site">

          <motion.div
            initial="hidden"
            animate={partnersInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={0}
            className="text-center mb-4"
          >
            <SectionLabel text="OUR PARTNERS" center />
            <h2
              className="font-display font-bold mb-3"
              style={{ color: NAVY, fontSize: 'clamp(1.6rem, 3vw, 2.4rem)', letterSpacing: '-0.025em' }}
            >
              Institutions We Work With
            </h2>
            <p className="text-body-lg mb-12" style={{ color: '#6B7280', maxWidth: '520px', margin: '0 auto 3rem' }}>
              A growing network of institutions committed to responsible textile disposal.
            </p>
          </motion.div>

          {/* Partner logo image grid */}
          <motion.div
            initial="hidden"
            animate={partnersInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
            className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-8"
          >
            {PARTNER_LOGOS.map((logo, i) => (
              <motion.div
                key={i}
                initial="hidden"
                animate={partnersInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i * 0.4 + 1}
                className="overflow-hidden border"
                style={{ borderColor: '#E8E8E8', aspectRatio: '3/2' }}
              >
                <img
                  src={logo}
                  alt={`Partner ${i + 1}`}
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-300"
                />
              </motion.div>
            ))}
          </motion.div>

          <motion.p
            initial="hidden"
            animate={partnersInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={3}
            className="text-center text-xs"
            style={{ color: '#9CA3AF' }}
          >
            ...and many more partners across India.
          </motion.p>

        </div>
      </section>

      {/* ── SECTION 4: POWERED BY COMMUNITY ── */}
      <section ref={communityRef} className="section-padding" style={{ background: '#F2EDE8' }}>
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-14 lg:gap-16 items-start">

            {/* Left — image */}
            <motion.div
              initial="hidden"
              animate={communityInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={0}
              className="w-full lg:w-[42%] flex-shrink-0"
            >
              <div className="aspect-[4/3] overflow-hidden" style={{ border: '1px solid rgba(0,0,0,0.06)' }}>
                <img
                  src="https://images.pexels.com/photos/8294606/pexels-photo-8294606.jpeg?auto=compress&cs=tinysrgb&w=1000&q=85"
                  alt="Community workers sorting textile waste"
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>

            {/* Right — content */}
            <div className="flex-1">
              <motion.div
                initial="hidden"
                animate={communityInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={1}
                className="mb-8"
              >
                <SectionLabel text="POWERED BY COMMUNITY" />
                <h2
                  className="font-display font-bold mb-5"
                  style={{ color: NAVY, fontSize: 'clamp(1.6rem, 3vw, 2.4rem)', lineHeight: 1.15, letterSpacing: '-0.025em' }}
                >
                  {cms.community_heading}
                </h2>
                <p className="text-sm leading-relaxed mb-3" style={{ color: '#6B7280' }}>
                  {cms.community_body_1}
                </p>
                <p className="text-sm leading-relaxed" style={{ color: '#6B7280' }}>
                  {cms.community_body_2}
                </p>
              </motion.div>

              {/* 4 numbered commitment boxes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {commitments.map((item, i) => (
                  <motion.div
                    key={item.verb}
                    initial="hidden"
                    animate={communityInView ? 'visible' : 'hidden'}
                    variants={fadeUp}
                    custom={i + 2}
                    className="p-5 bg-white border"
                    style={{ borderColor: 'rgba(0,0,0,0.06)' }}
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className="flex-shrink-0 w-10 h-10 flex items-center justify-center font-display font-black text-sm"
                        style={{ backgroundColor: NUM_COLORS[i], color: '#0A1F3C' }}
                      >
                        {item.num}
                      </div>
                      <div>
                        <p className="font-bold text-sm mb-1" style={{ color: NAVY }}>{item.verb}</p>
                        <p className="text-xs leading-relaxed" style={{ color: '#6B7280' }}>{item.detail}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ── SECTION 5: LEARN MORE BANNER ── */}
      <section
        ref={bannerRef}
        className="section-padding text-center"
        style={{ background: '#1A1A1A' }}
      >
        <div className="container-site">

          <motion.div
            initial="hidden"
            animate={bannerInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={0}
          >
            <h3
              className="font-display font-bold mb-3"
              style={{ color: '#ffffff', fontSize: 'clamp(1.5rem, 2.8vw, 2.2rem)', letterSpacing: '-0.025em' }}
            >
              Go through our research on textile circularity.
            </h3>
            <p
              className="text-sm mb-8 mx-auto"
              style={{ color: 'rgba(255,255,255,0.6)', maxWidth: '480px' }}
            >
              Explore the work we are doing to build circular systems for textile waste.
            </p>
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 px-8 py-3.5 font-semibold text-sm transition-all duration-300 hover:opacity-90"
              style={{ background: TEAL, color: '#0A1F3C', textDecoration: 'none' }}
            >
              Read our Research
              <ArrowRight size={16} />
            </Link>
          </motion.div>

        </div>
      </section>

    </main>
  );
}
