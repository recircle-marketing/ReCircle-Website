import { useRef, useState, useEffect } from 'react';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { MapPin, ArrowRight, Scale, Scissors, Package, Import as SortAsc, Heart, Users, ShieldCheck, Leaf, Star, CreditCard, Building2 } from 'lucide-react';
import { getMrfPageSettings } from '../../cms/queries';
import type { MrfPageSettings } from '../../cms/types';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

function SectionLabel({ text, light }: { text: string; light?: boolean }) {
  return (
    <p
      className="text-caption font-semibold uppercase tracking-[0.15em] mb-4"
      style={{ color: light ? '#00C499' : '#00C499' }}
    >
      {text}
    </p>
  );
}

function StatCard({ value, label }: { value: string; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });
  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={inView ? 'visible' : 'hidden'}
      variants={fadeUp}
      className="text-center p-8 border-r last:border-r-0"
      style={{ borderColor: 'rgba(1,41,138,0.1)' }}
    >
      <p className="font-display font-black text-4xl mb-2" style={{ color: '#01298A', letterSpacing: '-0.03em' }}>{value}</p>
      <p className="text-sm" style={{ color: '#5F5F5F' }}>{label}</p>
    </motion.div>
  );
}

export default function MrfPage() {
  const [cms, setCms] = useState<MrfPageSettings | null>(null);

  useEffect(() => {
    getMrfPageSettings().then(setCms).catch(() => setCms(null));
  }, []);

  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);

  const aboutRef = useRef<HTMLElement>(null);
  const lifeRef = useRef<HTMLElement>(null);
  const locationRef = useRef<HTMLElement>(null);

  const aboutInView = useInView(aboutRef, { once: true, margin: '-60px' });
  const lifeInView = useInView(lifeRef, { once: true, margin: '-60px' });
  const locationInView = useInView(locationRef, { once: true, margin: '-60px' });

  const heroHeading = cms?.hero_heading ?? 'Material Recovery Facility';
  const heroBody = cms?.hero_body ?? "Operated in collaboration with the Brihanmumbai Municipal Corporation (BMC), ReCircle's Material Recovery Facility is where waste begins its journey back into circulation.";
  const stat1Value = cms?.stat_1_value ?? '8T+';
  const stat1Label = cms?.stat_1_label ?? 'Dry waste processed daily';
  const stat2Value = cms?.stat_2_value ?? 'BMC';
  const stat2Label = cms?.stat_2_label ?? 'Municipal partnership';
  const overviewHeading = cms?.overview_heading ?? 'Inside the Recovery Process';
  const overviewBody = cms?.overview_body ?? [
    'Every material entering our MRF moves through a structured recovery process designed to maximise resource value before anything reaches landfill.',
    "Waste collected across Mumbai's R/C Ward is sorted, segregated, compacted, and directed toward responsible recycling channels through dedicated processing systems built for efficient waste management.",
    'Our facility handles multiple recyclable waste streams including PET bottles, plastics, paper, and mixed dry waste while maintaining operational traceability across every stage of recovery.',
    'Equipped with bale press machines, cutting machines, sorting stations, weighing systems, and material handling infrastructure, the MRF currently supports the recovery and processing of over 8 tons of dry waste every day.',
  ].join('\n');

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[70vh] flex items-end overflow-hidden">
        <motion.div className="absolute inset-0" style={{ y: bgY }}>
          <img
            src="https://images.pexels.com/photos/802221/pexels-photo-802221.jpeg?auto=compress&cs=tinysrgb&w=1600&q=85"
            alt="Material Recovery Facility"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(1,41,138,0.92) 0%, rgba(1,41,138,0.5) 50%, rgba(1,41,138,0.15) 100%)' }} />
        </motion.div>

        <div className="container-site relative z-10 pb-16 pt-40">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 mb-6 border text-xs font-semibold uppercase tracking-widest"
            style={{ borderColor: 'rgba(220,235,75,0.5)', color: '#DCEB4B', backgroundColor: 'rgba(220,235,75,0.08)' }}
          >
            Infrastructure
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white mb-4 leading-tight"
            style={{ fontSize: 'clamp(2.2rem, 5vw, 3.8rem)', letterSpacing: '-0.03em', maxWidth: 700 }}
          >
            {heroHeading}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-body-lg max-w-2xl leading-relaxed"
            style={{ color: 'rgba(255,255,255,0.75)' }}
          >
            {heroBody}
          </motion.p>

          {/* Location pill */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.35 }}
            className="mt-6 inline-flex items-center gap-2 text-sm"
            style={{ color: 'rgba(255,255,255,0.55)' }}
          >
            <MapPin size={14} style={{ color: '#00C499' }} />
            Borivali R/C Ward, Mumbai
          </motion.div>
        </div>
      </section>

      {/* ── Stats strip ──────────────────────────────────────────────────── */}
      <div className="bg-white border-b" style={{ borderColor: '#E8E8E8' }}>
        <div className="container-site">
          <div className="grid grid-cols-2 md:grid-cols-4 divide-x" style={{ borderColor: '#E8E8E8' }}>
            <StatCard value={stat1Value} label={stat1Label} />
            <StatCard value={stat2Value} label={stat2Label} />
            <StatCard value="R/C Ward" label="Coverage area" />
            <StatCard value="100%" label="Operational traceability" />
          </div>
        </div>
      </div>

      {/* ── About / Recovery Process ──────────────────────────────────────── */}
      <section ref={aboutRef} className="section-padding bg-ivory">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-16 items-start">
            {/* Left */}
            <motion.div
              className="flex-1 max-w-xl"
              initial="hidden"
              animate={aboutInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="ABOUT" />
              <h2 className="font-display text-display-sm font-bold mb-6 leading-tight" style={{ color: '#1A1A1A' }}>
                {overviewHeading}
              </h2>
              <div className="space-y-4">
                {overviewBody.split('\n').filter(Boolean).map((para, i) => (
                  <motion.p
                    key={i}
                    initial="hidden"
                    animate={aboutInView ? 'visible' : 'hidden'}
                    variants={fadeUp}
                    custom={i + 1}
                    className="text-body-lg leading-relaxed"
                    style={{ color: '#5F5F5F' }}
                  >
                    {para}
                  </motion.p>
                ))}
              </div>
            </motion.div>

            {/* Right — equipment cards with images */}
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                {
                  icon: <Package size={20} />,
                  title: 'Bale Press Machines',
                  desc: 'Compact sorted materials into dense bales for efficient transport and storage.',
                  img: 'https://images.pexels.com/photos/2284166/pexels-photo-2284166.jpeg?auto=compress&cs=tinysrgb&w=600&q=80',
                },
                {
                  icon: <Scissors size={20} />,
                  title: 'Cutting Machines',
                  desc: 'Process and size materials to meet downstream recycler specifications.',
                  img: 'https://images.pexels.com/photos/3862130/pexels-photo-3862130.jpeg?auto=compress&cs=tinysrgb&w=600&q=80',
                },
                {
                  icon: <SortAsc size={20} />,
                  title: 'Sorting Stations',
                  desc: 'Manual and mechanised segregation across PET, plastic, paper, and dry waste streams.',
                  img: 'https://images.pexels.com/photos/802221/pexels-photo-802221.jpeg?auto=compress&cs=tinysrgb&w=600&q=80',
                },
                {
                  icon: <Scale size={20} />,
                  title: 'Weighing Systems',
                  desc: 'Track material volumes at each stage, feeding operational traceability data.',
                  img: 'https://images.pexels.com/photos/4481260/pexels-photo-4481260.jpeg?auto=compress&cs=tinysrgb&w=600&q=80',
                },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  initial="hidden"
                  animate={aboutInView ? 'visible' : 'hidden'}
                  variants={fadeUp}
                  custom={i + 1}
                  className="bg-white border overflow-hidden"
                  style={{ borderColor: '#E8E8E8' }}
                  whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.08)', y: -3 }}
                  transition={{ duration: 0.2 }}
                >
                  {/* Machinery image */}
                  <div className="h-40 overflow-hidden">
                    <img src={item.img} alt={item.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-5">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-7 h-7 flex items-center justify-center flex-shrink-0" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                        {item.icon}
                      </div>
                      <h3 className="text-sm font-bold" style={{ color: '#1A1A1A' }}>{item.title}</h3>
                    </div>
                    <p className="text-xs leading-relaxed" style={{ color: '#858585' }}>{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Life at the MRF ───────────────────────────────────────────────── */}
      <section ref={lifeRef} className="py-14 lg:py-20" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Left — image */}
            <motion.div
              className="flex-1"
              initial={{ opacity: 0, x: -30 }}
              animate={lifeInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
              transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="aspect-[16/10] overflow-hidden relative">
                <img
                  src="https://images.pexels.com/photos/8728562/pexels-photo-8728562.jpeg?auto=compress&cs=tinysrgb&w=800&q=85"
                  alt="Life at the MRF"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(26,26,26,0.5) 0%, transparent 60%)' }} />
                <div className="absolute bottom-6 left-6 right-6">
                  <p className="text-sm font-semibold text-white">Our Safai Saathis</p>
                  <p className="text-xs" style={{ color: 'rgba(255,255,255,0.6)' }}>The people who power the recovery process</p>
                </div>
              </div>
            </motion.div>

            {/* Right — benefits */}
            <div className="flex-1">
              <motion.div
                initial="hidden"
                animate={lifeInView ? 'visible' : 'hidden'}
                variants={fadeUp}
              >
                <SectionLabel text="LIFE AT THE MRF" light />
                <h2 className="font-display text-display-sm font-bold text-white mb-4 leading-tight">
                  A supportive environment<br />for meaningful impact.
                </h2>
                <p className="text-body-lg mb-10 leading-relaxed" style={{ color: 'rgba(255,255,255,0.65)' }}>
                  We believe a supportive work environment is key to driving meaningful impact. Through these initiatives, we're fostering a supportive community, and we welcome partnerships that help uplift and empower our Safai Saathis in every way.
                </p>
              </motion.div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  { icon: <Heart size={16} />, title: 'Medical Camps & Health Check-ups', desc: 'Ensuring everyone feels their best.' },
                  { icon: <Star size={16} />, title: 'Festive Gatherings', desc: 'Celebrating together as a community.' },
                  { icon: <Leaf size={16} />, title: 'Environmental Workshops', desc: 'Reminding us of our shared purpose.' },
                  { icon: <Users size={16} />, title: 'Personal Celebrations', desc: "Acknowledging each team member's milestones." },
                  { icon: <ShieldCheck size={16} />, title: 'EPF & ESIC Access', desc: 'Government schemes for financial security.' },
                  { icon: <CreditCard size={16} />, title: 'Bank Account Access', desc: 'Empowering financial independence.' },
                ].map((benefit, i) => (
                  <motion.div
                    key={benefit.title}
                    initial="hidden"
                    animate={lifeInView ? 'visible' : 'hidden'}
                    variants={fadeUp}
                    custom={i}
                    className="flex items-start gap-3 p-4"
                    style={{ backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                  >
                    <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,196,153,0.15)', color: '#00C499' }}>
                      {benefit.icon}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white mb-0.5">{benefit.title}</p>
                      <p className="text-xs" style={{ color: 'rgba(255,255,255,0.45)' }}>{benefit.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Location ─────────────────────────────────────────────────────── */}
      <section ref={locationRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            className="mb-10"
            initial="hidden"
            animate={locationInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="LOCATION" />
            <h2 className="font-display text-display-sm font-bold mb-3 leading-tight" style={{ color: '#1A1A1A' }}>
              ReCircle Material Recovery Facility
            </h2>
            <div className="flex items-center gap-2 text-sm" style={{ color: '#5F5F5F' }}>
              <MapPin size={14} style={{ color: '#01298A' }} />
              Borivali R/C Ward, Mumbai
            </div>
            <p className="mt-3 text-body-lg max-w-xl" style={{ color: '#5F5F5F' }}>
              Located in Borivali, the facility supports dry waste collection, segregation, and plastic waste recovery operations across Mumbai's R/C Ward.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={locationInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="w-full overflow-hidden border"
            style={{ borderColor: '#E8E8E8', height: 480 }}
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3767.9!2d72.8777!3d19.2183!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b1257bba8f1b%3A0x2f0d5b2b2a0c1e0e!2sBorivali%20R%2FC%20Ward%2C%20Mumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1716000000000!5m2!1sen!2sin"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="ReCircle MRF Borivali Location"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={locationInView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-4 flex items-center gap-3"
          >
            <a
              href="https://maps.app.goo.gl/borivali-rc-ward"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white transition-opacity hover:opacity-90"
              style={{ backgroundColor: '#01298A' }}
            >
              <MapPin size={14} />
              Open in Google Maps
              <ArrowRight size={14} />
            </a>
          </motion.div>
        </div>
      </section>

    </main>
  );
}
