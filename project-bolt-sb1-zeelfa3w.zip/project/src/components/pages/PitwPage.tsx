import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, CheckCircle2, XCircle } from 'lucide-react';
import { getPitwPageSettings } from '../../cms/queries';
import type { PitwPageSettings } from '../../cms/types';

// ── Animation variants ────────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

// ── Brand colours ─────────────────────────────────────────────────────────────
const NAVY = '#01298A';
const TEAL = '#00C499';
const RED = '#DC2626';

// ── Section label ─────────────────────────────────────────────────────────────
function SectionLabel({ text, light, center }: { text: string; light?: boolean; center?: boolean }) {
  return (
    <p
      className={`text-caption font-semibold uppercase tracking-[0.15em] mb-4${center ? ' text-center' : ''}`}
      style={{ color: light ? 'rgba(0,196,153,0.9)' : TEAL }}
    >
      {text}
    </p>
  );
}

// ── Output images map ─────────────────────────────────────────────────────────
const OUTPUT_IMAGES = [
  'https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg?auto=compress&cs=tinysrgb&w=800&q=85',
  'https://images.pexels.com/photos/1148957/pexels-photo-1148957.jpeg?auto=compress&cs=tinysrgb&w=800&q=85',
  'https://images.pexels.com/photos/4622209/pexels-photo-4622209.jpeg?auto=compress&cs=tinysrgb&w=800&q=85',
];

// ── Partner dummy logos ───────────────────────────────────────────────────────
const PARTNER_LOGOS = [
  'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/1181533/pexels-photo-1181533.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
  'https://images.pexels.com/photos/3182773/pexels-photo-3182773.jpeg?auto=compress&cs=tinysrgb&w=400&q=80',
];

// ── CMS fallback ──────────────────────────────────────────────────────────────
const FALLBACK: PitwPageSettings = {
  hero_heading: 'End-to-End Post-Industrial Textile Waste Management',
  stat_1_value: '700 MT',
  stat_1_label: 'of textile waste processed since 2024',
  stat_2_value: '50 MT/mo',
  stat_2_label: 'monthly processing capacity',
  process_heading: 'From Factory Floor to Recycled Fibre',
  process_intro: 'We collect post-industrial textile waste directly from manufacturing facilities, sort and route it through our Textile Recovery Facility, and channel it to certified recycling partners — closing the loop on factory waste.',
  scope_note: '100% cotton (preferably white) and denim.',
  comparison_current: [
    { text: 'Waste handed off to unreliable aggregators' },
    { text: 'No visibility on where your waste goes' },
    { text: 'No certification to show auditors or buyers' },
    { text: 'Waste treated as a cost to get rid of' },
    { text: 'EPR regulations tightening with no compliance system' },
  ],
  comparison_recircle: [
    { text: 'Structured pickup with full accountability' },
    { text: 'Complete traceability from pickup to recycled fibre' },
    { text: 'GRS certified fibre and ReCircle sustainability certificate' },
    { text: 'Your waste becomes a raw material with real value' },
    { text: 'Be EPR-ready and build a compliant waste system' },
  ],
  outputs: [
    { name: 'White Fibre', application: 'Suitable for yarn blending' },
    { name: 'Colour Fibre', application: 'Used in felt manufacturing and industrial nonwoven applications' },
    { name: 'Denim Fibre', application: 'Suitable for denim yarn blending' },
  ],
  grs_note: 'All recycled fibres are supplied with GRS (Global Recycled Standard) certification.',
  work_models: [
    { num: '01', title: 'Collection Model', body: 'Hassle-free collection from your facility. We collect your waste directly.' },
    { num: '02', title: 'Recycled Fibre Supply Model', body: 'Buy recycled fibre from us and use it directly in your production.' },
    { num: '03', title: 'Complete Circularity Model', body: 'We collect your waste, process it, and return it to you as recycled fibres. You own your waste back into fibre.' },
  ],
};

// Number accent colours for work models
const NUM_COLORS = ['#DCEB4B', TEAL, '#F97316'];

// ─────────────────────────────────────────────────────────────────────────────
// MAIN PAGE
// ─────────────────────────────────────────────────────────────────────────────
export default function PitwPage() {
  const [cms, setCms] = useState<PitwPageSettings>(FALLBACK);

  useEffect(() => {
    getPitwPageSettings().then((d) => {
      if (d) setCms(d);
    });
  }, []);

  // Hero parallax
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress: heroScroll } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroBgY = useTransform(heroScroll, [0, 1], ['0%', '20%']);

  const processRef = useRef<HTMLElement>(null);
  const comparisonRef = useRef<HTMLElement>(null);
  const outputsRef = useRef<HTMLElement>(null);
  const waysRef = useRef<HTMLElement>(null);
  const partnersRef = useRef<HTMLElement>(null);
  const bannerRef = useRef<HTMLElement>(null);

  const processInView = useInView(processRef, { once: true, margin: '-60px' });
  const comparisonInView = useInView(comparisonRef, { once: true, margin: '-60px' });
  const outputsInView = useInView(outputsRef, { once: true, margin: '-60px' });
  const waysInView = useInView(waysRef, { once: true, margin: '-60px' });
  const partnersInView = useInView(partnersRef, { once: true, margin: '-60px' });
  const bannerInView = useInView(bannerRef, { once: true, margin: '-60px' });

  const comparisonRows = cms.comparison_current.map((cur, i) => ({
    current: cur.text,
    recircle: cms.comparison_recircle[i]?.text ?? '',
  }));

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Section 1: Hero ───────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[80vh] flex items-end overflow-hidden">
        {/* Background image with parallax */}
        <motion.div
          className="absolute inset-0 bg-center bg-cover"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/4481259/pexels-photo-4481259.jpeg?auto=compress&cs=tinysrgb&w=1800&q=85)',
            y: heroBgY,
            scale: 1.08,
          }}
        />
        {/* Gradient overlay */}
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, rgba(1,25,70,0.97) 0%, rgba(1,25,70,0.72) 50%, rgba(1,25,70,0.25) 100%)' }}
        />

        <div className="relative z-10 container-site w-full pb-16 pt-32">
          <div className="flex flex-col lg:flex-row lg:items-end gap-12">

            {/* Left — heading */}
            <div className="flex-1 max-w-2xl">
              <motion.div
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45 }}
              >
                <SectionLabel text="POST-INDUSTRIAL" light />
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: 32 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
                className="font-display font-bold text-white leading-tight"
                style={{ fontSize: 'clamp(2.2rem, 4.5vw, 3.6rem)', letterSpacing: '-0.03em' }}
              >
                {cms.hero_heading}
              </motion.h1>
            </div>

            {/* Right — stat boxes */}
            <div className="flex flex-col sm:flex-row lg:flex-col gap-4 lg:min-w-[280px]">
              {[
                { value: cms.stat_1_value, label: cms.stat_1_label },
                { value: cms.stat_2_value, label: cms.stat_2_label },
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.55, delay: 0.2 + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
                  className="p-6 border flex-1 lg:flex-none"
                  style={{ borderColor: 'rgba(255,255,255,0.15)', backgroundColor: 'rgba(255,255,255,0.06)', backdropFilter: 'blur(8px)' }}
                >
                  <p
                    className="font-display font-black leading-none mb-2"
                    style={{ fontSize: 'clamp(2rem, 4vw, 2.8rem)', color: '#DCEB4B', letterSpacing: '-0.04em' }}
                  >
                    {stat.value}
                  </p>
                  <p className="text-sm font-medium" style={{ color: 'rgba(255,255,255,0.65)' }}>
                    {stat.label}
                  </p>
                </motion.div>
              ))}
            </div>

          </div>
        </div>
      </section>

      {/* ── Section 2: Our Process ────────────────────────────────────────── */}
      <section ref={processRef} className="section-padding bg-ivory">
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={processInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="max-w-2xl mb-10"
          >
            <SectionLabel text="THE PROCESS" />
            <h2
              className="font-display font-bold leading-tight mb-5"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
            >
              {cms.process_heading}
            </h2>
            <p className="text-body-lg leading-relaxed" style={{ color: '#5F5F5F' }}>
              {cms.process_intro}
            </p>
          </motion.div>

          {/* Process image 4:3 */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={processInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 }}
            transition={{ duration: 0.65, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="w-full mb-8 overflow-hidden"
            style={{ border: '1px solid rgba(0,0,0,0.06)' }}
          >
            <div className="aspect-[4/3] w-full">
              <img
                src="https://images.pexels.com/photos/3965545/pexels-photo-3965545.jpeg?auto=compress&cs=tinysrgb&w=1400&q=85"
                alt="Post-industrial textile waste processing facility"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          {/* Scope callout */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={processInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="pl-5 py-3 pr-5"
            style={{
              backgroundColor: 'rgba(0,196,153,0.06)',
              border: '1px solid rgba(0,196,153,0.15)',
              borderLeftWidth: 4,
              borderLeftColor: TEAL,
            }}
          >
            <p className="text-sm font-semibold mb-1" style={{ color: NAVY }}>Current scope</p>
            <p className="text-sm" style={{ color: '#5F5F5F' }}>
              {cms.scope_note}
            </p>
          </motion.div>
        </div>
      </section>

      {/* ── Section 3: Comparison ────────────────────────────────────────── */}
      <section ref={comparisonRef} className="section-padding bg-white">
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={comparisonInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="mb-10"
          >
            <SectionLabel text="CURRENT VS RECIRCLE" />
            <h2
              className="font-display font-bold leading-tight"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
            >
              Why Make the Switch?
            </h2>
          </motion.div>

          {/* Column headers */}
          <motion.div
            initial="hidden"
            animate={comparisonInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={0.5}
            className="grid grid-cols-2 mb-3 gap-0"
          >
            <div className="pr-6 pb-3 border-b-2" style={{ borderColor: RED }}>
              <p className="text-sm font-bold uppercase tracking-widest" style={{ color: RED }}>
                Current Situation
              </p>
            </div>
            <div className="border-l pl-6 pb-3 border-b-2" style={{ borderColor: TEAL, borderLeftColor: '#E8E8E8' }}>
              <p className="text-sm font-bold uppercase tracking-widest" style={{ color: TEAL }}>
                With ReCircle
              </p>
            </div>
          </motion.div>

          {/* Rows */}
          {comparisonRows.map((row, i) => (
            <motion.div
              key={i}
              initial="hidden"
              animate={comparisonInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={i + 1}
              className="grid grid-cols-2 gap-0 border-b py-5"
              style={{ borderColor: '#F0F0F0' }}
            >
              {/* Current — red accent */}
              <div
                className="pr-6 flex items-start gap-3"
              >
                <div
                  className="flex-shrink-0 mt-0.5 w-5 h-5 flex items-center justify-center"
                  style={{ backgroundColor: '#FEE2E2', borderRadius: '50%' }}
                >
                  <XCircle size={14} style={{ color: RED }} />
                </div>
                <p className="text-sm leading-relaxed" style={{ color: '#6B2020' }}>{row.current}</p>
              </div>

              {/* ReCircle — teal accent */}
              <div
                className="border-l pl-6 flex items-start gap-3"
                style={{ borderLeftColor: 'rgba(0,196,153,0.25)' }}
              >
                <div
                  className="flex-shrink-0 mt-0.5 w-5 h-5 flex items-center justify-center"
                  style={{ backgroundColor: 'rgba(0,196,153,0.12)', borderRadius: '50%' }}
                >
                  <CheckCircle2 size={14} style={{ color: TEAL }} />
                </div>
                <p className="text-sm leading-relaxed font-medium" style={{ color: NAVY }}>{row.recircle}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ── Section 4: Recycled Fibre Outputs ────────────────────────────── */}
      <section ref={outputsRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={outputsInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="mb-12"
          >
            <SectionLabel text="OUR OUTPUTS" />
            <h2
              className="font-display font-bold leading-tight"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
            >
              Recycled Fibre We Produce
            </h2>
          </motion.div>

          {/* Output cards with images */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
            {cms.outputs.map((output, i) => (
              <motion.div
                key={output.name}
                initial="hidden"
                animate={outputsInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="bg-white border overflow-hidden"
                style={{ borderColor: '#E8E8E8' }}
                whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.08)', y: -3 }}
                transition={{ duration: 0.2 }}
              >
                {/* Card image */}
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={OUTPUT_IMAGES[i % OUTPUT_IMAGES.length]}
                    alt={output.name}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-base font-bold mb-2" style={{ color: '#1A1A1A' }}>{output.name}</h3>
                  <p className="text-sm leading-relaxed" style={{ color: '#858585' }}>{output.application}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* GRS note with logo provision */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={outputsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 12 }}
            transition={{ duration: 0.5, delay: 0.35 }}
            className="flex flex-col sm:flex-row items-start sm:items-center gap-5 p-5"
            style={{ backgroundColor: 'rgba(0,196,153,0.06)', border: '1px solid rgba(0,196,153,0.15)', borderLeftWidth: 4, borderLeftColor: TEAL }}
          >
            {/* GRS logo placeholder */}
            <div
              className="flex-shrink-0 flex items-center justify-center"
              style={{ width: 80, height: 56, backgroundColor: 'rgba(1,41,138,0.06)', border: '1px solid rgba(1,41,138,0.12)' }}
            >
              <span className="text-xs font-bold tracking-widest uppercase" style={{ color: NAVY, opacity: 0.5 }}>GRS</span>
            </div>
            <p className="text-sm" style={{ color: '#5F5F5F' }}>
              {cms.grs_note}
            </p>
          </motion.div>
        </div>
      </section>

      {/* ── Section 5: Three Ways to Work With Us ────────────────────────── */}
      <section ref={waysRef} className="section-padding" style={{ backgroundColor: NAVY }}>
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={waysInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="mb-12"
          >
            <SectionLabel text="WORK WITH US" light />
            <h2
              className="font-display font-bold text-white leading-tight"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em' }}
            >
              {cms.work_models.length} Ways to Work with Us
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {cms.work_models.map((way, i) => (
              <motion.div
                key={way.num}
                initial="hidden"
                animate={waysInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="p-8 flex flex-col relative overflow-hidden"
                style={{
                  border: '1px solid rgba(255,255,255,0.12)',
                  backgroundColor: 'rgba(255,255,255,0.04)',
                }}
                whileHover={{ backgroundColor: 'rgba(255,255,255,0.07)' }}
                transition={{ duration: 0.2 }}
              >
                {/* Prominent coloured number */}
                <div
                  className="w-14 h-14 flex items-center justify-center mb-5 font-display font-black text-xl"
                  style={{
                    backgroundColor: NUM_COLORS[i % NUM_COLORS.length],
                    color: '#0A1F3C',
                    letterSpacing: '-0.03em',
                  }}
                >
                  {way.num}
                </div>
                <h3 className="text-base font-bold text-white mb-3">{way.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.6)' }}>{way.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 6: Partners ───────────────────────────────────────────── */}
      <section ref={partnersRef} className="section-padding bg-white">
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={partnersInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="text-center mb-12"
          >
            <SectionLabel text="OUR PARTNERS" center />
            <h2
              className="font-display font-bold leading-tight mb-4"
              style={{ fontSize: 'clamp(1.7rem, 3vw, 2.4rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
            >
              Trusted by Industry Partners
            </h2>
            <p className="text-body-lg max-w-xl mx-auto" style={{ color: '#5F5F5F' }}>
              We work with manufacturing facilities, recycling partners, and certifying bodies to build a complete post-industrial circularity system.
            </p>
          </motion.div>

          {/* Logo image grid */}
          <motion.div
            initial="hidden"
            animate={partnersInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
            className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4"
          >
            {PARTNER_LOGOS.map((logo, i) => (
              <motion.div
                key={i}
                initial="hidden"
                animate={partnersInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i * 0.5 + 1}
                className="overflow-hidden border"
                style={{ borderColor: '#E8E8E8', aspectRatio: '3/2' }}
              >
                <img
                  src={logo}
                  alt={`Partner ${i + 1}`}
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-300"
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Section 7: Learn More Banner ─────────────────────────────────── */}
      <section ref={bannerRef} className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site text-center">
          <motion.h3
            initial={{ opacity: 0, y: 24 }}
            animate={bannerInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 }}
            transition={{ duration: 0.55, delay: 0.05, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white mb-4 max-w-2xl mx-auto"
            style={{ fontSize: 'clamp(1.5rem, 2.8vw, 2.2rem)', letterSpacing: '-0.025em' }}
          >
            Want to understand more about textile waste management?
          </motion.h3>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={bannerInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
            transition={{ duration: 0.55, delay: 0.15 }}
            className="text-body-lg mb-8 max-w-lg mx-auto"
            style={{ color: 'rgba(255,255,255,0.6)' }}
          >
            Go through our research on the textile circularity we are building.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={bannerInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 12 }}
            transition={{ duration: 0.5, delay: 0.25 }}
          >
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 px-7 py-3.5 font-semibold text-sm transition-all duration-300 hover:opacity-90"
              style={{ backgroundColor: TEAL, color: '#0A1F3C' }}
            >
              Read our Research
              <ArrowRight size={16} />
            </Link>
          </motion.div>
        </div>
      </section>

    </main>
  );
}
