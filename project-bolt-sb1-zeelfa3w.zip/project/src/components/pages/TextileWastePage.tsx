import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { ArrowRight, ChevronDown, ChevronRight, MapPin, Recycle, BarChart2, Megaphone } from 'lucide-react';
import { getTextileWastePageSettings } from '../../cms/queries';
import type { TextileWastePageSettings } from '../../cms/types';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

const NAVY = '#01298A';
const TEAL = '#00C499';

function SectionLabel({ text, center, light }: { text: string; center?: boolean; light?: boolean }) {
  return (
    <p
      className={`text-caption font-semibold uppercase tracking-[0.15em] mb-4 ${center ? 'text-center' : ''}`}
      style={{ color: light ? 'rgba(0,196,153,0.9)' : TEAL }}
    >
      {text}
    </p>
  );
}

const COMMITMENT_CARDS = [
  { verb: 'Collect', detail: 'Post-consumer fabric directly from Waghris. Integrate Safai Saathis into formal recovery operations.' },
  { verb: 'Create', detail: 'Predictable incomes, living wages, and stable livelihoods that uplift families and communities.' },
  { verb: 'Conduct', detail: 'IEC programmes that foster awareness, skill-building, and community leadership at the grassroots level.' },
  { verb: 'Champion', detail: 'Safer working conditions and integration into formal government schemes.' },
];

const MODEL_ICONS = [
  <MapPin size={20} />,
  <Recycle size={20} />,
  <BarChart2 size={20} />,
  <Megaphone size={20} />,
];

const FALLBACK: TextileWastePageSettings = {
  hero_stat: '134 million tonnes',
  hero_fact_1: 'Global textile waste projected by 2030',
  hero_fact_2: 'India is the 3rd-largest generator, contributing 8.5% to global textile waste',
  hero_closing: 'This is not a list we aspire to lead.',
  problem_body: 'Piles of post-consumer textile waste are leaching toxic dyes into soil, shedding microplastics into oceans, and overflowing into already strained landfills. And yet, we lack textile waste management systems to handle it.',
  problem_closing: 'But where most see a waste problem, ReCircle sees a world of opportunity.',
  model_intro: 'We are building a scalable, end-to-end textile circularity ecosystem — connecting collection, traceability, impact measurement, and awareness into one seamless system.',
  model_pillars: [
    { num: '01', title: 'Collection', body: 'From schools, offices, hotels, and factories. Our network recovers textile waste from wherever it exists.' },
    { num: '02', title: 'Traceability', body: 'From collection to processing, complete visibility on where your garments go and the impact created.' },
    { num: '03', title: 'Impact Reports', body: 'Every garment tracked. We measure how textile waste is reused, revamped, recycled, or repurposed.' },
    { num: '04', title: 'Awareness', body: 'Education is the first step. We help you understand the purpose and process of textile circularity.' },
  ],
  trf_stat_1_value: '700 MT',
  trf_stat_1_label: 'of textile waste processed since 2024',
  trf_stat_2_value: '50 MT',
  trf_stat_2_label: 'monthly processing capacity',
  trf_body: 'Our Textile Recovery Facility (TRF) in Dombivli is the operational backbone of ReCircle\'s textile circularity model — enabling organised collection, segregation, and channelization of textile waste at scale.',
  partner_categories: [
    { title: 'Textile Brands', subtypes: 'Multi-brand stores, D2C brands, boutiques, brand stores', desc: 'Collection of excess inventory, in-store takeback programmes, and pre-consumer waste management.' },
    { title: 'Textile Industries', subtypes: 'Spinning mills, weaving units, dyeing houses, garment manufacturers', desc: 'Collection of fabric waste generated during production.' },
    { title: 'T-Shirt to T-Shirt Circularity', subtypes: 'Fibre manufacturers, yarn spinners, fabric mills, ethical fashion brands', desc: 'Traceable post-consumer textile waste and closed-loop production collaboration.' },
    { title: 'Upcyclers', subtypes: 'Independent designers, upcycling brands, sustainable fashion startups, home decor creators, artisanal enterprises', desc: 'Sourcing high-quality post-consumer fabric, circular product design, traceable materials.' },
    { title: 'Other Institutions', subtypes: 'Educational institutions, corporates, hotels, hospitals', desc: 'Waste collection programmes and employee awareness initiatives.' },
  ],
  community_heading: 'The communities who make circularity real.',
  community_body_1: 'The Waghri community has long been the invisible backbone of India\'s informal textile recovery chain — collecting, sorting, and reselling fabrics across cities and towns for generations.',
  community_body_2: 'ReCircle integrates Safai Saathis into our formal recovery operations, recognising them as essential partners — not just participants — in building a just and circular textile economy.',
  supporters: [
    { name: 'CAIF' },
    { name: 'Intellecap' },
    { name: 'Fashion for Good' },
  ],
};

const SUPPORTER_DUMMY_LOGOS = [
  'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
];

export default function TextileWastePage() {
  const [activeTab, setActiveTab] = useState(0);
  const [cms, setCms] = useState<TextileWastePageSettings>(FALLBACK);

  useEffect(() => {
    getTextileWastePageSettings().then((d) => { if (d) setCms(d); });
  }, []);

  const heroRef = useRef<HTMLElement>(null);
  const problemRef = useRef<HTMLElement>(null);
  const modelRef = useRef<HTMLElement>(null);
  const infraRef = useRef<HTMLElement>(null);
  const redirectRef = useRef<HTMLElement>(null);
  const partnerRef = useRef<HTMLElement>(null);
  const peopleRef = useRef<HTMLElement>(null);
  const supportersRef = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);

  const problemInView = useInView(problemRef, { once: true, margin: '-60px' });
  const modelInView = useInView(modelRef, { once: true, margin: '-60px' });
  const infraInView = useInView(infraRef, { once: true, margin: '-60px' });
  const redirectInView = useInView(redirectRef, { once: true, margin: '-60px' });
  const partnerInView = useInView(partnerRef, { once: true, margin: '-60px' });
  const peopleInView = useInView(peopleRef, { once: true, margin: '-60px' });
  const supportersInView = useInView(supportersRef, { once: true, margin: '-60px' });

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Section 1: Hero ───────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[80vh] flex items-end overflow-hidden">
        <motion.div className="absolute inset-0" style={{ y: bgY }}>
          <img
            src="https://images.pexels.com/photos/3965545/pexels-photo-3965545.jpeg?auto=compress&cs=tinysrgb&w=1800&q=85"
            alt="Textile waste management"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(26,26,26,0.94) 0%, rgba(26,26,26,0.6) 48%, rgba(26,26,26,0.18) 100%)' }} />
        </motion.div>

        <div className="container-site relative z-10 pb-16 pt-40">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="text-caption font-semibold uppercase tracking-[0.15em] mb-5"
            style={{ color: TEAL }}
          >
            Textile Waste Management
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white leading-tight mb-6"
            style={{ fontSize: 'clamp(2.4rem, 5vw, 3.8rem)', letterSpacing: '-0.03em', maxWidth: 700 }}
          >
            Building a circular future for textile waste in India.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.22 }}
            className="text-body-lg leading-relaxed mb-10 max-w-2xl"
            style={{ color: 'rgba(255,255,255,0.72)' }}
          >
            From post-industrial offcuts to post-consumer garments, ReCircle builds end-to-end recovery systems that divert textile waste from landfills and return it to productive use.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.34 }}
            className="flex flex-col sm:flex-row gap-3"
          >
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-7 py-3.5 font-semibold text-sm transition-all duration-300 hover:opacity-90"
              style={{ backgroundColor: TEAL, color: '#0A1F3C' }}
            >
              Partner With Us
              <ArrowRight size={16} />
            </Link>
            <a
              href="#model"
              className="inline-flex items-center gap-2 px-7 py-3.5 font-medium text-sm border text-white transition-all duration-300 hover:bg-white/10"
              style={{ borderColor: 'rgba(255,255,255,0.3)' }}
            >
              How It Works
              <ChevronRight size={16} />
            </a>
          </motion.div>
        </div>
      </section>

      {/* ── Section 2: Problem Statement ─────────────────────────────────── */}
      <section ref={problemRef} className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <motion.div
            className="max-w-3xl mx-auto text-center"
            initial="hidden"
            animate={problemInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <motion.p
              initial="hidden"
              animate={problemInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={0}
              className="text-body-lg leading-[1.8] mb-8"
              style={{ color: 'rgba(255,255,255,0.75)' }}
            >
              {cms.problem_body}
            </motion.p>
            <motion.p
              initial="hidden"
              animate={problemInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={1}
              className="text-xl font-semibold leading-snug"
              style={{ color: TEAL }}
            >
              {cms.problem_closing}
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* ── Section 3: Our Model ──────────────────────────────────────────── */}
      <section id="model" ref={modelRef} className="section-padding bg-ivory">
        <div className="container-site">
          <motion.div
            className="mb-12"
            initial="hidden"
            animate={modelInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="OUR MODEL" />
            <h2
              className="font-display font-bold leading-tight mb-5"
              style={{ fontSize: 'clamp(1.8rem, 3vw, 2.5rem)', letterSpacing: '-0.03em', color: '#1A1A1A' }}
            >
              How ReCircle Works
            </h2>
            <p className="text-body-lg leading-relaxed max-w-3xl" style={{ color: '#5F5F5F' }}>
              {cms.model_intro}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {cms.model_pillars.map((card, i) => (
              <motion.div
                key={card.num}
                initial="hidden"
                animate={modelInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i + 1}
                className="p-7 bg-white border flex flex-col"
                style={{ borderColor: '#E8E8E8' }}
                whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.08)', y: -3 }}
                transition={{ duration: 0.2 }}
              >
                <div className="w-11 h-11 flex items-center justify-center mb-5" style={{ backgroundColor: '#E8EDF8', color: NAVY }}>
                  {MODEL_ICONS[i]}
                </div>
                <div
                  className="font-display font-black text-3xl mb-3 leading-none select-none"
                  style={{ color: 'rgba(1,41,138,0.12)', letterSpacing: '-0.04em' }}
                >
                  {card.num}
                </div>
                <h3 className="text-sm font-bold mb-2" style={{ color: '#1A1A1A' }}>
                  {card.title}
                </h3>
                <p className="text-sm leading-relaxed flex-1" style={{ color: '#858585' }}>
                  {card.body}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 4: Infrastructure (TRF) ──────────────────────────────── */}
      <section ref={infraRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-12 items-center">

            {/* Left — image */}
            <motion.div
              className="flex-1 w-full overflow-hidden"
              initial={{ opacity: 0, x: -24 }}
              animate={infraInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -24 }}
              transition={{ duration: 0.65, delay: 0.1 }}
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/3965545/pexels-photo-3965545.jpeg?auto=compress&cs=tinysrgb&w=1000&q=85"
                  alt="Textile Recovery Facility"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
            </motion.div>

            {/* Right — description + stats + button */}
            <motion.div
              className="flex-1 max-w-lg"
              initial="hidden"
              animate={infraInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={1}
            >
              <SectionLabel text="INFRASTRUCTURE" />
              <h2
                className="font-display font-bold leading-tight mb-5"
                style={{ fontSize: 'clamp(1.6rem, 2.8vw, 2.2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
              >
                Textile Recovery Facility
              </h2>
              <p className="text-body-lg leading-relaxed mb-8" style={{ color: '#5F5F5F' }}>
                {cms.trf_body}
              </p>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                {[
                  { value: cms.trf_stat_1_value, label: cms.trf_stat_1_label },
                  { value: cms.trf_stat_2_value, label: cms.trf_stat_2_label },
                ].map((stat, i) => (
                  <motion.div
                    key={i}
                    initial="hidden"
                    animate={infraInView ? 'visible' : 'hidden'}
                    variants={fadeUp}
                    custom={i + 2}
                    className="p-6 bg-white border"
                    style={{ borderColor: '#E8E8E8' }}
                  >
                    <p
                      className="font-display font-black leading-none mb-2"
                      style={{ fontSize: 'clamp(1.6rem, 3vw, 2.2rem)', letterSpacing: '-0.04em', color: NAVY }}
                    >
                      {stat.value}
                    </p>
                    <p className="text-xs leading-snug" style={{ color: '#858585' }}>
                      {stat.label}
                    </p>
                  </motion.div>
                ))}
              </div>

              <Link
                to="/infrastructure/trf"
                className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-semibold text-white transition-opacity hover:opacity-90"
                style={{ backgroundColor: NAVY }}
              >
                Explore the TRF
                <ArrowRight size={14} />
              </Link>
            </motion.div>

          </div>
        </div>
      </section>

      {/* ── Section 5: PITW / PCTW Redirect ─────────────────────────────── */}
      <section ref={redirectRef}>
        <div className="grid grid-cols-1 lg:grid-cols-2">

          {/* Left — PITW */}
          <motion.div
            className="flex flex-col"
            style={{ backgroundColor: '#F2EDE8' }}
            initial="hidden"
            animate={redirectInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={0}
          >
            <div className="px-12 pt-12 pb-0">
              <p className="text-caption font-semibold uppercase tracking-[0.15em] mb-4" style={{ color: TEAL }}>
                PITW
              </p>
              <h3
                className="font-display font-bold leading-tight mb-3"
                style={{ fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
              >
                Post-Industrial Textile Waste
              </h3>
              <p className="text-sm leading-relaxed mb-6" style={{ color: '#7A6F66' }}>
                Fabric offcuts, yarn waste, and deadstock material generated during manufacturing processes.
              </p>
            </div>
            {/* Image */}
            <div className="px-12 mb-6">
              <div className="aspect-[16/9] overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/3862130/pexels-photo-3862130.jpeg?auto=compress&cs=tinysrgb&w=800&q=85"
                  alt="Post-industrial textile waste"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="px-12 pb-12">
              <Link
                to="/textile/pitw"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold transition-opacity hover:opacity-90"
                style={{ backgroundColor: NAVY, color: '#ffffff' }}
              >
                Learn More
                <ArrowRight size={14} />
              </Link>
            </div>
          </motion.div>

          {/* Right — PCTW */}
          <motion.div
            className="flex flex-col"
            style={{ backgroundColor: '#EAF0F7' }}
            initial="hidden"
            animate={redirectInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
          >
            <div className="px-12 pt-12 pb-0">
              <p className="text-caption font-semibold uppercase tracking-[0.15em] mb-4" style={{ color: TEAL }}>
                PCTW
              </p>
              <h3
                className="font-display font-bold leading-tight mb-3"
                style={{ fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
              >
                Post-Consumer Textile Waste
              </h3>
              <p className="text-sm leading-relaxed mb-6" style={{ color: '#5A6E82' }}>
                Used clothing, worn textiles, and end-of-life garments collected from consumers and households.
              </p>
            </div>
            {/* Image */}
            <div className="px-12 mb-6">
              <div className="aspect-[16/9] overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/6192337/pexels-photo-6192337.jpeg?auto=compress&cs=tinysrgb&w=800&q=85"
                  alt="Post-consumer textile waste"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="px-12 pb-12">
              <Link
                to="/textile/pctw"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold transition-opacity hover:opacity-90"
                style={{ backgroundColor: NAVY, color: '#ffffff' }}
              >
                Learn More
                <ArrowRight size={14} />
              </Link>
            </div>
          </motion.div>

        </div>
      </section>

      {/* ── Section 6: Partner With Us ────────────────────────────────────── */}
      <section ref={partnerRef} className="section-padding" style={{ backgroundColor: NAVY }}>
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-16 items-start">

            {/* Left — heading + CTA */}
            <motion.div
              className="lg:w-2/5"
              initial="hidden"
              animate={partnerInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="PARTNER WITH US" light />
              <h2
                className="font-display font-bold text-white leading-tight mb-6"
                style={{ fontSize: 'clamp(1.8rem, 3.2vw, 2.6rem)', letterSpacing: '-0.03em' }}
              >
                Join a growing ecosystem.
              </h2>
              <p className="text-body-lg leading-relaxed mb-8" style={{ color: 'rgba(255,255,255,0.65)' }}>
                Whether you generate textile waste or want to build circular programmes, ReCircle connects you to a complete recovery ecosystem.
              </p>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-semibold transition-opacity hover:opacity-90"
                style={{ backgroundColor: TEAL, color: '#0A1F3C' }}
              >
                Partner with us
                <ArrowRight size={14} />
              </Link>
            </motion.div>

            {/* Right — category cards */}
            <motion.div
              className="flex-1"
              initial="hidden"
              animate={partnerInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={1}
            >
              <div className="space-y-3">
                {cms.partner_categories.map((tab, i) => {
                  const isActive = activeTab === i;
                  return (
                    <div key={tab.title}>
                      <button
                        type="button"
                        onClick={() => setActiveTab(isActive ? -1 : i)}
                        className="w-full flex items-center justify-between p-5 text-left transition-all duration-200"
                        style={{
                          backgroundColor: isActive ? 'rgba(255,255,255,0.10)' : 'rgba(255,255,255,0.04)',
                          border: `1px solid ${isActive ? 'rgba(0,196,153,0.5)' : 'rgba(255,255,255,0.10)'}`,
                        }}
                      >
                        <span className="text-sm font-bold text-white">{tab.title}</span>
                        <span style={{ color: isActive ? TEAL : 'rgba(255,255,255,0.4)', flexShrink: 0, marginLeft: 16 }}>
                          {isActive ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                        </span>
                      </button>
                      <AnimatePresence initial={false}>
                        {isActive && (
                          <motion.div
                            key="content"
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
                            className="overflow-hidden"
                          >
                            <div
                              className="px-5 py-4"
                              style={{ backgroundColor: 'rgba(255,255,255,0.03)', borderLeft: `2px solid ${TEAL}` }}
                            >
                              <p className="text-xs font-medium mb-2" style={{ color: 'rgba(255,255,255,0.4)' }}>
                                {tab.subtypes}
                              </p>
                              <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.7)' }}>
                                {tab.desc}
                              </p>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* ── Section 7: Powered by People ─────────────────────────────────── */}
      <section ref={peopleRef} className="section-padding" style={{ backgroundColor: '#F2EDE8' }}>
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-12 items-start">

            {/* Left — image */}
            <motion.div
              className="flex-1 w-full overflow-hidden"
              initial={{ opacity: 0, x: -24 }}
              animate={peopleInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -24 }}
              transition={{ duration: 0.65, delay: 0.1 }}
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/6192337/pexels-photo-6192337.jpeg?auto=compress&cs=tinysrgb&w=900&q=85"
                  alt="Waghri community"
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>

            {/* Right — heading + body + 2x2 boxes */}
            <div className="flex-1">
              <motion.div
                initial="hidden"
                animate={peopleInView ? 'visible' : 'hidden'}
                variants={fadeUp}
              >
                <SectionLabel text="POWERED BY PEOPLE" />
                <h2
                  className="font-display font-bold leading-tight mb-6"
                  style={{ fontSize: 'clamp(1.8rem, 3vw, 2.5rem)', letterSpacing: '-0.03em', color: '#1A1A1A' }}
                >
                  {cms.community_heading}
                </h2>
                <p className="text-body-lg leading-relaxed mb-3" style={{ color: '#6B5F56' }}>
                  {cms.community_body_1}
                </p>
                <p className="text-body-lg leading-relaxed mb-8" style={{ color: '#6B5F56' }}>
                  {cms.community_body_2}
                </p>
              </motion.div>

              {/* 2x2 commitment cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {COMMITMENT_CARDS.map((card, i) => (
                  <motion.div
                    key={card.verb}
                    initial="hidden"
                    animate={peopleInView ? 'visible' : 'hidden'}
                    variants={fadeUp}
                    custom={i + 1}
                    className="p-6 bg-white border"
                    style={{ borderColor: '#E8E8E8' }}
                  >
                    <h3
                      className="font-display font-bold text-xl mb-3 leading-none"
                      style={{ color: NAVY, letterSpacing: '-0.02em' }}
                    >
                      {card.verb}
                    </h3>
                    <p className="text-sm leading-relaxed" style={{ color: '#858585' }}>
                      {card.detail}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ── Section 8: Supporters ─────────────────────────────────────────── */}
      <section ref={supportersRef} className="section-padding bg-white border-t" style={{ borderColor: '#E8E8E8' }}>
        <div className="container-site text-center">

          <motion.div
            initial="hidden"
            animate={supportersInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="SUPPORTERS" center />
            <h3
              className="font-display font-bold leading-tight mb-4"
              style={{ fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', letterSpacing: '-0.025em', color: '#1A1A1A' }}
            >
              Circular change needs collective power.
            </h3>
            <motion.p
              initial="hidden"
              animate={supportersInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={1}
              className="text-body-lg mb-12 mx-auto"
              style={{ color: '#858585', maxWidth: 480 }}
            >
              ReCircle is backed by industry leaders who believe in a better future for textiles.
            </motion.p>
          </motion.div>

          {/* Supporter logo boxes */}
          <motion.div
            className="flex flex-wrap items-center justify-center gap-6"
            initial="hidden"
            animate={supportersInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={2}
          >
            {cms.supporters.map((supporter, i) => (
              <motion.div
                key={supporter.name}
                initial="hidden"
                animate={supportersInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i + 3}
                className="px-8 py-5 bg-white border flex items-center justify-center hover:border-teal-400 transition-all duration-200"
                style={{ borderColor: '#E0E0E0', minWidth: 180, minHeight: 80 }}
              >
                <img
                  src={SUPPORTER_DUMMY_LOGOS[i % SUPPORTER_DUMMY_LOGOS.length]}
                  alt={supporter.name}
                  className="h-10 w-auto object-contain grayscale opacity-60 hover:opacity-90 hover:grayscale-0 transition-all duration-300"
                />
              </motion.div>
            ))}
          </motion.div>

        </div>
      </section>

    </main>
  );
}
