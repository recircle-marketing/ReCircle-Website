import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Mail } from 'lucide-react';

const TEAL = '#00C499';
const NAVY = '#01298A';

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.5, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] },
  }),
};

interface Section {
  number: string;
  heading: string;
  content: React.ReactNode;
}

function SectionBlock({ section, index }: { section: Section; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-40px' });

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={inView ? 'visible' : 'hidden'}
      variants={fadeUp}
      custom={index % 4}
      className="scroll-mt-24"
      id={`section-${section.number}`}
    >
      <div className="flex gap-5 items-baseline mb-4">
        <span className="text-xs font-bold tabular-nums flex-shrink-0 w-6" style={{ color: TEAL }}>
          {section.number}
        </span>
        <h2 className="text-base font-bold" style={{ color: NAVY, letterSpacing: '-0.01em' }}>
          {section.heading}
        </h2>
      </div>
      <div className="ml-11 space-y-3 text-sm leading-relaxed" style={{ color: '#4A4A4A' }}>
        {section.content}
      </div>
    </motion.div>
  );
}

function Bullet({ children }: { children: React.ReactNode }) {
  return (
    <li className="flex gap-2.5 items-start">
      <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: TEAL }} />
      <span>{children}</span>
    </li>
  );
}

const SECTIONS: Section[] = [
  {
    number: '01',
    heading: 'Acceptance of Terms',
    content: (
      <>
        <p>By accessing or using any part of the ReCircle website, mobile application, or services (collectively, the "Platform"), you agree to be bound by these Terms of Use.</p>
        <p>If you do not agree to these terms, do not use the Platform.</p>
        <p>These Terms apply to all visitors, users, and other persons who access or use the Platform.</p>
      </>
    ),
  },
  {
    number: '02',
    heading: 'About ReCircle',
    content: (
      <>
        <p>ReCircle Recyclables Pvt. Ltd. is a waste management and circular economy company incorporated under the Companies Act 2013, operating from Mumbai, India.</p>
        <p>We provide services including but not limited to plastic and textile waste collection, EPR compliance support, CSR and ESG project management, recycled material supply, and traceability via our ClimaOne platform.</p>
      </>
    ),
  },
  {
    number: '03',
    heading: 'Use of the Platform',
    content: (
      <>
        <p>You may use the Platform for lawful purposes only. You agree not to:</p>
        <ul className="space-y-2 mt-3">
          <Bullet>Use the Platform in any way that violates applicable laws or regulations</Bullet>
          <Bullet>Transmit any unsolicited or unauthorised advertising or promotional material</Bullet>
          <Bullet>Introduce viruses, malicious code, or other harmful material</Bullet>
          <Bullet>Attempt to gain unauthorised access to any part of the Platform</Bullet>
          <Bullet>Impersonate any person or entity, or misrepresent your affiliation</Bullet>
          <Bullet>Reproduce, redistribute, or resell any part of our services without written permission</Bullet>
        </ul>
      </>
    ),
  },
  {
    number: '04',
    heading: 'Intellectual Property',
    content: (
      <>
        <p>All content on the Platform — including text, graphics, logos, images, and software — is the property of ReCircle Recyclables Pvt. Ltd. or its content suppliers and is protected under applicable intellectual property laws.</p>
        <p>You may not reproduce, modify, distribute, or publicly display any content from the Platform without our prior written consent.</p>
      </>
    ),
  },
  {
    number: '05',
    heading: 'User Accounts',
    content: (
      <>
        <p>If you create an account, you are responsible for maintaining the confidentiality of your credentials.</p>
        <p>You agree to notify us immediately of any unauthorised use of your account.</p>
        <p>We reserve the right to terminate or suspend accounts at our discretion.</p>
      </>
    ),
  },
  {
    number: '06',
    heading: 'Services and Transactions',
    content: (
      <>
        <p>Details of services, pricing, and deliverables are set out in individual service agreements or proposals.</p>
        <p>These Terms of Use govern your general use of the Platform and do not supersede any specific contractual arrangements.</p>
      </>
    ),
  },
  {
    number: '07',
    heading: 'Disclaimer of Warranties',
    content: (
      <>
        <p>The Platform is provided on an "as is" and "as available" basis, without warranties of any kind, either express or implied.</p>
        <p>We do not warrant that the Platform will be uninterrupted, error-free, or free of viruses or other harmful components.</p>
      </>
    ),
  },
  {
    number: '08',
    heading: 'Limitation of Liability',
    content: (
      <>
        <p>To the maximum extent permitted by law, ReCircle shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of, or inability to use, the Platform.</p>
        <p>Our total liability to you for any claims arising from use of the Platform shall not exceed the amount paid by you to ReCircle in the preceding three months.</p>
      </>
    ),
  },
  {
    number: '09',
    heading: 'Third Party Links and Services',
    content: (
      <>
        <p>The Platform may contain links to third-party websites or services. We are not responsible for the content, privacy practices, or availability of those external resources.</p>
      </>
    ),
  },
  {
    number: '10',
    heading: 'Governing Law and Dispute Resolution',
    content: (
      <>
        <p>These Terms are governed by the laws of India.</p>
        <p>Any dispute arising out of or relating to these Terms shall be subject to the exclusive jurisdiction of the courts of Mumbai, Maharashtra.</p>
        <p>We encourage resolution of disputes through good-faith discussion before initiating formal proceedings.</p>
      </>
    ),
  },
  {
    number: '11',
    heading: 'Modifications to Terms',
    content: (
      <>
        <p>We reserve the right to update or modify these Terms at any time. Changes will be effective immediately upon posting to the Platform.</p>
        <p>Your continued use of the Platform after changes are posted constitutes acceptance of the revised Terms.</p>
      </>
    ),
  },
  {
    number: '12',
    heading: 'Termination',
    content: (
      <>
        <p>We may terminate or suspend your access to the Platform immediately, without prior notice, for any reason, including breach of these Terms.</p>
      </>
    ),
  },
  {
    number: '13',
    heading: 'Contact',
    content: (
      <div className="p-5 border" style={{ borderColor: '#E8E8E8', backgroundColor: '#F8F6F3' }}>
        <p className="mb-3">For questions about these Terms, please contact us at:</p>
        <div className="space-y-1.5">
          <a
            href="mailto:legal@recircle.in"
            className="flex items-center gap-2 text-sm font-medium hover:opacity-75 transition-opacity"
            style={{ color: NAVY }}
          >
            <Mail size={14} />
            legal@recircle.in
          </a>
          <p className="text-sm" style={{ color: '#5F5F5F' }}>ReCircle Recyclables Pvt. Ltd., Mumbai, India</p>
        </div>
      </div>
    ),
  },
];

export default function TermsOfUsePage() {
  const heroRef = useRef<HTMLElement>(null);
  const inView = useInView(heroRef, { once: true });

  return (
    <main className="pt-[72px] min-h-screen" style={{ backgroundColor: '#F7F1EE' }}>

      {/* ── Hero ──────────────────────────────────────────────────────────── */}
      <section ref={heroRef} className="border-b" style={{ borderColor: '#E8E8E8', backgroundColor: 'white' }}>
        <div className="container-site py-14 md:py-20">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
          >
            <Link
              to="/"
              className="inline-flex items-center gap-1.5 text-xs font-medium mb-8 hover:opacity-75 transition-opacity"
              style={{ color: '#858585' }}
            >
              <ArrowLeft size={13} />
              Back to Home
            </Link>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-1 h-8" style={{ backgroundColor: NAVY }} />
              <span className="text-xs font-bold uppercase tracking-[0.15em]" style={{ color: NAVY }}>Legal</span>
            </div>

            <h1
              className="font-display font-bold leading-tight mb-4"
              style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.8rem)', letterSpacing: '-0.03em', color: '#1A1A1A' }}
            >
              Terms of Use
            </h1>
            <p className="text-sm" style={{ color: '#858585' }}>Last Updated: April 2025</p>
          </motion.div>
        </div>
      </section>

      {/* ── Main content ─────────────────────────────────────────────────── */}
      <div className="container-site py-14 md:py-20">
        <div className="max-w-3xl">

          {/* TOC */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.1 }}
            className="mb-14 p-6 bg-white border"
            style={{ borderColor: '#E8E8E8' }}
          >
            <p className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: NAVY }}>Contents</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2">
              {SECTIONS.map((s) => (
                <a
                  key={s.number}
                  href={`#section-${s.number}`}
                  className="flex items-center gap-2.5 text-xs hover:opacity-70 transition-opacity group"
                  style={{ color: '#5F5F5F' }}
                >
                  <span className="font-mono text-xs" style={{ color: NAVY }}>{s.number}</span>
                  <span className="group-hover:underline underline-offset-2">{s.heading}</span>
                </a>
              ))}
            </div>
          </motion.div>

          {/* Sections */}
          <div className="space-y-12">
            {SECTIONS.map((section, i) => (
              <div key={section.number}>
                <SectionBlock section={section} index={i} />
                {i < SECTIONS.length - 1 && (
                  <div className="mt-12 h-px" style={{ backgroundColor: '#E8E8E8' }} />
                )}
              </div>
            ))}
          </div>

          {/* Bottom note */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 0.3 }}
            className="mt-16 pt-8 border-t text-xs"
            style={{ borderColor: '#E8E8E8', color: '#ABABAB' }}
          >
            These Terms of Use are effective as of April 2025 and govern all access to and use of the ReCircle platform and services.
          </motion.div>
        </div>
      </div>

    </main>
  );
}
