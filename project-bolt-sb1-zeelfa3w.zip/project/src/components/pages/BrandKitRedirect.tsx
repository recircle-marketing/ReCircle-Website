import { useEffect } from 'react';

const BRAND_KIT_URL = 'https://drive.google.com/drive/folders/1tfDGoJ2VPTv65OE2B-gjiApT9btxRxRt?usp=drive_link';

export default function BrandKitRedirect() {
  useEffect(() => {
    window.open(BRAND_KIT_URL, '_blank', 'noopener,noreferrer');
    window.history.back();
  }, []);

  return (
    <main className="pt-20 min-h-screen flex items-center justify-center bg-ivory">
      <div className="text-center px-6">
        <p className="text-sm mb-3" style={{ color: '#858585' }}>Opening Brand Kit in a new tab…</p>
        <a
          href={BRAND_KIT_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm font-semibold underline"
          style={{ color: '#01298A' }}
        >
          Click here if it didn't open
        </a>
      </div>
    </main>
  );
}
