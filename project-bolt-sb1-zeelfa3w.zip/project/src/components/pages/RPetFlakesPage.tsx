import { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { ArrowRight, Mail, Phone, Filter, Cpu, Wrench, TrendingUp, Recycle, Eye, BarChart2, Building2, CheckCircle, Layers, Beaker, Grid2x2 as Grid } from 'lucide-react';
import {
  getRpetPageSettings,
  getRpetApplications,
  getRpetAdvantageCards,
  getRpetBenchmarkCards,
} from '../../cms/queries';
import type { RpetPageSettings, RpetApplication, RpetAdvantageCard, RpetBenchmarkCard } from '../../cms/types';

// ── Icon map ────────────────────────────────────────────────────────────────
const ICON_MAP: Record<string, React.ReactNode> = {
  Filter: <Filter size={24} />,
  Cpu: <Cpu size={24} />,
  Wrench: <Wrench size={24} />,
  TrendingUp: <TrendingUp size={24} />,
  Recycle: <Recycle size={24} />,
  Eye: <Eye size={24} />,
  BarChart2: <BarChart2 size={24} />,
  Building2: <Building2 size={24} />,
  CheckCircle: <CheckCircle size={24} />,
  Layers: <Layers size={24} />,
  Beaker: <Beaker size={24} />,
  Grid: <Grid size={24} />,
};

function getIcon(name: string) {
  return ICON_MAP[name] ?? <CheckCircle size={24} />;
}

// ── Default content (fallback) ──────────────────────────────────────────────
const DEFAULT_SETTINGS: RpetPageSettings = {
  id: '',
  hero_heading: 'Advancing Circularity Through High-Quality rPET Flakes',
  hero_body: 'As one of the top plastic recycling companies, our rPET flakes are made from 100% post-consumer plastic. Food-grade safe by design, our recycled flakes integrate smoothly with virgin PET and perform consistently across a wide range of applications.',
  hero_cta_label: 'Inquire Now',
  hero_cta_href: '/contact',
  hero_image_url: 'https://images.pexels.com/photos/3850512/pexels-photo-3850512.jpeg?auto=compress&cs=tinysrgb&w=1200&q=85',
  applications_label: 'APPLICATIONS',
  applications_intro: 'Our rPET flakes are versatile and widely used in:',
  tech_specs_label: 'TECHNICAL SPECIFICATIONS',
  tech_specs_heading: 'Recycled PET that leaves no room for doubt',
  tech_specs_body: 'From low moisture levels and zero contamination by PVC, PP/PE, and metals to clean polymer filtration at 20 microns, the technical specification sheet provides a clear view of how we meet defined quality benchmarks.',
  tech_specs_cta_label: 'Enquire for Specifications',
  tech_specs_cta_href: '/contact',
  tech_specs_image_url: 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg?auto=compress&cs=tinysrgb&w=900&q=85',
  advantages_label: 'OPERATIONAL ADVANTAGES',
  advantages_heading: 'rPET flakes built for the realities of your production line',
  advantages_body: 'When you\'re running a line, consistency matters more than promises. Our food-grade rPET flakes are produced with tight process control and minimal contamination, so your equipment stays cleaner, your process stays stable, and your day runs with fewer surprises.',
  benchmarks_label: 'OUR PILLARS OF ETHICAL RECYCLING',
  benchmarks_heading: 'The 4 quality benchmarks of ReCircle\'s recycled plastic flakes',
  benchmarks_intro: 'With our rPET flakes, we enable industries to adopt circular packaging materials that work as reliably as virgin plastics.',
  benchmarks_cta_label: 'Talk to Our rPET Experts',
  benchmarks_cta_href: '/contact',
  climaone_label: 'TECH-DRIVEN TRACEABILITY',
  climaone_heading: 'Gain control over your BIS targets with ease',
  climaone_body_1: 'Plastic recycling only works when every step is transparent. Which is why we built a tech platform that connects every stakeholder across the plastic recycling chain.',
  climaone_body_2: 'From the first bottle collected to the final rPET flakes produced, ClimaOne tracks every movement of recycled plastic in real time and provides businesses with complete transparency across the supply chain, aligned with BIS standards.',
  climaone_cta_label: 'Explore ClimaOne',
  climaone_cta_href: 'https://climaonev2.recircle.in/',
  climaone_image_url: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=900&q=85',
  certifications_label: 'CERTIFICATIONS',
  certifications_heading: 'Tested to meet EU food-contact requirements',
  certifications_body: 'Our rPET flakes are tested by Intertek and checked against European food-contact regulations, including EC 1935/2004 and EU 10/2011. They meet migration limits and REACH SVHC requirements, making them a reliable option for regulated packaging applications.',
  certifications_image_url: 'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=900&q=85',
  contact_band_label: 'CONTACT US',
  contact_band_heading: 'Empower your recycling journey with ReCircle',
  contact_band_body: 'Connect with us today for high-quality recycled plastic flakes from one of the top 10 plastic recycling companies in India.',
  contact_band_email: 'info@recircle.in',
  contact_band_phone: '+91 90042 40004',
  updated_at: '',
};

const DEFAULT_APPLICATIONS: RpetApplication[] = [
  { id: '1', sort_order: 1, is_active: true, title: 'rPET Chips / Resins', spec_callout: 'With contamination <30 ppm, our rPET flakes support B2B manufacturing.', image_url: 'https://images.pexels.com/photos/3825578/pexels-photo-3825578.jpeg?auto=compress&cs=tinysrgb&w=800&q=85', image_alt: 'rPET chips', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, title: 'Films', spec_callout: 'A bulk density of 0.31 g/cc helps maintain steady feeding and consistent film output.', image_url: 'https://images.pexels.com/photos/4483610/pexels-photo-4483610.jpeg?auto=compress&cs=tinysrgb&w=800&q=85', image_alt: 'Plastic films', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, title: 'Sheets', spec_callout: 'An IV range of 0.72–0.80 dL/g delivers the melt strength needed for thermoforming.', image_url: 'https://images.pexels.com/photos/4246110/pexels-photo-4246110.jpeg?auto=compress&cs=tinysrgb&w=800&q=85', image_alt: 'PET sheets', created_at: '', updated_at: '' },
  { id: '4', sort_order: 4, is_active: true, title: 'Additives', spec_callout: 'Low ash content (0.022 wt%) allows smooth blending without introducing impurities.', image_url: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=800&q=85', image_alt: 'Plastic additives', created_at: '', updated_at: '' },
];

const DEFAULT_ADVANTAGES: RpetAdvantageCard[] = [
  { id: '1', sort_order: 1, is_active: true, icon_name: 'Filter', heading: 'Longer Filter Life', body: 'Our low-contamination recycled flakes reduce residue buildup in your melt filters, helping them last longer between changeovers and reducing unnecessary interruptions.', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, icon_name: 'Cpu', heading: 'Reduced Machine Downtime', body: 'Because our recycled plastic flakes are uniformly sized and thoroughly washed, they move smoothly through your line, reducing the risk of blockages or sudden production stops.', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, icon_name: 'Wrench', heading: 'Lower Maintenance Costs', body: 'With zero metal and non-PET contamination, your screws, barrels, and dyes face less long-term wear, keeping maintenance cycles predictable and under control.', created_at: '', updated_at: '' },
  { id: '4', sort_order: 4, is_active: true, icon_name: 'TrendingUp', heading: 'Improved Line Efficiency', body: 'With consistent quality, batch-after-batch, your production line stays steady, making daily output easier to manage without frequent process tweaks.', created_at: '', updated_at: '' },
];

const DEFAULT_BENCHMARKS: RpetBenchmarkCard[] = [
  { id: '1', sort_order: 1, is_active: true, icon_name: 'Recycle', heading: '100% Post-Consumer rPET Flakes', body: 'Sourced through a pan-India recovery network, our rPET flakes are made from 100% post-consumer PET, delivering circular packaging materials at scale.', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, icon_name: 'Eye', heading: 'Complete Transparency & Traceability', body: 'Powered by ClimaOne\'s real-time data, every batch of recycled plastic flakes are traceable from collection to processing, ensuring compliance with BIS & CPCB standards.', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, icon_name: 'BarChart2', heading: 'Consistent High-Quality Output', body: 'Engineered to exact specifications, our rPET flakes deliver consistent purity and grades, batch after batch.', created_at: '', updated_at: '' },
  { id: '4', sort_order: 4, is_active: true, icon_name: 'Building2', heading: 'Advanced Infrastructure & Tech', body: 'Our state-of-the-art facility in Bhiwani delivers precision, scale, and a reliable supply of high-grade recycled PET that meets global standards.', created_at: '', updated_at: '' },
];

// ── Reusable animation variants ─────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

const slideLeft = {
  hidden: { opacity: 0, x: -40 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

const slideRight = {
  hidden: { opacity: 0, x: 40 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

// ── SectionLabel ─────────────────────────────────────────────────────────────
function SectionLabel({ text }: { text: string }) {
  return (
    <p className="text-caption font-semibold uppercase tracking-[0.15em] mb-4" style={{ color: '#01298A' }}>
      {text}
    </p>
  );
}

// ── NavLink helper ────────────────────────────────────────────────────────────
function NavLinkEl({ href, children, className }: { href: string; children: React.ReactNode; className?: string }) {
  const isExternal = href.startsWith('http') || href.startsWith('mailto');
  if (isExternal) {
    return <a href={href} target="_blank" rel="noopener noreferrer" className={className}>{children}</a>;
  }
  return <Link to={href} className={className}>{children}</Link>;
}

// ── Highlight numbers in spec callout ────────────────────────────────────────
function HighlightSpec({ text }: { text: string }) {
  const parts = text.split(/(\b[\d.,–]+\s*(?:ppm|g\/cc|dL\/g|wt%|%|microns)?)/g);
  return (
    <span>
      {parts.map((part, i) =>
        /[\d.,–]/.test(part) ? (
          <span key={i} className="font-bold text-base" style={{ color: '#01298A' }}>{part}</span>
        ) : (
          <span key={i}>{part}</span>
        )
      )}
    </span>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function RPetFlakesPage() {
  const [settings, setSettings] = useState<RpetPageSettings>(DEFAULT_SETTINGS);
  const [applications, setApplications] = useState<RpetApplication[]>(DEFAULT_APPLICATIONS);
  const [advantages, setAdvantages] = useState<RpetAdvantageCard[]>(DEFAULT_ADVANTAGES);
  const [benchmarks, setBenchmarks] = useState<RpetBenchmarkCard[]>(DEFAULT_BENCHMARKS);
  const [activeTab, setActiveTab] = useState(0);

  useEffect(() => {
    Promise.all([
      getRpetPageSettings(),
      getRpetApplications(),
      getRpetAdvantageCards(),
      getRpetBenchmarkCards(),
    ]).then(([s, apps, adv, bench]) => {
      if (s) setSettings(s);
      if (apps.length) setApplications(apps);
      if (adv.length) setAdvantages(adv);
      if (bench.length) setBenchmarks(bench);
    });
  }, []);

  // Refs for in-view triggers
  const specsRef = useRef<HTMLElement>(null);
  const advantagesRef = useRef<HTMLElement>(null);
  const benchmarksRef = useRef<HTMLElement>(null);
  const climaoneRef = useRef<HTMLElement>(null);
  const certsRef = useRef<HTMLElement>(null);
  const contactRef = useRef<HTMLElement>(null);

  const specsInView = useInView(specsRef, { once: true, margin: '-80px' });
  const advantagesInView = useInView(advantagesRef, { once: true, margin: '-60px' });
  const benchmarksInView = useInView(benchmarksRef, { once: true, margin: '-60px' });
  const climaoneInView = useInView(climaoneRef, { once: true, margin: '-80px' });
  const certsInView = useInView(certsRef, { once: true, margin: '-80px' });
  const contactInView = useInView(contactRef, { once: true, margin: '-60px' });

  const heroImage = settings.hero_image_url || DEFAULT_SETTINGS.hero_image_url;
  const techSpecsImage = settings.tech_specs_image_url || DEFAULT_SETTINGS.tech_specs_image_url;
  const climaoneImage = settings.climaone_image_url || DEFAULT_SETTINGS.climaone_image_url;
  const certsImage = settings.certifications_image_url || DEFAULT_SETTINGS.certifications_image_url;

  return (
    <main className="pt-[72px]">

      {/* ── Section 1: Hero ──────────────────────────────────────────────── */}
      <section className="section-padding bg-ivory overflow-hidden">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            {/* Text */}
            <div className="flex-1 max-w-xl">
              <motion.p
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45 }}
                className="text-caption font-semibold uppercase tracking-[0.15em] mb-4"
                style={{ color: '#01298A' }}
              >
                rPET Flakes
              </motion.p>
              <motion.h1
                initial={{ opacity: 0, y: 28 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
                className="font-display text-display-md font-bold leading-tight mb-6"
                style={{ color: '#1A1A1A' }}
              >
                {settings.hero_heading}
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.22, ease: [0.22, 1, 0.36, 1] }}
                className="text-body-lg leading-relaxed mb-8"
                style={{ color: '#5F5F5F' }}
              >
                {settings.hero_body}
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.36, ease: [0.22, 1, 0.36, 1] }}
              >
                <NavLinkEl href={settings.hero_cta_href} className="btn-primary inline-flex items-center gap-2">
                  {settings.hero_cta_label}
                  <ArrowRight size={16} />
                </NavLinkEl>
              </motion.div>
            </div>

            {/* Product image */}
            <motion.div
              className="flex-1 w-full max-w-xl lg:max-w-none relative"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="relative overflow-hidden aspect-[4/3]" style={{ backgroundColor: '#E8EDF8' }}>
                <img
                  src={heroImage}
                  alt="High-quality rPET flakes"
                  className="w-full h-full object-cover"
                  loading="eager"
                />
                {/* Accent badge */}
                <div className="absolute top-6 right-6 bg-white px-4 py-3 shadow-card">
                  <p className="text-xs font-bold uppercase tracking-widest" style={{ color: '#01298A' }}>100% Post-Consumer</p>
                  <p className="text-xs mt-0.5" style={{ color: '#858585' }}>Food-Grade Safe</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 2: Applications ──────────────────────────────────────── */}
      <section className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={fadeUp}
            className="mb-10"
          >
            <SectionLabel text={settings.applications_label} />
            <p className="text-body-lg" style={{ color: 'rgba(255,255,255,0.75)' }}>{settings.applications_intro}</p>
          </motion.div>

          {/* Tab labels */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-40px' }}
            variants={fadeUp}
            custom={0.5}
            className="flex flex-wrap gap-2 mb-8"
          >
            {applications.map((app, i) => (
              <button
                key={app.id}
                onClick={() => setActiveTab(i)}
                className="relative px-5 py-2.5 text-sm font-medium transition-all duration-200"
                style={{
                  color: activeTab === i ? '#1A1A1A' : 'rgba(255,255,255,0.6)',
                  backgroundColor: activeTab === i ? '#DCEB4B' : 'transparent',
                  border: activeTab === i ? 'none' : '1px solid rgba(255,255,255,0.15)',
                }}
              >
                {app.title}
              </button>
            ))}
          </motion.div>

          {/* Tab content */}
          <div className="relative">
            <AnimatePresence mode="wait">
              {applications[activeTab] && (
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3, ease: 'easeOut' }}
                  className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center"
                >
                  {/* Image */}
                  <div className="overflow-hidden aspect-[4/3] order-2 lg:order-1" style={{ backgroundColor: '#2E2E2E' }}>
                    {applications[activeTab].image_url ? (
                      <img
                        src={applications[activeTab].image_url}
                        alt={applications[activeTab].image_alt || applications[activeTab].title}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Layers size={48} style={{ color: '#3A3A3A' }} />
                      </div>
                    )}
                  </div>

                  {/* Spec callout */}
                  <div className="order-1 lg:order-2 flex flex-col justify-center">
                    <h3 className="font-display text-heading-xl font-bold text-white mb-6">
                      {applications[activeTab].title}
                    </h3>
                    <div className="p-6 border-l-4" style={{ borderColor: '#DCEB4B', backgroundColor: 'rgba(220,235,75,0.06)' }}>
                      <p className="text-body-lg leading-relaxed" style={{ color: 'rgba(255,255,255,0.85)' }}>
                        <HighlightSpec text={applications[activeTab].spec_callout} />
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* ── Section 3: Technical Specifications ─────────────────────────── */}
      <section ref={specsRef} className="section-padding bg-ivory overflow-hidden">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            {/* Left */}
            <motion.div
              className="flex-1 max-w-lg"
              initial="hidden"
              animate={specsInView ? 'visible' : 'hidden'}
              variants={slideLeft}
            >
              <SectionLabel text={settings.tech_specs_label} />
              <h2 className="font-display text-display-sm font-bold mb-6" style={{ color: '#1A1A1A' }}>
                {settings.tech_specs_heading}
              </h2>
              <p className="text-body-lg leading-relaxed mb-8" style={{ color: '#5F5F5F' }}>
                {settings.tech_specs_body}
              </p>
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={specsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 12 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <NavLinkEl href={settings.tech_specs_cta_href} className="btn-primary inline-flex items-center gap-2">
                  {settings.tech_specs_cta_label}
                  <ArrowRight size={16} />
                </NavLinkEl>
              </motion.div>
            </motion.div>

            {/* Right — spec sheet visual */}
            <motion.div
              className="flex-1 w-full"
              initial="hidden"
              animate={specsInView ? 'visible' : 'hidden'}
              variants={slideRight}
            >
              <div className="overflow-hidden relative" style={{ backgroundColor: '#E8EDF8' }}>
                <img
                  src={techSpecsImage}
                  alt="Technical specifications sheet"
                  className="w-full object-cover aspect-[4/3]"
                  loading="lazy"
                />
                {/* Overlay spec data graphic */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'PVC contamination', value: '<5 ppm' },
                      { label: 'Moisture', value: '<0.5%' },
                      { label: 'Filtration', value: '20 microns' },
                      { label: 'Metal contamination', value: 'Zero' },
                    ].map((spec) => (
                      <div key={spec.label} className="bg-white/90 backdrop-blur-sm px-4 py-3">
                        <p className="text-xs font-bold" style={{ color: '#01298A' }}>{spec.value}</p>
                        <p className="text-xs mt-0.5" style={{ color: '#5F5F5F' }}>{spec.label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 4: Operational Advantages ───────────────────────────── */}
      <section ref={advantagesRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={advantagesInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="max-w-2xl mb-14"
          >
            <SectionLabel text={settings.advantages_label} />
            <h2 className="font-display text-display-sm font-bold mb-5" style={{ color: '#1A1A1A' }}>
              {settings.advantages_heading}
            </h2>
            <p className="text-body-lg leading-relaxed" style={{ color: '#5F5F5F' }}>
              {settings.advantages_body}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {advantages.map((card, i) => (
              <motion.div
                key={card.id}
                initial="hidden"
                animate={advantagesInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                whileHover={{ y: -4, boxShadow: '0 8px 32px rgba(1,41,138,0.14)' }}
                transition={{ duration: 0.2 }}
                className="bg-white p-7 border"
                style={{ borderColor: '#E8E8E8' }}
              >
                <motion.div
                  className="mb-5 w-12 h-12 flex items-center justify-center"
                  style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}
                  whileHover={{ backgroundColor: '#01298A', color: '#fff' }}
                  transition={{ duration: 0.2 }}
                >
                  {getIcon(card.icon_name)}
                </motion.div>
                <h3 className="text-base font-bold mb-3" style={{ color: '#1A1A1A' }}>{card.heading}</h3>
                <p className="text-body-sm leading-relaxed" style={{ color: '#5F5F5F' }}>{card.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 5: Quality Benchmarks ───────────────────────────────── */}
      <section ref={benchmarksRef} className="section-padding bg-ivory">
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={benchmarksInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="max-w-2xl mb-14"
          >
            <SectionLabel text={settings.benchmarks_label} />
            <h2 className="font-display text-display-sm font-bold mb-5" style={{ color: '#1A1A1A' }}>
              {settings.benchmarks_heading}
            </h2>
            <p className="text-body-lg leading-relaxed" style={{ color: '#5F5F5F' }}>
              {settings.benchmarks_intro}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {benchmarks.map((card, i) => (
              <motion.div
                key={card.id}
                initial="hidden"
                animate={benchmarksInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="bg-white p-7 border"
                style={{ borderColor: '#E8E8E8' }}
              >
                <motion.div
                  className="mb-5 w-12 h-12 flex items-center justify-center"
                  style={{ color: '#00C499', backgroundColor: '#E0FAF4' }}
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.2 }}
                >
                  {getIcon(card.icon_name)}
                </motion.div>
                <h3 className="text-base font-bold mb-3 leading-snug" style={{ color: '#1A1A1A' }}>{card.heading}</h3>
                <p className="text-body-sm leading-relaxed" style={{ color: '#5F5F5F' }}>{card.body}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial="hidden"
            animate={benchmarksInView ? 'visible' : 'hidden'}
            variants={{ ...fadeUp, visible: { opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.45 } } }}
          >
            <NavLinkEl href={settings.benchmarks_cta_href} className="btn-primary inline-flex items-center gap-2">
              {settings.benchmarks_cta_label}
              <ArrowRight size={16} />
            </NavLinkEl>
          </motion.div>
        </div>
      </section>

      {/* ── Section 6: ClimaOne Traceability ─────────────────────────────── */}
      <section ref={climaoneRef} className="section-padding overflow-hidden" style={{ backgroundColor: '#01298A' }}>
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            {/* Left */}
            <motion.div
              className="flex-1 max-w-lg"
              initial="hidden"
              animate={climaoneInView ? 'visible' : 'hidden'}
              variants={slideLeft}
            >
              <p className="text-caption font-semibold uppercase tracking-[0.15em] mb-4" style={{ color: '#DCEB4B' }}>
                {settings.climaone_label}
              </p>
              <h2 className="font-display text-display-sm font-bold text-white mb-6">
                {settings.climaone_heading}
              </h2>
              <p className="text-body-lg leading-relaxed mb-5" style={{ color: 'rgba(255,255,255,0.8)' }}>
                {settings.climaone_body_1}
              </p>
              <p className="text-body-lg leading-relaxed mb-8" style={{ color: 'rgba(255,255,255,0.8)' }}>
                {settings.climaone_body_2}
              </p>
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={climaoneInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 12 }}
                transition={{ duration: 0.5, delay: 0.45 }}
              >
                <NavLinkEl
                  href={settings.climaone_cta_href}
                  className="inline-flex items-center gap-2 px-6 py-3 font-medium text-body-sm transition-all duration-300"
                  style={{ backgroundColor: '#DCEB4B', color: '#1A1A1A' }}
                >
                  {settings.climaone_cta_label}
                  <ArrowRight size={16} />
                </NavLinkEl>
              </motion.div>
            </motion.div>

            {/* Right — ClimaOne platform visual */}
            <motion.div
              className="flex-1 w-full"
              initial="hidden"
              animate={climaoneInView ? 'visible' : 'hidden'}
              variants={slideRight}
            >
              <div className="overflow-hidden relative border border-white/10" style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}>
                <img
                  src={climaoneImage}
                  alt="ClimaOne traceability platform"
                  className="w-full object-cover aspect-[4/3]"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-transparent pointer-events-none" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 7: Certifications ────────────────────────────────────── */}
      <section ref={certsRef} className="section-padding bg-ivory overflow-hidden">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            {/* Left */}
            <motion.div
              className="flex-1 max-w-lg"
              initial="hidden"
              animate={certsInView ? 'visible' : 'hidden'}
              variants={slideLeft}
            >
              <SectionLabel text={settings.certifications_label} />
              <h2 className="font-display text-display-sm font-bold mb-6" style={{ color: '#1A1A1A' }}>
                {settings.certifications_heading}
              </h2>
              <p className="text-body-lg leading-relaxed" style={{ color: '#5F5F5F' }}>
                {settings.certifications_body}
              </p>

              {/* Regulation badges */}
              <div className="mt-8 flex flex-wrap gap-3">
                {['EC 1935/2004', 'EU 10/2011', 'REACH SVHC', 'Intertek Tested'].map((badge) => (
                  <span
                    key={badge}
                    className="px-4 py-2 border text-xs font-semibold uppercase tracking-widest"
                    style={{ borderColor: '#01298A', color: '#01298A', backgroundColor: '#F0F4FC' }}
                  >
                    {badge}
                  </span>
                ))}
              </div>
            </motion.div>

            {/* Right — cert image */}
            <motion.div
              className="flex-1 w-full"
              initial={{ opacity: 0, scale: 0.97 }}
              animate={certsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="overflow-hidden aspect-[4/3]" style={{ backgroundColor: '#E8EDF8' }}>
                <img
                  src={certsImage}
                  alt="Certifications"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 8: Contact CTA Band ───────────────────────────────────── */}
      <section ref={contactRef} className="section-padding" style={{ backgroundColor: '#0D1F5C' }}>
        <div className="container-site text-center">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={contactInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 12 }}
            transition={{ duration: 0.45 }}
            className="text-caption font-semibold uppercase tracking-[0.15em] mb-4"
            style={{ color: '#DCEB4B' }}
          >
            {settings.contact_band_label}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            animate={contactInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 }}
            transition={{ duration: 0.55, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display text-display-sm font-bold text-white mb-5 max-w-2xl mx-auto"
          >
            {settings.contact_band_heading}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={contactInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
            transition={{ duration: 0.55, delay: 0.2 }}
            className="text-body-lg mb-10 max-w-xl mx-auto"
            style={{ color: 'rgba(255,255,255,0.75)' }}
          >
            {settings.contact_band_body}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={contactInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 12 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-10"
          >
            <a
              href={`mailto:${settings.contact_band_email}`}
              className="flex items-center gap-3 text-sm font-medium transition-opacity hover:opacity-80"
              style={{ color: 'rgba(255,255,255,0.9)' }}
            >
              <div className="w-9 h-9 flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.15)' }}>
                <Mail size={16} style={{ color: '#DCEB4B' }} />
              </div>
              {settings.contact_band_email}
            </a>
            <a
              href={`tel:${settings.contact_band_phone.replace(/\s/g, '')}`}
              className="flex items-center gap-3 text-sm font-medium transition-opacity hover:opacity-80"
              style={{ color: 'rgba(255,255,255,0.9)' }}
            >
              <div className="w-9 h-9 flex items-center justify-center" style={{ backgroundColor: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.15)' }}>
                <Phone size={16} style={{ color: '#DCEB4B' }} />
              </div>
              {settings.contact_band_phone}
            </a>
          </motion.div>
        </div>
      </section>

    </main>
  );
}
