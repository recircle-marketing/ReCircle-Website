import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Download, ExternalLink } from 'lucide-react';
import { getAnnualReportsPageSettings, getAnnualReportItems } from '../../cms/queries';
import type { AnnualReportsPageSettings, AnnualReportItem } from '../../cms/types';

const FALLBACK_SETTINGS: AnnualReportsPageSettings = {
  id: '',
  hero_heading: 'A Year of Ethical Circularity',
  hero_body: "We began with a simple question: What if nothing, not a single material or the person recovering it, got left behind? This year, that question became our way-forward. From Safai Saathis turning waste into opportunities to partners closing loops across industries, every story within the report begins and ends with people, the hands, hearts and minds that turn our world.",
  hero_cta_text: 'STEP INSIDE OUR CIRCLE.',
  reports_heading: 'Read Our Previous Impact Reports Here',
  updated_at: '',
};

const FALLBACK_REPORTS: AnnualReportItem[] = [
  { id: '1', sort_order: 1, is_active: true, year_label: '2023-24', button_text: 'Download for 2023-24', report_url: '', title: '', report_year: 2024, created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, year_label: '2022-23', button_text: 'Download for 2022-23', report_url: '', title: '', report_year: 2023, created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, year_label: '2021-22', button_text: 'Download for 2021-22', report_url: '', title: '', report_year: 2022, created_at: '', updated_at: '' },
];

export default function AnnualReportsPage() {
  const [settings, setSettings] = useState<AnnualReportsPageSettings>(FALLBACK_SETTINGS);
  const [reports, setReports] = useState<AnnualReportItem[]>(FALLBACK_REPORTS);

  useEffect(() => {
    Promise.all([getAnnualReportsPageSettings(), getAnnualReportItems()]).then(([s, r]) => {
      if (s) setSettings(s);
      const active = r.filter((x) => x.is_active);
      if (active.length) setReports(active);
    });
  }, []);

  return (
    <main className="pt-20">
      {/* Hero */}
      <section className="section-padding" style={{ backgroundColor: '#01298A' }}>
        <div className="container-site">
          <div className="max-w-3xl">
            <motion.p
              className="text-xs font-semibold uppercase tracking-widest mb-5"
              style={{ color: '#DCEB4B' }}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Annual Reports
            </motion.p>
            <motion.h1
              className="font-display text-display-md font-bold text-white mb-8"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              {settings.hero_heading}
            </motion.h1>
            <motion.p
              className="text-body-lg leading-relaxed mb-10"
              style={{ color: 'rgba(255,255,255,0.8)' }}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              {settings.hero_body}
            </motion.p>
            <motion.p
              className="text-sm font-bold uppercase tracking-[0.2em]"
              style={{ color: '#DCEB4B' }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.35 }}
            >
              {settings.hero_cta_text}
            </motion.p>
          </div>
        </div>
      </section>

      {/* Previous Reports */}
      <section className="section-padding bg-ivory">
        <div className="container-site">
          <motion.h2
            className="font-display text-heading-xl font-bold mb-10"
            style={{ color: '#1A1A1A' }}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            {settings.reports_heading}
          </motion.h2>

          <motion.div
            className="flex flex-col sm:flex-row flex-wrap gap-5"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            {reports.map((report, i) => (
              <motion.a
                key={report.id}
                href={report.report_url || '#'}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className={`group inline-flex items-center gap-3 px-8 py-4 border-2 font-semibold text-sm uppercase tracking-widest transition-all ${!report.report_url ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-primary hover:text-white hover:border-blue-primary'}`}
                style={{ borderColor: '#01298A', color: '#01298A' }}
                onClick={(e) => { if (!report.report_url) e.preventDefault(); }}
              >
                <Download size={16} className="transition-transform group-hover:translate-y-0.5" />
                {report.button_text}
                <ExternalLink size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.a>
            ))}
          </motion.div>
        </div>
      </section>
    </main>
  );
}
