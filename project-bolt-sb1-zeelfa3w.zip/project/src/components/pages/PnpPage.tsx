import { useRef, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight, ChevronRight, CheckCircle, Zap, Globe, BarChart2,
  Eye, Cpu, DollarSign, Megaphone, TrendingUp, Layers,
  ShieldCheck, Award, Users,
} from 'lucide-react';
import { getPnpPageSettings } from '../../cms/queries';
import type { PnpPageSettings } from '../../cms/types';

// ── Animation variants ────────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.6, ease: 'easeOut' } },
};

// ── Default / fallback CMS content ───────────────────────────────────────────
const DEFAULT_CMS: PnpPageSettings = {
  id: '',
  hero_heading: 'Zero Plastic Footprint. Verified. Certified. Yours.',
  hero_body: 'Every business leaves behind a plastic footprint. Plastic Neutrality means taking full accountability of yours. Measure it. Reduce it. Offset what remains.',
  hero_tag: 'Voluntary',
  programme_heading: 'What is the Plastic Neutral Program?',
  programme_body: "Plastic Neutrality is the commitment a business makes to offset every gram of plastic it introduces into the market. Through verified collection, sorting, and recycling, that equivalent volume of plastic is recovered — closing the loop. ReCircle's PNP provides end-to-end support: from measuring your plastic footprint to managing offset projects and issuing your certified Plastic Neutral status — backed by our proprietary ClimaOne platform.",
  steps_heading: 'How It Works',
  steps: [
    { step: '01', title: 'Measure', body: 'Quantify the plastic your business places into the market.' },
    { step: '02', title: 'Reduce', body: 'Identify and act on reduction opportunities across your supply chain.' },
    { step: '03', title: 'Offset', body: 'Recover an equivalent volume of plastic through verified collection and recycling.' },
  ],
  benefits_heading: 'Why ReCircle',
  benefits: [
    { title: 'Smart Tech Platform', body: 'Track your plastic journey with transparent data and real insights through ClimaOne, our proprietary supply chain platform.' },
    { title: 'Pan-India Collection Network', body: 'With 310+ waste recovery locations across the country, our reach ensures no corner is left behind.' },
    { title: 'Flexible for Every Budget', body: 'Whichever industry you operate in, we structure plastic neutrality to work within your financial means.' },
    { title: 'Impact Visibility', body: 'Your sustainability wins do not stay hidden. We help you share them with customers, media, and stakeholders.' },
    { title: 'Cost-Effective Recovery', body: 'Every rupee spent on recovery also drives visibility, credibility, and brand loyalty.' },
    { title: 'MLP Specialists', body: 'We are one of the few global PNP providers specializing in Multi-Layered Plastics, the hardest category to recycle.' },
  ],
  updated_at: '',
};

// ── Step icon map (cycles) ────────────────────────────────────────────────────
const STEP_ICONS = [
  <BarChart2 size={24} />,
  <TrendingUp size={24} />,
  <CheckCircle size={24} />,
  <Zap size={24} />,
  <Globe size={24} />,
  <Award size={24} />,
];

// ── Benefit icon map (cycles) ─────────────────────────────────────────────────
const BENEFIT_ICONS = [
  <Cpu size={20} />,
  <Globe size={20} />,
  <DollarSign size={20} />,
  <Eye size={20} />,
  <TrendingUp size={20} />,
  <Layers size={20} />,
  <ShieldCheck size={20} />,
  <Award size={20} />,
];

// ── Section label ─────────────────────────────────────────────────────────────
function SectionLabel({ text, center }: { text: string; center?: boolean }) {
  return (
    <p
      className={`text-caption font-semibold uppercase tracking-[0.15em] mb-4 ${center ? 'text-center' : ''}`}
      style={{ color: '#00C499' }}
    >
      {text}
    </p>
  );
}

// ── Placeholder brand logos ───────────────────────────────────────────────────
function BrandLogo({ label }: { label: string }) {
  return (
    <div
      className="flex items-center justify-center px-6 py-3 border"
      style={{ borderColor: 'rgba(255,255,255,0.12)', backgroundColor: 'rgba(255,255,255,0.04)', minWidth: 100 }}
    >
      <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: 'rgba(255,255,255,0.35)' }}>{label}</span>
    </div>
  );
}

const PNP_DUMMY_LOGOS = [
  'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5726837/pexels-photo-5726837.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/6863183/pexels-photo-6863183.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
];

// ── Ticker logos ─────────────────────────────────────────────────────────────
const CLIENT_LOGOS = [
  'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5726837/pexels-photo-5726837.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/6863183/pexels-photo-6863183.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/4491881/pexels-photo-4491881.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
  'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=200&q=80',
];

function ClientTicker() {
  const tripled = [...CLIENT_LOGOS, ...CLIENT_LOGOS, ...CLIENT_LOGOS];
  return (
    <div className="ticker-container border-t border-b" style={{ borderColor: '#E8E8E8' }}>
      <div className="ticker-track py-5">
        {tripled.map((logo, i) => (
          <div
            key={i}
            className="flex-shrink-0 flex items-center justify-center px-10 border-r"
            style={{ borderColor: '#E8E8E8', minWidth: 140 }}
          >
            <img
              src={logo}
              alt={`Client logo ${i + 1}`}
              className="h-8 w-auto object-contain grayscale opacity-50 hover:opacity-80 hover:grayscale-0 transition-all duration-300"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function PnpPage() {
  const [cms, setCms] = useState<PnpPageSettings>(DEFAULT_CMS);

  useEffect(() => {
    getPnpPageSettings().then((data) => {
      if (data) setCms(data);
    });
  }, []);

  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroBgY = useTransform(scrollYProgress, [0, 1], ['0%', '18%']);

  const conceptRef = useRef<HTMLElement>(null);
  const caseRef = useRef<HTMLElement>(null);
  const whyRef = useRef<HTMLElement>(null);
  const expertiseRef = useRef<HTMLElement>(null);
  const nextRef = useRef<HTMLElement>(null);
  const clientsRef = useRef<HTMLElement>(null);
  const ctaRef = useRef<HTMLElement>(null);

  const conceptInView = useInView(conceptRef, { once: true, margin: '-60px' });
  const caseInView = useInView(caseRef, { once: true, margin: '-60px' });
  const whyInView = useInView(whyRef, { once: true, margin: '-60px' });
  const expertiseInView = useInView(expertiseRef, { once: true, margin: '-60px' });
  const nextInView = useInView(nextRef, { once: true, margin: '-60px' });
  const clientsInView = useInView(clientsRef, { once: true, margin: '-60px' });
  const ctaInView = useInView(ctaRef, { once: true, margin: '-60px' });

  const steps = (cms.steps as { step: string; title: string; body: string }[]);
  const benefits = (cms.benefits as { title: string; body: string }[]);

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Section 1: Hero ──────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[80vh] flex items-end overflow-hidden">
        <motion.div className="absolute inset-0" style={{ y: heroBgY }}>
          <img
            src="https://images.pexels.com/photos/4481259/pexels-photo-4481259.jpeg?auto=compress&cs=tinysrgb&w=1800&q=85"
            alt="Plastic Neutral Programme"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(1,41,138,0.96) 0%, rgba(1,41,138,0.68) 45%, rgba(1,41,138,0.15) 100%)' }} />
        </motion.div>

        <div className="container-site relative z-10 pb-14 pt-36">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="text-caption font-semibold uppercase tracking-[0.15em] mb-5"
            style={{ color: '#00C499' }}
          >
            Plastic Neutral Programme
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white leading-tight mb-6"
            style={{ fontSize: 'clamp(2.2rem, 4.5vw, 3.6rem)', letterSpacing: '-0.03em', maxWidth: 680 }}
          >
            Plastic Neutral Programme
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.22 }}
            className="text-body-lg leading-relaxed mb-10 max-w-2xl"
            style={{ color: 'rgba(255,255,255,0.78)' }}
          >
            {cms.hero_body}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.34 }}
            className="flex flex-col sm:flex-row gap-3"
          >
            <Link
              to="/contact"
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 font-semibold text-sm transition-all duration-300 hover:opacity-90"
              style={{ backgroundColor: '#00C499', color: '#0A1F3C' }}
            >
              Start Your Journey
              <ArrowRight size={16} />
            </Link>
            <a
              href="#features"
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 font-medium text-sm border text-white transition-all duration-300 hover:bg-white/10"
              style={{ borderColor: 'rgba(255,255,255,0.3)' }}
            >
              See How It Works
              <ChevronRight size={16} />
            </a>
          </motion.div>

          {/* Trust logos */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.55 }}
            className="mt-12 pt-8 border-t"
            style={{ borderColor: 'rgba(255,255,255,0.15)' }}
          >
            <p className="text-caption font-medium uppercase tracking-widest mb-5" style={{ color: 'rgba(255,255,255,0.4)' }}>
              Trusted by brands across India
            </p>
            <div className="flex flex-wrap gap-4 items-center">
              {PNP_DUMMY_LOGOS.map((logo, i) => (
                <div
                  key={i}
                  className="px-4 py-2.5 border"
                  style={{ borderColor: 'rgba(255,255,255,0.15)', backgroundColor: 'rgba(255,255,255,0.06)' }}
                >
                  <img
                    src={logo}
                    alt={`Brand logo ${i + 1}`}
                    className="h-7 w-auto object-contain grayscale opacity-60 hover:opacity-90 transition-all duration-300"
                  />
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Section 2: What is Plastic Neutrality ──────────────────────── */}
      <section ref={conceptRef} id="features" className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <motion.div
            initial="hidden"
            animate={conceptInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            className="text-center mb-6"
          >
            <SectionLabel text="THE CONCEPT" center />
            <h2 className="font-display text-display-sm font-bold text-white mb-0 leading-tight max-w-xl mx-auto">
              {cms.programme_heading}
            </h2>
          </motion.div>

          {/* Pull quote */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={conceptInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.97 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="my-14 text-center"
          >
            <div className="inline-block relative px-8 md:px-16">
              <span className="absolute -top-4 -left-2 text-6xl font-serif leading-none" style={{ color: '#00C499', opacity: 0.4 }}>"</span>
              <p
                className="font-display font-bold text-white leading-tight"
                style={{ fontSize: 'clamp(1.6rem, 3.5vw, 2.8rem)', letterSpacing: '-0.02em' }}
              >
                The balance between what you use<br className="hidden md:block" /> and what you recover.
              </p>
              <span className="absolute -bottom-8 -right-2 text-6xl font-serif leading-none" style={{ color: '#00C499', opacity: 0.4 }}>"</span>
            </div>
          </motion.div>

          {/* Body paragraph from CMS */}
          <motion.div
            initial="hidden"
            animate={conceptInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
            className="max-w-2xl mx-auto text-center mb-16"
          >
            <p className="text-body-lg leading-relaxed" style={{ color: 'rgba(255,255,255,0.7)' }}>
              {cms.programme_body}
            </p>
          </motion.div>

          {/* Steps heading */}
          <motion.div
            initial="hidden"
            animate={conceptInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={2}
            className="text-center mb-10"
          >
            <h3 className="font-display font-bold text-white text-xl" style={{ letterSpacing: '-0.02em' }}>
              {cms.steps_heading}
            </h3>
          </motion.div>

          {/* Steps process */}
          <div className="relative max-w-3xl mx-auto">
            {/* Dashed connector line (desktop) */}
            <div className="absolute top-10 left-[calc(16.67%+20px)] right-[calc(16.67%+20px)] hidden md:block">
              <svg width="100%" height="4" viewBox="0 0 400 4">
                <path d="M 0 2 Q 200 2 400 2" stroke="rgba(0,196,153,0.3)" strokeWidth="1.5" strokeDasharray="6 4" fill="none" />
              </svg>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-0">
              {steps.map((step, i) => (
                <motion.div
                  key={step.step}
                  initial="hidden"
                  animate={conceptInView ? 'visible' : 'hidden'}
                  variants={fadeUp}
                  custom={i + 3}
                  className="flex flex-col items-center text-center px-6"
                >
                  <div
                    className="w-20 h-20 rounded-full flex items-center justify-center mb-4 relative z-10"
                    style={{ backgroundColor: '#1A1A1A', border: '2px solid rgba(0,196,153,0.5)', boxShadow: '0 0 24px rgba(0,196,153,0.15)' }}
                  >
                    <div style={{ color: '#00C499' }}>{STEP_ICONS[i % STEP_ICONS.length]}</div>
                  </div>
                  <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: 'rgba(255,255,255,0.3)' }}>{step.step}</p>
                  <h3 className="text-base font-bold text-white mb-2">{step.title}</h3>
                  <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.55)' }}>{step.body}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Section 3: Why Your Brand Needs This ─────────────────────────── */}
      <section ref={caseRef} className="section-padding bg-ivory">
        <div className="container-site">
          <motion.div
            className="mb-12"
            initial="hidden"
            animate={caseInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="THE CASE" />
            <h2 className="font-display text-display-sm font-bold mb-2 leading-tight" style={{ color: '#1A1A1A' }}>
              Plastic Neutrality pays off.
            </h2>
            <p className="text-heading-md font-medium" style={{ color: '#00C499' }}>
              For the planet, and your brand.
            </p>
            <p className="mt-4 text-body-lg leading-relaxed max-w-2xl" style={{ color: '#5F5F5F' }}>
              Consumers are watching, regulators are tightening, and investors are asking harder questions. Plastic Neutrality gives your brand the proof, the story, and the credibility to answer all three.
            </p>
          </motion.div>

          {/* Stat cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                big: '81%',
                label: 'Consumers expect real action',
                body: '81% of people want brands to take meaningful environmental steps, not just make promises.',
                color: '#01298A',
              },
              {
                big: 'Stand Apart',
                label: 'Differentiate with proof',
                body: 'Offset your plastic footprint and build trust with consumers who hold brands accountable.',
                color: '#00C499',
              },
              {
                big: 'Investor Ready',
                label: 'Attract sustainable capital',
                body: 'Verified sustainability practices open doors to funding, credibility, and long-term growth.',
                color: '#1A1A1A',
              },
            ].map((card, i) => (
              <motion.div
                key={card.label}
                initial="hidden"
                animate={caseInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="flex flex-col p-8 bg-white border"
                style={{ borderColor: '#E8E8E8' }}
                whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.1)', y: -3 }}
                transition={{ duration: 0.2 }}
              >
                <p
                  className="font-display font-black leading-none mb-3"
                  style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', color: card.color, letterSpacing: '-0.03em' }}
                >
                  {card.big}
                </p>
                <p className="text-sm font-bold mb-auto pb-4" style={{ color: '#1A1A1A' }}>{card.label}</p>
                <div className="pt-4 border-t" style={{ borderColor: '#F0F0F0' }}>
                  <p className="text-sm leading-relaxed" style={{ color: '#858585' }}>{card.body}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 4: Why ReCircle (Benefits) ───────────────────────────── */}
      <section ref={whyRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            className="text-center mb-14"
            initial="hidden"
            animate={whyInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="WHY RECIRCLE" center />
            <h2 className="font-display text-display-sm font-bold mb-3 leading-tight" style={{ color: '#1A1A1A' }}>
              {cms.benefits_heading}
            </h2>
            <p className="text-body-lg max-w-2xl mx-auto" style={{ color: '#5F5F5F' }}>
              Plastic neutrality is not just about keeping waste out of landfills. It is about building a business that consumers believe in.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {benefits.map((benefit, i) => (
              <motion.div
                key={benefit.title}
                initial="hidden"
                animate={whyInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="bg-white p-7 border"
                style={{ borderColor: '#E8E8E8' }}
                whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.10)', y: -3 }}
                transition={{ duration: 0.2 }}
              >
                <div className="w-10 h-10 flex items-center justify-center mb-4" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                  {BENEFIT_ICONS[i % BENEFIT_ICONS.length]}
                </div>
                <h3 className="text-sm font-bold mb-2" style={{ color: '#1A1A1A' }}>{benefit.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: '#5F5F5F' }}>{benefit.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 5: Proven Expertise ──────────────────────────────────── */}
      <section ref={expertiseRef} className="section-padding" style={{ backgroundColor: '#01298A' }}>
        <div className="container-site">
          <motion.div
            className="text-center mb-14"
            initial="hidden"
            animate={expertiseInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="OUR CREDENTIALS" center />
            <h2 className="font-display text-display-sm font-bold text-white leading-tight">
              Why choose ReCircle?
            </h2>
          </motion.div>

          {/* Four credential boxes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-0">
            {[
              {
                icon: <Award size={20} />,
                title: 'Proven Expertise',
                body: 'One of the few global PNP providers handling Multi-Layered Plastics. Trusted by brands across India and internationally.',
              },
              {
                icon: <Zap size={20} />,
                title: 'Additionality That Matters',
                body: 'Go beyond baseline. Choose Additionality by Volume or select verified initiatives from our curated White List.',
              },
              {
                icon: <Globe size={20} />,
                title: 'Global Partnerships',
                body: 'We collaborate with PCX and other global leaders in Plastic Credits, meeting international compliance and audit standards.',
              },
              {
                icon: <Cpu size={20} />,
                title: 'ClimaOne Traceability',
                body: 'Every unit collected traces through ClimaOne in real time. Your audits get verified, accurate, and defensible data.',
              },
            ].map((col, i) => (
              <motion.div
                key={col.title}
                initial="hidden"
                animate={expertiseInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="p-8 flex flex-col"
                style={{ backgroundColor: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.18)' }}
                whileHover={{ backgroundColor: 'rgba(255,255,255,0.13)' }}
                transition={{ duration: 0.18 }}
              >
                <div className="w-10 h-10 flex items-center justify-center mb-5" style={{ backgroundColor: '#DCEB4B', color: '#0A1F3C' }}>
                  {col.icon}
                </div>
                <h3 className="text-sm font-bold text-white mb-3">{col.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.72)' }}>{col.body}</p>
              </motion.div>
            ))}
          </div>

          {/* Stat bar */}
          <motion.div
            initial="hidden"
            animate={expertiseInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={4}
            className="border-t mt-0"
            style={{ borderColor: 'rgba(255,255,255,0.12)', backgroundColor: 'rgba(0,0,0,0.15)' }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x" style={{ '--tw-divide-opacity': 1, borderColor: 'rgba(255,255,255,0.12)' } as React.CSSProperties}>
              {[
                { value: '310+', label: 'Collection Hotspots Across India' },
                { value: '100%', label: 'Traceable Through ClimaOne' },
                { value: 'MLP Certified', label: 'Multi-Layered Plastic Specialists' },
              ].map((stat) => (
                <div key={stat.label} className="flex flex-col items-center justify-center py-7 px-6 text-center">
                  <p className="font-display font-black text-2xl mb-1" style={{ color: '#DCEB4B' }}>{stat.value}</p>
                  <p className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.5)' }}>{stat.label}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Section 6: What Comes Next ───────────────────────────────────── */}
      <section ref={nextRef} className="section-padding bg-ivory">
        <div className="container-site">
          <motion.div
            className="mb-14"
            initial="hidden"
            animate={nextInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="WHAT'S NEXT" />
            <h2 className="font-display text-display-sm font-bold mb-3 leading-tight" style={{ color: '#1A1A1A' }}>
              Going Plastic Neutral is just the beginning.
            </h2>
            <p className="text-body-lg max-w-2xl" style={{ color: '#5F5F5F' }}>
              Your efforts become the foundation of a larger story your brand can tell.
            </p>
          </motion.div>

          {/* Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            {[
              {
                num: '01',
                title: 'Wear It Proudly',
                body: 'Display the Plastic Neutral logo on your products. Let your consumers know you are walking the talk, not just talking about it.',
                icon: <ShieldCheck size={20} />,
              },
              {
                num: '02',
                title: 'Make It Official',
                body: 'Receive your Plastic Neutral certification. A tangible, verifiable proof of your commitment to a cleaner future.',
                icon: <Award size={20} />,
              },
              {
                num: '03',
                title: 'Spread the Word',
                body: "Leverage ReCircle's PNP communications toolkit to showcase your impact story and inspire customers, stakeholders, and peers.",
                icon: <Megaphone size={20} />,
              },
            ].map((card, i) => (
              <motion.div
                key={card.num}
                initial="hidden"
                animate={nextInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="p-8 bg-white border"
                style={{ borderColor: '#E8E8E8' }}
                whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.10)', y: -3 }}
                transition={{ duration: 0.2 }}
              >
                <div
                  className="w-12 h-12 flex items-center justify-center font-display font-black text-lg mb-5"
                  style={{ backgroundColor: '#01298A', color: '#DCEB4B', letterSpacing: '-0.03em' }}
                >
                  {card.num}
                </div>
                <div className="w-9 h-9 flex items-center justify-center mb-4" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                  {card.icon}
                </div>
                <h3 className="text-base font-bold mb-3" style={{ color: '#1A1A1A' }}>{card.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: '#5F5F5F' }}>{card.body}</p>
              </motion.div>
            ))}
          </div>

          {/* Callout box */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={nextInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.55, delay: 0.4 }}
            className="p-10 text-center"
            style={{ backgroundColor: '#01298A' }}
          >
            <p
              className="font-display font-bold text-white mx-auto max-w-2xl leading-snug"
              style={{ fontSize: 'clamp(1.1rem, 2vw, 1.4rem)' }}
            >
              This is where impact turns visible. This is where your consumers see you leading the change.
            </p>
          </motion.div>
        </div>
      </section>

      {/* ── Section 7: Our Clients ────────────────────────────────────────── */}
      <section ref={clientsRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            className="text-center mb-12"
            initial="hidden"
            animate={clientsInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="OUR CLIENTS" center />
            <h2 className="font-display text-display-sm font-bold mb-3 leading-tight" style={{ color: '#1A1A1A' }}>
              We proudly lead the way.
            </h2>
            <p className="text-body-lg" style={{ color: '#5F5F5F' }}>
              Inspiring the next wave of sustainable businesses.
            </p>
          </motion.div>
        </div>

        {/* Full-width ticker */}
        <ClientTicker />

        <div className="container-site mt-10 text-center">
          <motion.p
            initial="hidden"
            animate={clientsInView ? 'visible' : 'hidden'}
            variants={fadeIn}
            className="text-body-sm font-medium"
            style={{ color: '#858585' }}
          >
            Join brands already building a cleaner future with ReCircle.
          </motion.p>
        </div>
      </section>

      {/* ── Section 8: Closing CTA ────────────────────────────────────────── */}
      <section ref={ctaRef} className="section-padding relative overflow-hidden" style={{ backgroundColor: '#060F2E' }}>
        {/* Background decoration */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full" style={{ background: 'radial-gradient(circle, rgba(0,196,153,0.06) 0%, transparent 70%)' }} />
        </div>

        <div className="container-site relative z-10 text-center">
          <motion.h2
            initial={{ opacity: 0, y: 32 }}
            animate={ctaInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 32 }}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white mb-5 leading-tight mx-auto"
            style={{ fontSize: 'clamp(1.8rem, 4vw, 3rem)', letterSpacing: '-0.025em', maxWidth: 700 }}
          >
            Your plastic footprint is measurable.<br /> So is your impact.
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={ctaInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
            transition={{ duration: 0.55, delay: 0.12 }}
            className="text-body-lg mb-10 max-w-sm mx-auto"
            style={{ color: 'rgba(255,255,255,0.65)' }}
          >
            Start today. Lead the change tomorrow.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={ctaInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 14 }}
            transition={{ duration: 0.5, delay: 0.22 }}
          >
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 font-semibold transition-all duration-300 hover:opacity-90"
              style={{ backgroundColor: '#00C499', color: '#060F2E', padding: '1rem 2.5rem', fontSize: '0.95rem' }}
            >
              Book Your Free Consultation
              <ArrowRight size={18} />
            </Link>
          </motion.div>

          {/* Trust signals */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={ctaInView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.5, delay: 0.36 }}
            className="mt-8 flex items-center justify-center gap-3 flex-wrap"
          >
            {['No commitment required', 'Pan-India coverage', 'Certified and verified'].map((sig, i) => (
              <span key={sig} className="flex items-center gap-3">
                {i > 0 && <span style={{ color: 'rgba(255,255,255,0.2)' }}>·</span>}
                <span className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.5)' }}>
                  <Users size={11} className="inline mr-1.5 mb-0.5" style={{ color: '#00C499' }} />
                  {sig}
                </span>
              </span>
            ))}
          </motion.div>
        </div>
      </section>

    </main>
  );
}
