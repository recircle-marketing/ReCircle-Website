import { useRef, useState, useEffect } from 'react';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import {
  MapPin, ArrowRight, Package, Scissors, CheckCircle,
  Shuffle, RefreshCw, Sparkles, Wrench,
} from 'lucide-react';
import { getTrfPageSettings } from '../../cms/queries';
import type { TrfPageSettings } from '../../cms/types';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

function SectionLabel({ text, light }: { text: string; light?: boolean }) {
  return (
    <p className="text-caption font-semibold uppercase tracking-[0.15em] mb-4" style={{ color: light ? 'rgba(0,196,153,0.9)' : '#00C499' }}>
      {text}
    </p>
  );
}

const FALLBACK_CATEGORIES = [
  { label: 'Rewear', color: '#01298A', bg: '#E8EDF8', desc: 'Garments suitable for direct reuse and redistribution.' },
  { label: 'Recycle', color: '#00C499', bg: '#E6F7F3', desc: 'Materials processed for fibre or material recovery.' },
  { label: 'Relife', color: '#E7182A', bg: '#FEE8EA', desc: 'Items repurposed for extended service life applications.' },
  { label: 'Revamp', color: '#5F5F5F', bg: '#F0F0F0', desc: 'Textiles reworked into new products through upcycling.' },
];

const SOURCES = [
  'Institutions', 'NGOs', 'Households', 'Waghri Community',
  'Textile Manufacturers', 'Deadstock Materials', 'Textile Cut Pieces',
];

const HIGHLIGHTS = [
  { icon: <RefreshCw size={20} />, title: 'Textile Waste Collection & Recovery', desc: 'Wide-network sourcing from institutions, NGOs, households, and industry across the region.' },
  { icon: <Package size={20} />, title: 'Bale Press & Cutting Machine Infrastructure', desc: 'Purpose-built equipment for efficient handling, compaction, and processing of textile waste.' },
  { icon: <Shuffle size={20} />, title: 'Sorting & Channelization Systems', desc: 'Structured segregation into four output categories for optimized downstream processing.' },
  { icon: <Sparkles size={20} />, title: 'Circular Textile Processing Support', desc: 'End-to-end support for reuse, recycling, and responsible downstream processing channels.' },
  { icon: <CheckCircle size={20} />, title: 'Traceable Recovery Operations', desc: 'Every material stream is tracked from intake to channelization, ensuring operational transparency.' },
];

export default function TrfPage() {
  const [cms, setCms] = useState<TrfPageSettings | null>(null);

  useEffect(() => {
    getTrfPageSettings().then(setCms).catch(() => setCms(null));
  }, []);

  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);

  const overviewRef = useRef<HTMLElement>(null);
  const categoriesRef = useRef<HTMLElement>(null);
  const highlightsRef = useRef<HTMLElement>(null);
  const locationRef = useRef<HTMLElement>(null);

  const overviewInView = useInView(overviewRef, { once: true, margin: '-60px' });
  const categoriesInView = useInView(categoriesRef, { once: true, margin: '-60px' });
  const highlightsInView = useInView(highlightsRef, { once: true, margin: '-60px' });
  const locationInView = useInView(locationRef, { once: true, margin: '-60px' });

  const heroHeading = cms?.hero_heading ?? 'Textile Recovery Facility';
  const heroBody = cms?.hero_body ?? "ReCircle's Textile Recovery Facility (TRF) enables organized recovery, sorting, and channelization of textile waste streams, supporting circular textile systems by extending material life cycles.";
  const stat1Value = cms?.stat_1_value ?? '';
  const stat1Label = cms?.stat_1_label ?? '';
  const stat2Value = cms?.stat_2_value ?? '';
  const stat2Label = cms?.stat_2_label ?? '';
  const overviewHeading = cms?.overview_heading ?? 'Circular systems for textile waste recovery.';
  const overviewBody = cms?.overview_body ?? [
    'Located in Dombivli, the facility manages textile waste through structured recovery and sorting operations designed to support reuse, recycling, and responsible downstream processing.',
    'The facility is equipped with a bale press machine and cutting machine to support efficient handling, processing, and channelization of textile waste.',
    'Textile waste is collected from a wide network of sources including institutions, NGOs, households, the Waghri community, and textile manufacturers. The facility also manages deadstock materials and textile cut pieces generated during manufacturing processes.',
  ].join('\n');

  const categories = (cms?.categories as { label: string; color: string; bg: string; desc: string }[] | undefined)
    ?? FALLBACK_CATEGORIES;

  return (
    <main className="pt-[72px] overflow-x-hidden">

      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-[70vh] flex items-end overflow-hidden">
        <motion.div className="absolute inset-0" style={{ y: bgY }}>
          <img
            src="https://images.pexels.com/photos/3965545/pexels-photo-3965545.jpeg?auto=compress&cs=tinysrgb&w=1600&q=85"
            alt="Textile Recovery Facility"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(26,26,26,0.92) 0%, rgba(26,26,26,0.55) 50%, rgba(26,26,26,0.2) 100%)' }} />
        </motion.div>

        <div className="container-site relative z-10 pb-16 pt-40">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 mb-6 border text-xs font-semibold uppercase tracking-widest"
            style={{ borderColor: 'rgba(0,196,153,0.5)', color: '#00C499', backgroundColor: 'rgba(0,196,153,0.08)' }}
          >
            Infrastructure
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="font-display font-bold text-white mb-2 leading-tight"
            style={{ fontSize: 'clamp(2.2rem, 5vw, 3.8rem)', letterSpacing: '-0.03em', maxWidth: 700 }}
          >
            {heroHeading}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.18 }}
            className="text-lg font-medium mb-4"
            style={{ color: '#00C499' }}
          >
            Textile Waste Recovery Systems
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.22 }}
            className="text-body-lg max-w-2xl leading-relaxed"
            style={{ color: 'rgba(255,255,255,0.75)' }}
          >
            {heroBody}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.35 }}
            className="mt-6 inline-flex items-center gap-2 text-sm"
            style={{ color: 'rgba(255,255,255,0.55)' }}
          >
            <MapPin size={14} style={{ color: '#00C499' }} />
            Dombivli
          </motion.div>
        </div>
      </section>

      {/* ── Overview ─────────────────────────────────────────────────────── */}
      <section ref={overviewRef} className="section-padding bg-ivory">
        <div className="container-site">
          {/* Header row */}
          <div className="flex flex-col lg:flex-row gap-16 items-start">
            {/* Left — label + heading */}
            <motion.div
              className="lg:w-1/2"
              initial="hidden"
              animate={overviewInView ? 'visible' : 'hidden'}
              variants={fadeUp}
            >
              <SectionLabel text="ABOUT THE FACILITY" />
              <h2 className="font-display text-display-sm font-bold mb-6 leading-tight" style={{ color: '#1A1A1A' }}>
                {overviewHeading}
              </h2>
            </motion.div>

            {/* Right — body text aligned to heading start */}
            <motion.div
              className="lg:w-1/2"
              initial="hidden"
              animate={overviewInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={1}
            >
              <div className="space-y-4">
                {overviewBody.split('\n').filter(Boolean).map((para, i) => (
                  <motion.p
                    key={i}
                    initial="hidden"
                    animate={overviewInView ? 'visible' : 'hidden'}
                    variants={fadeUp}
                    custom={i + 2}
                    className="text-body-lg leading-relaxed"
                    style={{ color: '#5F5F5F' }}
                  >
                    {para}
                  </motion.p>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Sources + Equipment row — below the text */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-10">
            <motion.div
              initial="hidden"
              animate={overviewInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={4}
              className="p-8 bg-white border"
              style={{ borderColor: '#E8E8E8' }}
            >
              <p className="text-caption font-semibold uppercase tracking-widest mb-5" style={{ color: '#01298A' }}>
                Waste Sources
              </p>
              <div className="flex flex-wrap gap-2">
                {SOURCES.map((s) => (
                  <span key={s} className="px-3 py-1.5 text-xs font-semibold border" style={{ borderColor: '#E8EDF8', backgroundColor: '#F0F4FF', color: '#01298A' }}>
                    {s}
                  </span>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial="hidden"
              animate={overviewInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={5}
              className="p-8 bg-white border"
              style={{ borderColor: '#E8E8E8' }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 flex items-center justify-center" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                  <Wrench size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold" style={{ color: '#1A1A1A' }}>Core Equipment</p>
                  <p className="text-xs" style={{ color: '#858585' }}>Processing infrastructure</p>
                </div>
              </div>
              <div className="space-y-2.5">
                {['Bale Press Machine', 'Cutting Machine'].map((eq) => (
                  <div key={eq} className="flex items-center gap-2 text-sm" style={{ color: '#5F5F5F' }}>
                    <CheckCircle size={14} style={{ color: '#00C499' }} />
                    {eq}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Segregation Categories ───────────────────────────────────────── */}
      <section ref={categoriesRef} className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <motion.div
            className="text-center mb-14"
            initial="hidden"
            animate={categoriesInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="SEGREGATION SYSTEM" light />
            <h2 className="font-display text-display-sm font-bold text-white mb-4 leading-tight">
              Four output categories.<br />One circular system.
            </h2>
            <p className="text-body-lg max-w-xl mx-auto" style={{ color: 'rgba(255,255,255,0.6)' }}>
              Once collected, textile waste is systematically segregated into four categories before being sent for further processing through appropriate downstream channels.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            animate={categoriesInView ? 'visible' : 'hidden'}
            variants={fadeUp}
            custom={1}
            className="overflow-hidden"
            style={{ border: '1px solid rgba(255,255,255,0.1)' }}
          >
            <div className="aspect-[4/3] w-full">
              <img
                src="https://images.pexels.com/photos/3965545/pexels-photo-3965545.jpeg?auto=compress&cs=tinysrgb&w=1200&q=85"
                alt="Textile segregation system"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Facility Highlights ──────────────────────────────────────────── */}
      <section ref={highlightsRef} className="section-padding" style={{ backgroundColor: '#F5F5F5' }}>
        <div className="container-site">
          <motion.div
            className="mb-14"
            initial="hidden"
            animate={highlightsInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="FACILITY HIGHLIGHTS" />
            <h2 className="font-display text-display-sm font-bold mb-3 leading-tight" style={{ color: '#1A1A1A' }}>
              Built for scalable textile recovery.
            </h2>
            <p className="text-body-lg max-w-2xl" style={{ color: '#5F5F5F' }}>
              The TRF strengthens ReCircle's circularity efforts within the textile value chain by creating systems for responsible textile recovery and resource optimization.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {HIGHLIGHTS.map((h, i) => (
              <motion.div
                key={h.title}
                initial="hidden"
                animate={highlightsInView ? 'visible' : 'hidden'}
                variants={fadeUp}
                custom={i}
                className="p-7 bg-white border"
                style={{ borderColor: '#E8E8E8' }}
                whileHover={{ boxShadow: '0 8px 32px rgba(1,41,138,0.08)', y: -3 }}
                transition={{ duration: 0.2 }}
              >
                <div className="w-10 h-10 flex items-center justify-center mb-4" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                  {h.icon}
                </div>
                <h3 className="text-sm font-bold mb-2" style={{ color: '#1A1A1A' }}>{h.title}</h3>
                <p className="text-xs leading-relaxed" style={{ color: '#858585' }}>{h.desc}</p>
              </motion.div>
            ))}

            {/* About callout card */}
            <motion.div
              initial="hidden"
              animate={highlightsInView ? 'visible' : 'hidden'}
              variants={fadeUp}
              custom={5}
              className="p-7 md:col-span-2 lg:col-span-3"
              style={{ backgroundColor: '#01298A' }}
            >
              <p className="text-caption font-semibold uppercase tracking-widest mb-3" style={{ color: 'rgba(220,235,75,0.8)' }}>About the Facility</p>
              <p className="text-sm leading-relaxed text-white">
                The TRF strengthens ReCircle's circularity efforts within the textile value chain by creating systems for responsible textile recovery and resource optimization. By enabling collection, segregation, and processing of diverse textile waste streams, the facility supports scalable textile waste management solutions for brands, businesses, institutions, and communities while promoting circular textile ecosystems.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Location ─────────────────────────────────────────────────────── */}
      <section ref={locationRef} className="section-padding bg-ivory">
        <div className="container-site">
          <motion.div
            className="mb-10"
            initial="hidden"
            animate={locationInView ? 'visible' : 'hidden'}
            variants={fadeUp}
          >
            <SectionLabel text="FACILITY LOCATION" />
            <h2 className="font-display text-display-sm font-bold mb-3 leading-tight" style={{ color: '#1A1A1A' }}>
              ReCircle TRF, Dombivli
            </h2>
            <div className="flex items-center gap-2 text-sm" style={{ color: '#5F5F5F' }}>
              <MapPin size={14} style={{ color: '#01298A' }} />
              Textile Recovery Facility, Dombivli, Maharashtra
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={locationInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="w-full overflow-hidden border"
            style={{ borderColor: '#E8E8E8', height: 480 }}
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3767.9!2d73.0855!3d19.2183!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7efb71c789c5b%3A0x4b7f8e9d2a3c1f2e!2sDombivli%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1716000000001!5m2!1sen!2sin"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="ReCircle TRF Dombivli Location"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={locationInView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-4"
          >
            <a
              href="https://maps.app.goo.gl/NM1RaDe8w4JjtwaDA"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white transition-opacity hover:opacity-90"
              style={{ backgroundColor: '#01298A' }}
            >
              <MapPin size={14} />
              Open in Google Maps
              <ArrowRight size={14} />
            </a>
          </motion.div>
        </div>
      </section>

    </main>
  );
}
