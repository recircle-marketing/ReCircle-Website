import { useEffect, useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Briefcase, Clock, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { getCareersPageSettings, getCareers } from '../../cms/queries';
import type { CareersPageSettings, Career } from '../../cms/types';

const FALLBACK_SETTINGS: CareersPageSettings = {
  id: '',
  hero_heading: 'Join us in Shaping a circular future!',
  hero_body: "We're on the lookout for energetic, future-thinking individuals to join our mission. If you're able to think outside the box, have an unwavering belief in consistent action, and strive to see the solution to a problem, come join our team.",
  hero_cta_label: 'Apply Now',
  hero_cta_url: '#open-positions',
  culture_heading: 'Together as one',
  culture_body: "We're on the lookout for energetic, future-thinking individuals to join our mission. If you're able to think outside the box, have an unwavering belief in consistent action, and strive to see the solution to a problem, come join our team.",
  work_heading: 'See an opportunity in waste? ReCircle wants you!',
  work_body: "If you discover a position that aligns with your interests and skills or have ideas for a role we haven't covered, please reach out. We want to know your perspective on:",
  work_cta_label: 'Join Us Now',
  work_cta_url: '#open-positions',
  question_cards: [
    { label: 'Why', question: 'waste management?' },
    { label: 'Where', question: 'you think the planet is heading?' },
    { label: 'Will', question: 'collective action lead to a sustained impact?' },
    { label: 'How', question: 'can we get the world on board with our mission?' },
  ],
  listings_heading: "Be a part of ReCircle's inner circle",
  updated_at: '',
};

// 10 dummy office/team images for the carousel
const CULTURE_IMAGES = [
  { src: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Team collaboration' },
  { src: 'https://images.pexels.com/photos/1416530/pexels-photo-1416530.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Waste recovery operations' },
  { src: 'https://images.pexels.com/photos/3184325/pexels-photo-3184325.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Team meeting' },
  { src: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Office work' },
  { src: 'https://images.pexels.com/photos/6962921/pexels-photo-6962921.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Field operations' },
  { src: 'https://images.pexels.com/photos/3184431/pexels-photo-3184431.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Team event' },
  { src: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Community work' },
  { src: 'https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Strategy session' },
  { src: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Team member' },
  { src: 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg?auto=compress&cs=tinysrgb&w=800&q=80', alt: 'Recycling plant' },
];

function CultureCarousel() {
  const [current, setCurrent] = useState(0);
  const [paused, setPaused] = useState(false);
  const total = CULTURE_IMAGES.length;

  const next = useCallback(() => setCurrent((c) => (c + 1) % total), [total]);
  const prev = useCallback(() => setCurrent((c) => (c - 1 + total) % total), [total]);

  useEffect(() => {
    if (paused) return;
    const t = setInterval(next, 3500);
    return () => clearInterval(t);
  }, [next, paused]);

  return (
    <div
      className="relative overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Sliding strip — show 3 images at once on desktop */}
      <div className="relative h-64 md:h-80">
        <AnimatePresence mode="popLayout">
          {/* Show current and next 2 visible images */}
          {[0, 1, 2].map((offset) => {
            const idx = (current + offset) % total;
            const img = CULTURE_IMAGES[idx];
            return (
              <motion.div
                key={`${current}-${offset}`}
                className="absolute top-0 bottom-0"
                style={{ left: `${offset * 33.333}%`, width: '33.333%', padding: '0 4px' }}
                initial={{ opacity: offset === 0 ? 0 : 1, x: offset === 0 ? 40 : 0 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
              >
                <img src={img.src} alt={img.alt} className="w-full h-full object-cover" />
              </motion.div>
            );
          })}
        </AnimatePresence>

        {/* Nav buttons */}
        <button
          onClick={prev}
          className="absolute left-3 top-1/2 -translate-y-1/2 z-10 w-9 h-9 flex items-center justify-center bg-white/80 backdrop-blur-sm border border-white/40 hover:bg-white transition-colors duration-200"
          aria-label="Previous image"
        >
          <ChevronLeft size={16} />
        </button>
        <button
          onClick={next}
          className="absolute right-3 top-1/2 -translate-y-1/2 z-10 w-9 h-9 flex items-center justify-center bg-white/80 backdrop-blur-sm border border-white/40 hover:bg-white transition-colors duration-200"
          aria-label="Next image"
        >
          <ChevronRight size={16} />
        </button>
      </div>

      {/* Dots */}
      <div className="flex justify-center gap-1.5 mt-4">
        {CULTURE_IMAGES.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className="transition-all duration-300 rounded-full"
            style={{
              width: i === current ? 24 : 6,
              height: 6,
              backgroundColor: i === current ? '#00C499' : '#D1D1D1',
            }}
            aria-label={`Go to image ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}

function typeLabel(type: string): string {
  const map: Record<string, string> = { 'full-time': 'Full Time', 'part-time': 'Part Time', 'contract': 'Contract', 'internship': 'Internship' };
  return map[type] ?? type;
}

const fadeUp = {
  hidden: { opacity: 0, y: 32 },
  visible: (i = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.6, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] } }),
};

export default function CareersPage() {
  const [settings, setSettings] = useState<CareersPageSettings>(FALLBACK_SETTINGS);
  const [jobs, setJobs] = useState<Career[]>([]);
  const [loading, setLoading] = useState(true);
  const cultureRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    Promise.all([getCareersPageSettings(), getCareers()]).then(([s, j]) => {
      if (s) setSettings(s);
      setJobs(j);
      setLoading(false);
    });
  }, []);

  const cards = Array.isArray(settings.question_cards) ? settings.question_cards : FALLBACK_SETTINGS.question_cards;

  return (
    <main className="pt-20">

      {/* Hero — full-bleed image */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1920&q=80"
            alt="ReCircle team"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(1,41,138,0.92) 55%, rgba(1,41,138,0.55) 100%)' }} />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(1,41,138,0.7) 0%, transparent 60%)' }} />
        </div>

        <div className="relative z-10 container-site section-padding w-full">
          <div className="max-w-3xl">
            <motion.p
              className="text-xs font-semibold uppercase tracking-widest mb-4"
              style={{ color: '#DCEB4B' }}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Careers
            </motion.p>
            <motion.h1
              className="font-display text-display-md font-bold text-white mb-6"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              {settings.hero_heading}
            </motion.h1>
            <motion.p
              className="text-body-lg mb-10 leading-relaxed"
              style={{ color: 'rgba(255,255,255,0.8)' }}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              {settings.hero_body}
            </motion.p>
            <motion.a
              href={settings.hero_cta_url}
              className="btn-green inline-block px-8 py-4 text-sm font-semibold uppercase tracking-widest"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              {settings.hero_cta_label}
            </motion.a>
          </div>
        </div>
      </section>

      {/* Team Culture */}
      <section className="section-padding bg-ivory" ref={cultureRef}>
        <div className="container-site">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h2
              className="font-display text-display-sm font-bold mb-6"
              style={{ color: '#1A1A1A' }}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              {settings.culture_heading}
            </motion.h2>
            <motion.p
              className="text-body-lg leading-relaxed"
              style={{ color: '#5F5F5F' }}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              {settings.culture_body}
            </motion.p>
          </div>
        </div>
      </section>

      {/* Culture Image Carousel */}
      <section className="bg-ivory pb-16">
        <div className="container-site">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <CultureCarousel />
          </motion.div>
        </div>
      </section>

      {/* Work at ReCircle */}
      <section className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <div className="max-w-3xl mb-12">
            <motion.h2
              className="font-display text-display-sm font-bold text-white mb-6"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              {settings.work_heading}
            </motion.h2>
            <motion.p
              className="text-body-lg leading-relaxed"
              style={{ color: 'rgba(255,255,255,0.75)' }}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              {settings.work_body}
            </motion.p>
          </div>

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
          >
            {cards.map((card, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                custom={i}
                className="border p-6"
                style={{ borderColor: '#2E2E2E' }}
              >
                <p className="text-4xl font-black mb-2" style={{ color: '#DCEB4B' }}>{card.label}</p>
                <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.75)' }}>{card.question}</p>
              </motion.div>
            ))}
          </motion.div>

          <motion.a
            href={settings.work_cta_url}
            className="btn-green inline-flex items-center gap-2 px-8 py-4 text-sm font-semibold uppercase tracking-widest"
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            {settings.work_cta_label} <ArrowRight size={16} />
          </motion.a>
        </div>
      </section>

      {/* Open Positions */}
      <section id="open-positions" className="section-padding bg-ivory">
        <div className="container-site">
          <motion.h2
            className="font-display text-heading-xl font-bold mb-10"
            style={{ color: '#1A1A1A' }}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            {settings.listings_heading}
          </motion.h2>

          {loading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-7 h-7 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
            </div>
          ) : jobs.length === 0 ? (
            <motion.div
              className="text-center py-20 border border-dashed"
              style={{ borderColor: '#D1D1D1' }}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              <p className="text-lg font-semibold mb-2" style={{ color: '#1A1A1A' }}>No open positions right now</p>
              <p className="text-sm" style={{ color: '#858585' }}>We're always looking for great talent. Check back soon or send us your CV.</p>
              <a
                href="mailto:info@recircle.in"
                className="inline-block mt-6 px-6 py-3 text-sm font-semibold border transition-colors hover:bg-charcoal hover:text-white"
                style={{ borderColor: '#1A1A1A', color: '#1A1A1A' }}
              >
                Send your CV
              </a>
            </motion.div>
          ) : (
            <div className="space-y-4">
              {jobs.map((job, i) => (
                <motion.div
                  key={job.id}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.06 }}
                  className="bg-white border p-6 flex flex-col md:flex-row md:items-center gap-5"
                  style={{ borderColor: '#E8E8E8' }}
                >
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-bold mb-1" style={{ color: '#1A1A1A' }}>{job.title}</h3>
                    <div className="flex flex-wrap items-center gap-4 text-xs mb-3" style={{ color: '#858585' }}>
                      {job.department && <span className="flex items-center gap-1"><Briefcase size={12} />{job.department}</span>}
                      {job.location && <span className="flex items-center gap-1"><MapPin size={12} />{job.location}</span>}
                      {job.job_type && <span className="flex items-center gap-1"><Clock size={12} />{typeLabel(job.job_type)}</span>}
                    </div>
                    <p className="text-sm leading-relaxed" style={{ color: '#5F5F5F' }}>{job.description}</p>
                  </div>
                  {job.application_link && (
                    <a
                      href={job.application_link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-shrink-0 inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white transition-opacity hover:opacity-90"
                      style={{ backgroundColor: '#01298A' }}
                    >
                      Apply Now <ArrowRight size={14} />
                    </a>
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
