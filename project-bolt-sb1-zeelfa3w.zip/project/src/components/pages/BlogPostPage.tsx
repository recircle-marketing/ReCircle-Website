import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Search, ArrowRight } from 'lucide-react';
import { getBlogBySlug, getBlogs } from '../../cms/queries';
import type { Blog } from '../../cms/types';

function formatDate(dateStr: string | null): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const day = String(d.getDate()).padStart(2, '0');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${day}-${months[d.getMonth()]}-${d.getFullYear()}`;
}

function estimateReadTime(text: string): number {
  return Math.max(1, Math.ceil(text.split(/\s+/).length / 200));
}

interface CompactCardProps { blog: Blog; }
function CompactCard({ blog }: CompactCardProps) {
  return (
    <Link to={`/blog/${blog.slug}`} className="group flex gap-3 py-3 border-b last:border-b-0" style={{ borderColor: '#F0F0F0' }}>
      {blog.featured_image_url && (
        <div className="w-16 h-16 flex-shrink-0 overflow-hidden">
          <img src={blog.featured_image_url} alt={blog.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
        </div>
      )}
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold line-clamp-2 group-hover:underline" style={{ color: '#1A1A1A' }}>{blog.title}</p>
        <p className="text-xs mt-1" style={{ color: '#ABABAB' }}>{formatDate(blog.publish_date)}</p>
      </div>
    </Link>
  );
}

export default function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [blog, setBlog] = useState<Blog | null>(null);
  const [related, setRelated] = useState<Blog[]>([]);
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<Blog[]>([]);
  const [allBlogs, setAllBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    Promise.all([getBlogBySlug(slug), getBlogs()]).then(([b, all]) => {
      if (!b) { navigate('/blog', { replace: true }); return; }
      setBlog(b);
      const rel = all.filter((x) => x.id !== b.id && (x.category === b.category || b.tags?.some((t) => x.tags?.includes(t)))).slice(0, 4);
      setRelated(rel.length > 0 ? rel : all.filter((x) => x.id !== b.id).slice(0, 4));
      setAllBlogs(all);
      setLoading(false);
    });
  }, [slug, navigate]);

  useEffect(() => {
    if (!search.trim()) { setSearchResults([]); return; }
    const q = search.toLowerCase();
    setSearchResults(allBlogs.filter((b) => b.title.toLowerCase().includes(q) || b.seo_description?.toLowerCase().includes(q)).slice(0, 6));
  }, [search, allBlogs]);

  if (loading) {
    return (
      <main className="pt-20 min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </main>
    );
  }

  if (!blog) return null;

  return (
    <main className="pt-20">
      {/* Featured image */}
      {blog.featured_image_url && (
        <div className="w-full" style={{ maxHeight: '520px', overflow: 'hidden' }}>
          <img src={blog.featured_image_url} alt={blog.featured_image_alt || blog.title} className="w-full object-cover" style={{ maxHeight: '520px' }} />
        </div>
      )}

      {/* Meta row */}
      <div className="section-padding pb-0 bg-ivory">
        <div className="container-site">
          <Link to="/blog" className="inline-flex items-center gap-2 text-sm mb-6 transition-colors hover:underline" style={{ color: '#01298A' }}>
            <ArrowLeft size={14} /> Back to Blogs
          </Link>
          <div className="flex flex-wrap items-center gap-4 text-sm" style={{ color: '#858585' }}>
            {blog.author && <span>By <span className="font-semibold" style={{ color: '#1A1A1A' }}>{blog.author}</span></span>}
            {blog.category && (
              <span className="text-xs font-semibold uppercase tracking-widest px-2 py-0.5" style={{ backgroundColor: '#E8EDF8', color: '#01298A' }}>
                {blog.category}
              </span>
            )}
            {blog.publish_date && <span>{formatDate(blog.publish_date)}</span>}
            <span>{estimateReadTime(blog.body_content)} min read</span>
          </div>
        </div>
      </div>

      {/* Content + Sidebar */}
      <section className="section-padding bg-ivory">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
            {/* Main content — 70% */}
            <motion.div
              className="flex-1 min-w-0"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="font-display text-display-sm font-bold leading-tight mb-8" style={{ color: '#1A1A1A' }}>{blog.title}</h1>
              <div
                className="prose prose-lg max-w-none"
                style={{
                  '--tw-prose-headings': '#1A1A1A',
                  '--tw-prose-body': '#3A3A3A',
                  '--tw-prose-links': '#01298A',
                  '--tw-prose-bold': '#1A1A1A',
                  lineHeight: '1.8',
                } as React.CSSProperties}
                dangerouslySetInnerHTML={{ __html: blog.body_content || '<p>Full article coming soon.</p>' }}
              />

              {/* Prev/Next */}
              <div className="mt-12 pt-8 border-t flex items-center justify-between" style={{ borderColor: '#E8E8E8' }}>
                <Link to="/blog" className="flex items-center gap-2 text-sm font-semibold transition-colors hover:underline" style={{ color: '#01298A' }}>
                  <ArrowLeft size={14} /> All Articles
                </Link>
              </div>
            </motion.div>

            {/* Sidebar — 30% */}
            <aside className="lg:w-80 flex-shrink-0 space-y-8">
              {/* Search */}
              <div className="bg-white p-6 border" style={{ borderColor: '#E8E8E8' }}>
                <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: '#1A1A1A' }}>Search</h3>
                <div className="relative">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#ABABAB' }} />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search articles…"
                    className="w-full pl-9 pr-4 py-2.5 border text-sm focus:outline-none"
                    style={{ borderColor: '#D1D1D1' }}
                    onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                    onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                  />
                </div>
                {searchResults.length > 0 && (
                  <div className="mt-3 space-y-1">
                    {searchResults.map((r) => (
                      <Link key={r.id} to={`/blog/${r.slug}`} onClick={() => setSearch('')}
                        className="block px-2 py-1.5 text-xs rounded hover:bg-gray-50 transition-colors"
                        style={{ color: '#01298A' }}
                      >
                        {r.title}
                      </Link>
                    ))}
                  </div>
                )}
              </div>

              {/* Related posts */}
              {related.length > 0 && (
                <div className="bg-white p-6 border" style={{ borderColor: '#E8E8E8' }}>
                  <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: '#1A1A1A' }}>Related Articles</h3>
                  <div>
                    {related.map((r) => <CompactCard key={r.id} blog={r} />)}
                  </div>
                  <Link to="/blog" className="mt-4 flex items-center gap-1.5 text-xs font-semibold transition-colors" style={{ color: '#01298A' }}>
                    View all articles <ArrowRight size={12} />
                  </Link>
                </div>
              )}
            </aside>
          </div>
        </div>
      </section>
    </main>
  );
}
