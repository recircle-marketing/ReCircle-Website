import { useEffect, useState, useRef } from 'react';
import { motion, useInView, useMotionValue, useSpring } from 'framer-motion';
import { Download, ExternalLink, CheckCircle } from 'lucide-react';
import {
  getImpactPageSettings, getImpactMetrics, getImpactPreviousReports,
  submitImpactReportLead,
} from '../../cms/queries';
import type { ImpactPageSettings, ImpactMetric, ImpactPreviousReport } from '../../cms/types';

const FALLBACK_SETTINGS: ImpactPageSettings = {
  id: '',
  annual_feature_heading: "ReCircle's ANNUAL IMPACT REPORT 2024-25",
  annual_feature_subheading: 'A Year of Moving in Circles… In the Best Possible Way',
  annual_feature_body: 'This year, we completed a number of meaningful loops, from rethinking the idea of waste to redefining how it\'s recovered. Each milestone reminded us that progress doesn\'t always move in straight lines; it moves in circles, creating lasting impact for people and the planet.',
  annual_feature_cta_label: 'Download Report!',
  annual_feature_report_url: '',
  metrics_heading: 'Our Impact',
  metrics_subheading: 'Impact That Comes Full Circle',
  report_block_heading: 'Impact Report 2024-2025',
  report_block_subheading: 'A Year of Ethical Circularity',
  report_block_body: "We began with a simple question: What if nothing, not a single material or the person recovering it, got left behind? This year, that question became our way-forward. From Safai Saathis turning waste into opportunities to partners closing loops across industries, every story within the report begins and ends with people, the hands, hearts and minds that turn our world.",
  report_block_cta_text: 'STEP INSIDE OUR CIRCLE.',
  gated_form_heading: 'Download Our Impact Report',
  gated_form_button_label: 'Submit & Download',
  gated_report_url: '',
  previous_reports_heading: 'Read Our Previous Impact Reports Here',
  updated_at: '',
};

const FALLBACK_METRICS: ImpactMetric[] = [
  { id: '1', sort_order: 1, is_active: true, number_value: '291217', suffix: '', unit: ' MT', label: 'Waste diverted from polluting our landfills and oceans', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, number_value: '3608', suffix: '+', unit: '', label: 'Livelihoods impacted', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, number_value: '310', suffix: '+', unit: '', label: 'Village, Towns and Cities waste recovery sites', created_at: '', updated_at: '' },
  { id: '4', sort_order: 4, is_active: true, number_value: '10', suffix: '+', unit: '', label: 'Years of driving a Circular Economy', created_at: '', updated_at: '' },
  { id: '5', sort_order: 5, is_active: true, number_value: '4', suffix: '', unit: '', label: 'Years of consistently measuring impact', created_at: '', updated_at: '' },
];

const FALLBACK_REPORTS: ImpactPreviousReport[] = [
  { id: '1', sort_order: 1, is_active: true, year_label: '2023-24', button_text: 'Download for 2023-24', report_url: '', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, year_label: '2022-23', button_text: 'Download for 2022-23', report_url: '', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, year_label: '2021-22', button_text: 'Download for 2021-22', report_url: '', created_at: '', updated_at: '' },
];

function AnimatedCounter({ target, suffix, unit }: { target: number; suffix: string; unit: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });
  const motionVal = useMotionValue(0);
  const spring = useSpring(motionVal, { stiffness: 60, damping: 20, mass: 1 });
  const [display, setDisplay] = useState('0');

  useEffect(() => {
    if (inView) motionVal.set(target);
  }, [inView, target, motionVal]);

  useEffect(() => {
    return spring.on('change', (v) => {
      setDisplay(Math.round(v).toLocaleString('en-IN'));
    });
  }, [spring]);

  return <span ref={ref}>{display}{suffix}{unit}</span>;
}

export default function ImpactPage() {
  const [settings, setSettings] = useState<ImpactPageSettings>(FALLBACK_SETTINGS);
  const [metrics, setMetrics] = useState<ImpactMetric[]>(FALLBACK_METRICS);
  const [prevReports, setPrevReports] = useState<ImpactPreviousReport[]>(FALLBACK_REPORTS);
  const [gatedForm, setGatedForm] = useState({ full_name: '', email: '' });
  const [submitting, setSubmitting] = useState(false);
  const [gatedSubmitted, setGatedSubmitted] = useState(false);
  const [gatedError, setGatedError] = useState('');

  useEffect(() => {
    Promise.all([
      getImpactPageSettings(),
      getImpactMetrics(),
      getImpactPreviousReports(),
    ]).then(([s, m, r]) => {
      if (s) setSettings(s);
      if (m.length) setMetrics(m);
      if (r.length) setPrevReports(r);
    });
  }, []);

  const handleGatedSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGatedError('');
    setSubmitting(true);
    const { error } = await submitImpactReportLead(gatedForm);
    setSubmitting(false);
    if (error) { setGatedError('Something went wrong. Please try again.'); return; }
    setGatedSubmitted(true);
  };

  return (
    <main className="pt-20">

      {/* Section 1: Annual Report Feature — full-bleed image hero */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden">
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/2449452/pexels-photo-2449452.jpeg?auto=compress&cs=tinysrgb&w=1920&q=80"
            alt="ReCircle impact operations"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(1,41,138,0.92) 55%, rgba(1,41,138,0.6) 100%)' }} />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(1,41,138,0.7) 0%, transparent 50%)' }} />
        </div>

        <div className="relative z-10 container-site section-padding w-full">
          <div className="max-w-3xl">
            <motion.p
              className="text-xs font-semibold uppercase tracking-widest mb-5"
              style={{ color: '#DCEB4B' }}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Impact
            </motion.p>
            <motion.h1
              className="font-display text-display-md font-bold text-white mb-4"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              {settings.annual_feature_heading}
            </motion.h1>
            <motion.h2
              className="text-xl font-semibold mb-6"
              style={{ color: '#DCEB4B' }}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
            >
              {settings.annual_feature_subheading}
            </motion.h2>
            <motion.p
              className="text-body-lg leading-relaxed mb-10"
              style={{ color: 'rgba(255,255,255,0.8)' }}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              {settings.annual_feature_body}
            </motion.p>
            {settings.annual_feature_report_url && (
              <motion.a
                href={settings.annual_feature_report_url}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-green inline-flex items-center gap-2 px-8 py-4 text-sm font-semibold uppercase tracking-widest"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <Download size={16} /> {settings.annual_feature_cta_label}
              </motion.a>
            )}
          </div>
        </div>
      </section>

      {/* Section 2: Impact Metrics */}
      <section className="section-padding bg-ivory">
        <div className="container-site">
          <div className="text-center mb-14">
            <motion.h2
              className="font-display text-display-sm font-bold mb-3"
              style={{ color: '#1A1A1A' }}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              {settings.metrics_heading}
            </motion.h2>
            <motion.p
              className="text-body-lg"
              style={{ color: '#5F5F5F' }}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              {settings.metrics_subheading}
            </motion.p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
            {metrics.map((metric, i) => (
              <motion.div
                key={metric.id}
                className="text-center"
                initial={{ opacity: 0, y: 32 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
              >
                <p className="font-display text-3xl lg:text-4xl font-black mb-2" style={{ color: '#01298A' }}>
                  <AnimatedCounter
                    target={parseInt(metric.number_value.replace(/[^0-9]/g, '')) || 0}
                    suffix={metric.suffix}
                    unit={metric.unit}
                  />
                </p>
                <p className="text-sm leading-relaxed" style={{ color: '#5F5F5F' }}>{metric.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 3: Impact Report Feature Block — 50/50 with inline download form */}
      <section className="section-padding" style={{ backgroundColor: '#1A1A1A' }}>
        <div className="container-site">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">

            {/* Left — content */}
            <motion.div
              initial={{ opacity: 0, x: -24 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <motion.h2
                className="font-display text-display-sm font-bold text-white mb-4"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                {settings.report_block_heading}
              </motion.h2>
              <motion.h3
                className="text-xl font-semibold mb-6"
                style={{ color: '#DCEB4B' }}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                {settings.report_block_subheading}
              </motion.h3>
              <motion.p
                className="text-body-lg leading-relaxed mb-8"
                style={{ color: 'rgba(255,255,255,0.8)' }}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.15 }}
              >
                {settings.report_block_body}
              </motion.p>
              <motion.p
                className="text-sm font-bold uppercase tracking-[0.2em]"
                style={{ color: '#DCEB4B' }}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                {settings.report_block_cta_text}
              </motion.p>
            </motion.div>

            {/* Right — download form */}
            <motion.div
              initial={{ opacity: 0, x: 24 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="bg-white p-8"
            >
              <h3 className="font-display text-heading-xl font-bold mb-6" style={{ color: '#1A1A1A' }}>
                {settings.gated_form_heading}
              </h3>

              {gatedSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center text-center py-10"
                >
                  <CheckCircle size={48} style={{ color: '#00C499' }} className="mb-5" />
                  <p className="text-lg font-bold mb-3" style={{ color: '#1A1A1A' }}>Thank you!</p>
                  {settings.gated_report_url ? (
                    <a
                      href={settings.gated_report_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-8 py-4 text-sm font-semibold text-white"
                      style={{ backgroundColor: '#01298A' }}
                    >
                      <Download size={16} /> Download Report <ExternalLink size={12} />
                    </a>
                  ) : (
                    <p className="text-sm" style={{ color: '#858585' }}>The report download link will be shared shortly.</p>
                  )}
                </motion.div>
              ) : (
                <form onSubmit={handleGatedSubmit} className="space-y-4">
                  {gatedError && (
                    <div className="px-4 py-3 text-sm" style={{ backgroundColor: '#FEE2E2', color: '#E7182A', border: '1px solid #FECACA' }}>{gatedError}</div>
                  )}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: '#858585' }}>Full Name *</label>
                    <input
                      type="text" required placeholder="Your full name"
                      value={gatedForm.full_name}
                      onChange={(e) => setGatedForm({ ...gatedForm, full_name: e.target.value })}
                      className="w-full px-4 py-3 border text-sm focus:outline-none transition-colors"
                      style={{ borderColor: '#D1D1D1' }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: '#858585' }}>Email Address *</label>
                    <input
                      type="email" required placeholder="you@company.com"
                      value={gatedForm.email}
                      onChange={(e) => setGatedForm({ ...gatedForm, email: e.target.value })}
                      className="w-full px-4 py-3 border text-sm focus:outline-none transition-colors"
                      style={{ borderColor: '#D1D1D1' }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = '#01298A'; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = '#D1D1D1'; }}
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-4 text-sm font-semibold uppercase tracking-widest text-white transition-opacity hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2 mt-2"
                    style={{ backgroundColor: '#01298A' }}
                  >
                    <Download size={15} />
                    {submitting ? 'Submitting…' : settings.gated_form_button_label}
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Section 4: Previous Reports */}
      <section className="section-padding" style={{ backgroundColor: '#01298A' }}>
        <div className="container-site">
          <motion.h2
            className="font-display text-heading-xl font-bold text-white mb-10"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            {settings.previous_reports_heading}
          </motion.h2>
          <div className="flex flex-col sm:flex-row flex-wrap gap-5">
            {prevReports.map((report, i) => (
              <motion.a
                key={report.id}
                href={report.report_url || '#'}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className={`group inline-flex items-center gap-3 px-8 py-4 border-2 border-white text-white font-semibold text-sm uppercase tracking-widest transition-all ${!report.report_url ? 'opacity-50 cursor-not-allowed' : 'hover:bg-white hover:text-blue-primary'}`}
                onClick={(e) => { if (!report.report_url) e.preventDefault(); }}
              >
                <Download size={16} /> {report.button_text}
              </motion.a>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
