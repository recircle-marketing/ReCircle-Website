import { useRef, useEffect, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { getClients, getClientsMeta } from '../../cms/queries';
import type { Client, ClientsSectionMeta } from '../../cms/types';

const FALLBACK_META: ClientsSectionMeta = {
  id: '', heading: 'Our Clients', body_copy: 'Progressive brands enabling a better future.', updated_at: '',
};

// Clients with logo URLs for the 6 specified brands
const LOGO_MAP: Record<string, string> = {
  'Colgate-Palmolive': 'https://recircle.in/wp-content/uploads/2025/05/EPR_Colgate.png',
  'Dabur': 'https://recircle.in/wp-content/uploads/2025/05/EPR_Dabur.png',
  'Castrol': 'https://recircle.in/wp-content/uploads/2025/05/EPR_Castrol.png',
  'Hindustan Coca-Cola Beverages': 'https://recircle.in/wp-content/uploads/2025/05/EPR_Cococola.png',
  'FirstCry': 'https://recircle.in/wp-content/uploads/2025/05/EPR_Firstcry.png',
  'Kimberly Clark': 'https://recircle.in/wp-content/uploads/2025/05/EPR_Kimberly.png',
};

const FALLBACK_CLIENTS: Client[] = [
  'Colgate-Palmolive', 'Dabur', 'Castrol', 'Hindustan Coca-Cola Beverages', 'FirstCry',
  'Kimberly Clark', 'Mondelez', 'Endless Affair', 'Konexus Resource Group', 'PepsiCo',
  'Samsung', 'Tata Starbucks', 'Zepto', 'Symphony', 'Bisleri',
].map((name, i) => ({
  id: String(i + 1),
  sort_order: i + 1,
  is_active: true,
  name,
  logo_url: LOGO_MAP[name] || '',
  logo_alt: `${name} logo`,
  created_at: '',
  updated_at: '',
}));

function ClientLogo({ client }: { client: Client }) {
  return (
    <div className="flex-shrink-0 flex items-center justify-center px-8 py-6 min-w-[160px] group">
      {client.logo_url ? (
        <img
          src={client.logo_url}
          alt={client.logo_alt}
          className="h-9 object-contain grayscale opacity-45 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-300 max-w-[130px]"
        />
      ) : (
        <span className="text-body-sm font-semibold text-charcoal-300 hover:text-charcoal transition-colors duration-300 whitespace-nowrap tracking-wide">
          {client.name}
        </span>
      )}
    </div>
  );
}

export default function ClientsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as React.RefObject<HTMLElement>, { once: true, margin: '-60px' });
  const [meta, setMeta] = useState<ClientsSectionMeta>(FALLBACK_META);
  const [clients, setClients] = useState<Client[]>(FALLBACK_CLIENTS);

  useEffect(() => {
    Promise.all([getClientsMeta(), getClients()]).then(([m, c]) => {
      if (m) setMeta(m);
      if (c.length > 0) {
        // Merge logo URLs for known brands
        const enriched = c.map((client) => ({
          ...client,
          logo_url: client.logo_url || LOGO_MAP[client.name] || '',
        }));
        setClients(enriched);
      }
    });
  }, []);

  const doubled = [...clients, ...clients, ...clients];

  return (
    <section className="bg-white section-padding-sm border-t border-charcoal-100">
      <div className="container-site mb-12" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.55, ease: 'easeOut' }}
          className="flex flex-col sm:flex-row sm:items-end justify-between gap-4"
        >
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-6 h-px bg-green-primary" />
              <span className="section-label">Trusted by</span>
            </div>
            <h2 className="text-display-sm font-bold text-charcoal">{meta.heading}</h2>
          </div>
          <p className="text-body-lg text-charcoal-400 font-light max-w-xs text-right leading-relaxed">
            {meta.body_copy}
          </p>
        </motion.div>
      </div>

      {/* Ticker row 1 */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={inView ? { opacity: 1 } : {}}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="ticker-container border-t border-charcoal-50 bg-charcoal-50/30"
      >
        <div className="ticker-track py-2">
          {doubled.map((client, i) => (
            <ClientLogo key={`${client.id}-${i}`} client={client} />
          ))}
        </div>
      </motion.div>

      <div className="h-px bg-charcoal-100" />

      {/* Ticker row 2 — reversed */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={inView ? { opacity: 1 } : {}}
        transition={{ duration: 0.6, delay: 0.45 }}
        className="ticker-container bg-charcoal-50/20 border-b border-charcoal-50"
        style={{ direction: 'rtl' }}
      >
        <div className="ticker-track-slow py-2">
          {[...doubled].reverse().map((client, i) => (
            <ClientLogo key={`r-${client.id}-${i}`} client={client} />
          ))}
        </div>
      </motion.div>
    </section>
  );
}
