import { useRef, useEffect, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { getAboutContent } from '../../cms/queries';
import type { AboutContent, CtaButton, Highlight } from '../../cms/types';

const FALLBACK: AboutContent = {
  id: '',
  section_label: 'About ReCircle',
  heading: 'Building Circular Systems for a Changing Business Landscape',
  body_paragraphs: [
    'At ReCircle, we are driven by a singular mission: to accelerate the world\'s transition towards a circular economy.',
    'What began as an effort to keep valuable materials out of landfills has evolved into one of India\'s leading waste management organisations, helping businesses build more compliant, traceable, and resource-efficient operations.',
    'Today, our work spans plastic and textile waste management, end-to-end EPR Compliance services, CSR/ESG projects, and the supply of recycled raw materials, including food-grade rPET flakes for circular packaging systems.',
    'These solutions are powered by a pan-India waste recovery network of 3,608 Safai Saathis recovering 14,970 kgs of waste every hour, alongside ClimaOne, our in-house traceability platform that enables end-to-end visibility across the waste value chain.',
    'As plastic waste management regulations evolve and expectations around traceability continue to grow, ReCircle enables businesses to stay ahead through technology-driven solutions designed for compliance, accountability, and measurable circular impact.',
  ],
  closing_line: 'Explore our services, products, and infrastructure powering circularity across the value chain.',
  cta_buttons: [
    { label: 'Services', href: '#solutions' },
    { label: 'Products', href: '#products' },
    { label: 'Infrastructure', href: '#infrastructure' },
  ],
  highlights: [
    { value: '3,608', unit: '+', label: 'Safai Saathis in our recovery network' },
    { value: '14,970', unit: ' kgs', label: 'of waste recovered every hour' },
    { value: '10', unit: '+', label: 'years driving circular economy' },
  ],
  updated_at: '',
};

export default function AboutSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });
  const [content, setContent] = useState<AboutContent>(FALLBACK);

  useEffect(() => {
    getAboutContent().then((data) => {
      if (data) setContent(data);
    });
  }, []);

  const ctaButtons = content.cta_buttons as CtaButton[];
  const highlights = content.highlights as Highlight[];

  return (
    <section id="about" className="bg-ivory section-padding overflow-hidden">
      <div className="container-site" ref={ref}>
        <div className="grid lg:grid-cols-[30%_70%] gap-8 lg:gap-0 items-start">

          {/* Left — large watermark label (30%) */}
          <div className="relative lg:self-stretch flex items-start">
            <motion.div
              initial={{ opacity: 0, x: -24 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.7, ease: 'easeOut' }}
              className="lg:sticky lg:top-32 self-start"
            >
              {/* Watermark "ABOUT US" */}
              <div
                className="select-none leading-none font-bold text-left"
                style={{
                  fontSize: 'clamp(3rem, 7vw, 6.5rem)',
                  color: 'transparent',
                  WebkitTextStroke: '1.5px #C5D0ED',
                  letterSpacing: '-0.03em',
                  lineHeight: 1,
                  marginLeft: '-0.04em',
                }}
              >
                ABOUT<br />US
              </div>
              {/* Subtle accent bar below */}
              <div className="w-8 h-0.5 bg-green-primary mt-6 hidden lg:block" />
            </motion.div>
          </div>

          {/* Right — main content (70%) */}
          <div className="lg:pl-8 xl:pl-16">
            {/* Section label */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="flex items-center gap-3 mb-6"
            >
              <div className="w-6 h-px bg-green-primary" />
              <span className="section-label">{content.section_label}</span>
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 28 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, ease: 'easeOut', delay: 0.1 }}
              className="text-display-md font-bold text-charcoal leading-tight mb-8 max-w-2xl"
            >
              {content.heading}
            </motion.h2>

            <div className="space-y-5 text-body-xl text-charcoal-500 font-light leading-relaxed max-w-2xl">
              {content.body_paragraphs.map((para, i) => (
                <motion.p
                  key={i}
                  initial={{ opacity: 0, y: 28 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, ease: 'easeOut', delay: 0.22 + i * 0.1 }}
                >
                  {para}
                </motion.p>
              ))}

              {content.closing_line && (
                <motion.p
                  initial={{ opacity: 0, y: 28 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, ease: 'easeOut', delay: 0.72 }}
                  className="font-medium text-charcoal"
                >
                  {content.closing_line}
                </motion.p>
              )}
            </div>

            {/* CTA Buttons */}
            {ctaButtons.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 28 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, ease: 'easeOut', delay: 0.82 }}
                className="flex flex-wrap gap-3 mt-10"
              >
                {ctaButtons.map((btn) => (
                  <a
                    key={btn.label}
                    href={btn.href}
                    className="inline-flex items-center gap-2 px-6 py-3 border border-charcoal-200 text-charcoal font-medium text-body-sm hover:bg-blue-primary hover:text-white hover:border-blue-primary transition-all duration-300 group"
                  >
                    {btn.label}
                    <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-200" />
                  </a>
                ))}
              </motion.div>
            )}

            {/* Highlight Strip */}
            {highlights.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 28 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, ease: 'easeOut', delay: 0.92 }}
                className="mt-14 grid grid-cols-1 sm:grid-cols-3 gap-0 border border-charcoal-100 max-w-2xl"
              >
                {highlights.map((h, i) => (
                  <div
                    key={i}
                    className={`p-6 ${i < highlights.length - 1 ? 'border-b sm:border-b-0 sm:border-r border-charcoal-100' : ''}`}
                  >
                    <div className="text-display-sm font-bold text-blue-primary leading-none">
                      {h.value}
                      <span className="text-heading-xl text-green-primary">{h.unit}</span>
                    </div>
                    <p className="text-body-sm text-charcoal-500 mt-2 leading-relaxed">{h.label}</p>
                  </div>
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
