import { useRef, useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import type { RefObject } from 'react';
import { getImpactStats } from '../../cms/queries';
import type { ImpactStat } from '../../cms/types';

const FALLBACK_STATS: ImpactStat[] = [
  { id: '1', sort_order: 1, is_active: true, number_value: '291000', suffix: '+', unit: ' MT', label: 'of waste diverted from landfills & oceans', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, number_value: '3608', suffix: '+', unit: '', label: 'livelihoods impacted', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, number_value: '310', suffix: '+', unit: '', label: 'villages, towns and cities with waste recovery sites', created_at: '', updated_at: '' },
  { id: '4', sort_order: 4, is_active: true, number_value: '10', suffix: '+', unit: '', label: 'years of driving a circular economy', created_at: '', updated_at: '' },
];

function useCountUp(target: number, duration: number, start: boolean) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const animate = (ts: number) => {
      if (!startTime) startTime = ts;
      const progress = Math.min((ts - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * target));
      if (progress < 1) requestAnimationFrame(animate);
      else setCount(target);
    };
    requestAnimationFrame(animate);
  }, [target, duration, start]);
  return count;
}

function StatItem({ stat, index, started }: { stat: ImpactStat; index: number; started: boolean }) {
  const raw = parseInt(stat.number_value.replace(/,/g, ''), 10);
  const count = useCountUp(raw, 2200 + index * 200, started);
  const formatted = count >= 1000 ? count.toLocaleString('en-IN') : count.toString();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={started ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.55, delay: index * 0.1, ease: 'easeOut' }}
      className="flex-shrink-0 px-10 border-r border-white/10 last:border-r-0 first:pl-0"
    >
      <div className="flex items-baseline gap-1">
        <span className="text-display-md font-bold text-white leading-none">{formatted}</span>
        <span className="text-heading-xl font-bold text-green-primary leading-none">{stat.suffix}{stat.unit}</span>
      </div>
      <p className="text-body-sm text-white/55 mt-2 leading-relaxed max-w-[200px]">{stat.label}</p>
    </motion.div>
  );
}

export default function ImpactSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as unknown as RefObject<HTMLElement>, { once: true, margin: '-80px' });
  const [stats, setStats] = useState<ImpactStat[]>(FALLBACK_STATS);

  useEffect(() => {
    getImpactStats().then((data) => {
      if (data.length > 0) {
        // Filter out "4 years of consistently measuring impact" stat
        const filtered = data.filter((s) => !s.label.includes('consistently measuring impact'));
        setStats(filtered.length > 0 ? filtered : data.filter((_, i) => i < 4));
      }
    });
  }, []);

  return (
    <section id="our-impact" className="bg-blue-primary overflow-hidden">
      <div className="container-site" ref={ref}>
        <div className="py-20 lg:py-28">
          {/* Header */}
          <div className="flex items-center justify-between flex-wrap gap-4 mb-14">
            <div className="flex items-center gap-4">
              <div className="w-8 h-px bg-green-primary" />
              <motion.h2
                initial={{ opacity: 0, x: -16 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className="text-display-sm font-bold text-white"
              >
                Our Impact
              </motion.h2>
            </div>
            <motion.a
              href="/impact"
              initial={{ opacity: 0, x: 16 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.15, ease: 'easeOut' }}
              className="inline-flex items-center gap-2 px-6 py-3 border border-white/30 text-white font-medium text-body-sm hover:bg-white hover:text-blue-primary transition-all duration-300 group"
            >
              View Full Impact Report
              <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-200" />
            </motion.a>
          </div>

          {/* Stats — horizontal scroll on mobile */}
          <div className="overflow-x-auto no-scrollbar -mx-6 px-6 lg:mx-0 lg:px-0">
            <div className="flex gap-0 min-w-max lg:min-w-0 lg:flex-wrap lg:gap-y-10">
              {stats.map((stat, i) => (
                <StatItem key={stat.id} stat={stat} index={i} started={inView} />
              ))}
            </div>
          </div>

          {/* Bottom decorative line */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={inView ? { scaleX: 1 } : {}}
            transition={{ duration: 1.2, delay: 0.6, ease: 'easeOut' }}
            className="mt-14 h-px bg-gradient-to-r from-white/5 via-white/20 to-white/5 origin-left"
          />

          <motion.p
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 1 }}
            className="mt-6 text-body-sm text-white/40 text-right font-light"
          >
            Impact data as measured through verified ground operations across India.
          </motion.p>
        </div>
      </div>
    </section>
  );
}
