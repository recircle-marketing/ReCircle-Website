import { useRef, useEffect, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { getInvestors, getInvestorsMeta } from '../../cms/queries';
import type { Investor, InvestorsSectionMeta } from '../../cms/types';

const FALLBACK_META: InvestorsSectionMeta = {
  id: '', heading: 'Our Investors', body_copy: 'Meet the forward-thinking investors who drive ReCircle\'s mission of creating a circular future.', updated_at: '',
};

const FALLBACK_INVESTORS: Investor[] = [
  { id: '1', sort_order: 1, is_active: true, name: 'Mumbai Angels', abbr: 'MA', color: '#E7182A', logo_url: 'https://recircle.in/wp-content/uploads/2024/09/Mumbai-Angels_01.png', logo_alt: 'Mumbai Angels logo', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, name: 'Flipkart Ventures', abbr: 'FV', color: '#2874F0', logo_url: 'https://recircle.in/wp-content/uploads/2024/07/Flip_Ventures.svg', logo_alt: 'Flipkart Ventures logo', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, name: 'Acumen', abbr: 'AC', color: '#00A86B', logo_url: 'https://recircle.in/wp-content/uploads/2025/05/Acumen.jpg', logo_alt: 'Acumen logo', created_at: '', updated_at: '' },
  { id: '4', sort_order: 4, is_active: true, name: '3i Partners', abbr: '3i', color: '#1A1A1A', logo_url: 'https://recircle.in/wp-content/uploads/2024/07/3i.svg', logo_alt: '3i Partners logo', created_at: '', updated_at: '' },
  { id: '5', sort_order: 5, is_active: true, name: 'Venture Catalysts', abbr: 'VC', color: '#01298A', logo_url: 'https://recircle.in/wp-content/uploads/2024/09/Venture-catalysts1.png', logo_alt: 'Venture Catalysts logo', created_at: '', updated_at: '' },
];

function InvestorLogo({ investor }: { investor: Investor }) {
  return (
    <div className="flex-shrink-0 flex items-center justify-center px-12 py-8 min-w-[220px] group">
      <img
        src={investor.logo_url || `data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'/>`}
        alt={investor.logo_alt}
        className="h-10 object-contain grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-400 max-w-[160px]"
      />
    </div>
  );
}

export default function InvestorsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as React.RefObject<HTMLElement>, { once: true, margin: '-60px' });
  const [meta, setMeta] = useState<InvestorsSectionMeta>(FALLBACK_META);
  const [investors, setInvestors] = useState<Investor[]>(FALLBACK_INVESTORS);

  useEffect(() => {
    Promise.all([getInvestorsMeta(), getInvestors()]).then(([m, inv]) => {
      if (m) setMeta(m);
      if (inv.length > 0) setInvestors(inv);
    });
  }, []);

  const doubled = [...investors, ...investors, ...investors, ...investors];

  return (
    <section className="bg-ivory section-padding-sm border-t border-charcoal-100">
      <div className="container-site mb-12" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.55, ease: 'easeOut' }}
          className="flex flex-col sm:flex-row sm:items-end justify-between gap-4"
        >
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-6 h-px bg-green-primary" />
              <span className="section-label">Backed by</span>
            </div>
            <h2 className="text-display-sm font-bold text-charcoal">{meta.heading}</h2>
          </div>
          <p className="text-body-lg text-charcoal-400 font-light max-w-xs text-right leading-relaxed">
            {meta.body_copy}
          </p>
        </motion.div>
      </div>

      {/* Ticker */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={inView ? { opacity: 1 } : {}}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="ticker-container border-y border-charcoal-100 bg-white"
      >
        <div className="ticker-track-slow py-2">
          {doubled.map((inv, i) => (
            <InvestorLogo key={`${inv.id}-${i}`} investor={inv} />
          ))}
        </div>
      </motion.div>
    </section>
  );
}
