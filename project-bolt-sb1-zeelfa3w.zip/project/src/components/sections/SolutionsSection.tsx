import { useState, useRef, useEffect } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { Plus, Minus, ArrowRight } from 'lucide-react';
import { getSolutions, getSolutionsMeta } from '../../cms/queries';
import type { Solution, SolutionsSectionMeta } from '../../cms/types';

const FALLBACK_META: SolutionsSectionMeta = {
  id: '',
  heading: 'End-to-End Solutions Across the Value Chain',
  body_copy: 'Our business model brings recovery infrastructure, traceability technology, compliance execution, and recycled raw material supply into one connected system that drives circular operations at scale.',
  updated_at: '',
};

const FALLBACK_SOLUTIONS: Solution[] = [
  { id: '1', sort_order: 1, is_active: true, heading: 'Extended Producer Responsibility (EPR)', expanded_description: 'End-to-end EPR Compliance services that help businesses meet regulatory obligations through verified collection, recovery, and transparent reporting.', tag: 'Service — Plastic', side: 'left', href: '/epr', created_at: '', updated_at: '' },
  { id: '2', sort_order: 2, is_active: true, heading: 'Plastic Neutral Programme', expanded_description: 'Plastic offsetting programmes designed to help brands recover an equivalent amount of plastic waste while driving measurable environmental impact.', tag: 'Service — Plastic', side: 'right', href: '/pnp', created_at: '', updated_at: '' },
  { id: '3', sort_order: 3, is_active: true, heading: 'Textile Waste Management', expanded_description: 'Structured post-consumer and post-industrial textile waste management solutions that enable responsible recovery, diversion, and circular reuse.', tag: 'Service — Textile', side: 'left', href: '/textile', created_at: '', updated_at: '' },
  { id: '4', sort_order: 4, is_active: true, heading: 'rPET Flakes', expanded_description: 'High-quality food-grade rPET flakes supporting recycled content goals and circular packaging supply chains.', tag: 'Product', side: 'right', href: '/rpet-flakes', created_at: '', updated_at: '' },
  { id: '5', sort_order: 5, is_active: true, heading: 'ESG Projects', expanded_description: 'Custom CSR/ESG projects built around waste recovery, livelihoods, circularity, and long-term environmental impact.', tag: 'ESG', side: 'left', href: '/esg-projects', created_at: '', updated_at: '' },
  { id: '6', sort_order: 6, is_active: true, heading: 'ClimaOne for rPET', expanded_description: 'A traceability platform that tracks material movement across the recycling supply chain with verified recovery and compliance data.', tag: 'Product — Technology', side: 'right', href: 'https://climaonev2.recircle.in/', created_at: '', updated_at: '' },
  { id: '7', sort_order: 7, is_active: true, heading: 'Infrastructure', expanded_description: 'Integrated infrastructure, including material & textile recovery facilities and recycling plants, that enable efficient sorting, processing, and material recovery.', tag: 'Operations', side: 'left', href: '/infrastructure/mrf', created_at: '', updated_at: '' },
];

export default function SolutionsSection() {
  const [openId, setOpenId] = useState<string | null>('1');
  const [meta, setMeta] = useState<SolutionsSectionMeta>(FALLBACK_META);
  const [solutions, setSolutions] = useState<Solution[]>(FALLBACK_SOLUTIONS);
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as React.RefObject<HTMLElement>, { once: true, margin: '-80px' });

  useEffect(() => {
    Promise.all([getSolutionsMeta(), getSolutions()]).then(([m, s]) => {
      if (m) setMeta(m);
      if (s.length > 0) setSolutions(s);
    });
  }, []);

  const toggle = (id: string) => setOpenId(openId === id ? null : id);

  return (
    <section id="solutions" className="bg-white section-padding overflow-hidden">
      <div className="container-site">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-start" ref={ref}>

          {/* Left — heading + description, sticky centered in viewport */}
          <div className="lg:sticky lg:top-0 lg:h-screen lg:flex lg:items-center self-start">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="w-full"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-px bg-green-primary" />
                <span className="section-label">Solutions & Offerings</span>
              </div>

              <h2 className="text-display-md font-bold text-charcoal leading-tight mb-6">
                {meta.heading}
              </h2>

              <p className="text-body-xl text-charcoal-500 font-light leading-relaxed mb-8">
                {meta.body_copy}
              </p>

              <a href="#contact" className="inline-flex items-center gap-2 px-6 py-3 bg-blue-primary text-white font-medium text-body-sm hover:bg-blue-800 transition-all duration-300 group">
                Partner With Us
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-200" />
              </a>

              <div className="flex items-center gap-4 mt-16 pt-8 border-t border-charcoal-100">
                <div className="w-3 h-3 rounded-full bg-blue-primary shrink-0" />
                <p className="text-body-sm text-charcoal-400 font-light leading-relaxed">
                  Each solution operates as a node in a connected circular ecosystem — not as isolated services.
                </p>
              </div>
            </motion.div>
          </div>

          {/* Right — pathway visualization */}
          <div className="relative py-8">
            {/* Central vertical line — extends slightly past last item */}
            <div className="absolute left-1/2 -translate-x-1/2" style={{ top: 0, bottom: '-2rem' }}>
              <div className="relative w-px h-full bg-charcoal-100">
                <motion.div
                  initial={{ scaleY: 0 }}
                  animate={inView ? { scaleY: 1 } : {}}
                  transition={{ duration: 1.5, delay: 0.3, ease: 'easeOut' }}
                  className="absolute inset-0 bg-gradient-to-b from-blue-primary to-green-primary origin-top"
                />
              </div>
            </div>

            {/* Solution nodes */}
            <div className="relative space-y-6">
              {solutions.map((solution, i) => {
                const isLeft = solution.side === 'left';
                return (
                  <div key={solution.id} className="relative">
                    {/* Center dot — centered on line */}
                    <motion.div
                      initial={{ scale: 0, opacity: 0 }}
                      animate={inView ? { scale: 1, opacity: 1 } : {}}
                      transition={{ duration: 0.3, delay: 0.3 + i * 0.1 }}
                      className="absolute left-1/2 -translate-x-1/2 z-10"
                      style={{ top: '1.125rem' }}
                    >
                      <div className={`w-3 h-3 rounded-full border-2 ${openId === solution.id ? 'bg-green-primary border-green-primary' : 'bg-white border-blue-primary'} transition-colors duration-300`} />
                    </motion.div>

                    {/* Card — always on left or right of center line */}
                    <div className={`flex ${isLeft ? 'justify-start pr-[54%]' : 'justify-end pl-[54%]'}`}>
                      <motion.div
                        initial={{ opacity: 0, x: isLeft ? -24 : 24 }}
                        animate={inView ? { opacity: 1, x: 0 } : {}}
                        transition={{ duration: 0.55, delay: 0.2 + i * 0.1, ease: 'easeOut' }}
                        className="w-full"
                      >
                        <button
                          onClick={() => toggle(solution.id)}
                          className={`w-full text-left border transition-all duration-300 ${
                            openId === solution.id
                              ? 'border-blue-primary bg-blue-primary text-white'
                              : 'border-charcoal-200 bg-white hover:border-blue-primary text-charcoal'
                          }`}
                        >
                          <div className="flex items-center justify-between px-4 py-3.5">
                            <div className="flex-1 min-w-0 pr-2">
                              <span className={`text-[10px] font-semibold tracking-widest uppercase block mb-0.5 ${openId === solution.id ? 'text-green-primary' : 'text-charcoal-400'}`}>
                                {solution.tag}
                              </span>
                              <span className="text-body-sm font-semibold leading-tight block">{solution.heading}</span>
                            </div>
                            <div className={`w-6 h-6 flex items-center justify-center shrink-0 ${openId === solution.id ? 'text-white' : 'text-charcoal-400'}`}>
                              {openId === solution.id ? <Minus size={12} /> : <Plus size={12} />}
                            </div>
                          </div>
                        </button>

                        <AnimatePresence>
                          {openId === solution.id && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="overflow-hidden border border-t-0 border-blue-primary bg-blue-primary"
                            >
                              <div className="px-4 pb-4">
                                <p className="text-body-sm text-white/80 leading-relaxed">{solution.expanded_description}</p>
                                <a
                                  href={solution.href}
                                  className="inline-flex items-center gap-1.5 text-green-primary text-body-sm font-medium mt-3 hover:gap-2.5 transition-all duration-200"
                                >
                                  Learn more <ArrowRight size={12} />
                                </a>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* End node — Circular Economy box, centered, line extends through it */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: 1.2 }}
              className="relative flex justify-center mt-6 z-10"
            >
              <div className="flex items-center gap-2 px-5 py-2.5 border-2 border-green-primary bg-white">
                <div className="w-2 h-2 rounded-full bg-green-primary" />
                <span className="text-caption font-semibold tracking-wider uppercase text-green-primary">
                  Circular Economy
                </span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
