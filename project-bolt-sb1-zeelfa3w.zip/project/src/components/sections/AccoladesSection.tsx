import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const ACCOLADES = [
  {
    id: '1',
    org: 'YourStory',
    logo_url: 'https://recircle.in/wp-content/uploads/2025/05/Yourstory.png',
    award: 'Tech30 Recognition',
    date: '2024',
  },
  {
    id: '2',
    org: 'The Economic Times',
    logo_url: 'https://recircle.in/wp-content/uploads/2025/05/The-Economic-Times.jpg',
    award: 'Top Innovative MSME of the Year',
    date: '2024',
  },
  {
    id: '3',
    org: 'CSR Universe',
    logo_url: 'https://recircle.in/wp-content/uploads/2025/05/CSR-Universe.png',
    award: "CASCA'25 Award for Excellence in Waste Management & Circular Economy",
    date: '2025',
  },
  {
    id: '4',
    org: 'FICCI',
    logo_url: 'https://recircle.in/wp-content/uploads/2025/05/FICCI_logo.png',
    award: 'Circular Business Model — Evolved Category Award',
    date: '2024',
  },
];

function AccoladeCard({ a, index, inView }: { a: typeof ACCOLADES[0]; index: number; inView: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: 0.1 + index * 0.1, ease: 'easeOut' }}
      className="bg-white border border-charcoal-100 p-8 flex flex-col hover:border-blue-primary hover:shadow-card transition-all duration-300 group"
    >
      {/* Publication logo */}
      <div className="h-12 flex items-center mb-6">
        <img
          src={a.logo_url}
          alt={`${a.org} logo`}
          className="h-full object-contain max-w-[160px] grayscale group-hover:grayscale-0 transition-all duration-300"
        />
      </div>

      {/* Award name */}
      <h3 className="text-body-lg font-semibold text-charcoal leading-snug flex-1 group-hover:text-blue-primary transition-colors duration-200 mb-4">
        {a.award}
      </h3>

      {/* Date */}
      <div className="flex items-center justify-between pt-4 border-t border-charcoal-100">
        <span className="text-caption font-bold text-charcoal-300 tracking-widest">{a.date}</span>
        <div className="w-6 h-0.5 bg-green-primary group-hover:w-12 transition-all duration-300" />
      </div>
    </motion.div>
  );
}

export default function AccoladesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as React.RefObject<HTMLElement>, { once: true, margin: '-60px' });

  return (
    <section className="bg-ivory section-padding border-t border-charcoal-100">
      <div className="container-site" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.55, ease: 'easeOut' }}
          className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12"
        >
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-6 h-px bg-green-primary" />
              <span className="section-label">Recognition</span>
            </div>
            <h2 className="text-display-sm font-bold text-charcoal">Accolades & Mentions</h2>
          </div>
          <p className="text-body-lg text-charcoal-400 font-light max-w-xs text-right leading-relaxed">
            Defining the gold standard in waste management
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {ACCOLADES.map((a, i) => (
            <AccoladeCard key={a.id} a={a} index={i} inView={inView} />
          ))}
        </div>
      </div>
    </section>
  );
}
