import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, Linkedin, Facebook, Instagram, CheckCircle, ArrowRight } from 'lucide-react';
import { getContactPageSettings, submitContactEnquiry } from '../../cms/queries';
import type { ContactPageSettings } from '../../cms/types';

const FALLBACK: ContactPageSettings = {
  id: '',
  email: 'info@recircle.in',
  phone: '+91 90042 40004',
  linkedin_url: 'https://www.linkedin.com/company/recircleindia',
  facebook_url: 'https://www.facebook.com/recircle.in/',
  instagram_url: 'https://www.instagram.com/RECIRCLE.IN/',
  form_heading: "Let's Start the Conversation",
  form_subheading: 'Ready to take the next step? Reach out to our team and let us help you achieve your sustainability goals.',
  service_options: [
    'Extended Producer Responsibility (EPR)',
    'Plastic Neutral Programme',
    'Textile Waste Management (PITW)',
    'Textile Waste Management (PCTW)',
    'rPET Flakes',
    'ClimaOne for EPR',
    'ClimaOne for rPET',
    'ESG Projects',
    'Other',
  ],
  map_embed_url: '',
  updated_at: '',
};

const fadeUp = {
  hidden: { opacity: 0, y: 32 },
  visible: (i = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.6, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] } }),
};

const NAVY = '#01298A';

export default function ContactSection() {
  const [settings, setSettings] = useState<ContactPageSettings>(FALLBACK);
  const [form, setForm] = useState({ name: '', company_name: '', email: '', phone: '', service: '', message: '' });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    getContactPageSettings().then((data) => { if (data) setSettings(data); });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    const { error: err } = await submitContactEnquiry(form);
    setSubmitting(false);
    if (err) { setError('Something went wrong. Please try again.'); return; }
    setSubmitted(true);
    setForm({ name: '', company_name: '', email: '', phone: '', service: '', message: '' });
  };

  return (
    <>
      {/* ── Contact Form (blue background) ─────────────────────────────── */}
      <section className="section-padding" style={{ backgroundColor: NAVY }}>
        <div className="container-site">
          <div className="max-w-3xl mx-auto">
            <motion.div
              className="text-center mb-12"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="w-8 h-px bg-green-primary" />
                <span className="text-xs font-semibold tracking-widest uppercase text-green-primary">Get in Touch</span>
                <div className="w-8 h-px bg-green-primary" />
              </div>
              <h2 className="font-display text-display-sm font-bold mb-4 text-white">{settings.form_heading}</h2>
              <p className="text-body-lg text-white/60">{settings.form_subheading}</p>
            </motion.div>

            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center text-center py-16"
              >
                <CheckCircle size={56} style={{ color: '#00C499' }} className="mb-6" />
                <h3 className="text-2xl font-bold text-white mb-3">Message Received!</h3>
                <p className="text-white/60">Our team will get back to you within 24–48 hours.</p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-8 px-6 py-3 text-sm font-semibold border border-white/30 text-white hover:bg-white/10 transition-colors"
                >
                  Send Another Message
                </button>
              </motion.div>
            ) : (
              <motion.form
                onSubmit={handleSubmit}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="space-y-6"
              >
                {error && (
                  <div className="px-4 py-3 text-sm bg-red-500/20 border border-red-400/40 text-red-200">{error}</div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest mb-2 text-white/50">Name *</label>
                    <input
                      type="text" required value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-4 py-3 bg-white/8 border text-white placeholder-white/25 focus:outline-none transition-colors"
                      style={{ borderColor: 'rgba(255,255,255,0.15)' }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = '#00C499'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)'; }}
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest mb-2 text-white/50">Company Name *</label>
                    <input
                      type="text" required value={form.company_name}
                      onChange={(e) => setForm({ ...form, company_name: e.target.value })}
                      className="w-full px-4 py-3 bg-white/8 border text-white placeholder-white/25 focus:outline-none transition-colors"
                      style={{ borderColor: 'rgba(255,255,255,0.15)' }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = '#00C499'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)'; }}
                      placeholder="Your organisation"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest mb-2 text-white/50">Email *</label>
                    <input
                      type="email" required value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-3 bg-white/8 border text-white placeholder-white/25 focus:outline-none transition-colors"
                      style={{ borderColor: 'rgba(255,255,255,0.15)' }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = '#00C499'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)'; }}
                      placeholder="you@company.com"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest mb-2 text-white/50">Phone Number *</label>
                    <input
                      type="tel" required value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full px-4 py-3 bg-white/8 border text-white placeholder-white/25 focus:outline-none transition-colors"
                      style={{ borderColor: 'rgba(255,255,255,0.15)' }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = '#00C499'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)'; }}
                      placeholder="+91 00000 00000"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-widest mb-2 text-white/50">I Need Help With *</label>
                  <select
                    required value={form.service}
                    onChange={(e) => setForm({ ...form, service: e.target.value })}
                    className="w-full px-4 py-3 border text-white focus:outline-none transition-colors appearance-none cursor-pointer"
                    style={{ borderColor: 'rgba(255,255,255,0.15)', backgroundColor: 'rgba(255,255,255,0.05)' }}
                    onFocus={(e) => { e.currentTarget.style.borderColor = '#00C499'; }}
                    onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'; }}
                  >
                    <option value="" disabled style={{ backgroundColor: NAVY }}>Select a service…</option>
                    {(settings.service_options as string[]).map((opt) => (
                      <option key={opt} value={opt} style={{ backgroundColor: NAVY }}>{opt}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-widest mb-2 text-white/50">Message *</label>
                  <textarea
                    required value={form.message} rows={5}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border text-white placeholder-white/25 focus:outline-none transition-colors resize-none"
                    style={{ borderColor: 'rgba(255,255,255,0.15)' }}
                    onFocus={(e) => { e.currentTarget.style.borderColor = '#00C499'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'; }}
                    onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'; e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)'; }}
                    placeholder="Tell us about your project or question…"
                  />
                </div>
                <div>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex items-center gap-2 px-10 py-4 bg-green-primary text-white text-sm font-semibold uppercase tracking-widest hover:bg-green-600 transition-colors duration-300 disabled:opacity-60 disabled:cursor-not-allowed group"
                  >
                    {submitting ? 'Sending…' : 'Send Message'}
                    {!submitting && <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-200" />}
                  </button>
                </div>
              </motion.form>
            )}
          </div>
        </div>
      </section>

      {/* ── Contact Details (email, phone, social) ──────────────────────── */}
      <section className="section-padding bg-ivory border-t border-charcoal-100">
        <div className="container-site">
          <motion.div
            className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
          >
            {/* Email */}
            <motion.div variants={fadeUp} custom={0} className="flex flex-col items-start">
              <div className="w-12 h-12 rounded-full flex items-center justify-center mb-5" style={{ backgroundColor: '#E8EDF8' }}>
                <Mail size={20} style={{ color: NAVY }} />
              </div>
              <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: '#858585' }}>Email Us</p>
              <a
                href={`mailto:${settings.email}`}
                className="text-lg font-semibold transition-colors hover:underline"
                style={{ color: NAVY }}
              >
                {settings.email}
              </a>
            </motion.div>

            {/* Phone */}
            <motion.div variants={fadeUp} custom={1} className="flex flex-col items-start">
              <div className="w-12 h-12 rounded-full flex items-center justify-center mb-5" style={{ backgroundColor: '#E8EDF8' }}>
                <Phone size={20} style={{ color: NAVY }} />
              </div>
              <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: '#858585' }}>Call Us</p>
              <a
                href={`tel:${settings.phone.replace(/\s/g, '')}`}
                className="text-lg font-semibold transition-colors hover:underline"
                style={{ color: NAVY }}
              >
                {settings.phone}
              </a>
            </motion.div>

            {/* Social */}
            <motion.div variants={fadeUp} custom={2} className="flex flex-col items-start">
              <div className="w-12 h-12 rounded-full flex items-center justify-center mb-5" style={{ backgroundColor: '#E8EDF8' }}>
                <Instagram size={20} style={{ color: NAVY }} />
              </div>
              <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: '#858585' }}>Follow Us</p>
              <div className="flex items-center gap-4 mt-1">
                <a href={settings.linkedin_url} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn"
                  className="w-10 h-10 rounded-full flex items-center justify-center border transition-all hover:scale-110"
                  style={{ borderColor: '#D1D1D1' }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = NAVY; e.currentTarget.style.borderColor = NAVY; (e.currentTarget.querySelector('svg') as SVGElement).style.color = '#fff'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.borderColor = '#D1D1D1'; (e.currentTarget.querySelector('svg') as SVGElement).style.color = '#1A1A1A'; }}
                >
                  <Linkedin size={16} style={{ color: '#1A1A1A' }} />
                </a>
                <a href={settings.facebook_url} target="_blank" rel="noopener noreferrer" aria-label="Facebook"
                  className="w-10 h-10 rounded-full flex items-center justify-center border transition-all hover:scale-110"
                  style={{ borderColor: '#D1D1D1' }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = NAVY; e.currentTarget.style.borderColor = NAVY; (e.currentTarget.querySelector('svg') as SVGElement).style.color = '#fff'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.borderColor = '#D1D1D1'; (e.currentTarget.querySelector('svg') as SVGElement).style.color = '#1A1A1A'; }}
                >
                  <Facebook size={16} style={{ color: '#1A1A1A' }} />
                </a>
                <a href={settings.instagram_url} target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                  className="w-10 h-10 rounded-full flex items-center justify-center border transition-all hover:scale-110"
                  style={{ borderColor: '#D1D1D1' }}
                  onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = NAVY; e.currentTarget.style.borderColor = NAVY; (e.currentTarget.querySelector('svg') as SVGElement).style.color = '#fff'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.borderColor = '#D1D1D1'; (e.currentTarget.querySelector('svg') as SVGElement).style.color = '#1A1A1A'; }}
                >
                  <Instagram size={16} style={{ color: '#1A1A1A' }} />
                </a>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Map */}
      <section className="w-full" style={{ height: '420px' }}>
        {settings.map_embed_url ? (
          <iframe
            src={settings.map_embed_url}
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="ReCircle Office Location"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: '#E8EDF8' }}>
            <div className="text-center">
              <p className="text-sm font-medium" style={{ color: NAVY }}>Map coming soon</p>
              <p className="text-xs mt-1" style={{ color: '#858585' }}>Configure the map embed URL in the CMS admin panel</p>
            </div>
          </div>
        )}
      </section>
    </>
  );
}
