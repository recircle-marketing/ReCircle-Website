import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { getHeroSlides } from '../../cms/queries';
import type { HeroSlide } from '../../cms/types';
import { FALLBACK_HERO_SLIDES } from '../../cms/types';

const AUTOPLAY_INTERVAL = 6000;

export default function HeroSection() {
  const [slides, setSlides] = useState<HeroSlide[]>(FALLBACK_HERO_SLIDES);
  const [current, setCurrent] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    getHeroSlides().then((data) => {
      if (data.length > 0) setSlides(data);
    });
  }, []);

  const goTo = useCallback((index: number) => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrent(index);
    setTimeout(() => setIsTransitioning(false), 700);
  }, [isTransitioning]);

  const goNext = useCallback(() => goTo((current + 1) % slides.length), [current, goTo, slides.length]);
  const goPrev = useCallback(() => goTo((current - 1 + slides.length) % slides.length), [current, goTo, slides.length]);

  useEffect(() => {
    const timer = setInterval(goNext, AUTOPLAY_INTERVAL);
    return () => clearInterval(timer);
  }, [goNext]);

  const slide = slides[current];
  if (!slide) return null;

  return (
    <section className="relative h-screen min-h-[640px] max-h-[960px] overflow-hidden bg-charcoal-900">
      {/* Background Images */}
      <AnimatePresence mode="wait">
        <motion.div
          key={slide.id}
          initial={{ opacity: 0, scale: 1.04 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.85, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="absolute inset-0"
        >
          <img
            src={slide.image_url}
            alt={slide.image_alt}
            className="w-full h-full object-cover"
            loading="eager"
          />
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal-900/85 via-charcoal-900/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/60 via-transparent to-transparent" />
        </motion.div>
      </AnimatePresence>

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-grid opacity-10" />

      {/* Content */}
      <div className="relative z-10 h-full flex items-center">
        <div className="container-site w-full">
          <div className="max-w-3xl">
            <AnimatePresence mode="wait">
              <motion.div
                key={slide.id}
                initial={{ opacity: 0, y: 32 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.65, ease: [0.25, 0.46, 0.45, 0.94], delay: 0.1 }}
              >
                {/* Tag */}
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-8 h-px bg-green-primary" />
                  <span className="text-caption font-semibold tracking-widest uppercase text-green-primary">
                    {slide.tag}
                  </span>
                </div>

                {/* Headline */}
                <h1 className="text-display-lg lg:text-display-xl font-bold text-white leading-[1.05] mb-6 tracking-tight">
                  {slide.headline}
                </h1>

                {/* Subheading */}
                <p className="text-body-xl text-white/75 leading-relaxed mb-10 max-w-xl font-light">
                  {slide.subheading}
                </p>

                {/* CTAs */}
                <div className="flex flex-wrap gap-4">
                  <a href={slide.cta_href} className="inline-flex items-center gap-2 px-7 py-3.5 bg-green-primary text-white font-medium text-body-sm hover:bg-green-600 transition-all duration-300 group">
                    {slide.cta_label}
                    <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-200" />
                  </a>
                  {slide.cta_secondary_label && (
                    <a href={slide.cta_secondary_href} className="inline-flex items-center gap-2 px-7 py-3.5 border border-white/40 text-white font-medium text-body-sm hover:bg-white/10 transition-all duration-300 backdrop-blur-sm">
                      {slide.cta_secondary_label}
                    </a>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-10 left-0 right-0 z-10">
        <div className="container-site flex items-center justify-between">
          {/* Progress dots */}
          <div className="flex items-center gap-2">
            {slides.map((s, i) => (
              <button
                key={s.id}
                onClick={() => goTo(i)}
                className={`transition-all duration-400 rounded-full ${
                  i === current
                    ? 'w-8 h-1.5 bg-green-primary'
                    : 'w-1.5 h-1.5 bg-white/40 hover:bg-white/70'
                }`}
                aria-label={`Go to slide ${i + 1}`}
              />
            ))}
          </div>

          {/* Slide number + controls */}
          <div className="flex items-center gap-4">
            <span className="text-caption text-white/50 font-medium">
              {String(current + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={goPrev}
                className="w-9 h-9 border border-white/30 flex items-center justify-center text-white hover:bg-white/10 transition-colors duration-200"
                aria-label="Previous slide"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                onClick={goNext}
                className="w-9 h-9 border border-white/30 flex items-center justify-center text-white hover:bg-white/10 transition-colors duration-200"
                aria-label="Next slide"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/10 z-10">
        <motion.div
          key={current}
          initial={{ width: '0%' }}
          animate={{ width: '100%' }}
          transition={{ duration: AUTOPLAY_INTERVAL / 1000, ease: 'linear' }}
          className="h-full bg-green-primary"
        />
      </div>

      {/* Stats bar at bottom */}
      <div className="absolute bottom-0 right-0 hidden xl:flex z-10">
        <div className="flex">
          {[
            { value: '291K+', label: 'MT Waste Diverted' },
            { value: '3,608+', label: 'Livelihoods Impacted' },
            { value: '310+', label: 'Recovery Sites' },
          ].map((stat, i) => (
            <div key={i} className="px-6 py-4 border-l border-white/10 bg-charcoal-900/60 backdrop-blur-sm">
              <div className="text-heading-lg font-bold text-green-primary leading-none">{stat.value}</div>
              <div className="text-caption text-white/60 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
