/*
  # Extend Site Settings and SEO Metadata

  ## Summary
  Adds missing columns to support the new CMS admin editors for:
  - SEO Defaults (keywords field, per-page SEO)
  - Contact Details (working hours, secondary phone, address lines)
  - Social Links (all platforms stored as structured JSON in site settings)
  - Brand Kit (external link managed from CMS)

  ## Changes to cms_site_settings
  - social_links: jsonb array of {platform, url, is_active} objects
  - working_hours: text field for office hours
  - secondary_phone: text
  - address_line_1, address_line_2, city, state, country, pincode: structured address
  - brand_kit_url: external URL for the brand kit Google Drive folder

  ## Changes to cms_seo_metadata
  - keywords: text field for comma-separated SEO keywords

  ## Notes
  - All new columns use safe IF NOT EXISTS checks
  - No data is dropped or altered
*/

DO $$
BEGIN
  -- Social links as JSON array
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'social_links') THEN
    ALTER TABLE cms_site_settings ADD COLUMN social_links jsonb NOT NULL DEFAULT '[
      {"platform":"LinkedIn","url":"https://www.linkedin.com/company/recircleindia","is_active":true},
      {"platform":"Instagram","url":"https://www.instagram.com/RECIRCLE.IN/","is_active":true},
      {"platform":"Facebook","url":"https://www.facebook.com/recircle.in/","is_active":true},
      {"platform":"YouTube","url":"","is_active":false},
      {"platform":"X / Twitter","url":"","is_active":false}
    ]';
  END IF;

  -- Working hours
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'working_hours') THEN
    ALTER TABLE cms_site_settings ADD COLUMN working_hours text NOT NULL DEFAULT 'Monday – Friday, 9:00 AM – 6:00 PM IST';
  END IF;

  -- Secondary phone
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'secondary_phone') THEN
    ALTER TABLE cms_site_settings ADD COLUMN secondary_phone text NOT NULL DEFAULT '';
  END IF;

  -- Structured address fields
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'address_line_1') THEN
    ALTER TABLE cms_site_settings ADD COLUMN address_line_1 text NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'address_line_2') THEN
    ALTER TABLE cms_site_settings ADD COLUMN address_line_2 text NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'city') THEN
    ALTER TABLE cms_site_settings ADD COLUMN city text NOT NULL DEFAULT 'Mumbai';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'state') THEN
    ALTER TABLE cms_site_settings ADD COLUMN state text NOT NULL DEFAULT 'Maharashtra';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'country') THEN
    ALTER TABLE cms_site_settings ADD COLUMN country text NOT NULL DEFAULT 'India';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'pincode') THEN
    ALTER TABLE cms_site_settings ADD COLUMN pincode text NOT NULL DEFAULT '';
  END IF;

  -- Brand Kit URL
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_site_settings' AND column_name = 'brand_kit_url') THEN
    ALTER TABLE cms_site_settings ADD COLUMN brand_kit_url text NOT NULL DEFAULT 'https://drive.google.com/drive/folders/1tfDGoJ2VPTv65OE2B-gjiApT9btxRxRt?usp=drive_link';
  END IF;

  -- Keywords on seo_metadata
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_seo_metadata' AND column_name = 'keywords') THEN
    ALTER TABLE cms_seo_metadata ADD COLUMN keywords text NOT NULL DEFAULT '';
  END IF;

  -- OG title and OG description on seo_metadata
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_seo_metadata' AND column_name = 'og_title') THEN
    ALTER TABLE cms_seo_metadata ADD COLUMN og_title text NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_seo_metadata' AND column_name = 'og_description') THEN
    ALTER TABLE cms_seo_metadata ADD COLUMN og_description text NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_seo_metadata' AND column_name = 'page_label') THEN
    ALTER TABLE cms_seo_metadata ADD COLUMN page_label text NOT NULL DEFAULT '';
  END IF;
END $$;

-- Seed default seo_metadata rows for all pages if they don't exist yet
INSERT INTO cms_seo_metadata (page_slug, page_label, page_title, meta_description, keywords, canonical_url)
VALUES
  ('/', 'Homepage', 'ReCircle — India''s Circular Economy Infrastructure', 'ReCircle builds India''s resource recovery systems, enabling traceable EPR compliance and circular infrastructure at scale.', 'EPR, circular economy, waste management, rPET, sustainability, India', '/'),
  ('/contact', 'Contact Us', 'Contact Us | ReCircle', 'Get in touch with ReCircle to learn more about our sustainability solutions.', 'contact ReCircle, EPR enquiry, sustainability contact', '/contact'),
  ('/blog', 'Blog / Knowledge Centre', 'Knowledge Centre | ReCircle', 'Insights, articles and updates from India''s leading circular economy company.', 'circular economy blog, EPR insights, waste management articles', '/blog'),
  ('/careers', 'Careers', 'Careers | ReCircle', 'Join ReCircle and be part of India''s circular economy movement.', 'ReCircle careers, sustainability jobs, circular economy jobs India', '/careers'),
  ('/annual-reports', 'Annual Reports', 'Annual Reports | ReCircle', 'Download ReCircle''s annual impact reports and learn about our circular economy milestones.', 'ReCircle annual report, impact report, circular economy India', '/annual-reports'),
  ('/webinars', 'Webinars', 'Webinars | ReCircle', 'Watch ReCircle''s webinars on EPR, circular economy, and sustainability.', 'EPR webinar, circular economy India, sustainability webinar', '/webinars'),
  ('/impact', 'Impact', 'Impact | ReCircle', 'Explore ReCircle''s environmental and social impact across India.', 'ReCircle impact, waste diverted, circular economy impact India', '/impact')
ON CONFLICT (page_slug) DO NOTHING;
