/*
  # New Pages Settings Tables

  ## Summary
  Creates singleton settings tables and submission tables for Contact, Blog, Careers,
  Annual Reports, Webinars, and Impact pages. Uses the existing cms_ prefix convention.

  ## New Tables
  - contact_page_settings: email, phone, social URLs, form config, map embed URL
  - contact_enquiries: public contact form submissions
  - blog_page_settings: hero image, headings for the blog listing page
  - careers_page_settings: all editable text for careers page
  - annual_reports_page_settings: hero and reports heading
  - webinars_page_settings: YouTube source config, page heading/intro
  - impact_page_settings: all impact page sections
  - impact_metrics: animated counter data rows
  - impact_previous_reports: downloadable previous report rows
  - impact_report_leads: gated download form submissions

  ## Security
  - RLS on all tables
  - Public read for page settings
  - Anon INSERT for form submission tables (enquiries, leads)
  - Authenticated-only SELECT for submission tables
*/

-- ============================================================
-- CONTACT PAGE
-- ============================================================

CREATE TABLE IF NOT EXISTS contact_page_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL DEFAULT 'info@recircle.in',
  phone text NOT NULL DEFAULT '+91 90042 40004',
  linkedin_url text NOT NULL DEFAULT 'https://www.linkedin.com/company/recircleindia',
  facebook_url text NOT NULL DEFAULT 'https://www.facebook.com/recircle.in/',
  instagram_url text NOT NULL DEFAULT 'https://www.instagram.com/RECIRCLE.IN/',
  form_heading text NOT NULL DEFAULT 'Let''s Start the Conversation',
  form_subheading text NOT NULL DEFAULT 'Ready to take the next step? Reach out to our team and let us help you achieve your sustainability goals.',
  service_options jsonb NOT NULL DEFAULT '["Extended Producer Responsibility (EPR)","Plastic Neutral Programme","Textile Waste Management (PITW)","Textile Waste Management (PCTW)","rPET Flakes","ClimaOne for EPR","ClimaOne for rPET","ESG Projects","Other"]',
  map_embed_url text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE contact_page_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read contact settings"
  ON contact_page_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can update contact settings"
  ON contact_page_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can insert contact settings"
  ON contact_page_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS contact_enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  service text NOT NULL,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE contact_enquiries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit contact enquiry"
  ON contact_enquiries FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated can view enquiries"
  ON contact_enquiries FOR SELECT
  TO authenticated
  USING (true);

-- ============================================================
-- BLOG PAGE SETTINGS
-- ============================================================

CREATE TABLE IF NOT EXISTS blog_page_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_image_url text NOT NULL DEFAULT '',
  hero_heading text NOT NULL DEFAULT 'Blogs',
  hero_subheading text NOT NULL DEFAULT 'Insights from India''s evolving waste ecosystem',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE blog_page_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read blog page settings"
  ON blog_page_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can update blog page settings"
  ON blog_page_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can insert blog page settings"
  ON blog_page_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- ============================================================
-- CAREERS PAGE SETTINGS
-- ============================================================

CREATE TABLE IF NOT EXISTS careers_page_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_heading text NOT NULL DEFAULT 'Join us in Shaping a circular future!',
  hero_body text NOT NULL DEFAULT 'We''re on the lookout for energetic, future-thinking individuals to join our mission. If you''re able to think outside the box, have an unwavering belief in consistent action, and strive to see the solution to a problem, come join our team.',
  hero_cta_label text NOT NULL DEFAULT 'Apply Now',
  hero_cta_url text NOT NULL DEFAULT '#open-positions',
  culture_heading text NOT NULL DEFAULT 'Together as one',
  culture_body text NOT NULL DEFAULT 'We''re on the lookout for energetic, future-thinking individuals to join our mission. If you''re able to think outside the box, have an unwavering belief in consistent action, and strive to see the solution to a problem, come join our team.',
  work_heading text NOT NULL DEFAULT 'See an opportunity in waste? ReCircle wants you!',
  work_body text NOT NULL DEFAULT 'If you discover a position that aligns with your interests and skills or have ideas for a role we haven''t covered, please reach out. We want to know your perspective on:',
  work_cta_label text NOT NULL DEFAULT 'Join Us Now',
  work_cta_url text NOT NULL DEFAULT '#open-positions',
  question_cards jsonb NOT NULL DEFAULT '[{"label":"Why","question":"waste management?"},{"label":"Where","question":"you think the planet is heading?"},{"label":"Will","question":"collective action lead to a sustained impact?"},{"label":"How","question":"can we get the world on board with our mission?"}]',
  listings_heading text NOT NULL DEFAULT 'Be a part of ReCircle''s inner circle',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE careers_page_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read careers settings"
  ON careers_page_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can update careers settings"
  ON careers_page_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can insert careers settings"
  ON careers_page_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- ============================================================
-- ANNUAL REPORTS PAGE SETTINGS
-- ============================================================

CREATE TABLE IF NOT EXISTS annual_reports_page_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_heading text NOT NULL DEFAULT 'A Year of Ethical Circularity',
  hero_body text NOT NULL DEFAULT 'We began with a simple question: What if nothing, not a single material or the person recovering it, got left behind? This year, that question became our way-forward.',
  hero_cta_text text NOT NULL DEFAULT 'STEP INSIDE OUR CIRCLE.',
  reports_heading text NOT NULL DEFAULT 'Read Our Previous Impact Reports Here',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE annual_reports_page_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read annual reports settings"
  ON annual_reports_page_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can update annual reports settings"
  ON annual_reports_page_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can insert annual reports settings"
  ON annual_reports_page_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Extend existing cms_annual_reports table
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_annual_reports' AND column_name = 'year_label') THEN
    ALTER TABLE cms_annual_reports ADD COLUMN year_label text NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_annual_reports' AND column_name = 'button_text') THEN
    ALTER TABLE cms_annual_reports ADD COLUMN button_text text NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_annual_reports' AND column_name = 'report_url') THEN
    ALTER TABLE cms_annual_reports ADD COLUMN report_url text NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_annual_reports' AND column_name = 'sort_order') THEN
    ALTER TABLE cms_annual_reports ADD COLUMN sort_order integer NOT NULL DEFAULT 99;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_annual_reports' AND column_name = 'is_active') THEN
    ALTER TABLE cms_annual_reports ADD COLUMN is_active boolean NOT NULL DEFAULT true;
  END IF;
END $$;

-- ============================================================
-- WEBINARS PAGE SETTINGS
-- ============================================================

CREATE TABLE IF NOT EXISTS webinars_page_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_heading text NOT NULL DEFAULT 'Webinars',
  page_intro text NOT NULL DEFAULT 'Watch our latest webinars and panel discussions on circular economy, EPR, and sustainability.',
  youtube_source_id text NOT NULL DEFAULT '',
  source_type text NOT NULL DEFAULT 'channel',
  entry_mode text NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE webinars_page_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read webinars settings"
  ON webinars_page_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can update webinars settings"
  ON webinars_page_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can insert webinars settings"
  ON webinars_page_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Extend existing cms_webinars table
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_webinars' AND column_name = 'youtube_url') THEN
    ALTER TABLE cms_webinars ADD COLUMN youtube_url text NOT NULL DEFAULT '';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_webinars' AND column_name = 'publish_date') THEN
    ALTER TABLE cms_webinars ADD COLUMN publish_date date;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cms_webinars' AND column_name = 'is_active') THEN
    ALTER TABLE cms_webinars ADD COLUMN is_active boolean NOT NULL DEFAULT true;
  END IF;
END $$;

-- ============================================================
-- IMPACT PAGE SETTINGS
-- ============================================================

CREATE TABLE IF NOT EXISTS impact_page_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  annual_feature_heading text NOT NULL DEFAULT 'ReCircle''s ANNUAL IMPACT REPORT 2024-25',
  annual_feature_subheading text NOT NULL DEFAULT 'A Year of Moving in Circles… In the Best Possible Way',
  annual_feature_body text NOT NULL DEFAULT 'This year, we completed a number of meaningful loops, from rethinking the idea of waste to redefining how it''s recovered.',
  annual_feature_cta_label text NOT NULL DEFAULT 'Download Report!',
  annual_feature_report_url text NOT NULL DEFAULT '',
  metrics_heading text NOT NULL DEFAULT 'Our Impact',
  metrics_subheading text NOT NULL DEFAULT 'Impact That Comes Full Circle',
  report_block_heading text NOT NULL DEFAULT 'Impact Report 2024-2025',
  report_block_subheading text NOT NULL DEFAULT 'A Year of Ethical Circularity',
  report_block_body text NOT NULL DEFAULT 'We began with a simple question: What if nothing, not a single material or the person recovering it, got left behind?',
  report_block_cta_text text NOT NULL DEFAULT 'STEP INSIDE OUR CIRCLE.',
  gated_form_heading text NOT NULL DEFAULT 'Download Our Impact Report',
  gated_form_button_label text NOT NULL DEFAULT 'Submit & Download',
  gated_report_url text NOT NULL DEFAULT '',
  previous_reports_heading text NOT NULL DEFAULT 'Read Our Previous Impact Reports Here',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE impact_page_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read impact page settings"
  ON impact_page_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can update impact page settings"
  ON impact_page_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can insert impact page settings"
  ON impact_page_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS impact_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 99,
  is_active boolean NOT NULL DEFAULT true,
  number_value text NOT NULL DEFAULT '',
  suffix text NOT NULL DEFAULT '',
  unit text NOT NULL DEFAULT '',
  label text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE impact_metrics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read impact metrics"
  ON impact_metrics FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can insert impact metrics"
  ON impact_metrics FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated can update impact metrics"
  ON impact_metrics FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can delete impact metrics"
  ON impact_metrics FOR DELETE
  TO authenticated
  USING (true);

CREATE TABLE IF NOT EXISTS impact_previous_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 99,
  is_active boolean NOT NULL DEFAULT true,
  year_label text NOT NULL DEFAULT '',
  button_text text NOT NULL DEFAULT '',
  report_url text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE impact_previous_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read impact previous reports"
  ON impact_previous_reports FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated can insert impact previous reports"
  ON impact_previous_reports FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated can update impact previous reports"
  ON impact_previous_reports FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated can delete impact previous reports"
  ON impact_previous_reports FOR DELETE
  TO authenticated
  USING (true);

CREATE TABLE IF NOT EXISTS impact_report_leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  email text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE impact_report_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit impact lead"
  ON impact_report_leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated can view impact leads"
  ON impact_report_leads FOR SELECT
  TO authenticated
  USING (true);

-- ============================================================
-- SEED DEFAULT DATA
-- ============================================================

INSERT INTO contact_page_settings (id) VALUES ('00000000-0000-0000-0000-000000000010') ON CONFLICT (id) DO NOTHING;
INSERT INTO blog_page_settings (id) VALUES ('00000000-0000-0000-0000-000000000020') ON CONFLICT (id) DO NOTHING;
INSERT INTO careers_page_settings (id) VALUES ('00000000-0000-0000-0000-000000000030') ON CONFLICT (id) DO NOTHING;
INSERT INTO annual_reports_page_settings (id) VALUES ('00000000-0000-0000-0000-000000000040') ON CONFLICT (id) DO NOTHING;
INSERT INTO webinars_page_settings (id) VALUES ('00000000-0000-0000-0000-000000000050') ON CONFLICT (id) DO NOTHING;
INSERT INTO impact_page_settings (id) VALUES ('00000000-0000-0000-0000-000000000060') ON CONFLICT (id) DO NOTHING;

INSERT INTO impact_metrics (id, sort_order, number_value, suffix, unit, label) VALUES
  ('00000000-0000-0000-0001-000000000001', 1, '291217', '', ' MT', 'Waste diverted from polluting our landfills and oceans'),
  ('00000000-0000-0000-0001-000000000002', 2, '3608', '+', '', 'Livelihoods impacted'),
  ('00000000-0000-0000-0001-000000000003', 3, '310', '+', '', 'Village, Towns and Cities waste recovery sites'),
  ('00000000-0000-0000-0001-000000000004', 4, '10', '+', '', 'Years of driving a Circular Economy'),
  ('00000000-0000-0000-0001-000000000005', 5, '4', '', '', 'Years of consistently measuring impact')
ON CONFLICT (id) DO NOTHING;

INSERT INTO impact_previous_reports (id, sort_order, year_label, button_text, report_url) VALUES
  ('00000000-0000-0000-0002-000000000001', 1, '2023-24', 'Download for 2023-24', ''),
  ('00000000-0000-0000-0002-000000000002', 2, '2022-23', 'Download for 2022-23', ''),
  ('00000000-0000-0000-0002-000000000003', 3, '2021-22', 'Download for 2021-22', '')
ON CONFLICT (id) DO NOTHING;

INSERT INTO cms_annual_reports (id, sort_order, year_label, button_text, report_url, is_active, title, report_year) VALUES
  ('00000000-0000-0000-0003-000000000001', 1, '2023-24', 'Download for 2023-24', '', true, 'Annual Report 2023-24', 2024),
  ('00000000-0000-0000-0003-000000000002', 2, '2022-23', 'Download for 2022-23', '', true, 'Annual Report 2022-23', 2023),
  ('00000000-0000-0000-0003-000000000003', 3, '2021-22', 'Download for 2021-22', '', true, 'Annual Report 2021-22', 2022)
ON CONFLICT (id) DO NOTHING;
