/*
  # CMS Tables for Additional Pages

  Creates CMS settings tables for pages that previously had only placeholder admin editors.

  ## New Tables

  ### `cms_about_page`
  - Settings for the Our Story / About Us page (hero stat, vision quote, team section toggle)

  ### `cms_mrf_page`
  - Settings for the Material Recovery Facility page (hero, overview, stats, process, capabilities)

  ### `cms_trf_page`
  - Settings for the Textile Recovery Facility page (hero, overview, stats)

  ### `cms_recycling_plant_page`
  - Settings for the Recycling Plant page (hero, overview, stats, process)

  ### `cms_plastic_waste_page`
  - Settings for the Plastic Waste Management parent page (hero, compliance context, why-recircle section)

  ### `cms_epr_page`
  - Settings for the EPR Services page (hero, process steps, compliance benefits)

  ### `cms_pnp_page`
  - Settings for the Plastic Neutral Programme page (hero, programme overview, steps)

  ### `cms_textile_waste_page`
  - Settings for the Textile Waste Management parent page (hero stats, model overview, TRF stats)

  ### `cms_pitw_page`
  - Settings for Post-Industrial Textile Waste page (hero, process, outputs)

  ### `cms_pctw_page`
  - Settings for Post-Consumer Textile Waste page (hero, collection channels, stats)

  ### `cms_esg_page`
  - Settings for ESG Projects page (hero, projects intro)

  ## Security
  - RLS enabled on every table
  - SELECT: authenticated users only
  - INSERT/UPDATE: authenticated users only
  - No public access (admin-only content)
*/

-- ── cms_about_page ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_about_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_stat text NOT NULL DEFAULT '465 crore',
  hero_stat_label text NOT NULL DEFAULT 'plastic bottles',
  hero_stat_note text NOT NULL DEFAULT 'annually',
  hero_paragraph_1 text NOT NULL DEFAULT 'India ranks second globally in plastic waste production. And yet it imports plastic waste from other nations because the systems and incentives for waste retrieval do not exist at scale.',
  hero_paragraph_2 text NOT NULL DEFAULT 'ReCircle found this unacceptable a decade ago. That is where our story begins.',
  vision_quote text NOT NULL DEFAULT 'See a world where no resources are wasted by pursuing and promoting ethical circularity.',
  commitments jsonb NOT NULL DEFAULT '[{"num":"01","text":"Divert waste away from landfills and oceans."},{"num":"02","text":"Formalise the marginalised waste industry in India."},{"num":"03","text":"Enable a circular economy where waste is recognised as a resource."}]',
  roots_heading text NOT NULL DEFAULT 'Bridging the gap between economy and ecology.',
  roots_body text NOT NULL DEFAULT 'ReCircle is headquartered in Mumbai, operating between India''s economic centre and its largest landfill. That contrast is not incidental. It is a constant reminder of the balance between economic development and environmental responsibility that ReCircle works to support every day.',
  roots_closing text NOT NULL DEFAULT 'We set the standard for brands to pursue excellence, responsibly.',
  mind_heading text NOT NULL DEFAULT 'Waste can either be a circular problem or a circular solution.',
  mind_body text NOT NULL DEFAULT 'Waste affects all life, whether we acknowledge it or not. Within every problem lies its solution. When reengineered, waste becomes a new raw material. At ReCircle, we have built on waste''s evolving role.',
  growth_heading text NOT NULL DEFAULT 'Every small step in waste management is a giant leap toward a sustainable future.',
  growth_body text NOT NULL DEFAULT 'ReCircle started as a grassroots-level waste collection aggregator in 2016. Today, with 8,800 kg recovered per hour, we have become the trusted choice for urban government bodies, global corporations, local business owners, and individuals.',
  growth_closing text NOT NULL DEFAULT 'Together, we are proving that waste is the new eco-currency.',
  growth_stat text NOT NULL DEFAULT '8,800 kg',
  growth_stat_unit text NOT NULL DEFAULT '/ hour',
  growth_stat_descriptor text NOT NULL DEFAULT 'of waste recovered across India',
  reach_heading text NOT NULL DEFAULT 'Wherever there is waste, there is ReCircle.',
  reach_body text NOT NULL DEFAULT 'ReCircle has mobilised across every village, town, and city in India — building the recovery infrastructure the country needs, one location at a time.',
  reach_stats jsonb NOT NULL DEFAULT '[{"value":"310+","label":"Village, Town & City Waste Recovery Sites"},{"value":"300+","label":"Collection Partners across India"},{"value":"45","label":"Processors in the recovery network"}]',
  reach_footnote text NOT NULL DEFAULT 'As on April 2023',
  team_section_heading text NOT NULL DEFAULT 'The people behind ReCircle.',
  team_section_intro_1 text NOT NULL DEFAULT 'We are a passionate group of professionals with expertise in finance, supply chain, logistics, management, and regulations, united by one goal: to re-establish waste as a resource.',
  team_section_intro_2 text NOT NULL DEFAULT 'We lead by example. Meet us at our next waste collection drive or zero waste event.',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_about_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read about page settings"
  ON cms_about_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert about page settings"
  ON cms_about_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update about page settings"
  ON cms_about_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_mrf_page ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_mrf_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_label text NOT NULL DEFAULT 'Material Recovery Facility',
  hero_heading text NOT NULL DEFAULT 'Where Plastic Waste Finds a New Purpose',
  hero_body text NOT NULL DEFAULT 'ReCircle''s Material Recovery Facility is the operational backbone of our plastic waste management system — where collected plastic is sorted, processed, and routed to verified recycling partners.',
  stat_1_value text NOT NULL DEFAULT '400+',
  stat_1_label text NOT NULL DEFAULT 'Cities in our recovery network',
  stat_2_value text NOT NULL DEFAULT '14,970 kg',
  stat_2_label text NOT NULL DEFAULT 'of waste recovered every hour',
  overview_heading text NOT NULL DEFAULT 'Built for Scale, Designed for Traceability',
  overview_body text NOT NULL DEFAULT 'The MRF handles multi-stream plastic waste — from post-consumer packaging to industrial scrap — and channels each material type to the appropriate downstream recycler.',
  process_heading text NOT NULL DEFAULT 'How the MRF Works',
  process_steps jsonb NOT NULL DEFAULT '[{"step":"01","title":"Intake & Weighment","body":"All incoming material is weighed and recorded at entry."},{"step":"02","title":"Sorting & Segregation","body":"Plastic streams are sorted by type: PET, HDPE, LDPE, PP, and multi-layer packaging."},{"step":"03","title":"Baling & Compaction","body":"Sorted material is compacted into bales for efficient storage and transport."},{"step":"04","title":"Dispatch to Recyclers","body":"Baled material is dispatched to CPCB-registered recycling partners."}]',
  capabilities jsonb NOT NULL DEFAULT '[{"title":"Multi-stream Plastic Processing"},{"title":"CPCB-Compliant Operations"},{"title":"Traceability via ClimaOne"},{"title":"GRS-Certified Outputs"}]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_mrf_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read MRF page settings"
  ON cms_mrf_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert MRF page settings"
  ON cms_mrf_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update MRF page settings"
  ON cms_mrf_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_trf_page ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_trf_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_label text NOT NULL DEFAULT 'Textile Recovery Facility',
  hero_heading text NOT NULL DEFAULT 'A Dedicated Space for Textile Waste Recovery',
  hero_body text NOT NULL DEFAULT 'ReCircle''s Textile Recovery Facility (TRF) is a purpose-built infrastructure that gives discarded garments and textile waste a new purpose — reducing landfill pressure and feeding a new supply chain.',
  stat_1_value text NOT NULL DEFAULT '700 MT',
  stat_1_label text NOT NULL DEFAULT 'of textile waste processed since 2024',
  stat_2_value text NOT NULL DEFAULT '50 MT',
  stat_2_label text NOT NULL DEFAULT 'monthly processing capacity',
  overview_heading text NOT NULL DEFAULT 'Infrastructure Built for Textile Circularity',
  overview_body text NOT NULL DEFAULT 'The TRF handles both post-industrial and post-consumer textile waste, sorting and channelising each stream to reuse, recycling, or repurposing partners through a structured sorting system.',
  categories_heading text NOT NULL DEFAULT 'Four Output Channels',
  categories jsonb NOT NULL DEFAULT '[{"label":"Rewear","color":"#01298A","bg":"#E8EDF8","desc":"Garments suitable for direct reuse and redistribution."},{"label":"Recycle","color":"#00C499","bg":"#E6F7F3","desc":"Materials processed for fibre or material recovery."},{"label":"Relife","color":"#E7182A","bg":"#FEE8EA","desc":"Items repurposed for extended service life applications."},{"label":"Revamp","color":"#5F5F5F","bg":"#F0F0F0","desc":"Textiles reworked into new products through upcycling."}]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_trf_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read TRF page settings"
  ON cms_trf_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert TRF page settings"
  ON cms_trf_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update TRF page settings"
  ON cms_trf_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_recycling_plant_page ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_recycling_plant_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_label text NOT NULL DEFAULT 'Recycling Plant',
  hero_heading text NOT NULL DEFAULT 'Closing the Loop on Plastic',
  hero_body text NOT NULL DEFAULT 'ReCircle''s recycling plant converts post-consumer PET bottles and plastic waste into food-grade rPET flakes, completing the circular economy loop from collection to remanufacturing.',
  stat_1_value text NOT NULL DEFAULT '2,500 MT',
  stat_1_label text NOT NULL DEFAULT 'annual rPET flakes production capacity',
  stat_2_value text NOT NULL DEFAULT '99.9%',
  stat_2_label text NOT NULL DEFAULT 'purity of food-grade rPET output',
  overview_heading text NOT NULL DEFAULT 'From Collected Bottles to rPET Flakes',
  overview_body text NOT NULL DEFAULT 'The plant processes washed and sorted PET bottles through a multi-stage mechanical recycling process, producing GRS-certified rPET flakes for use in food-grade packaging, textiles, and industrial applications.',
  process_heading text NOT NULL DEFAULT 'The Recycling Process',
  process_steps jsonb NOT NULL DEFAULT '[{"step":"01","title":"Feedstock Intake","body":"Sorted PET bottles arrive from the MRF and collection network."},{"step":"02","title":"Washing & Cleaning","body":"Bottles are hot-washed to remove labels, adhesives, and contaminants."},{"step":"03","title":"Shredding & Flaking","body":"Clean bottles are shredded into uniform flakes."},{"step":"04","title":"Quality Testing","body":"Flakes are tested for purity, viscosity, and colour consistency."},{"step":"05","title":"Output","body":"GRS-certified rPET flakes dispatched to brand partners."}]',
  certifications jsonb NOT NULL DEFAULT '[{"name":"GRS — Global Recycled Standard"},{"name":"FSSAI Compliant — Food-Grade"},{"name":"ISO 9001:2015"}]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_recycling_plant_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read recycling plant page settings"
  ON cms_recycling_plant_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert recycling plant page settings"
  ON cms_recycling_plant_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update recycling plant page settings"
  ON cms_recycling_plant_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_plastic_waste_page ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_plastic_waste_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_heading text NOT NULL DEFAULT 'Comprehensive Plastic Waste Management Solutions for Businesses in India',
  hero_stat text NOT NULL DEFAULT '3.5M',
  hero_stat_label text NOT NULL DEFAULT 'tonnes',
  hero_stat_descriptor text NOT NULL DEFAULT 'of plastic waste generated in India annually',
  hero_para_1 text NOT NULL DEFAULT 'India generates over 3.5 million tonnes of plastic waste every year, yet a significant share still remains outside formal recovery systems.',
  hero_para_2 text NOT NULL DEFAULT 'At the same time, regulations are tightening, reporting expectations are growing, and sustainability claims are being examined more closely than ever before.',
  hero_cta_label text NOT NULL DEFAULT 'Book a Free Consultation',
  compliance_heading text NOT NULL DEFAULT 'Plastic waste regulation is now a business responsibility.',
  compliance_body text NOT NULL DEFAULT 'Under the Plastic Waste Management Rules 2016, businesses introducing plastic into the Indian market are required to take responsibility for its recovery and recycling. Producers, importers, and brand owners are now expected to meet clear EPR obligations under the CPCB framework, with stricter scrutiny around documentation, reporting, and traceability.',
  compliance_closing text NOT NULL DEFAULT 'ReCircle simplifies the operational side of plastic waste management by helping businesses manage compliance, recovery targets, and reporting through one integrated ecosystem.',
  consequences jsonb NOT NULL DEFAULT '[{"text":"Financial penalties and regulatory action from the CPCB."},{"text":"Restricted business operations and delayed product approvals."},{"text":"Reputational damage as sustainability scrutiny from buyers and investors increases."}]',
  why_heading text NOT NULL DEFAULT 'Why Choose ReCircle',
  why_advantages jsonb NOT NULL DEFAULT '[{"num":"01","title":"Integrated Recovery Ecosystem","body":"A connected network of collectors, aggregators, processors, and recyclers enables traceable plastic recovery across the value chain."},{"num":"02","title":"Solutions That Scale With You","body":"From growing businesses to multinational enterprises, our waste management systems adapt to different operational and compliance requirements."},{"num":"03","title":"Pan-India Operations","body":"With a presence across 400+ cities and towns, ReCircle delivers measurable impact wherever your business operates."},{"num":"04","title":"People at the Centre","body":"Every recovery system is designed with worker wellbeing, fair livelihoods, and safer working conditions built into the process."}]',
  infra_body text NOT NULL DEFAULT 'The above services are backed by physical infrastructure. ReCircle''s Material Recovery Facility (MRF) is where plastic waste is sorted, processed, and routed to verified recycling partners — creating the operational backbone behind our compliance and recovery programmes.',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_plastic_waste_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read plastic waste page settings"
  ON cms_plastic_waste_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert plastic waste page settings"
  ON cms_plastic_waste_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update plastic waste page settings"
  ON cms_plastic_waste_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_epr_page ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_epr_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_heading text NOT NULL DEFAULT 'End-to-End EPR Compliance for Plastic Waste',
  hero_body text NOT NULL DEFAULT 'India''s Plastic Waste Management Rules require producers, importers, and brand owners to meet EPR targets. ReCircle manages the entire compliance journey — from registration to annual reporting.',
  stat_1_value text NOT NULL DEFAULT '500+',
  stat_1_label text NOT NULL DEFAULT 'businesses supported with EPR compliance',
  stat_2_value text NOT NULL DEFAULT '100%',
  stat_2_label text NOT NULL DEFAULT 'CPCB documentation accuracy',
  process_heading text NOT NULL DEFAULT 'Our EPR Compliance Process',
  process_steps jsonb NOT NULL DEFAULT '[{"step":"01","title":"EPR Registration","body":"We register your entity on the CPCB EPR portal and set up your compliance account."},{"step":"02","title":"Target Assessment","body":"We assess your annual plastic introduction and calculate your EPR targets."},{"step":"03","title":"Credit Procurement","body":"We procure EPR credits from verified collection and recycling partners."},{"step":"04","title":"Reporting & Filing","body":"We prepare and file your annual EPR returns with full documentation."},{"step":"05","title":"Certificate Issuance","body":"You receive official compliance certificates for use with auditors and buyers."}]',
  benefits_heading text NOT NULL DEFAULT 'What You Get with ReCircle EPR',
  benefits jsonb NOT NULL DEFAULT '[{"title":"Full Regulatory Coverage","body":"We manage every step from registration to annual filing."},{"title":"Certified Credits","body":"Credits sourced from CPCB-registered processors with full traceability."},{"title":"Audit-Ready Documentation","body":"Complete documentation package ready for buyer and regulatory audits."},{"title":"Dedicated Compliance Manager","body":"A single point of contact for all your EPR compliance needs."}]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_epr_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read EPR page settings"
  ON cms_epr_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert EPR page settings"
  ON cms_epr_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update EPR page settings"
  ON cms_epr_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_pnp_page ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_pnp_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_heading text NOT NULL DEFAULT 'Plastic Neutral Program',
  hero_body text NOT NULL DEFAULT 'Go beyond compliance. ReCircle''s Plastic Neutral Program enables businesses to verify and communicate their plastic footprint reduction through traceable, certified recovery.',
  hero_tag text NOT NULL DEFAULT 'Voluntary',
  programme_heading text NOT NULL DEFAULT 'What is the Plastic Neutral Program?',
  programme_body text NOT NULL DEFAULT 'The PNP enables brands to offset the plastic they introduce into the market by funding equivalent collection and responsible processing of plastic waste — generating verified impact that can be communicated to consumers, investors, and regulators.',
  steps_heading text NOT NULL DEFAULT 'How It Works',
  steps jsonb NOT NULL DEFAULT '[{"step":"01","title":"Measure","body":"We calculate your plastic footprint based on materials introduced into the market."},{"step":"02","title":"Offset","body":"We recover an equivalent weight of plastic waste from the environment through our collection network."},{"step":"03","title":"Verify","body":"All recovery is tracked on ClimaOne with full traceability from collection to processing."},{"step":"04","title":"Certify","body":"You receive a Plastic Neutral Certificate to communicate your verified impact."}]',
  benefits_heading text NOT NULL DEFAULT 'Why Brands Choose the PNP',
  benefits jsonb NOT NULL DEFAULT '[{"title":"Credible Sustainability Claims","body":"Verified recovery backed by chain-of-custody traceability — not just self-declaration."},{"title":"Consumer Trust","body":"Communicate a genuine environmental commitment with a recognised certificate."},{"title":"Investor-Grade Reporting","body":"ESG-compatible data on plastic recovery and circular impact."},{"title":"Regulatory Readiness","body":"Stay ahead of evolving plastic disclosure and reporting requirements."}]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_pnp_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read PNP page settings"
  ON cms_pnp_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert PNP page settings"
  ON cms_pnp_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update PNP page settings"
  ON cms_pnp_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_textile_waste_page ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_textile_waste_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_stat text NOT NULL DEFAULT '134 million tonnes',
  hero_fact_1 text NOT NULL DEFAULT 'Global textile waste projected by 2030',
  hero_fact_2 text NOT NULL DEFAULT 'India is the 3rd-largest generator, contributing 8.5% to global textile waste',
  hero_closing text NOT NULL DEFAULT 'This is not a list we aspire to lead.',
  problem_body text NOT NULL DEFAULT 'Piles of post-consumer textile waste are leaching toxic dyes into soil, shedding microplastics into oceans, and overflowing into already strained landfills. And yet, we lack textile waste management systems to handle it.',
  problem_closing text NOT NULL DEFAULT 'But where most see a waste problem, ReCircle sees a world of opportunity.',
  model_intro text NOT NULL DEFAULT 'ReCircle is building a scalable, end-to-end ecosystem for textile waste circularity, designed to keep materials in use and out of landfills. Our model connects people, purpose, and process.',
  model_pillars jsonb NOT NULL DEFAULT '[{"num":"01","title":"Collection","body":"From schools, offices, hotels, and factories. Our network recovers textile waste from wherever it exists."},{"num":"02","title":"Traceability","body":"From collection to processing, complete visibility on where your garments go and the impact created."},{"num":"03","title":"Impact Reports","body":"Every garment tracked. We measure how textile waste is reused, revamped, recycled, or repurposed."},{"num":"04","title":"Awareness","body":"Education is the first step. We help you understand the purpose and process of textile circularity."}]',
  trf_stat_1_value text NOT NULL DEFAULT '700 MT',
  trf_stat_1_label text NOT NULL DEFAULT 'of textile waste processed since 2024',
  trf_stat_2_value text NOT NULL DEFAULT '50 MT',
  trf_stat_2_label text NOT NULL DEFAULT 'monthly processing capacity',
  trf_body text NOT NULL DEFAULT 'We believe infrastructure is vital for effectively addressing textile pollution. That''s why we built our Textile Recovery Facility (TRF), a dedicated space that gives new purpose to discarded garments. The facility reduces landfill pressure, supports a new supply chain for businesses, and keeps valuable resources in circulation.',
  partner_categories jsonb NOT NULL DEFAULT '[{"title":"Textile Brands","subtypes":"Multi-brand stores, D2C brands, boutiques, brand stores","desc":"Collection of excess inventory, in-store takeback programmes, and pre-consumer waste management."},{"title":"Textile Industries","subtypes":"Spinning mills, weaving units, dyeing houses, garment manufacturers","desc":"Collection of fabric waste generated during production."},{"title":"T-Shirt to T-Shirt Circularity","subtypes":"Fibre manufacturers, yarn spinners, fabric mills, ethical fashion brands","desc":"Traceable post-consumer textile waste and closed-loop production collaboration."},{"title":"Upcyclers","subtypes":"Independent designers, upcycling brands, sustainable fashion startups, home decor creators, artisanal enterprises","desc":"Sourcing high-quality post-consumer fabric, circular product design, traceable materials."},{"title":"Other Institutions","subtypes":"Educational institutions, corporates, hotels, hospitals","desc":"Waste collection programmes and employee awareness initiatives."}]',
  community_heading text NOT NULL DEFAULT 'No system works without the hands that power it.',
  community_body_1 text NOT NULL DEFAULT 'The Waghri community has been collecting old garments for generations. Safai Saathis carefully sort and process textile waste. These people keep recovery systems running, often without the recognition or support they deserve.',
  community_body_2 text NOT NULL DEFAULT 'ReCircle is committed to integrating these communities into formal recovery operations, creating predictable livelihoods, and running awareness programmes at the grassroots level.',
  supporters jsonb NOT NULL DEFAULT '[{"name":"CAIF"},{"name":"Intellecap"},{"name":"Fashion for Good"}]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_textile_waste_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read textile waste page settings"
  ON cms_textile_waste_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert textile waste page settings"
  ON cms_textile_waste_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update textile waste page settings"
  ON cms_textile_waste_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_pitw_page ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_pitw_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_heading text NOT NULL DEFAULT 'End-to-End Post-Industrial Textile Waste Management',
  stat_1_value text NOT NULL DEFAULT '700 MT',
  stat_1_label text NOT NULL DEFAULT 'of textile waste processed since 2024',
  stat_2_value text NOT NULL DEFAULT '50 MT/mo',
  stat_2_label text NOT NULL DEFAULT 'monthly processing capacity',
  process_heading text NOT NULL DEFAULT 'From Factory Floor to Recycled Fibre',
  process_intro text NOT NULL DEFAULT 'ReCircle collects textile waste directly from your facility, sorts and grades it at the Textile Recovery Facility, and routes it to a certified recycling partner, returning it to the supply chain as recycled fibre.',
  scope_note text NOT NULL DEFAULT 'Current scope: 100% cotton (preferably white) and denim.',
  comparison_current jsonb NOT NULL DEFAULT '[{"text":"Waste handed off to unreliable aggregators."},{"text":"No visibility on where your waste goes."},{"text":"No certification to show auditors or buyers."},{"text":"Waste treated as a cost to get rid of."},{"text":"EPR regulations tightening with no compliance system."}]',
  comparison_recircle jsonb NOT NULL DEFAULT '[{"text":"Structured pickup with full accountability."},{"text":"Complete traceability from pickup to recycled fibre."},{"text":"GRS certified fibre and ReCircle sustainability certificate."},{"text":"Your waste becomes a raw material with real value."},{"text":"Be EPR-ready and build a compliant waste system."}]',
  outputs jsonb NOT NULL DEFAULT '[{"name":"White Fibre","application":"Suitable for yarn blending"},{"name":"Colour Fibre","application":"Used in felt manufacturing and industrial nonwoven applications"},{"name":"Denim Fibre","application":"Suitable for denim yarn blending"}]',
  grs_note text NOT NULL DEFAULT 'All recycled fibres are supplied with GRS (Global Recycled Standard) certification.',
  work_models jsonb NOT NULL DEFAULT '[{"num":"01","title":"Collection Model","body":"Hassle-free collection from your facility. We collect your waste directly."},{"num":"02","title":"Recycled Fibre Supply Model","body":"Buy recycled fibre from us and use it directly in your production."},{"num":"03","title":"Complete Circularity Model","body":"We collect your waste, process it, and return it to you as recycled fibres. You own your waste back into fibre."}]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_pitw_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read PITW page settings"
  ON cms_pitw_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert PITW page settings"
  ON cms_pitw_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update PITW page settings"
  ON cms_pitw_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_pctw_page ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_pctw_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_heading text NOT NULL DEFAULT 'End-to-End Post-Consumer Textile Waste Management',
  hero_subheading text NOT NULL DEFAULT 'From the hands of consumers back into the supply chain.',
  channels jsonb NOT NULL DEFAULT '[{"title":"Institutions","icon":"Building2","desc":"Schools, offices, hotels, and NGOs donate discarded materials through scheduled collection drives."},{"title":"Households via Volunteers","icon":"Users","desc":"Clothes are collected directly from households by trained volunteers."},{"title":"Waghri Community","icon":"Heart","desc":"Waghris collect old garments from households through a barter system — a practice carried across generations."}]',
  stats jsonb NOT NULL DEFAULT '[{"value":"50,000+","label":"Garments collected"},{"value":"120 MT+","label":"Textile waste processed"},{"value":"30+","label":"Institutions served"}]',
  institutions jsonb NOT NULL DEFAULT '[{"name":"Taj Project Mumbai"},{"name":"Oberoi International School"},{"name":"Symbiosis University"}]',
  community_heading text NOT NULL DEFAULT 'The Hands Behind Recovery',
  community_body_1 text NOT NULL DEFAULT 'The Waghri community and Safai Saathis are central to how post-consumer textile waste gets collected and sorted. They have practised this form of circularity long before it had a name.',
  community_body_2 text NOT NULL DEFAULT 'ReCircle integrates them into formal recovery operations, creates predictable livelihoods, and runs awareness programmes at the grassroots level.',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_pctw_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read PCTW page settings"
  ON cms_pctw_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert PCTW page settings"
  ON cms_pctw_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update PCTW page settings"
  ON cms_pctw_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ── cms_esg_page ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_esg_page (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_heading text NOT NULL DEFAULT 'ESG Projects',
  hero_body text NOT NULL DEFAULT 'ReCircle partners with businesses to design, execute, and report on environmental and social impact projects that meet ESG reporting requirements and sustainability commitments.',
  intro_heading text NOT NULL DEFAULT 'Purpose-Built ESG Impact Programmes',
  intro_body text NOT NULL DEFAULT 'From waste recovery drives to community livelihoods and circular economy education, ReCircle''s ESG projects create measurable, traceable, and reportable environmental and social value.',
  projects jsonb NOT NULL DEFAULT '[{"title":"Plastic Waste Recovery Drive","category":"Environmental","body":"Organised mass collection events recovering plastic waste from public spaces, waterways, and underserved communities."},{"title":"Safai Saathi Livelihood Programme","category":"Social","body":"Formalising waste picker livelihoods with fair wages, safety gear, and integration into government welfare schemes."},{"title":"Zero Waste Campus","category":"Education","body":"End-to-end waste management programme for educational institutions covering collection, awareness, and reporting."},{"title":"Circular Economy Workshop Series","category":"Education","body":"Structured workshops for corporate teams on waste reduction, circularity, and EPR awareness."}]',
  reporting_heading text NOT NULL DEFAULT 'Reporting That Meets ESG Standards',
  reporting_body text NOT NULL DEFAULT 'Every project is tracked on ClimaOne, producing third-party verifiable data on waste diverted, communities supported, and CO₂ emissions avoided — formatted for GRI, BRSR, and investor-grade ESG disclosures.',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_esg_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read ESG page settings"
  ON cms_esg_page FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert ESG page settings"
  ON cms_esg_page FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update ESG page settings"
  ON cms_esg_page FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
