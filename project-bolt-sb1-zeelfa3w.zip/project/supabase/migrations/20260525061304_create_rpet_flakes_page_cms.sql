/*
  # Create rPET Flakes Page CMS Tables

  ## Overview
  Creates a CMS-backed content system for the rPET Flakes product page (/rpet-flakes).

  ## New Tables

  ### cms_rpet_page_settings (singleton)
  Stores all singleton text fields for the rPET page:
  - Hero: heading, body, CTA label/href
  - Applications section: label, intro text
  - Technical Specs: label, heading, body, CTA label/href
  - Operational Advantages: label, heading, body
  - Quality Benchmarks: label, heading, intro, CTA label/href
  - ClimaOne Traceability: label, heading, body (2 paragraphs), CTA label/href
  - Certifications: label, heading, body
  - Contact Band: label, heading, body, email, phone

  ### cms_rpet_applications (list)
  Four application tabs — each with title, spec callout, image URL.

  ### cms_rpet_advantage_cards (list)
  Four operational advantage cards — icon name, heading, body.

  ### cms_rpet_benchmark_cards (list)
  Four quality benchmark cards — icon name, heading, body.

  ## Security
  - RLS enabled on all tables
  - Public SELECT for frontend reads
  - Authenticated users only for writes (INSERT/UPDATE/DELETE)

  ## Notes
  - All tables seeded with default content from the product specification
*/

-- ── SINGLETON SETTINGS ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_rpet_page_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Hero
  hero_heading text NOT NULL DEFAULT 'Advancing Circularity Through High-Quality rPET Flakes',
  hero_body text NOT NULL DEFAULT 'As one of the top plastic recycling companies, our rPET flakes are made from 100% post-consumer plastic. Food-grade safe by design, our recycled flakes integrate smoothly with virgin PET and perform consistently across a wide range of applications.',
  hero_cta_label text NOT NULL DEFAULT 'Inquire Now',
  hero_cta_href text NOT NULL DEFAULT '/contact',
  hero_image_url text NOT NULL DEFAULT '',

  -- Applications
  applications_label text NOT NULL DEFAULT 'APPLICATIONS',
  applications_intro text NOT NULL DEFAULT 'Our rPET flakes are versatile and widely used in:',

  -- Technical Specs
  tech_specs_label text NOT NULL DEFAULT 'TECHNICAL SPECIFICATIONS',
  tech_specs_heading text NOT NULL DEFAULT 'Recycled PET that leaves no room for doubt',
  tech_specs_body text NOT NULL DEFAULT 'From low moisture levels and zero contamination by PVC, PP/PE, and metals to clean polymer filtration at 20 microns, the technical specification sheet provides a clear view of how we meet defined quality benchmarks.',
  tech_specs_cta_label text NOT NULL DEFAULT 'Enquire for Specifications',
  tech_specs_cta_href text NOT NULL DEFAULT '/contact',
  tech_specs_image_url text NOT NULL DEFAULT '',

  -- Operational Advantages
  advantages_label text NOT NULL DEFAULT 'OPERATIONAL ADVANTAGES',
  advantages_heading text NOT NULL DEFAULT 'rPET flakes built for the realities of your production line',
  advantages_body text NOT NULL DEFAULT 'When you''re running a line, consistency matters more than promises. Our food-grade rPET flakes are produced with tight process control and minimal contamination, so your equipment stays cleaner, your process stays stable, and your day runs with fewer surprises.',

  -- Quality Benchmarks
  benchmarks_label text NOT NULL DEFAULT 'OUR PILLARS OF ETHICAL RECYCLING',
  benchmarks_heading text NOT NULL DEFAULT 'The 4 quality benchmarks of ReCircle''s recycled plastic flakes',
  benchmarks_intro text NOT NULL DEFAULT 'With our rPET flakes, we enable industries to adopt circular packaging materials that work as reliably as virgin plastics.',
  benchmarks_cta_label text NOT NULL DEFAULT 'Talk to Our rPET Experts',
  benchmarks_cta_href text NOT NULL DEFAULT '/contact',

  -- ClimaOne Traceability
  climaone_label text NOT NULL DEFAULT 'TECH-DRIVEN TRACEABILITY',
  climaone_heading text NOT NULL DEFAULT 'Gain control over your BIS targets with ease',
  climaone_body_1 text NOT NULL DEFAULT 'Plastic recycling only works when every step is transparent. Which is why we built a tech platform that connects every stakeholder across the plastic recycling chain.',
  climaone_body_2 text NOT NULL DEFAULT 'From the first bottle collected to the final rPET flakes produced, ClimaOne tracks every movement of recycled plastic in real time and provides businesses with complete transparency across the supply chain, aligned with BIS standards.',
  climaone_cta_label text NOT NULL DEFAULT 'Explore ClimaOne',
  climaone_cta_href text NOT NULL DEFAULT '/contact',
  climaone_image_url text NOT NULL DEFAULT '',

  -- Certifications
  certifications_label text NOT NULL DEFAULT 'CERTIFICATIONS',
  certifications_heading text NOT NULL DEFAULT 'Tested to meet EU food-contact requirements',
  certifications_body text NOT NULL DEFAULT 'Our rPET flakes are tested by Intertek and checked against European food-contact regulations, including EC 1935/2004 and EU 10/2011. They meet migration limits and REACH SVHC requirements, making them a reliable option for regulated packaging applications.',
  certifications_image_url text NOT NULL DEFAULT '',

  -- Contact Band
  contact_band_label text NOT NULL DEFAULT 'CONTACT US',
  contact_band_heading text NOT NULL DEFAULT 'Empower your recycling journey with ReCircle',
  contact_band_body text NOT NULL DEFAULT 'Connect with us today for high-quality recycled plastic flakes from one of the top 10 plastic recycling companies in India.',
  contact_band_email text NOT NULL DEFAULT 'info@recircle.in',
  contact_band_phone text NOT NULL DEFAULT '+91 90042 40004',

  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_rpet_page_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read rPET page settings"
  ON cms_rpet_page_settings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert rPET page settings"
  ON cms_rpet_page_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update rPET page settings"
  ON cms_rpet_page_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Seed default row
INSERT INTO cms_rpet_page_settings (id) VALUES (gen_random_uuid())
ON CONFLICT DO NOTHING;

-- ── APPLICATIONS ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_rpet_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  title text NOT NULL DEFAULT '',
  spec_callout text NOT NULL DEFAULT '',
  image_url text NOT NULL DEFAULT '',
  image_alt text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_rpet_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read rPET applications"
  ON cms_rpet_applications FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert rPET applications"
  ON cms_rpet_applications FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update rPET applications"
  ON cms_rpet_applications FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete rPET applications"
  ON cms_rpet_applications FOR DELETE
  TO authenticated
  USING (true);

INSERT INTO cms_rpet_applications (sort_order, title, spec_callout, image_url, image_alt) VALUES
  (1, 'rPET Chips / Resins', 'With contamination <30 ppm, our rPET flakes support B2B manufacturing.', 'https://images.pexels.com/photos/3825578/pexels-photo-3825578.jpeg?auto=compress&cs=tinysrgb&w=800&q=85', 'rPET chips and resins'),
  (2, 'Films', 'A bulk density of 0.31 g/cc helps maintain steady feeding and consistent film output.', 'https://images.pexels.com/photos/4483610/pexels-photo-4483610.jpeg?auto=compress&cs=tinysrgb&w=800&q=85', 'Plastic films'),
  (3, 'Sheets', 'An IV range of 0.72–0.80 dL/g delivers the melt strength needed for thermoforming.', 'https://images.pexels.com/photos/4246110/pexels-photo-4246110.jpeg?auto=compress&cs=tinysrgb&w=800&q=85', 'PET sheets'),
  (4, 'Additives', 'Low ash content (0.022 wt%) allows smooth blending without introducing impurities.', 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=800&q=85', 'Plastic additives');

-- ── ADVANTAGE CARDS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_rpet_advantage_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  icon_name text NOT NULL DEFAULT 'Filter',
  heading text NOT NULL DEFAULT '',
  body text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_rpet_advantage_cards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read rPET advantage cards"
  ON cms_rpet_advantage_cards FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert rPET advantage cards"
  ON cms_rpet_advantage_cards FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update rPET advantage cards"
  ON cms_rpet_advantage_cards FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete rPET advantage cards"
  ON cms_rpet_advantage_cards FOR DELETE
  TO authenticated
  USING (true);

INSERT INTO cms_rpet_advantage_cards (sort_order, icon_name, heading, body) VALUES
  (1, 'Filter', 'Longer Filter Life', 'Our low-contamination recycled flakes reduce residue buildup in your melt filters, helping them last longer between changeovers and reducing unnecessary interruptions.'),
  (2, 'Cpu', 'Reduced Machine Downtime', 'Because our recycled plastic flakes are uniformly sized and thoroughly washed, they move smoothly through your line, reducing the risk of blockages or sudden production stops.'),
  (3, 'Wrench', 'Lower Maintenance Costs', 'With zero metal and non-PET contamination, your screws, barrels, and dyes face less long-term wear, keeping maintenance cycles predictable and under control.'),
  (4, 'TrendingUp', 'Improved Line Efficiency', 'With consistent quality, batch-after-batch, your production line stays steady, making daily output easier to manage without frequent process tweaks.');

-- ── BENCHMARK CARDS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cms_rpet_benchmark_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  icon_name text NOT NULL DEFAULT 'CheckCircle',
  heading text NOT NULL DEFAULT '',
  body text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_rpet_benchmark_cards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read rPET benchmark cards"
  ON cms_rpet_benchmark_cards FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert rPET benchmark cards"
  ON cms_rpet_benchmark_cards FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update rPET benchmark cards"
  ON cms_rpet_benchmark_cards FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete rPET benchmark cards"
  ON cms_rpet_benchmark_cards FOR DELETE
  TO authenticated
  USING (true);

INSERT INTO cms_rpet_benchmark_cards (sort_order, icon_name, heading, body) VALUES
  (1, 'Recycle', '100% Post-Consumer rPET Flakes', 'Sourced through a pan-India recovery network, our rPET flakes are made from 100% post-consumer PET, delivering circular packaging materials at scale.'),
  (2, 'Eye', 'Complete Transparency & Traceability', 'Powered by ClimaOne''s real-time data, every batch of recycled plastic flakes are traceable from collection to processing, ensuring compliance with BIS & CPCB standards.'),
  (3, 'BarChart2', 'Consistent High-Quality Output', 'Engineered to exact specifications, our rPET flakes deliver consistent purity and grades, batch after batch.'),
  (4, 'Building2', 'Advanced Infrastructure & Tech', 'Our state-of-the-art facility in Bhiwani delivers precision, scale, and a reliable supply of high-grade recycled PET that meets global standards.');
