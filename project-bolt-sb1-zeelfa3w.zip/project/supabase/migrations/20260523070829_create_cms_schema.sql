/*
  # ReCircle CMS Schema

  ## Overview
  Creates the complete content management system schema for ReCircle's website.
  
  ## New Tables

  ### User Management
  - `admin_users` — Admin user accounts with roles (super_admin, editor, viewer)
  - `admin_sessions` — Active session tracking for security audit

  ### Homepage Content
  - `cms_hero_slides` — Hero section carousel slides (image, headline, subheadline, CTAs)
  - `cms_about` — About ReCircle section (heading, body, CTAs, highlights)
  - `cms_impact_stats` — Impact numbers ticker (number, suffix, unit, label)
  - `cms_solutions` — Solutions pathway nodes (heading, description, tag, side, href)
  - `cms_investors` — Investor logos and names
  - `cms_clients` — Client logo ticker
  - `cms_accolades` — Awards and recognitions
  - `cms_footer` — Footer content (singleton)

  ### Global / Future-Ready
  - `cms_site_settings` — Global singleton (logo, SEO defaults, contact, social links)
  - `cms_navigation` — Navigation items with nested structure
  - `cms_seo_metadata` — Per-page SEO metadata
  - `cms_blogs` — Blog posts with rich content
  - `cms_webinars` — Webinar listings
  - `cms_annual_reports` — Annual report documents
  - `cms_careers` — Job listings
  - `cms_infrastructure_pages` — MRF, TRF, Recycling Plant pages
  - `cms_services` — Service pages (EPR, PNP, PITW, PCTW)
  - `cms_products` — Product pages (rPET, ClimaOne variants)
  - `cms_esg_projects` — ESG project listings
  - `cms_our_story` — Our Story page content
  - `cms_brand_kit` — Brand kit downloadable assets
  - `cms_content_audit` — Last-edited timestamps per content section

  ## Security
  - RLS enabled on all tables
  - Admin users table protected — only super_admin can manage users
  - Content tables allow read by anon (public website) and write by authenticated admins
*/

-- ============================================================
-- ADMIN USERS
-- ============================================================
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'viewer' CHECK (role IN ('super_admin', 'editor', 'viewer')),
  is_active boolean DEFAULT true,
  last_login_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Admin users can only be read/managed by authenticated admins (checked via JWT custom claims)
-- We use a bypass approach via service role for admin operations
CREATE POLICY "Admin users visible to authenticated"
  ON admin_users FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Super admin can insert users"
  ON admin_users FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Super admin can update users"
  ON admin_users FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- CONTENT AUDIT LOG
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_content_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_type text NOT NULL,
  content_id text,
  action text NOT NULL CHECK (action IN ('created', 'updated', 'deleted', 'published')),
  performed_by uuid REFERENCES admin_users(id) ON DELETE SET NULL,
  performed_by_name text,
  performed_at timestamptz DEFAULT now()
);

ALTER TABLE cms_content_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Audit log readable by authenticated"
  ON cms_content_audit FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Audit log insertable by authenticated"
  ON cms_content_audit FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- ============================================================
-- HERO SLIDES
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_hero_slides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean DEFAULT true,
  tag text NOT NULL DEFAULT '',
  headline text NOT NULL DEFAULT '',
  subheading text NOT NULL DEFAULT '',
  cta_label text NOT NULL DEFAULT '',
  cta_href text NOT NULL DEFAULT '#',
  cta_secondary_label text NOT NULL DEFAULT '',
  cta_secondary_href text NOT NULL DEFAULT '#',
  image_url text NOT NULL DEFAULT '',
  image_alt text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_hero_slides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Hero slides readable by anyone"
  ON cms_hero_slides FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Hero slides writable by authenticated"
  ON cms_hero_slides FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Hero slides updatable by authenticated"
  ON cms_hero_slides FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Hero slides deletable by authenticated"
  ON cms_hero_slides FOR DELETE
  TO authenticated
  USING (true);

-- ============================================================
-- ABOUT SECTION
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_about (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section_label text NOT NULL DEFAULT 'About ReCircle',
  heading text NOT NULL DEFAULT '',
  body_paragraphs text[] NOT NULL DEFAULT '{}',
  closing_line text NOT NULL DEFAULT '',
  cta_buttons jsonb NOT NULL DEFAULT '[]',
  highlights jsonb NOT NULL DEFAULT '[]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_about ENABLE ROW LEVEL SECURITY;

CREATE POLICY "About readable by anyone"
  ON cms_about FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "About writable by authenticated"
  ON cms_about FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "About updatable by authenticated"
  ON cms_about FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- IMPACT STATS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_impact_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean DEFAULT true,
  number_value text NOT NULL DEFAULT '',
  suffix text NOT NULL DEFAULT '',
  unit text NOT NULL DEFAULT '',
  label text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_impact_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Impact stats readable by anyone"
  ON cms_impact_stats FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Impact stats writable by authenticated"
  ON cms_impact_stats FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Impact stats updatable by authenticated"
  ON cms_impact_stats FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Impact stats deletable by authenticated"
  ON cms_impact_stats FOR DELETE
  TO authenticated
  USING (true);

-- ============================================================
-- SOLUTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_solutions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean DEFAULT true,
  heading text NOT NULL DEFAULT '',
  expanded_description text NOT NULL DEFAULT '',
  tag text NOT NULL DEFAULT '',
  side text NOT NULL DEFAULT 'left' CHECK (side IN ('left', 'right')),
  href text NOT NULL DEFAULT '#',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_solutions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Solutions readable by anyone"
  ON cms_solutions FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Solutions writable by authenticated"
  ON cms_solutions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Solutions updatable by authenticated"
  ON cms_solutions FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Solutions deletable by authenticated"
  ON cms_solutions FOR DELETE
  TO authenticated
  USING (true);

CREATE TABLE IF NOT EXISTS cms_solutions_section (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  heading text NOT NULL DEFAULT '',
  body_copy text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_solutions_section ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Solutions section readable by anyone"
  ON cms_solutions_section FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Solutions section writable by authenticated"
  ON cms_solutions_section FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Solutions section updatable by authenticated"
  ON cms_solutions_section FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- INVESTORS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_investors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean DEFAULT true,
  name text NOT NULL DEFAULT '',
  logo_url text NOT NULL DEFAULT '',
  logo_alt text NOT NULL DEFAULT '',
  abbr text NOT NULL DEFAULT '',
  color text NOT NULL DEFAULT '#01298A',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_investors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Investors readable by anyone"
  ON cms_investors FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Investors writable by authenticated"
  ON cms_investors FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Investors updatable by authenticated"
  ON cms_investors FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Investors deletable by authenticated"
  ON cms_investors FOR DELETE
  TO authenticated
  USING (true);

CREATE TABLE IF NOT EXISTS cms_investors_section (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  heading text NOT NULL DEFAULT 'Our Investors',
  body_copy text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_investors_section ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Investors section readable by anyone"
  ON cms_investors_section FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Investors section writable by authenticated"
  ON cms_investors_section FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Investors section updatable by authenticated"
  ON cms_investors_section FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- CLIENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean DEFAULT true,
  name text NOT NULL DEFAULT '',
  logo_url text NOT NULL DEFAULT '',
  logo_alt text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clients readable by anyone"
  ON cms_clients FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Clients writable by authenticated"
  ON cms_clients FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Clients updatable by authenticated"
  ON cms_clients FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Clients deletable by authenticated"
  ON cms_clients FOR DELETE
  TO authenticated
  USING (true);

CREATE TABLE IF NOT EXISTS cms_clients_section (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  heading text NOT NULL DEFAULT 'Our Clients',
  body_copy text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_clients_section ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clients section readable by anyone"
  ON cms_clients_section FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Clients section writable by authenticated"
  ON cms_clients_section FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Clients section updatable by authenticated"
  ON cms_clients_section FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- ACCOLADES
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_accolades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean DEFAULT true,
  org text NOT NULL DEFAULT '',
  award text NOT NULL DEFAULT '',
  detail text NOT NULL DEFAULT '',
  year text NOT NULL DEFAULT '',
  color text NOT NULL DEFAULT '#01298A',
  image_url text NOT NULL DEFAULT '',
  image_alt text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_accolades ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Accolades readable by anyone"
  ON cms_accolades FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Accolades writable by authenticated"
  ON cms_accolades FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Accolades updatable by authenticated"
  ON cms_accolades FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Accolades deletable by authenticated"
  ON cms_accolades FOR DELETE
  TO authenticated
  USING (true);

CREATE TABLE IF NOT EXISTS cms_accolades_section (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  heading text NOT NULL DEFAULT 'Accolades & Mentions',
  body_copy text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_accolades_section ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Accolades section readable by anyone"
  ON cms_accolades_section FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Accolades section writable by authenticated"
  ON cms_accolades_section FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Accolades section updatable by authenticated"
  ON cms_accolades_section FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- FOOTER
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_footer (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tagline text NOT NULL DEFAULT '',
  grievance_officer_name text NOT NULL DEFAULT '',
  grievance_officer_phone text NOT NULL DEFAULT '',
  grievance_officer_email text NOT NULL DEFAULT '',
  newsletter_cta_text text NOT NULL DEFAULT '',
  social_links jsonb NOT NULL DEFAULT '[]',
  nav_columns jsonb NOT NULL DEFAULT '[]',
  legal_company_name text NOT NULL DEFAULT '',
  legal_cin text NOT NULL DEFAULT '',
  legal_copyright text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_footer ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Footer readable by anyone"
  ON cms_footer FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Footer writable by authenticated"
  ON cms_footer FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Footer updatable by authenticated"
  ON cms_footer FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- SITE SETTINGS (global singleton)
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_name text NOT NULL DEFAULT 'ReCircle',
  logo_url text NOT NULL DEFAULT '',
  favicon_url text NOT NULL DEFAULT '',
  default_seo_title text NOT NULL DEFAULT '',
  default_seo_description text NOT NULL DEFAULT '',
  default_og_image text NOT NULL DEFAULT '',
  primary_email text NOT NULL DEFAULT '',
  primary_phone text NOT NULL DEFAULT '',
  primary_address text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_site_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Site settings readable by anyone"
  ON cms_site_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Site settings writable by authenticated"
  ON cms_site_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Site settings updatable by authenticated"
  ON cms_site_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- SEO METADATA
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_seo_metadata (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_slug text UNIQUE NOT NULL,
  page_title text NOT NULL DEFAULT '',
  meta_description text NOT NULL DEFAULT '',
  og_image text NOT NULL DEFAULT '',
  canonical_url text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_seo_metadata ENABLE ROW LEVEL SECURITY;

CREATE POLICY "SEO metadata readable by anyone"
  ON cms_seo_metadata FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "SEO metadata writable by authenticated"
  ON cms_seo_metadata FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "SEO metadata updatable by authenticated"
  ON cms_seo_metadata FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- FUTURE: BLOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_blogs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  slug text UNIQUE NOT NULL,
  author text NOT NULL DEFAULT '',
  publish_date date,
  category text NOT NULL DEFAULT '',
  tags text[] NOT NULL DEFAULT '{}',
  featured_image_url text NOT NULL DEFAULT '',
  featured_image_alt text NOT NULL DEFAULT '',
  body_content text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'review', 'published')),
  seo_title text NOT NULL DEFAULT '',
  seo_description text NOT NULL DEFAULT '',
  seo_og_image text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_blogs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Published blogs readable by anyone"
  ON cms_blogs FOR SELECT
  TO anon
  USING (status = 'published');

CREATE POLICY "All blogs readable by authenticated"
  ON cms_blogs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Blogs writable by authenticated"
  ON cms_blogs FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Blogs updatable by authenticated"
  ON cms_blogs FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Blogs deletable by authenticated"
  ON cms_blogs FOR DELETE
  TO authenticated
  USING (true);

-- ============================================================
-- FUTURE: WEBINARS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_webinars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  event_date timestamptz,
  description text NOT NULL DEFAULT '',
  speaker_name text NOT NULL DEFAULT '',
  speaker_photo_url text NOT NULL DEFAULT '',
  speaker_photo_alt text NOT NULL DEFAULT '',
  registration_link text NOT NULL DEFAULT '',
  watch_link text NOT NULL DEFAULT '',
  thumbnail_url text NOT NULL DEFAULT '',
  thumbnail_alt text NOT NULL DEFAULT '',
  webinar_status text NOT NULL DEFAULT 'upcoming' CHECK (webinar_status IN ('upcoming', 'past')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_webinars ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Webinars readable by anyone"
  ON cms_webinars FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Webinars writable by authenticated"
  ON cms_webinars FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Webinars updatable by authenticated"
  ON cms_webinars FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Webinars deletable by authenticated"
  ON cms_webinars FOR DELETE
  TO authenticated
  USING (true);

-- ============================================================
-- FUTURE: ANNUAL REPORTS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_annual_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  report_year integer NOT NULL,
  description text NOT NULL DEFAULT '',
  cover_image_url text NOT NULL DEFAULT '',
  cover_image_alt text NOT NULL DEFAULT '',
  pdf_url text NOT NULL DEFAULT '',
  download_link text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_annual_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Annual reports readable by anyone"
  ON cms_annual_reports FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Annual reports writable by authenticated"
  ON cms_annual_reports FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Annual reports updatable by authenticated"
  ON cms_annual_reports FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Annual reports deletable by authenticated"
  ON cms_annual_reports FOR DELETE
  TO authenticated
  USING (true);

-- ============================================================
-- FUTURE: CAREERS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_careers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  department text NOT NULL DEFAULT '',
  location text NOT NULL DEFAULT '',
  job_type text NOT NULL DEFAULT '' CHECK (job_type IN ('full-time', 'part-time', 'contract', 'internship', '')),
  description text NOT NULL DEFAULT '',
  application_link text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_careers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Active careers readable by anyone"
  ON cms_careers FOR SELECT
  TO anon
  USING (status = 'active');

CREATE POLICY "All careers readable by authenticated"
  ON cms_careers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Careers writable by authenticated"
  ON cms_careers FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Careers updatable by authenticated"
  ON cms_careers FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Careers deletable by authenticated"
  ON cms_careers FOR DELETE
  TO authenticated
  USING (true);

-- ============================================================
-- FUTURE: INFRASTRUCTURE PAGES
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_infrastructure_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_type text UNIQUE NOT NULL CHECK (page_type IN ('mrf', 'trf', 'recycling_plant')),
  heading text NOT NULL DEFAULT '',
  subheading text NOT NULL DEFAULT '',
  body_content text NOT NULL DEFAULT '',
  stats jsonb NOT NULL DEFAULT '[]',
  process_blocks jsonb NOT NULL DEFAULT '[]',
  gallery_images jsonb NOT NULL DEFAULT '[]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_infrastructure_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Infrastructure pages readable by anyone"
  ON cms_infrastructure_pages FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Infrastructure pages writable by authenticated"
  ON cms_infrastructure_pages FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Infrastructure pages updatable by authenticated"
  ON cms_infrastructure_pages FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- FUTURE: SERVICES
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_type text UNIQUE NOT NULL,
  heading text NOT NULL DEFAULT '',
  value_proposition text NOT NULL DEFAULT '',
  process_steps jsonb NOT NULL DEFAULT '[]',
  impact_metrics jsonb NOT NULL DEFAULT '[]',
  cta_label text NOT NULL DEFAULT '',
  cta_href text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_services ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Services readable by anyone"
  ON cms_services FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Services writable by authenticated"
  ON cms_services FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Services updatable by authenticated"
  ON cms_services FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- FUTURE: PRODUCTS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_type text UNIQUE NOT NULL,
  heading text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  specs jsonb NOT NULL DEFAULT '[]',
  application_industries text[] NOT NULL DEFAULT '{}',
  cta_label text NOT NULL DEFAULT '',
  cta_href text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Products readable by anyone"
  ON cms_products FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Products writable by authenticated"
  ON cms_products FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Products updatable by authenticated"
  ON cms_products FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- FUTURE: ESG PROJECTS
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_esg_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 0,
  title text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  impact_metrics jsonb NOT NULL DEFAULT '[]',
  images jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_esg_projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ESG projects readable by anyone"
  ON cms_esg_projects FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "ESG projects writable by authenticated"
  ON cms_esg_projects FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "ESG projects updatable by authenticated"
  ON cms_esg_projects FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "ESG projects deletable by authenticated"
  ON cms_esg_projects FOR DELETE
  TO authenticated
  USING (true);

-- ============================================================
-- FUTURE: OUR STORY
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_our_story (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  heading text NOT NULL DEFAULT '',
  intro_text text NOT NULL DEFAULT '',
  content_blocks jsonb NOT NULL DEFAULT '[]',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_our_story ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Our story readable by anyone"
  ON cms_our_story FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Our story writable by authenticated"
  ON cms_our_story FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Our story updatable by authenticated"
  ON cms_our_story FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================================
-- FUTURE: BRAND KIT
-- ============================================================
CREATE TABLE IF NOT EXISTS cms_brand_kit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sort_order integer NOT NULL DEFAULT 0,
  label text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  file_url text NOT NULL DEFAULT '',
  file_type text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cms_brand_kit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Brand kit readable by anyone"
  ON cms_brand_kit FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Brand kit writable by authenticated"
  ON cms_brand_kit FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Brand kit updatable by authenticated"
  ON cms_brand_kit FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Brand kit deletable by authenticated"
  ON cms_brand_kit FOR DELETE
  TO authenticated
  USING (true);
